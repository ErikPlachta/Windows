# Plan-Driven Workflow Pack for GitHub Copilot

A `.github/` layout that turns Copilot Chat into a disciplined plan → task → commit → archive workflow. Uses every current (April 2026) customization surface — custom agents, prompt files, scoped instructions, docs templates — and tiers work across premium and free models to keep costs down.

## What This Gives You

- **Plans as source of truth.** `docs/plans/<slug>.md` holds the todo checklist. The plan file drives Copilot Chat's built-in todo UI, not the other way around.
- **Branch + commit discipline.** One plan = one branch. One task = one commit. Conventional Commits scoped to the plan slug. Checkbox updates ride with the task's code in the same commit.
- **Immutable archival.** Completed plans move to `docs/changelog/` via `git mv`. The changelog is write-protected by an auto-loading instruction file.
- **Session + task logging.** Every agent session produces a log file in `docs/logs/<agent>/` with a ULID session ID, decisions, files touched, and user checkpoints. Useful for audit, for debugging the agent's behavior, and for enterprise review.
- **Model tiering.** Planning and execution use a premium-model agent (Claude Opus/Sonnet → GPT-5). Mechanical work — logging, validation, syncing the todo UI — uses free-tier agents (GPT-4o → GPT-4). Reduces both cost and rate-limit pressure.
- **Model-specific agent variants.** Enterprise without Claude or GPT-5? Pick `Plan Workflow (GPT-4o)` or `Plan Workflow (GPT-4)` from the dropdown — same workflow, stricter scaffolding for weaker models.

## Layer Map

| Layer | Location | When it loads | Use |
| --- | --- | --- | --- |
| Always-on | `.github/copilot-instructions.md` | Every chat turn | Repo-wide context, pointer to agents/prompts |
| Custom agents | `.github/agents/*.agent.md` | On agent selection (dropdown) | Persona + model pin + tool scope |
| Path-scoped instructions | `.github/instructions/*.instructions.md` | When active file matches `applyTo` | Rules tied to file types/paths |
| Prompt files | `.github/prompts/*.prompt.md` | When user runs `/name` | Multi-step task macros |
| Docs | `.github/docs/` | N/A (data) | Plans, changelog, logs, templates |

## Quick Start

1. Copy `.github/` into your repo root.
2. Ensure these VS Code settings are set (defaults usually handle them):
   ```json
   {
     "github.copilot.chat.codeGeneration.useInstructionFiles": true,
     "chat.agentFilesLocations": { ".github/agents": true },
     "chat.instructionsFilesLocations": { ".github/instructions": true },
     "chat.promptFilesLocations": { ".github/prompts": true },
     "chat.includeApplyingInstructions": true,
     "chat.includeReferencedInstructions": true
   }
   ```
3. Restart VS Code so custom agents appear in the dropdown.
4. Open Copilot Chat, paste the setup prompt from `SETUP-PROMPT.md` — verifies every layer loaded.
5. Select the **Plan Workflow** agent from the dropdown, then run `/planner-setup` to verify your VS Code settings. Then `/planner-new` to scaffold your first plan.

## Key Design Decisions

- **Uses current VS Code canon** — `.agent.md` files in `.github/agents/` (the `.chatmode.md` name is legacy; VS Code v1.106 renamed chat modes → custom agents).
- **Logs everywhere are ULID-keyed** — sortable, unique, embed the timestamp, no collision risk between parallel sessions.
- **Templates are files, not embedded in prompts** — edit one place, referenced from every scaffolding prompt.
- **`copilot-instructions.md` is deliberately short** (under 50 lines) — GitHub's guidance caps at ~1,000 lines and warns that task-specific content belongs elsewhere.
- **No parallel todo trackers.** The plan's `## Tasks` list IS the todo system. `.vscode/tasks.json`, GitHub issues, and in-chat summaries are off-limits.

## Full Layout

```
.pre-commit-config.yaml                # enforcement: staged-file checks
package.json                           # tsx runner for hooks
tsconfig.json                          # TS config for hooks
.github/
├── copilot-instructions.md            # always loaded, ~40 lines
├── agents/
│   ├── planner-workflow.agent.md         # PREMIUM — Claude Opus/Sonnet → GPT-5
│   ├── planner-workflow-gpt4o.agent.md   # GPT-4o variant (tightened stop-gates)
│   ├── planner-workflow-gpt4.agent.md    # GPT-4 variant (strict output format)
│   ├── session-logger.agent.md        # FREE — GPT-4o → GPT-4, minimal tools
│   ├── planner-validator.agent.md        # FREE — GPT-4o → GPT-4, read-only
│   └── planner-reviewer.agent.md         # MID — grills plans for gaps
├── instructions/
│   ├── plan-authoring.instructions.md       # applyTo: plan files
│   ├── research-authoring.instructions.md   # applyTo: research notes
│   ├── log-authoring.instructions.md        # applyTo: log files
│   ├── changelog-protection.instructions.md # applyTo: archived plans
│   └── commit-messages.instructions.md      # applyTo: **
├── prompts/
│   ├── planner-setup.prompt.md      # verify install + VS Code settings
│   ├── planner-new.prompt.md          # scaffold plan + branch
│   ├── planner-work.prompt.md         # execute one task, stop
│   ├── planner-archive.prompt.md      # move to changelog
│   ├── planner-sync-todos.prompt.md   # re-mirror Chat todo UI
│   ├── planner-validate.prompt.md     # validate frontmatter + structure
│   ├── planner-review.prompt.md       # grill a plan for gaps
│   ├── log-session-open.prompt.md     # start a session log
│   ├── log-session-close.prompt.md    # finalize a session log
│   ├── log-task.prompt.md             # write a task execution log
│   ├── logs-cleanup.prompt.md         # archive/compact old logs
│   ├── branch-new.prompt.md           # create branch for a plan
│   └── branch-status.prompt.md        # report current branch/plan state
├── hooks/                             # TypeScript enforcement scripts (run via tsx)
│   ├── _lib.ts                        # shared helpers: frontmatter parser, git, logging
│   ├── bump-modified.ts               # auto-bump plan `modified:`
│   ├── validate-plan-frontmatter.ts   # schema validation
│   ├── check-changelog-immutable.ts   # reject changelog edits
│   ├── check-log-append-only.ts       # reject non-append edits to logs
│   ├── validate-commit-msg.ts         # commit-msg hook
│   └── ci-archival-gate.ts            # PR-level lifecycle checks
├── workflows/
│   └── plan-checks.yml                # CI: runs hooks + lifecycle gates
└── docs/
    ├── README.md                      # explains docs layout
    ├── plans/                         # active plans
    │   └── research/                  # one subfolder per plan
    ├── changelog/                     # completed plans (immutable)
    │   └── research/
    ├── logs/                          # one subfolder per agent
    └── templates/
        ├── plan.template.md
        ├── research.template.md
        ├── session-log.template.md
        └── task-log.template.md
```

## Model Tiering & Availability

All agents live in `.github/agents/` as peer files. Users pick from the Chat panel dropdown based on which models their Copilot plan includes.

**Plan execution — pick one based on model access:**

| Agent file | Dropdown label | Model pin | When to use |
| --- | --- | --- | --- |
| `planner-workflow.agent.md` | Plan Workflow | Claude Opus 4.5 → Sonnet 4.5 → GPT-5 | Default. If you have Claude or GPT-5 access. |
| `planner-workflow-gpt4o.agent.md` | Plan Workflow (GPT-4o) | GPT-4o | Enterprise with GPT-4o only. Tightened stop-gates. |
| `planner-workflow-gpt4.agent.md` | Plan Workflow (GPT-4) | GPT-4 | Enterprise with GPT-4 only. UPPERCASE rules + required output format. |

**Utility agents — model-agnostic, free tier preferred:**

| Agent file | Dropdown label | Tier |
| --- | --- | --- |
| `session-logger.agent.md` | Session Logger | Free (GPT-4o → GPT-4 → Haiku) |
| `planner-validator.agent.md` | Plan Validator | Free (GPT-4o → GPT-4 → Haiku) |
| `planner-reviewer.agent.md` | Plan Reviewer | Mid (Sonnet → GPT-5 → GPT-4o) |

All three `planner-workflow-*` agents accept the same `/planner-*` slash commands. The only differences are the pinned model and tuning in the body. To add a model, copy an existing agent and change `model:`.

## Inline Invocation (`@agent-name`)

Every agent in this pack sets `user-invocable: true` in its frontmatter. That means you can invoke them inline from any chat context with `@<filename-stem>`:

```
@planner-validator check this
@planner-reviewer grill this plan
@session-logger append to the current session
```

Inline invocation is useful when you're mid-task and don't want to switch agents via dropdown or handoff button. The invoked agent runs once with your inline prompt, then control returns to the active agent.

Without `user-invocable: true`, agents only appear in the Chat dropdown and can only be reached via handoff buttons. With it, they're addressable from anywhere.

## Handoffs — One-Click Agent Switching

Every agent in this pack declares `handoffs:` in its frontmatter. After a response completes, VS Code renders buttons that switch to the target agent with a pre-filled (or auto-submitted) prompt. No manual dropdown fiddling.

**Wiring:**

```
planner-workflow ──► Review this plan       → planner-reviewer
              ──► Validate structure     → planner-validator    (auto-submits)
              ──► Log this session       → session-logger
              ──► Switch to GPT-4o       → planner-workflow-gpt4o

planner-workflow-gpt4o ──► Review / Validate / Log (same as above)
                    ──► Downgrade to GPT-4 → planner-workflow-gpt4

planner-workflow-gpt4   ──► Review / Validate / Log

planner-reviewer    ──► Back to Plan Workflow → planner-workflow
                 ──► Validate structure    → planner-validator  (auto-submits)

planner-validator   ──► Back to Plan Workflow → planner-workflow
                 ──► Grill this plan       → planner-reviewer

session-logger   ──► Back to Plan Workflow → planner-workflow (or -gpt4o)
```

**`send: true` vs `send: false`:**
- `send: true` (auto-submit) is used for validator calls — no typing needed, the check runs immediately.
- `send: false` (pre-fill input) is used when you might want to edit the prompt before hitting Enter.

**Typical workflow using buttons only:**
1. Start in `Plan Workflow`. Run `/planner-new`.
2. Click **Review this plan** → switches to `planner-reviewer`, which grills you.
3. Answer questions. Click **Back to Plan Workflow** when satisfied.
4. Run `/planner-work <slug>` to execute a task.
5. After the task, click **Log this session** → handoff to `Session Logger`.
6. After logging, click **Back to Plan Workflow** to continue.

**Customizing handoffs:** add, remove, or reword them in any agent's frontmatter. The `agent:` value is the target agent's filename stem (without `.agent.md`). Per VS Code docs, handoff buttons are the recommended way to orchestrate multi-agent workflows.

## Cost-Conscious Multi-Agent Usage

The agents are tiered so you can push mechanical work to free models:

| Task | Agent | Model tier | Why |
| --- | --- | --- | --- |
| Scaffold a plan | `planner-workflow` | Premium | Needs judgment on structure |
| Execute a task | `planner-workflow` | Premium | Real code changes, decisions |
| Write a session log | `session-logger` | Free | Mechanical summarization |
| Validate plan structure | `planner-validator` | Free | Rule-based checks |
| Archive old logs | `session-logger` | Free | File moves |
| Grill a plan for gaps | `planner-reviewer` | Mid | Depends on stakes |
| Sync Chat UI todos | any | Free | Deterministic mirror |

Switch agents from the Chat panel dropdown. The prompt files work across agents — running `/log-task` from the premium agent handoffs to the logger is fine, but it's cheaper to switch agents first.

## Enforcement

Copilot customizations are guidance the model *tries* to follow. Hard enforcement comes from the `.pre-commit-config.yaml` at repo root plus the CI workflow at `.github/workflows/plan-checks.yml`.

**Pre-commit hooks** (run locally, block bad commits before they happen):

| Hook | What it does |
| --- | --- |
| `bump-plan-modified` | Auto-sets `modified:` to today on staged plan files; re-stages silently. |
| `validate-plan-frontmatter` | Rejects plans missing required fields, with bad status values, inconsistent dates, bad branch format, H1 ≠ title, or `status: done` with unchecked tasks. |
| `changelog-immutable` | Rejects modifications to files under `.github/docs/changelog/` (additions via `git mv` are allowed). |
| `logs-append-only` | Rejects edits to closed/aborted session logs. Allows pure appends to open logs. |
| `validate-commit-msg` | Enforces `<type>(<slug>): <summary>` format, 72-char subject limit. |

Plus standard hygiene: trailing-whitespace, end-of-file-fixer, check-yaml, check-merge-conflict, detect-private-key.

**Install:**
```bash
# Node deps (provides tsx, the TypeScript runner)
npm install

# pre-commit framework
pip install pre-commit          # or: brew install pre-commit
pre-commit install
pre-commit install --hook-type commit-msg
```

Hooks are written in TypeScript (`.github/hooks/*.ts`) and run directly via `tsx` — no compile step. Requires Node ≥ 20.

**CI workflow** (`.github/workflows/plan-checks.yml`) runs the same pre-commit hooks in a `pre-commit` job plus a `plan-gates` job that checks lifecycle rules you can't validate locally:

- PR title matches `<type>(<slug>): <summary>`.
- If any plan was set to `status: done`, an archival commit (`chore(<slug>): archive plan to changelog`) exists in the PR range.
- PR body references the archived plan path (`.github/docs/changelog/<slug>.md`).
- No modifications (only additions/renames-in) to `.github/docs/changelog/`.

**What this pack does NOT enforce** — add if needed:
- **GitHub branch protection rulesets** — restrict direct commits to `main` to plan-merge PRs only. (Configured in the GitHub UI or via `gh` CLI, not in-repo.)
- **Required PR reviews** — same, repo settings.
- **Semantic plan-goal validation** — no automated check that a plan's tasks actually achieve its Goal. That's what `/planner-review` (the agent) is for.

## Compatibility Notes

- **VS Code 1.106+** required for the `.agent.md` format. Older versions: rename `.agent.md` → `.chatmode.md` and move `agents/` → `chatmodes/`. (Feature is identical; only naming changed.)
- **GitHub Mobile / Chat on github.com** only honors `copilot-instructions.md`, not path-specific `.instructions.md`. Rules in instruction files won't apply there.
- **JetBrains, Xcode** only honor `copilot-instructions.md`. No agents, prompts, or instruction files.
- **`excludeAgent`** is a GitHub-side frontmatter field for hiding instructions from Copilot Code Review (`"code-review"`) or Copilot Cloud Agent (`"cloud-agent"`). Not used in this pack; add it if your org uses those surfaces.

## Adapting

- Branch naming, merge strategy → `instructions/commit-messages.instructions.md`.
- Frontmatter schema, status values → `instructions/plan-authoring.instructions.md` and `docs/templates/plan.template.md`.
- Log structure → `docs/templates/session-log.template.md` + `instructions/log-authoring.instructions.md`.
- Add models → create a new `agents/*.agent.md` with the desired `model:` fallback list.
