# Copilot Chat Setup Prompt

Paste the following into Copilot Chat on first use. It primes Copilot to acknowledge the workflow and confirms every layer loaded correctly.

---

```
I've installed a plan-driven workflow pack in .github/. Before we do any
work, confirm you've loaded it correctly by answering these, concisely:

1. What is the single source of truth for workflow todos in this repo?
2. Where do active plans live, and where do completed plans go?
3. Name every slash command available for plan, log, and branch management.
4. Name every custom agent defined in this pack, and for each: what model
   it pins (first in the fallback list) and what tier (premium/mid/free)
   it's intended for.
5. What file name pattern triggers scoped instructions under
   .github/instructions/, and what controls when they apply?
6. Under what conditions are you allowed to edit a file in
   .github/docs/changelog/?
7. What frontmatter field must update every time a plan file is modified,
   and what format must it use?
8. Where do session logs live, what's their filename format, and what
   agent is responsible for managing them?
9. Which model is currently backing this chat, and is it the model the
   currently-selected agent would pin?

After answering, list every file in .github/copilot-instructions.md,
.github/agents/, .github/instructions/, .github/prompts/, and
.github/docs/templates/ that you can see, grouped by directory. If any
are missing, tell me which.

Do not start any work or scaffold anything yet. Just confirm the setup.
```

---

## Expected Answers

1. The `## Tasks` checklist in the active plan file at `.github/docs/plans/<slug>.md`.
2. Active: `.github/docs/plans/<slug>.md`. Completed: `.github/docs/changelog/<slug>.md`.
3. `/plan-new`, `/plan-work <slug>`, `/plan-archive <slug>`, `/plan-sync-todos <slug>`, `/plan-validate <slug>`, `/plan-review <slug>`, `/log-session-open`, `/log-session-close`, `/log-task <slug> <N>`, `/logs-cleanup`, `/branch-new <slug>`, `/branch-status`.
4. `Plan Workflow` (Claude Opus 4.5, premium), `Session Logger` (GPT-4o, free), `Plan Validator` (GPT-4o, free), `Plan Reviewer` (Claude Sonnet 4.5, mid).
5. Files named `*.instructions.md` with an `applyTo` glob in YAML frontmatter. Auto-load when the active file matches the glob.
6. Never — files in `.github/docs/changelog/` are immutable. Amendments require a new plan referencing the archived one.
7. `modified:` — bumped to today's ISO date (`YYYY-MM-DD`) on every commit that touches the plan file.
8. `.github/docs/logs/<agent-name>/<YYYY-MM-DD>-<ulid>.session.md` for sessions and `<YYYY-MM-DD>-<ulid>-t<N>.task.md` for task logs. Managed by the `Session Logger` agent.
9. Copilot should name its current model and compare against the selected agent's `model:` frontmatter list.

## If Copilot Gets Any Answer Wrong

- **Wrong source of truth (1):** `copilot-instructions.md` isn't loading. Check `github.copilot.chat.codeGeneration.useInstructionFiles`.
- **Can't list agents (4) or agents missing from dropdown:** agents not discovered. Restart VS Code. Check `chat.agentFilesLocations` includes `.github/agents`. VS Code < 1.106: rename `.agent.md` → `.chatmode.md`, move `agents/` → `chatmodes/`.
- **Can't list files in `instructions/` or `prompts/`:** scoped files not discovered. Check `chat.instructionsFilesLocations` and `chat.promptFilesLocations`.
- **Claims it can edit changelog files (6):** `changelog-protection.instructions.md` isn't auto-loading on the glob. Open a file under `.github/docs/changelog/` first, then re-ask.
- **Wrong model (9):** the agent's `model:` fallback couldn't find its preferred option in your Copilot plan. Either adjust the agent's model list or use a variant from `variants/`.

## Followup Prompts

After setup passes:

```
Scaffold our first plan with /plan-new.
```

```
Switch to Session Logger and run /log-session-open to start tracking this session.
```

```
Run /branch-status to show me where we are.
```
