---
applyTo: ".github/docs/plans/*/\_RESEARCH/**/*.md,.github/docs/changelog/*/\_RESEARCH/**/*.md"
description: "Conventions for phase-scoped research notes within a plan group."
---

# Research Authoring

Applies to files under `.github/docs/plans/pNNNNNN-slug/_RESEARCH/NN/` and the changelog mirror.

## Layout

```
plans/pNNNNNN-slug/_RESEARCH/
└── NN/                        # phase number
    ├── N.M_description.md     # research file
    └── N.M_description/       # asset folder, same prefix
        └── *.png / *.svg / *.pdf
```

One file per distinct topic. The `N.M` prefix indicates phase (`N`) and sub-topic ordinal (`M`), e.g., `1.1`, `1.2`, `2.1`. The prefix is independent of sub-phase plans — use `N.M` to order research within a phase.

## Naming

- File: `N.M_description.md`. Description is kebab-case (`jwt-vs-sessions`, `postgres-replica-latency`), no date suffix.
- Asset folder: `N.M_description/` — **exactly matches** the owning file's prefix and description, minus the `.md`.

## Frontmatter

Required:

```yaml
---
title: "Research: <DESCRIPTION>"
phase: "NN"
sub-phase: "N.M"
status: draft        # draft | finalized | superseded
created: YYYY-MM-DD
---
```

`status: superseded` when a later research file replaces this one. The Summary section MUST link the replacement:

```markdown
## Summary

Superseded by [3.2_new-approach.md](3.2_new-approach.md). Original findings preserved below for history.
```

The validator will warn if `status: superseded` but Summary has no Markdown link.

## Content

- Write for future-you. Capture the *why*.
- Link external sources in `## Source`.
- Code, diagrams, tables welcome.
- Reference the parent phase plan by relative path in `## Relevance to Plan`.

## Lifecycle

- Created during `/planner-work` when a task needs deeper exploration.
- Committed as: `docs(<group>): research on <phase>/<topic>` (bumps `_INDEX.md` `Updated:`).
- Moves with the group on archival via `git mv`.
- Immutable once in `changelog/`.
