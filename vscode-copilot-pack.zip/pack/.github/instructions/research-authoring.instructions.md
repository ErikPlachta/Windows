---
applyTo: ".github/docs/plans/research/**/*.md,.github/docs/changelog/research/**/*.md"
description: "Conventions for research notes supporting a plan."
---

# Research Authoring

Applies to files under `.github/docs/plans/research/<slug>/` and `.github/docs/changelog/research/<slug>/`.

## Purpose
Research notes hold the detail that does not belong in the plan file: design exploration, API spikes, tradeoff analysis, benchmark results, reference material. Keeps plans under ~100 lines.

## Layout
```
.github/docs/plans/research/<plan-slug>/
  <topic>.md
  <another-topic>.md
```

One file per distinct topic. Name descriptively (`jwt-vs-sessions.md`, `postgres-replica-latency.md`), not `notes.md` or `research.md`.

## Format

Follow `.github/docs/templates/research.template.md`:

```markdown
# <Topic Title>

> Plan: [../../plans/<slug>.md](../../plans/<slug>.md)
> Created: YYYY-MM-DD

<!-- body: free-form markdown, whatever helps the plan author -->
```

Include the plan link so the file is traceable when opened standalone.

## Content Guidance
- Write for future-you. Capture the *why*, not just the *what*.
- Include links to external sources, tickets, specs.
- Code snippets, diagrams, and tables welcome.
- No YAML frontmatter required — research files are not tracked the way plan files are.

## Lifecycle
- Created during `/plan-work` when a task needs deeper exploration.
- Committed in its own commit: `docs(<slug>): research on <topic>` (also bumps the plan's `modified:`).
- Moves with the plan on archival via `git mv`.
- Files under `.github/docs/changelog/research/` are immutable — do not edit.
