---
applyTo: "**"
description: "Commit message format, branch naming, and PR rules for plan-scoped work."
---

# Commit Messages & Branches

Applies to all commits authored for plan work.

## Branches
- One plan = one branch.
- Naming: `<type>/<plan-slug>` where type ∈ {`feat`, `fix`, `chore`, `refactor`, `docs`, `spike`}.
- Example: plan `auth-refactor` → branch `refactor/auth-refactor`.
- Branch recorded in the plan's `branch:` frontmatter field.
- Base off `main` unless the plan's `## Context` declares a dependency.
- Never commit plan work to `main` directly. Never mix plans in one branch.

## Commit Format

Conventional Commits, scoped to the plan slug:

```
<type>(<plan-slug>): <summary, ≤72 chars>

Task: <plan task number> — <short task text>
Refs: .github/docs/plans/<slug>.md
```

Filled example:

```
feat(auth-refactor): extract token validator to separate module

Task: 2 — Extract token validator into auth/validator.ts
Refs: .github/docs/plans/auth-refactor.md
```

## Rules
- **One task = one commit minimum.** Split further only if logically separable.
- Stage only files relevant to that task.
- Plan checkbox update AND `modified:` frontmatter bump ride in the SAME commit as the task's work.
- Research notes → separate commit: `docs(<slug>): research on <topic>` (also bumps `modified:`).
- Archival → its own commit: `chore(<slug>): archive plan to changelog`.
- Never mix commits across plans.
- Never amend pushed commits.
- Never force-push shared branches.

## Branch Lifecycle

1. `/planner-new` creates branch + plan file + scaffold commit.
2. Commits accumulate as tasks complete.
3. `/planner-archive` runs the final commit (archival move).
4. Open PR.
5. Delete branch post-merge. Plan stays in `.github/docs/changelog/`.

## PRs
- Title: `<type>(<slug>): <plan goal>`.
- Description links the archived plan path (`.github/docs/changelog/<slug>.md`) and lists completed tasks.
- Cannot merge unless plan `status: done` AND archival commit is on the branch.
- Squash-merge if < 5 commits; merge commit otherwise.
