---
applyTo: ".github/docs/changelog/**"
description: "Immutability guardrails for archived plans and research."
---

# Changelog Protection

Applies to any file under `.github/docs/changelog/`.

## Immutable

The changelog is the historical record of completed plans. Once archived here, files must not be edited.

**Do not:**
- Change the body of an archived plan.
- Update frontmatter fields (including `modified:`).
- Append new tasks, decisions, or outcomes.
- Rename or move archived files.
- Edit archived research notes.

## Amendments

If an archived plan's conclusions are wrong or need follow-up:

1. Open a **new plan** in `.github/docs/plans/` via `/planner-new`.
2. Reference the archived plan in the new plan's `## Context`:
   ```markdown
   ## Context
   Amends: [../changelog/<original-slug>.md](../changelog/<original-slug>.md)
   ```
3. The new plan goes through its own draft → active → done → archival lifecycle.

## When Asked to "Fix" an Archived Plan

Refuse and propose a new plan. Example:

> Files under `.github/docs/changelog/` are immutable. I'd suggest opening a new plan that amends `<original-slug>`. Want me to scaffold it with `/planner-new`?

## Reading Is Fine

Reading archived plans for context, grepping for prior decisions, or linking to them from new plans is all fine. Just no edits.
