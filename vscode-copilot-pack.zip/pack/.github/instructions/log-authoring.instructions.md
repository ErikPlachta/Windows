---
applyTo: ".github/docs/logs/**/*.md"
description: "Schema and conventions for agent session and task execution logs."
---

# Log Authoring

Applies to every file under `.github/docs/logs/`. Templates live at `.github/docs/templates/session-log.template.md` and `task-log.template.md`.

## Layout

```
.github/docs/logs/
├── <agent-name>/
│   ├── <YYYY-MM-DD>-<ulid>.session.md      # one per session
│   └── <YYYY-MM-DD>-<ulid>-t<N>.task.md    # one per task execution (optional)
```

- `<agent-name>` matches the agent's `name:` frontmatter from its `.agent.md` (kebab-case).
- `<ulid>` — a ULID for chronological sort + uniqueness. Generate once at session start.
- `<YYYY-MM-DD>` prefix keeps per-day browsing simple even though the ULID already encodes time.
- Task logs are optional; use when a task has enough decisions/outputs to warrant its own file.

## Session Log Frontmatter

```yaml
---
agent: <agent-name>
session_id: <ulid>
model: <actual model used, as reported by agent>
started: <ISO 8601 with timezone>
ended:                 # set on close
plan_slug:             # optional — if the session was scoped to a plan
branch:                # optional — current branch at session start
status: open           # open | closed | aborted
---
```

## Session Log Body

```markdown
# Session <ulid>

## Intent
<what the user asked for at session start>

## Timeline
- <HH:MM> <event>
- <HH:MM> <event>

## Files Touched
- path/to/file — <summary of change>

## Commands Run
- `<command>` → <outcome summary>

## Decisions
- <rationale>

## User Checkpoints
- <HH:MM> Q: <question to user>
  A: <their response>

## Outcome
<set on close: what shipped, what's pending, follow-up>
```

## Task Log Frontmatter

```yaml
---
agent: <agent-name>
session_id: <ulid>
plan_slug: <slug>
task_number: <N>
task_text: <verbatim from plan>
started: <ISO 8601>
ended:                 # set on close
commit:                # SHA of the task's commit, if any
status: open           # open | closed | aborted
---
```

Task log body mirrors the session log structure, scoped to one task.

## Hard Rules
- **Append-only.** Never edit or delete prior log entries once written. Corrections append a new note, not a rewrite.
- **One ULID per session.** Do not reuse. Generate at session open; all task logs within the session carry the same `session_id`.
- **Timezone-aware timestamps.** Use ISO 8601 with `+HH:MM` or `Z` suffix. Not bare local time.
- **`status: aborted`** when a session ends unexpectedly (user interrupt, error). Do not leave `open` past session end.
- **No secrets, no tokens, no API keys.** Redact with `<redacted>`.
- **Reference plans by path, not content.** Link to `../../plans/<slug>.md`, don't copy the plan body in.
- **Logs are not the todo system.** The plan file's `## Tasks` stays the source of truth.

## Generating a ULID

If an agent can't produce a ULID directly, fall back to `<YYYY-MM-DDTHH:MM:SS>-<6-random-alnum>`. The sort property and uniqueness are what matter; the exact format is flexible.
