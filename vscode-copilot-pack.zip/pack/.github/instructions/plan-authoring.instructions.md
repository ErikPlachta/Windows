---
applyTo: ".github/docs/plans/**/*.md,.github/docs/changelog/**/*.md"
description: "Schema and authoring rules for plan groups, phase plans, _INDEX, and research files."
---

# Plan Group Authoring

Applies to every file under `.github/docs/plans/` and `.github/docs/changelog/`.

## File Roles

| File | Location | Role |
|---|---|---|
| `_INDEX.md` | `plans/pNNNNNN-slug/_INDEX.md` | Group overview, phase table, branch map, group-level status |
| Phase plan | `plans/pNNNNNN-slug/NN/NN_desc_YYYYMMDD.md` | Single phase's plan |
| Sub-phase plan | `plans/pNNNNNN-slug/NN/NN.M_desc_YYYYMMDD.md` | Sub-phase within a phase folder |
| Research | `plans/pNNNNNN-slug/_RESEARCH/NN/N.M_desc.md` | Phase-scoped research |
| Research assets | `plans/pNNNNNN-slug/_RESEARCH/NN/N.M_desc/*` | Asset folder (same prefix) |
| `CURRENT.md` | `plans/CURRENT.md` | Thin pointer — NOT a plan file; validator skips it |

## Status Vocabulary (Text — No Emoji)

```
not_started | in_progress | completed | deferred | pending_review | canceled
```

Applies to group `status:` in `_INDEX.md`, phase plan `status:`, and all progress-tracker tables.

## Group Frontmatter (`_INDEX.md`)

Required: `title`, `status`, `integration_branch`, `base_branch`, `Created`, `Updated`, `Author`, `version`.
Optional: `description`, `semantic_title`, `tags`, `assignees`, `reviewers`, `approvers`, `pull_request`, `issues`, `milestone`, `release`, `effort`, `priority`, `risk`, `impact`, `Co-Authors`, `changelog`.

Rules:
- `status` is auto-derived from phase statuses; keep it consistent with the Phases table.
- `Updated:` bumps to current datetime on every edit.
- `integration_branch` is blank if branching pattern is `single_branch` — in that case the group uses one branch end-to-end.

## Phase Plan Frontmatter

Required: `title`, `status`, `Branch`, `Base Branch`, `group`, `phase`, `Created`, `Updated`, `Author`, `version`.
Optional: all other fields from the template.

Rules:
- `group:` matches the parent directory name (`pNNNNNN-slug`).
- `phase:` matches the containing folder (`NN`) or includes sub-phase (`NN.M`).
- `Base Branch` is the integration branch for `branch_per_phase` pattern, or `main`/`develop` for `single_branch`.
- `Updated:` bumps on every commit touching the file.
- H1 of the body must be `# Phase <NN>: <title>` (or `# Sub-phase <NN.M>: <title>` for sub-phase plans).

## Phase Plan Body Structure

Required sections in order (enforced by `/planner-validate`):

1. `## Table of Contents`
2. `## Session State` — table with Last Action / Next Action / Current Phase / Current Sub-phase / Blockers
3. `## Problem Statement(s)` — with at least one `### Problem_N` and `### Out of Scope`
4. `## Decisions Made` — table
5. `## Risk & Mitigation` — with `### Risk & Mitigation Strategy` and `### Rollback Plan`
6. `## Tasks` — with the three-part structure:
   - `### Progress Tracking` — with `#### Phased Implementation Steps - Progress Tracker` and `#### End of Plan Strategies - Progress Tracker` tables
   - `## Phased Implementation Steps` — with `### Sub-phase N: <name>` headings
   - `## End of Plan Strategies` — with `### Testing`, `### Code Coverage`, `### Documentation`
7. `## References`

## Filename Rules

- Plan groups: `pNNNNNN-slug/` — `NN` is zero-padded two digits, `slug` is kebab-case.
- Phase plans: `NN_description_YYYYMMDD.md`. `YYYYMMDD` is the creation date.
- Sub-phase plans: `NN.M_description_YYYYMMDD.md`, sit in the **same phase folder** as their parent.
- Research files: `N.M_description.md` (no date, no extension prefix on the folder).
- All `description` portions use `snake-case` or `kebab-case` — pick one and stay consistent within a group.

## Branch Map Rules (`_INDEX.md`)

The Branch Map table must stay in sync with phase plan `Branch:` / `Base Branch:` fields. Validator checks for drift. Patterns:

- `single_branch` — all phases list the same `Branch:`; Branch Map has one row.
- `branch_per_phase` — each phase has unique `Branch:`; all phases share `Base Branch: integration/pNNNNNN-slug`.
- `branch_per_subphase` — sub-phase plans base off their parent phase's branch.

## Hard Rules

- Status values are text. Never use emoji (🔲 🔨 ✅ etc.) in `status:` fields or in any progress-tracker `Status` column.
- No research content inline in phase plans. >20 lines → `_RESEARCH/NN/N.M_desc.md`.
- Phase plans stay under ~200 lines. Longer → split into sub-phases.
- `Updated:` MUST bump on every commit touching a plan or `_INDEX.md`.
- `completed:` equivalent — when all phases `completed`, group `status: completed`; archival is the final commit before PR.
- Never edit files under `.github/docs/changelog/` (see `changelog-protection.instructions.md`).
- Use `git mv` for phase folder / research folder moves, never delete + recreate.
- Sub-phase plan files must share the `NN.` prefix with their containing folder `NN/`.
