---
applyTo: ".github/docs/plans/**/*.md,.github/docs/changelog/**/*.md"
description: "Schema and authoring rules for plan files."
---

# Plan Authoring

Applies to every plan file under `.github/docs/plans/` and `.github/docs/changelog/` (excluding `research/` subfolders — see `research-authoring.instructions.md`).

## Frontmatter Schema

Every plan starts with a YAML frontmatter block. Dates are ISO (`YYYY-MM-DD`).

```yaml
---
title: <Plan Title>
status: draft          # draft | active | blocked | done
author: <user>
branch: <type>/<plan-slug>
ticket_number:         # optional: PROJ-1234, #567, etc.
created: YYYY-MM-DD
modified: YYYY-MM-DD
completed:             # set on archival only
---
```

**Field rules:**
- `title` — mirrors the H1 in the body.
- `status` — transitions: `draft` → `active` → (`blocked` ↔ `active`) → `done`.
- `author` — plan owner.
- `branch` — set before first commit, never changes after.
- `ticket_number` — optional; blank if no external tracker item.
- `created` — set once, never changes.
- `modified` — MUST bump to today's date on every commit that touches the plan file. No exceptions.
- `completed` — blank until archival; set by `/plan-archive`.

The canonical template is at `.github/docs/templates/plan.template.md`.

## Body Structure

```markdown
# <Plan Title>

## Goal
One sentence. What "done" looks like.

## Context
Research: research/<slug>/
<!-- Optional: Amends: ../changelog/<slug>.md -->

## Tasks
- [ ] 1. <atomic todo>
- [ ] 2. <atomic todo>
- [ ] 3. <atomic todo>

## Decisions
- <date>: <decision + rationale>

## Open Questions
- <question>

## Outcome
<!-- Filled on archival: what shipped, PR links, follow-up plans. -->
```

## Task Granularity

Each task is an atomic unit of work: a research/decision step, a code change, a test run, a review. **Rule of thumb: one task = one commit.** If a task would produce three unrelated commits, split it.

## Hard Rules
- No research content inline. Anything over ~20 lines goes to `research/<slug>/<topic>.md` and is linked from `## Context`.
- Plans stay under ~100 lines. Longer plans decompose into sub-plans with a parent index plan.
- `modified:` updates on every plan-file commit. No exceptions.
- `completed:` is only touched by `/plan-archive`.
- Do not reorder or renumber completed tasks retroactively — append new ones.
- Do not edit files in `.github/docs/changelog/` (see `changelog-protection.instructions.md`).
