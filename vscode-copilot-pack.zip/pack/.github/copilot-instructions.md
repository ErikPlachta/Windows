# Copilot Instructions

This repo uses a plan-group workflow. All work is organized as **plan groups** under `.github/docs/plans/pNNNNNN-slug/`. Each group has an `_INDEX.md`, one or more **phases** (`NN/`), optional **sub-phases** (`NN.M`), and phase-scoped research under `_RESEARCH/NN/`.

The active phase plan's `## Phased Implementation Steps` drives Copilot Chat's built-in todo UI. Never the reverse.

## Always-true Rules
- No commits to `main` for plan work.
- One phase = one branch (for `branch_per_phase` pattern) OR one group = one branch (for `single_branch`).
- Never mix phases across groups in a branch or commit.
- Never edit files under `.github/docs/changelog/` — immutable archive.
- Never use emoji in `status:` fields. Use text: `not_started | in_progress | completed | deferred | pending_review | canceled`.
- Every commit touching a plan/index file MUST bump `Updated:` in its frontmatter.
- No parallel trackers. `.vscode/tasks.json`, GitHub issues, in-chat summaries are NOT todo systems.
- No force-push. No amending pushed commits. No committing secrets.

## Agents
Select from the Chat panel dropdown, or invoke inline with `@agent-name`:
- `@planner-workflow` — disciplined phase execution (premium model)
- `@planner-reviewer` — grill a plan for gaps (mid-tier)
- `@planner-validator` — check structure (free model)
- `@session-logger` — append to session log (free model)
- `@planner-workflow-gpt4o` / `@planner-workflow-gpt4` — when premium unavailable

## Slash Commands

Setup:
- `/planner-setup` — verify install + VS Code settings (run once)

Classification:
- `/planner-classify` — decide: new group, new phase, new sub-phase

Scaffolding:
- `/planner-group-new` — new plan group (`pNNNNNN-slug/`)
- `/planner-phase-new <group>` — new phase in existing group
- `/planner-subphase-new <group>/<phase>` — new sub-phase (`NN.M`)

Execution:
- `/planner-work <group>/<phase>` — execute one task, stop
- `/planner-sync-todos <group>/<phase>` — re-mirror Chat UI from phase plan
- `/planner-validate <group> | all` — structural checks
- `/planner-review <group> | <group>/<phase>` — stress-test
- `/planner-group-status [group]` — overview + drift check
- `/planner-archive <group>` — move completed group to changelog

Logs:
- `/log-session-open` / `/log-session-close`
- `/log-task <group> <phase> <N>`
- `/logs-cleanup`

Branch helpers:
- `/branch-new <group>/<phase>` / `/branch-status`

## Layout
```
.github/docs/
├── plans/
│   ├── CURRENT.md                 # thin pointer
│   └── pNNNNNN-slug/
│       ├── _INDEX.md
│       ├── _RESEARCH/NN/N.M_*.md
│       └── NN/NN_*_YYYYMMDD.md    (and NN.M_*_YYYYMMDD.md for sub-phases)
├── changelog/pNNNNNN-slug/            # archived groups (immutable)
├── logs/<agent>/*.session.md
└── templates/p000000_TEMPLATE_PLAN/   # canonical templates
```

## When Unsure
Ask before: new group, deleting/reordering phases, archiving, restructuring, force-pushing, rebasing, merging to `main`. Default: propose a diff.
