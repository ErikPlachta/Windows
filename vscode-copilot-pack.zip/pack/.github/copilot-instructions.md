# Copilot Instructions

This repo uses a plan-driven workflow. Plan files under `.github/docs/plans/<slug>.md` are the single source of truth for workflow todos. Their `## Tasks` checklist drives Copilot Chat's built-in todo UI — never the reverse.

## Always-true Rules
- No commits to `main` for plan work. One plan = one branch.
- No mixing plans in a branch or commit.
- No drive-by fixes in another plan's branch — open a new plan.
- No editing files under `.github/docs/changelog/` (immutable archive).
- No parallel trackers: `.vscode/tasks.json`, GitHub issues, and in-chat summaries are NOT todo systems.
- No force-push on shared branches. No amending pushed commits. No committing secrets.
- Every commit that touches a plan file MUST bump `modified:` in its frontmatter.

## How to Work
Switch to the **Plan Workflow** custom agent (dropdown at the bottom of the Chat panel) for disciplined plan execution. For utility work, switch to the cheaper agents:

| Task | Agent |
| --- | --- |
| Scaffold or execute a plan | `Plan Workflow` (premium model) |
| Write a session/task log | `Session Logger` (free model) |
| Validate plan structure | `Plan Validator` (free model) |
| Grill a plan for gaps | `Plan Reviewer` (mid-tier) |

Slash commands (work from any agent):
- `/plan-new` — scaffold a new plan + branch
- `/plan-work <slug>` — execute one task, stop
- `/plan-archive <slug>` — move completed plan to changelog
- `/plan-sync-todos <slug>` — re-mirror plan tasks into the Chat UI
- `/plan-validate <slug>` — check frontmatter + structure
- `/plan-review <slug>` — stress-test a plan
- `/log-session-open` / `/log-session-close` — session log lifecycle
- `/log-task <slug> <task>` — write a task execution log
- `/logs-cleanup` — archive or compact old logs
- `/branch-new <slug>` / `/branch-status` — branch helpers

Scoped rules (frontmatter schemas, authoring conventions, changelog immutability, commit format, log structure) live in `.github/instructions/` and auto-load based on the active file. Templates live in `.github/docs/templates/`.

## Docs Layout
```
.github/docs/
├── README.md       # conventions
├── plans/          # active plans + research/<slug>/
├── changelog/      # completed plans (immutable)
├── logs/           # per-agent session/task logs
└── templates/      # scaffolding templates
```

## When Unsure
Ask before: creating a plan, deleting or reordering tasks, archiving, restructuring `docs/`, force-pushing, rebasing, merging to `main`. Default: propose a diff, do not apply.
