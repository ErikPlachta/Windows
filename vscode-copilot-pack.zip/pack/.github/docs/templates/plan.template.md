---
title: <TITLE>
status: draft
author: <AUTHOR>
branch: <TYPE>/<SLUG>
ticket_number: <TICKET>
created: <TODAY>
modified: <TODAY>
completed:
---

# <TITLE>

## Goal
<!-- One sentence. What "done" looks like. -->

## Context
Research: research/<SLUG>/
<!-- Optional: Amends: ../changelog/<other-slug>.md -->

## Tasks
- [ ] 1. <first atomic task>

## Decisions
<!-- - YYYY-MM-DD: <decision + rationale> -->

## Open Questions
<!-- - <question> -->

## Outcome
<!-- Filled on archival: what shipped, PR links, follow-up plans. -->
