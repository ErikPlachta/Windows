---
agent: <AGENT-NAME>
session_id: <ULID>
model: <MODEL>
started: <ISO-WITH-TZ>
ended:
plan_slug:
branch:
status: open
---

# Session <ULID-SHORT>

## Intent
<!-- What the user asked for at session start. One or two sentences. -->

## Timeline
<!-- Append-only. Format: - HH:MM <event> -->

## Files Touched
<!-- - path/to/file — <summary of change> -->

## Commands Run
<!-- - `<command>` → <outcome summary> -->

## Decisions
<!-- - <rationale> -->

## User Checkpoints
<!-- - HH:MM Q: <question>
       A: <response> -->

## Outcome
<!-- Filled on close. 2–4 sentences: what shipped, what's pending, follow-up. -->
