---
agent: <AGENT-NAME>
session_id: <SESSION-ULID>
group_slug: <GROUP_SLUG>
phase: <NN or NN.M>
plan_file: <path to phase plan>
task_number: <N>
task_text: <VERBATIM FROM PLAN>
started: <ISO-WITH-TZ>
ended:
commit:
status: open
---

# Task <N> — <SHORT TASK SUMMARY>

> Group: [../../../../plans/<GROUP>/_INDEX.md](../../../../plans/<GROUP>/_INDEX.md)
> Phase plan: [../../../../<PLAN_FILE>](../../../../<PLAN_FILE>)
> Session: <SESSION-ULID>

## Approach

## Timeline

## Files Touched

## Commands Run

## Decisions

## User Checkpoints

## Outcome
