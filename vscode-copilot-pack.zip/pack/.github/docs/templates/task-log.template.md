---
agent: <AGENT-NAME>
session_id: <SESSION-ULID>
plan_slug: <SLUG>
task_number: <N>
task_text: <VERBATIM FROM PLAN>
started: <ISO-WITH-TZ>
ended:
commit:
status: open
---

# Task <N> — <SHORT TASK SUMMARY>

> Plan: [../../../plans/<SLUG>.md](../../../plans/<SLUG>.md)
> Session: <SESSION-ULID>

## Approach
<!-- How the task was tackled. 1–3 sentences. -->

## Timeline
<!-- - HH:MM <event> -->

## Files Touched
<!-- - path/to/file — <summary> -->

## Commands Run
<!-- - `<command>` → <outcome> -->

## Decisions
<!-- - <rationale> -->

## User Checkpoints
<!-- - HH:MM Q: <question>
       A: <response> -->

## Outcome
<!-- Filled on close. 1–3 sentences. Reference commit SHA. -->
