---
## Markdown Frontmatter Metadata
title: "{{GROUP_TITLE}}"
description: # {{DESCRIPTION_OF_GROUP_GOAL}}

## Metadata Related to Github Repository Management
semantic_title: "{{TYPE(SCOPE):SUBJECT}}" # e.g., feat(auth): authentication overhaul
tags: [plan-group, {{TOPIC_TAGS}}]
assignees: # [@github_username]
reviewers: # [@github_username]
approvers: # [@github_username]
integration_branch: # e.g., integration/p000001-auth-overhaul
base_branch: # main | develop
pull_request: # PR number or URL once opened
issues: # [issue URLs]
milestone: # milestone name
release: # ['v1.0.0']
version: 0.1.0

## Metadata Related to Planning and Execution
status: not_started   # not_started | in_progress | completed | deferred | pending_review | canceled
effort: # total estimate across phases (e.g., 2w)
priority: # P0-Critical | P1-High | P2-Medium | P3-Low
risk: # High | Medium | Low
impact: # High | Medium | Low

# Documentation of additional metadata for tracking and management
Created: # YYYY-MM-DD HH:mm:ss
Updated: # YYYY-MM-DD HH:mm:ss
Author: # {{AUTHOR_NAME}}
Co-Authors: # [@user, ClaudeAI]
changelog: # newest-first entries, ISO datetime + one-line change
---

# {{GROUP_TITLE}}

<!-- AI INSTRUCTIONS:

Maintain this index as the authoritative overview of the plan group.

## Status Vocabulary (text, not emoji)

- not_started     — phase not begun
- in_progress     — phase currently being executed
- completed       — phase done and merged to integration branch
- deferred        — postponed
- pending_review  — awaiting review/approval
- canceled        — no longer relevant

## Update Rules

- Bump `Updated:` on every edit.
- `status:` of the group rolls up from phase statuses:
    - All phases completed → completed
    - Any phase in_progress → in_progress
    - All not_started → not_started
- Phase table and branch map must stay in sync with phase plan files.
- On archival, entire pXX/ directory is moved under .github/docs/changelog/ via git mv.

-->

## Overview

{{1-3_SENTENCE_SUMMARY_OF_THE_GROUP_GOAL}}

## Phases

| Phase | Status | Description | Plan |
|-------|--------|-------------|------|
| 01    | not_started | {{PHASE_1_DESCRIPTION}} | [01/01_{{DESC}}_{{YYYYMMDD}}.md](01/01_{{DESC}}_{{YYYYMMDD}}.md) |

## Branch Map

Branching pattern: `{{single_branch | branch_per_phase | branch_per_subphase}}`

| Phase / Sub-phase | Branch | Base Branch | PR |
|-------------------|--------|-------------|----|
| 01 | {{TYPE}}/p{{NN}}-01-{{DESC}} | {{INTEGRATION_OR_MAIN}} | {{PR}} |

Integration branch (if branch-per-phase): `{{integration/pNNNNNN-slug}}` — merges to `{{BASE_BRANCH}}`.

## Research

See [_RESEARCH/](_RESEARCH/) for phase-scoped research artifacts. Files under `_RESEARCH/NN/` belong to phase `NN`.

## Decisions (Group-Level)

| Decision | Rationale | Related To | Date Time |
|----------|-----------|------------|-----------|
| {{DECISION}} | {{WHY}} | {{RELATED_PHASES}} | {{YYYY-MM-DD HH:mm:ss}} |

## Risk & Mitigation (Group-Level)

{{RISK_OVERVIEW_ACROSS_PHASES}}

### Rollback Strategy

{{HOW_TO_UNWIND_THE_GROUP_IF_ABORTED_MID-FLIGHT}}

## References

{{EXTERNAL_LINKS_TICKETS_SPECS}}
