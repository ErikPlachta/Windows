---
## Markdown Frontmatter Metadata
title: "Phase {{NN}}: {{PHASE_TITLE}}"
description: # {{WHAT_THIS_PHASE_DELIVERS}}

## Metadata Related to Github Repository Management
semantic_title: "{{TYPE(SCOPE):SUBJECT}}" # e.g., feat(auth): extract token validator
tags: [plan, phase, {{TOPIC_TAGS}}]
assignees: # [@github_username]
reviewers: # [@github_username]
approvers: # [@github_username]
Branch: # e.g., feat/p000001-01-extract-validator
Base Branch: # e.g., integration/p000001-auth-overhaul OR main
pull_request: # PR number or URL
issues: # [issue URLs]
milestone: # milestone name
release: # ['v1.0.0']
version: 0.0.1

## Metadata Related to Planning and Execution
status: not_started   # not_started | in_progress | completed | deferred | pending_review | canceled
effort: # e.g., 2h, 1d, 3d, 1w
priority: # P0-Critical | P1-High | P2-Medium | P3-Low
risk: # High | Medium | Low
impact: # High | Medium | Low

## Group Membership
group: # p000001-auth-overhaul
phase: # 01
sub_phase: # blank for top-level phases; 01.1 / 01.2 / ... for sub-phases

# Documentation of additional metadata for tracking and management
Created: # YYYY-MM-DD HH:mm:ss
Updated: # YYYY-MM-DD HH:mm:ss
Author: # {{AUTHOR_NAME}}
Co-Authors: # [@user, ClaudeAI]
changelog: # newest-first entries
---

<!-- AI INSTRUCTIONS:

## Key Points

- Replace all {{PLACEHOLDERS}} with actual content
- Update `status:` as work progresses (text, not emoji)
- Check acceptance criteria boxes when met
- Log decisions in Decisions Made section
- Keep Session State current after each action
- Update frontmatter `status` when all phases complete
- Bump `Updated:` on every edit
- Append to `changelog:` newest-first on substantive updates

## Status Vocabulary

| Value          | Meaning                             |
| -------------- | ----------------------------------- |
| not_started    | Not started yet                     |
| in_progress    | Currently being worked              |
| completed      | Merged, done                        |
| deferred       | Postponed or waiting                |
| pending_review | Awaiting review/approval            |
| canceled       | No longer relevant, rejected        |

-->

# Phase {{NN}}: {{PHASE_TITLE}}

## Table of Contents

- [Session State](#session-state)
- [Problem Statement(s)](#problem-statements)
- [Decisions Made](#decisions-made)
- [Risk & Mitigation](#risk--mitigation)
- [Tasks](#tasks)
  - [Progress Tracking](#progress-tracking)
  - [Phased Implementation Steps](#phased-implementation-steps)
  - [End of Plan Strategies](#end-of-plan-strategies)
- [References](#references)

## Session State

| Field         | Value                          |
| ------------- | ------------------------------ |
| Last Action   | {{LAST_COMPLETED_ACTION}}      |
| Next Action   | {{NEXT_ACTION_TO_TAKE}}        |
| Current Phase | Phase {{NN}} — {{TOPIC_NAME}}  |
| Current Sub-phase | {{BLANK_OR_NN.M}}          |
| Blockers      | {{NONE_OR_DESCRIPTION}}        |

## Problem Statement(s)

Clearly define the problem(s) this phase solves and what success looks like.

### Problem_1

- **User Story**: As a {{USER_TYPE}}, I want {{ACTION}} so that {{BENEFIT}}
- **Description**: {{DETAILED_PROBLEM_DESCRIPTION}}
- **Impact**: {{HOW_THIS_AFFECTS_USERS_OR_PRODUCT}}
- **Acceptance Criteria**:
  - [ ] {{CRITERION_1}}
  - [ ] {{CRITERION_2}}
  - [ ] {{CRITERION_3}}
- **Notes**:
  - {{ADDITIONAL_CONTEXT}}

### Out of Scope

- {{EXCLUDED_ITEM_1}}
- {{EXCLUDED_ITEM_2}}

---

## Decisions Made

| Decision       | Rationale | Related To          | Date Time               |
| -------------- | --------- | ------------------- | ----------------------- |
| {{DECISION_1}} | {{WHY}}   | {{RELATED_ITEM(S)}} | {{YYYY-MM-DD HH:mm:ss}} |

---

## Risk & Mitigation

Strategies for avoiding risk and mitigating issues if they arise.

### Risk & Mitigation Strategy

{{RISK_AND_MITIGATION_STRATEGY}}

### Rollback Plan

{{ROLLBACK_PLAN_DESCRIPTION}}

---

## Tasks

This section outlines the specific tasks needed to address the problem statement(s).

Content is broken down into 3 sections:

1. [Progress Tracking](#progress-tracking) — track overall progress of the phase.
2. [Phased Implementation Steps](#phased-implementation-steps) — detailed breakdown into sub-phases for structured execution.
3. [End of Plan Strategies](#end-of-plan-strategies) — strategies required for all phases (testing, coverage, docs).

### Progress Tracking

Track progress to prevent drift and ensure clarity between User and AI collaborator.

#### [Phased Implementation Steps](#phased-implementation-steps) — Progress Tracker

| Title                               | Status      | Description                   |
| ----------------------------------- | ----------- | ----------------------------- |
| [Sub-phase 1](#sub-phase-1-topic)   | not_started | {{BRIEF_DESCRIPTION}}         |
| [Sub-phase 2](#sub-phase-2-topic)   | not_started | {{BRIEF_DESCRIPTION}}         |

#### [End of Plan Strategies](#end-of-plan-strategies) — Progress Tracker

| Title                           | Status      | Description                                                   |
| ------------------------------- | ----------- | ------------------------------------------------------------- |
| [Testing](#testing)             | not_started | Testing meets or exceeds target: **Target**: #, **Actual**: # |
| [Coverage](#code-coverage)      | not_started | Full Coverage: **Target**: ##.##%, **Actual**: ##.##%         |
| [Documentation](#documentation) | not_started | Existing updated, new created & old deprecated.               |

---

## Phased Implementation Steps

Detailed breakdown of implementation steps into sub-phases for structured execution.

### Sub-phase 1: {{TOPIC_NAME}}

{{SUBPHASE_1_DETAILS}}

**Done when**: {{COMPLETION_CRITERIA}}

### Sub-phase 2: {{TOPIC_NAME}}

{{SUBPHASE_2_DETAILS}}

**Done when**: {{COMPLETION_CRITERIA}}

---

## End of Plan Strategies

How to handle specific scenarios.

### Testing

{{TESTING_STRATEGY_REFERENCE_SUMMARY_AND_LINK_TO_REFERENCE_FILE}}

### Code Coverage

{{CODE_COVERAGE_STRATEGY_REFERENCE_SUMMARY_AND_LINK_TO_REFERENCE_FILE}}

### Documentation

{{DOCUMENTATION_STRATEGY_REFERENCE_SUMMARY_AND_LINK_TO_REFERENCE_FILE}}

---

## References

{{REFERENCES_AND_LINKS_TO_ADDITIONAL_RESOURCES}}
