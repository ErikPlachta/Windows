# <TOPIC TITLE>

> Plan: [../../plans/<SLUG>.md](../../plans/<SLUG>.md)
> Created: <TODAY>

## Summary
<!-- 1–3 sentences on what this note covers. -->

## Context
<!-- Why this research exists. What question it answers for the plan. -->

## Findings
<!-- Free-form: bullets, prose, code, tables, diagrams. -->

## Sources
<!-- Links to docs, tickets, specs, prior art. -->

## Implications for the Plan
<!-- What does this mean for tasks, decisions, or open questions in the parent plan? -->
