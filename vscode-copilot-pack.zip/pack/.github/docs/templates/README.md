# Plan Group Directory — Naming Convention

## Structure

```
.github/docs/plans/
├── CURRENT.md                 Thin pointer to the plan file currently being worked
├── archived/                  (none here — use .github/docs/changelog/ for archived groups)
└── pXX-slug/                  Plan group (e.g., p000003-auth-overhaul/)
    ├── _INDEX.md              Plan group overview + phase status + branch map
    ├── _RESEARCH/             Research artifacts scoped by phase
    │   └── NN/                Phase subfolder (e.g., 01/, 02/)
    │       ├── N.N_description.md
    │       └── N.N_description/    (asset folder, same prefix)
    └── NN/                    Phase folder (e.g., 01/, 02/)
        └── NN_description_YYYYMMDD.md          (top-level phase plan)
        └── NN.N_description_YYYYMMDD.md        (sub-phase plan, same folder)
```

Completed groups move to `.github/docs/changelog/pXX-slug/` (same structure).

## Naming Patterns

| Element          | Pattern                        | Example                           |
|------------------|--------------------------------|-----------------------------------|
| Plan group       | `pNNNNNN-slug/`                    | `p000003-auth-overhaul/`              |
| Phase folder     | `NN/`                          | `p000003-auth-overhaul/01/`           |
| Phase plan       | `NN_description_YYYYMMDD.md`   | `01_extract-validator_20260422.md`|
| Sub-phase plan   | `NN.M_description_YYYYMMDD.md` | `02.1_mfa-backup-codes_20260423.md`|
| Research folder  | `_RESEARCH/NN/`                | `_RESEARCH/01/`                   |
| Research file    | `N.M_description.md`           | `1.1_jwt-vs-sessions.md`          |
| Research assets  | `N.M_description/`             | `1.1_jwt-vs-sessions/img_01.png`  |

## Conventions

- `_` prefix = meta/infrastructure (sorts to top): `_INDEX.md`, `_RESEARCH/`.
- Research files are scoped to the phase that generated them.
- Asset folders sit alongside their owning research file, same prefix.
- Use `git mv` for all moves (phases, research, archival) to preserve history.
- Status values are text, never emoji: `not_started | in_progress | completed | deferred | pending_review | canceled`.
- Plan group number (`pNNNNNN`) is auto-incremented from the highest existing under `plans/` and `changelog/`. The `-slug` portion is user-chosen kebab-case.
- Date suffix on phase plan filenames is the creation date, not modified — it makes reopening an abandoned phase with a fresh plan explicit (two dated files in one folder).

## Status Rollup

Group `status:` in `_INDEX.md` is computed from phase statuses:

- All phases `completed` → group `completed`
- Any phase `in_progress` → group `in_progress`
- All phases `not_started` → group `not_started`
- Any phase `blocked`/`pending_review` → reflected up to group

## Branching Patterns

Recorded in `_INDEX.md` → Branch Map:

| Pattern | When | Branches |
|---|---|---|
| `single_branch` | Sequential phases, no parallel work | One branch for the whole group |
| `branch_per_phase` | Phases reviewable independently | Phase branches merge to an integration branch which merges to `main` |
| `branch_per_subphase` | Complex, phases have own sub-trees | Sub-phase branches base off phase branches |
