# `.github/docs/` — Workflow Data

This directory holds the workflow's durable data: plans, their archived versions, per-agent logs, and the templates used to scaffold them. Code doesn't live here; decisions, tasks, and execution history do.

## Layout

```
docs/
├── README.md               # this file
├── plans/                  # active and in-progress plans
│   ├── <slug>.md           # one plan per file
│   └── research/
│       └── <slug>/         # supporting research, one folder per plan
│           └── <topic>.md
├── changelog/              # completed plans (immutable)
│   ├── <slug>.md
│   └── research/
│       └── <slug>/
├── logs/                   # per-agent session/task logs
│   └── <agent-name>/
│       ├── <YYYY-MM-DD>-<ulid>.session.md
│       └── <YYYY-MM-DD>-<ulid>-t<N>.task.md
└── templates/              # scaffolding templates referenced by prompts
    ├── plan.template.md
    ├── research.template.md
    ├── session-log.template.md
    └── task-log.template.md
```

## Conventions

### `plans/`
One plan per file, named by kebab-case slug. The plan's `## Tasks` checklist is the **single source of truth** for workflow todos. Authoring rules: `.github/instructions/plan-authoring.instructions.md`. Schema is enforced by `/plan-validate`. Canonical template: `templates/plan.template.md`.

### `plans/research/<slug>/`
Supporting notes for a specific plan. One topic per file. Rules: `.github/instructions/research-authoring.instructions.md`. Template: `templates/research.template.md`.

### `changelog/`
Archived plans — moved here by `/plan-archive` via `git mv`. **Immutable.** Enforced by `.github/instructions/changelog-protection.instructions.md`. To revise an archived plan's conclusions, open a new amending plan.

### `changelog/research/<slug>/`
Mirrors the archived plan's research. Moved together on archival. Same immutability rule.

### `logs/<agent-name>/`
Session and task execution logs for a specific agent. One subfolder per agent (e.g., `plan-workflow/`, `session-logger/`). Files:

- **Session logs** — one per working session: `<YYYY-MM-DD>-<ulid>.session.md`.
- **Task logs** — optional, one per substantive plan-task execution: `<YYYY-MM-DD>-<ulid>-t<N>.task.md`.

Rules: `.github/instructions/log-authoring.instructions.md`. Templates: `templates/session-log.template.md`, `templates/task-log.template.md`. Managed by `Session Logger` agent and the `/log-*` prompts. Append-only.

### `templates/`
Scaffolding templates referenced by prompts (e.g., `/plan-new` reads `plan.template.md`). Edit these files to change the format used by the whole pack — changes are picked up the next time a prompt references them.

## ULIDs

Session and task logs use ULIDs for their IDs. If the agent can't produce a real ULID, fall back to `<ISO-datetime>-<6-random-alnum>`. Sort order + uniqueness are what matter; exact format is flexible. Keep them stable within a session.

## Relationships

```
Plan   ────────►  Research (plans/research/<slug>/)
  │
  │ executed by agents
  ▼
Session logs (logs/<agent>/*.session.md)
  │
  └──►  Task logs (logs/<agent>/*-t<N>.task.md)
```

Plans drive work. Logs record what happened during work. Research captures what was learned in service of plans. Archival moves plans + research (together) into the changelog.

## Adding New Content Types

If a future agent/workflow needs its own data type (e.g., `decisions/`, `reviews/`, `incidents/`):
1. Add the folder here.
2. Add matching `.github/instructions/<topic>-authoring.instructions.md` with `applyTo: ".github/docs/<topic>/**/*.md"`.
3. Add a template under `templates/`.
4. Update this README.
