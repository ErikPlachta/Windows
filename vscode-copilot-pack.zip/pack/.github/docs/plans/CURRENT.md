# Current Plan Indicator

> Thin pointer to the phase plan currently being worked.
> Updated by `/planner-work`, `/planner-phase-new`, `/planner-group-new`, `/planner-archive`.
> Full session/task detail lives in the phase plan's `## Session State` table and in `.github/docs/logs/`.

## Active

group: (none)
phase: (none)
plan_file: (none)
branch: (none)
last_touched: (none)

## Notes

No active plan. Run `/planner-group-new` to scaffold a new plan group or `/planner-work <group>/<phase>` to resume one.
