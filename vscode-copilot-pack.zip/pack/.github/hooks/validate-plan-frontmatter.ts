/**
 * Pre-commit hook: validate plan frontmatter against the schema in
 * .github/instructions/plan-authoring.instructions.md.
 *
 * Runs on: .github/docs/plans/*.md and .github/docs/changelog/*.md
 * Exit: 0 pass, 1 fail.
 */

import { readFileSync } from "node:fs";
import { parseFrontmatter, isIsoDate, logFail } from "./_lib.ts";

const VALID_STATUSES = new Set(["draft", "active", "blocked", "done"]);
const VALID_TYPES = new Set(["feat", "fix", "chore", "refactor", "docs", "spike"]);
const REQUIRED_FIELDS = ["title", "status", "author", "branch", "created", "modified"];
const BRANCH_RE = /^([a-z]+)\/([a-z0-9][a-z0-9-]*)$/;
const TASK_RE = /^- \[([ xX])\]\s+\d+\.\s+/gm;

function validate(path: string): string[] {
  const errors: string[] = [];
  let text: string;
  try {
    text = readFileSync(path, "utf8");
  } catch (e) {
    return [`${path}: cannot read (${String(e)})`];
  }

  const parsed = parseFrontmatter(text);
  if (!parsed) return [`${path}: missing or malformed YAML frontmatter`];
  const { fields: fm, body } = parsed;

  for (const f of REQUIRED_FIELDS) {
    if (!fm[f]) errors.push(`${path}: missing required field \`${f}:\``);
  }

  const status = fm.status ?? "";
  if (status && !VALID_STATUSES.has(status)) {
    errors.push(`${path}: status \`${status}\` not in [${[...VALID_STATUSES].sort().join(", ")}]`);
  }

  for (const f of ["created", "modified"] as const) {
    const v = fm[f];
    if (v && !isIsoDate(v)) errors.push(`${path}: ${f}: \`${v}\` is not ISO YYYY-MM-DD`);
  }

  if (fm.created && fm.modified && isIsoDate(fm.created) && isIsoDate(fm.modified)) {
    if (fm.modified < fm.created) {
      errors.push(`${path}: modified (${fm.modified}) < created (${fm.created})`);
    }
  }

  const completed = fm.completed ?? "";
  if (status === "done") {
    if (!completed) errors.push(`${path}: status: done requires completed: to be set`);
    else if (!isIsoDate(completed)) errors.push(`${path}: completed: \`${completed}\` is not ISO YYYY-MM-DD`);
  } else if (completed) {
    errors.push(`${path}: completed: set but status is \`${status}\` (must be \`done\`)`);
  }

  if (fm.branch) {
    const m = BRANCH_RE.exec(fm.branch);
    if (!m) errors.push(`${path}: branch \`${fm.branch}\` does not match \`<type>/<slug>\` kebab-case`);
    else if (!VALID_TYPES.has(m[1])) {
      errors.push(`${path}: branch type \`${m[1]}\` not in [${[...VALID_TYPES].sort().join(", ")}]`);
    }
  }

  if (fm.title && body) {
    const h1 = /^#\s+(.+)$/m.exec(body);
    if (h1 && h1[1].trim() !== fm.title) {
      errors.push(`${path}: title \`${fm.title}\` != H1 \`${h1[1].trim()}\``);
    } else if (!h1) {
      errors.push(`${path}: body has no H1`);
    }
  }

  if (status === "done" && body) {
    const unchecked: string[] = [];
    for (const m of body.matchAll(TASK_RE)) {
      if (m[1] === " ") unchecked.push(m[0]);
    }
    if (unchecked.length > 0) {
      errors.push(`${path}: status: done but ${unchecked.length} task(s) unchecked`);
    }
  }

  return errors;
}

const allErrors = process.argv.slice(2).flatMap(validate);
if (allErrors.length > 0) {
  logFail("plan frontmatter validation failed:", allErrors);
  process.exit(1);
}
