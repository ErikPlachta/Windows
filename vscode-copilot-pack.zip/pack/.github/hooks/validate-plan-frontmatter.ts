/**
 * Pre-commit hook: validate plan group frontmatter (group _INDEX.md, phase plans, research).
 *
 * Runs on: .github/docs/plans/**\/*.md and .github/docs/changelog/**\/*.md
 * Skips: CURRENT.md (thin pointer, not a plan)
 * Exit: 0 pass, 1 fail.
 */

import { readFileSync, readdirSync } from "node:fs";
import { basename, dirname, sep } from "node:path";
import { parseFrontmatter, isIsoDate, logFail } from "./_lib.ts";

const VALID_STATUSES = new Set([
  "not_started", "in_progress", "completed", "deferred", "pending_review", "canceled",
]);
const VALID_RESEARCH_STATUSES = new Set(["draft", "finalized", "superseded"]);
const VALID_TYPES = new Set(["feat", "fix", "chore", "refactor", "docs", "spike"]);

const INDEX_REQUIRED = ["title", "status", "base_branch", "Created", "Updated", "Author", "version"];
const PHASE_REQUIRED = ["title", "status", "Branch", "Base Branch", "group", "phase", "Created", "Updated", "Author", "version"];
const RESEARCH_REQUIRED = ["title", "phase", "status", "created"];

const ISO_DATETIME_RE = /^\d{4}-\d{2}-\d{2}( \d{2}:\d{2}:\d{2})?$/;
const GROUP_DIR_RE = /^p\d{6}-[a-z0-9][a-z0-9-]*$/;
const PHASE_DIR_RE = /^\d{2}$/;
const PHASE_FILE_RE = /^(\d{2}(?:\.\d+)?)_[a-z0-9-]+_\d{8}\.md$/;
const RESEARCH_FILE_RE = /^\d+\.\d+_[a-z0-9][a-z0-9-]*\.md$/;
const BRANCH_RE = /^([a-z]+)\/[a-z0-9][a-z0-9/-]*$/;
const EMOJI_RE = /[\u{1F300}-\u{1FAFF}\u{2600}-\u{27BF}\u{1F000}-\u{1F9FF}\u{2B00}-\u{2BFF}]/u;

type FileKind = "index" | "phase" | "research" | "other";

function classify(path: string): FileKind {
  // .github/docs/(plans|changelog)/pNNNNNN-slug/...
  const parts = path.split(sep);
  const plansIdx = parts.findIndex((p) => p === "plans" || p === "changelog");
  if (plansIdx < 0) return "other";
  const rel = parts.slice(plansIdx + 1);
  if (rel.length < 2) return "other";
  if (!GROUP_DIR_RE.test(rel[0])) return "other";
  const name = basename(path);
  if (name === "_INDEX.md") return "index";
  if (rel[1] === "_RESEARCH") return "research";
  if (PHASE_DIR_RE.test(rel[1])) return "phase";
  return "other";
}

function checkCommon(path: string, fm: Record<string, string>, required: string[]): string[] {
  const errors: string[] = [];
  for (const f of required) {
    if (!fm[f]) errors.push(`${path}: missing required field \`${f}:\``);
  }
  if (fm.status) {
    if (EMOJI_RE.test(fm.status)) errors.push(`${path}: status contains emoji; use text vocabulary`);
  }
  return errors;
}

function validateIndex(path: string, fm: Record<string, string>, body: string): string[] {
  const errors = checkCommon(path, fm, INDEX_REQUIRED);
  if (fm.status && !VALID_STATUSES.has(fm.status)) {
    errors.push(`${path}: status \`${fm.status}\` not in ${[...VALID_STATUSES].sort().join(", ")}`);
  }
  // H1 check
  const h1 = /^#\s+(.+)$/m.exec(body);
  if (fm.title && h1 && h1[1].trim() !== fm.title) {
    errors.push(`${path}: title \`${fm.title}\` != H1 \`${h1[1].trim()}\``);
  }
  // required sections
  for (const section of ["## Overview", "## Phases", "## Branch Map", "## Research"]) {
    if (!body.includes(section)) errors.push(`${path}: missing section \`${section}\``);
  }
  return errors;
}

function validatePhase(path: string, fm: Record<string, string>, body: string): string[] {
  const errors = checkCommon(path, fm, PHASE_REQUIRED);
  if (fm.status && !VALID_STATUSES.has(fm.status)) {
    errors.push(`${path}: status \`${fm.status}\` not in ${[...VALID_STATUSES].sort().join(", ")}`);
  }

  // Filename convention
  const name = basename(path);
  const fileMatch = PHASE_FILE_RE.exec(name);
  if (!fileMatch) {
    errors.push(`${path}: filename \`${name}\` doesn't match \`NN_description_YYYYMMDD.md\` or \`NN.M_...\``);
  }

  // group: matches parent dir grandparent (plans/<group>/NN/file.md)
  const parts = path.split(sep);
  const plansIdx = parts.findIndex((p) => p === "plans" || p === "changelog");
  const groupDir = parts[plansIdx + 1];
  const phaseDir = parts[plansIdx + 2];
  if (fm.group && fm.group !== groupDir) {
    errors.push(`${path}: group \`${fm.group}\` doesn't match parent dir \`${groupDir}\``);
  }
  if (fm.phase && phaseDir) {
    // phase: is NN or NN.M; must start with NN matching phaseDir
    if (!fm.phase.startsWith(phaseDir)) {
      errors.push(`${path}: phase \`${fm.phase}\` doesn't align with folder \`${phaseDir}\``);
    }
    // Filename prefix must match
    if (fileMatch && fileMatch[1] !== fm.phase) {
      errors.push(`${path}: filename prefix \`${fileMatch[1]}\` doesn't match phase \`${fm.phase}\``);
    }
  }

  // Branch format
  if (fm.Branch && !BRANCH_RE.test(fm.Branch)) {
    errors.push(`${path}: Branch \`${fm.Branch}\` doesn't match \`<type>/<slug>\``);
  } else if (fm.Branch) {
    const type = fm.Branch.split("/")[0];
    if (!VALID_TYPES.has(type)) {
      errors.push(`${path}: Branch type \`${type}\` not in ${[...VALID_TYPES].sort().join(", ")}`);
    }
  }

  // Dates
  for (const f of ["Created", "Updated"]) {
    if (fm[f] && !ISO_DATETIME_RE.test(fm[f])) {
      errors.push(`${path}: ${f}: \`${fm[f]}\` not ISO date or datetime`);
    }
  }

  // H1
  const h1 = /^#\s+(.+)$/m.exec(body);
  if (h1 && fm.phase) {
    const isSub = fm.phase.includes(".");
    const expected = isSub ? `Sub-phase ${fm.phase}` : `Phase ${fm.phase}`;
    if (!h1[1].includes(expected)) {
      errors.push(`${path}: H1 \`${h1[1].trim()}\` should start with \`# ${expected}: \``);
    }
  }

  // Required sections
  const required = [
    "## Table of Contents", "## Session State", "## Problem Statement(s)",
    "## Decisions Made", "## Risk & Mitigation", "## Tasks",
    "## Phased Implementation Steps", "## End of Plan Strategies", "## References",
  ];
  for (const s of required) {
    if (!body.includes(s)) errors.push(`${path}: missing section \`${s}\``);
  }

  // No emoji in status tracker columns (heuristic: scan status column of tables)
  if (EMOJI_RE.test(body)) {
    errors.push(`${path}: body contains emoji; use text status vocabulary only`);
  }

  // Status rollup: completed => all problem checkboxes checked
  if (fm.status === "completed") {
    const unchecked = [...body.matchAll(/^-\s*\[\s\]/gm)];
    if (unchecked.length > 0) {
      errors.push(`${path}: status: completed but ${unchecked.length} checkbox(es) unchecked`);
    }
  }

  return errors;
}

function validateResearch(path: string, fm: Record<string, string>, body: string): string[] {
  const errors = checkCommon(path, fm, RESEARCH_REQUIRED);
  if (fm.status && !VALID_RESEARCH_STATUSES.has(fm.status)) {
    errors.push(`${path}: status \`${fm.status}\` not in ${[...VALID_RESEARCH_STATUSES].sort().join(", ")}`);
  }
  const name = basename(path);
  const fileMatch = RESEARCH_FILE_RE.exec(name);
  if (!fileMatch) {
    errors.push(`${path}: filename \`${name}\` doesn't match \`N.M_description.md\``);
  }
  if (fm.created && !isIsoDate(fm.created)) {
    errors.push(`${path}: created: \`${fm.created}\` not ISO YYYY-MM-DD`);
  }

  // phase frontmatter must match parent NN/ folder
  const parts = path.split(sep);
  const researchIdx = parts.lastIndexOf("_RESEARCH");
  const phaseDir = researchIdx >= 0 ? parts[researchIdx + 1] : "";
  if (phaseDir && fm.phase && fm.phase !== phaseDir) {
    errors.push(`${path}: phase \`${fm.phase}\` doesn't match parent folder \`${phaseDir}\``);
  }

  // file prefix N.M must start with phase number
  if (fileMatch && phaseDir) {
    const [, nm] = fileMatch[0].match(/^(\d+\.\d+)_/) ?? [, ""];
    const n = nm.split(".")[0];
    // Folder is "01" or "02" etc; N portion is "1", "2" etc
    if (n && String(Number(phaseDir)) !== n) {
      errors.push(`${path}: prefix \`${nm}\` doesn't match parent folder \`${phaseDir}\` (N portion should be ${Number(phaseDir)})`);
    }
  }

  // sub-phase frontmatter must match file prefix
  if (fileMatch && fm["sub-phase"]) {
    const prefix = fileMatch[0].match(/^(\d+\.\d+)_/)?.[1];
    if (prefix && prefix !== fm["sub-phase"]) {
      errors.push(`${path}: sub-phase \`${fm["sub-phase"]}\` doesn't match filename prefix \`${prefix}\``);
    }
  }

  // Asset folder (if exists) must share prefix with this file
  // Asset folder name = file stem (without .md). If a sibling folder with that name exists, fine.
  // If any sibling folder has the same N.M prefix but different description, flag.
  if (fileMatch) {
    const fileStem = name.slice(0, -3); // strip .md
    const nmPrefix = fileMatch[0].match(/^(\d+\.\d+)_/)?.[1] ?? "";
    const siblingDir = dirname(path);
    try {
      const siblings = readdirSync(siblingDir, { withFileTypes: true });
      for (const s of siblings) {
        if (!s.isDirectory()) continue;
        if (s.name.startsWith(nmPrefix + "_") && s.name !== fileStem) {
          errors.push(
            `${path}: sibling asset folder \`${s.name}/\` has same prefix \`${nmPrefix}\` but different name than this file's stem \`${fileStem}\``
          );
        }
      }
    } catch {
      // directory read failure; skip
    }
  }

  // superseded status requires Summary link to replacement
  if (fm.status === "superseded") {
    const summaryMatch = /##\s+Summary\s*\n([\s\S]*?)(?=\n##\s|\n---|\s*$)/.exec(body);
    const hasLink = summaryMatch && /\[[^\]]+\]\([^)]+\.md\)/.test(summaryMatch[1]);
    if (!hasLink) {
      errors.push(`${path}: status: superseded but ## Summary has no Markdown link to replacement`);
    }
  }

  return errors;
}

function validate(path: string): string[] {
  const kind = classify(path);
  if (kind === "other") return []; // unsupported file under plans/; skip

  let text: string;
  try {
    text = readFileSync(path, "utf8");
  } catch (e) {
    return [`${path}: cannot read (${String(e)})`];
  }

  const parsed = parseFrontmatter(text);
  if (!parsed) return [`${path}: missing or malformed YAML frontmatter`];

  if (kind === "index") return validateIndex(path, parsed.fields, parsed.body);
  if (kind === "phase") return validatePhase(path, parsed.fields, parsed.body);
  if (kind === "research") return validateResearch(path, parsed.fields, parsed.body);
  return [];
}

const allErrors = process.argv.slice(2).flatMap(validate);
if (allErrors.length > 0) {
  logFail("plan frontmatter validation failed:", allErrors);
  process.exit(1);
}
