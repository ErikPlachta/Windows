/**
 * Pre-commit hook: session/task logs are append-only once closed/aborted,
 * and open logs may only be appended to (no mid-file edits).
 *
 * Exit: 0 pass, 1 fail.
 */

import { readFileSync } from "node:fs";
import { parseFrontmatter, stagedStatus, fileAtHead, logFail } from "./_lib.ts";

const LOG_ROOT = ".github/docs/logs/";

function parseStatus(text: string): string {
  return parseFrontmatter(text)?.fields.status ?? "";
}

function isPureAppend(oldText: string, newText: string): boolean {
  if (!oldText) return true;
  const normalized = oldText.endsWith("\n") ? oldText : oldText + "\n";
  return newText.startsWith(normalized);
}

const rejected: string[] = [];
for (const arg of process.argv.slice(2)) {
  if (!arg.startsWith(LOG_ROOT)) continue;
  const status = stagedStatus(arg);
  if (status === "A") continue;
  if (status === "D") {
    rejected.push(`${arg}: deleted — logs are retained (use /logs-cleanup to compact)`);
    continue;
  }
  if (status === "R") {
    rejected.push(`${arg}: renamed — logs don't move (use /logs-cleanup --compact)`);
    continue;
  }
  if (status !== "M") continue;

  const headText = fileAtHead(arg);
  if (headText === null) continue;

  const headStatus = parseStatus(headText);
  if (headStatus === "closed" || headStatus === "aborted") {
    rejected.push(`${arg}: log is \`status: ${headStatus}\` at HEAD — cannot be edited`);
    continue;
  }

  let newText: string;
  try {
    newText = readFileSync(arg, "utf8");
  } catch (e) {
    rejected.push(`${arg}: cannot read working copy (${String(e)})`);
    continue;
  }

  if (!isPureAppend(headText, newText)) {
    rejected.push(`${arg}: not a pure append — existing content was modified or removed`);
  }
}

if (rejected.length > 0) {
  logFail("log append-only check failed:", rejected);
  process.exit(1);
}
