/**
 * Pre-commit hook: auto-bump `modified:` in staged plan files to today.
 * Runs on: .github/docs/plans/*.md
 * Exit: always 0 — we modify, we don't block.
 */

import { readFileSync, writeFileSync, existsSync } from "node:fs";
import { execFileSync } from "node:child_process";
import { todayIso } from "./_lib.ts";

const TODAY = todayIso();
const MODIFIED_RE = /^(modified:\s*)(\S*)\s*$/m;

function bump(path: string): void {
  if (!existsSync(path)) return;
  const text = readFileSync(path, "utf8");
  const m = MODIFIED_RE.exec(text);
  if (!m) return; // no modified: field — frontmatter validator will flag
  if (m[2] === TODAY) return;
  const next = text.replace(MODIFIED_RE, `$1${TODAY}`);
  writeFileSync(path, next, "utf8");
  execFileSync("git", ["add", path]);
  process.stdout.write(`[bump-plan-modified] ${path}: modified: -> ${TODAY}\n`);
}

for (const arg of process.argv.slice(2)) {
  bump(arg);
}
