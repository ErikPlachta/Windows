/**
 * Pre-commit hook: validate plan group structural integrity.
 * For each staged file under plans/pNNNNNN-slug/, check the whole group:
 *   - _INDEX.md Phases table row count == NN/ folder count
 *   - Each Phases row's Plan link resolves
 *   - Each phase folder has at least one NN_*.md
 *   - Branch Map row count aligns with branching pattern
 *
 * Exit: 0 pass, 1 fail.
 */

import { existsSync, readFileSync, readdirSync, statSync } from "node:fs";
import { basename, dirname, join, sep } from "node:path";
import { parseFrontmatter, logFail } from "./_lib.ts";

const GROUP_DIR_RE = /^p\d{6}-[a-z0-9][a-z0-9-]*$/;
const PHASE_DIR_RE = /^\d{2}$/;
const PHASE_FILE_RE = /^(\d{2}(?:\.\d+)?)_[a-z0-9-]+_\d{8}\.md$/;

function findGroupRoot(path: string): string | null {
  const parts = path.split(sep);
  const plansIdx = parts.findIndex((p) => p === "plans" || p === "changelog");
  if (plansIdx < 0 || plansIdx + 2 > parts.length) return null;
  const groupDir = parts[plansIdx + 1];
  if (!groupDir || !GROUP_DIR_RE.test(groupDir)) return null;
  return parts.slice(0, plansIdx + 2).join(sep);
}

function listPhaseDirs(groupRoot: string): string[] {
  try {
    return readdirSync(groupRoot)
      .filter((n) => PHASE_DIR_RE.test(n))
      .filter((n) => statSync(join(groupRoot, n)).isDirectory())
      .sort();
  } catch {
    return [];
  }
}

function listPhaseFiles(phaseDir: string): string[] {
  try {
    return readdirSync(phaseDir)
      .filter((n) => PHASE_FILE_RE.test(n))
      .sort();
  } catch {
    return [];
  }
}

function parsePhasesTable(indexBody: string): { phase: string; link: string }[] {
  const rows: { phase: string; link: string }[] = [];
  const tableStart = indexBody.indexOf("## Phases");
  if (tableStart < 0) return rows;
  const section = indexBody.slice(tableStart, indexBody.indexOf("\n## ", tableStart + 1));
  for (const line of section.split("\n")) {
    // | 01 | not_started | desc | [01/01_..._YYYYMMDD.md](01/01_...md) |
    const m = /^\|\s*(\d{2}(?:\.\d+)?)\s*\|[^|]*\|[^|]*\|\s*\[([^\]]+)\]\(([^)]+)\)/.exec(line);
    if (m) rows.push({ phase: m[1], link: m[3] });
  }
  return rows;
}

function parseBranchMapPattern(indexBody: string): string {
  const m = /Branching pattern:\s*`?(single_branch|branch_per_phase|branch_per_subphase)`?/.exec(indexBody);
  return m ? m[1] : "";
}

function countBranchMapRows(indexBody: string): number {
  const start = indexBody.indexOf("## Branch Map");
  if (start < 0) return 0;
  const end = indexBody.indexOf("\n## ", start + 1);
  const section = indexBody.slice(start, end < 0 ? undefined : end);
  // count rows that start with | and don't start with |---
  let n = 0;
  let headerSeen = false;
  for (const line of section.split("\n")) {
    if (/^\|\s*-+/.test(line)) { headerSeen = true; continue; }
    if (headerSeen && /^\|[^|]+\|/.test(line)) n++;
  }
  return n;
}

function validateGroup(groupRoot: string): string[] {
  const errors: string[] = [];
  const indexPath = join(groupRoot, "_INDEX.md");
  if (!existsSync(indexPath)) {
    errors.push(`${groupRoot}: missing _INDEX.md`);
    return errors;
  }

  let indexText: string;
  try {
    indexText = readFileSync(indexPath, "utf8");
  } catch (e) {
    return [`${indexPath}: cannot read (${String(e)})`];
  }
  const parsed = parseFrontmatter(indexText);
  if (!parsed) return [`${indexPath}: malformed frontmatter`];

  const indexBody = parsed.body;
  const phaseDirs = listPhaseDirs(groupRoot);
  const tableRows = parsePhasesTable(indexBody);

  // Every phase folder must have at least one plan file
  for (const pd of phaseDirs) {
    const files = listPhaseFiles(join(groupRoot, pd));
    if (files.length === 0) {
      errors.push(`${groupRoot}/${pd}/: phase folder has no NN_*.md files`);
    }
  }

  // Phases table top-level rows (non-sub-phase) match folder count
  const topLevelRows = tableRows.filter((r) => !r.phase.includes("."));
  if (topLevelRows.length !== phaseDirs.length) {
    errors.push(
      `${indexPath}: Phases table has ${topLevelRows.length} top-level row(s), but ${phaseDirs.length} NN/ folder(s) exist`
    );
  }

  // Each Plan link resolves
  for (const row of tableRows) {
    const linkTarget = join(groupRoot, row.link);
    if (!existsSync(linkTarget)) {
      errors.push(`${indexPath}: phase ${row.phase} Plan link \`${row.link}\` doesn't resolve`);
    }
  }

  // Branch Map row count per pattern
  const pattern = parseBranchMapPattern(indexBody);
  const branchRows = countBranchMapRows(indexBody);
  if (pattern === "single_branch" && branchRows !== 1) {
    errors.push(`${indexPath}: single_branch pattern should have 1 Branch Map row, found ${branchRows}`);
  }
  if (pattern === "branch_per_phase" && branchRows !== tableRows.length) {
    errors.push(
      `${indexPath}: branch_per_phase pattern should have ${tableRows.length} Branch Map rows (one per phase/sub-phase), found ${branchRows}`
    );
  }

  return errors;
}

const checked = new Set<string>();
const allErrors: string[] = [];
for (const arg of process.argv.slice(2)) {
  const root = findGroupRoot(arg);
  if (!root || checked.has(root)) continue;
  checked.add(root);
  allErrors.push(...validateGroup(root));
}

if (allErrors.length > 0) {
  logFail("plan group structure check failed:", allErrors);
  process.exit(1);
}
