/**
 * CI gate: enforce lifecycle rules for plan groups.
 *
 * Requires env: BASE_SHA, HEAD_SHA, PR_TITLE, PR_BODY
 *
 * Checks:
 *   1. PR title matches `<type>(<group>): <summary>` where group is pNNNNNN-slug.
 *   2. Groups set to `status: completed` have an archival commit in range.
 *   3. Archived groups linked in PR body.
 *   4. No modifications to changelog/.
 */

import { git, logFail } from "./_lib.ts";

const BASE = process.env.BASE_SHA ?? "";
const HEAD = process.env.HEAD_SHA ?? "HEAD";
const PR_TITLE = process.env.PR_TITLE ?? "";
const PR_BODY = process.env.PR_BODY ?? "";

const PR_TITLE_RE = /^(feat|fix|chore|refactor|docs|spike)\(p\d{6}-[a-z0-9][a-z0-9-]*\):\s+.+$/;

function groupsSetToCompleted(): string[] {
  if (!BASE) return [];
  const diff = git("diff", `${BASE}..${HEAD}`, "--", ".github/docs/plans/**/_INDEX.md");
  const slugs = new Set<string>();
  let current: string | null = null;
  for (const line of diff.split("\n")) {
    if (line.startsWith("+++ b/")) current = line.slice(6);
    if (current && /^\+status:\s*completed\s*$/.test(line)) {
      const m = /\.github\/docs\/plans\/([^/]+)\/_INDEX\.md$/.exec(current);
      if (m) slugs.add(m[1]);
    }
  }
  return [...slugs].sort();
}

function commitsInRange(): string[] {
  if (!BASE) return [];
  return git("log", "--format=%s", `${BASE}..${HEAD}`).split("\n").filter(Boolean);
}

function archivedGroups(): string[] {
  if (!BASE) return [];
  const out = git("diff", "--name-status", `${BASE}..${HEAD}`, "--", ".github/docs/changelog/");
  const groups = new Set<string>();
  for (const line of out.split("\n")) {
    if (!line) continue;
    const parts = line.split("\t");
    const status = parts[0]?.charAt(0) ?? "";
    const path = parts[parts.length - 1] ?? "";
    if ((status === "A" || status === "R")) {
      const m = /^\.github\/docs\/changelog\/(p\d{6}-[^/]+)\//.exec(path);
      if (m) groups.add(m[1]);
    }
  }
  return [...groups].sort();
}

function changelogModifications(): string[] {
  if (!BASE) return [];
  const out = git("diff", "--name-status", `${BASE}..${HEAD}`, "--", ".github/docs/changelog/");
  const bad: string[] = [];
  for (const line of out.split("\n")) {
    if (!line) continue;
    const parts = line.split("\t");
    const status = parts[0]?.charAt(0) ?? "";
    const path = parts[parts.length - 1] ?? "";
    if (status === "M") bad.push(path);
  }
  return bad;
}

const failures: string[] = [];

if (PR_TITLE && !PR_TITLE_RE.test(PR_TITLE)) {
  failures.push(`PR title must match \`<type>(pNNNNNN-slug): <summary>\` — got: ${JSON.stringify(PR_TITLE)}`);
}

const commits = commitsInRange();
for (const slug of groupsSetToCompleted()) {
  const expected = `chore(${slug}): archive plan group to changelog`;
  if (!commits.includes(expected)) {
    failures.push(`group \`${slug}\` set to \`status: completed\` but no archival commit \`${expected}\` in PR range`);
  }
}

for (const slug of archivedGroups()) {
  const link = `.github/docs/changelog/${slug}`;
  if (!PR_BODY.includes(link)) {
    failures.push(`PR body must reference \`${link}\` since this group was archived`);
  }
}

for (const path of changelogModifications()) {
  failures.push(`changelog is immutable; \`${path}\` was modified`);
}

if (failures.length > 0) {
  logFail("CI plan-gate failures:", failures);
  process.exit(1);
}
