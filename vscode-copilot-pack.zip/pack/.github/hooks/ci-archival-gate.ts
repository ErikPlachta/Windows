/**
 * CI gate: enforce lifecycle rules that can't be checked locally.
 *
 * Requires env: BASE_SHA, HEAD_SHA, PR_TITLE, PR_BODY
 *
 * Checks:
 *   1. PR title matches `<type>(<slug>): <summary>`.
 *   2. Plans set to `status: done` have an archival commit in the PR range.
 *   3. Archived plans are linked in the PR body.
 *   4. No modifications to .github/docs/changelog/.
 *
 * Exit: 0 pass, 1 fail.
 */

import { basename } from "node:path";
import { git, logFail } from "./_lib.ts";

const BASE = process.env.BASE_SHA ?? "";
const HEAD = process.env.HEAD_SHA ?? "HEAD";
const PR_TITLE = process.env.PR_TITLE ?? "";
const PR_BODY = process.env.PR_BODY ?? "";

const PR_TITLE_RE = /^(feat|fix|chore|refactor|docs|spike)\([a-z0-9][a-z0-9-]*\):\s+.+$/;

function plansSetToDone(): string[] {
  if (!BASE) return [];
  const diff = git(
    "diff",
    `${BASE}..${HEAD}`,
    "--",
    ".github/docs/plans/*.md",
    ".github/docs/changelog/*.md"
  );
  const slugs = new Set<string>();
  let currentFile: string | null = null;
  for (const line of diff.split("\n")) {
    if (line.startsWith("+++ b/")) currentFile = line.slice(6);
    if (currentFile && /^\+status:\s*done\s*$/.test(line)) {
      slugs.add(basename(currentFile, ".md"));
    }
  }
  return [...slugs].sort();
}

function commitsInRange(): string[] {
  if (!BASE) return [];
  return git("log", "--format=%s", `${BASE}..${HEAD}`).split("\n").filter(Boolean);
}

function archivedSlugs(): string[] {
  if (!BASE) return [];
  const out = git("diff", "--name-status", `${BASE}..${HEAD}`, "--", ".github/docs/changelog/*.md");
  const slugs: string[] = [];
  for (const line of out.split("\n")) {
    if (!line) continue;
    const parts = line.split("\t");
    const status = parts[0]?.charAt(0) ?? "";
    const path = parts[parts.length - 1] ?? "";
    if ((status === "A" || status === "R") && path.startsWith(".github/docs/changelog/") && path.endsWith(".md")) {
      slugs.push(basename(path, ".md"));
    }
  }
  return [...new Set(slugs)].sort();
}

function changelogModifications(): string[] {
  if (!BASE) return [];
  const out = git("diff", "--name-status", `${BASE}..${HEAD}`, "--", ".github/docs/changelog/");
  const bad: string[] = [];
  for (const line of out.split("\n")) {
    if (!line) continue;
    const parts = line.split("\t");
    const status = parts[0]?.charAt(0) ?? "";
    const path = parts[parts.length - 1] ?? "";
    if (status === "M") bad.push(path);
  }
  return bad;
}

const failures: string[] = [];

if (PR_TITLE && !PR_TITLE_RE.test(PR_TITLE)) {
  failures.push(`PR title must match \`<type>(<slug>): <summary>\` — got: ${JSON.stringify(PR_TITLE)}`);
}

const doneSlugs = plansSetToDone();
const commits = commitsInRange();
for (const slug of doneSlugs) {
  const expected = `chore(${slug}): archive plan to changelog`;
  if (!commits.includes(expected)) {
    failures.push(
      `plan \`${slug}\` was set to \`status: done\` but no archival commit \`${expected}\` found in this PR range`
    );
  }
}

for (const slug of archivedSlugs()) {
  const link = `.github/docs/changelog/${slug}.md`;
  if (!PR_BODY.includes(link)) {
    failures.push(`PR body must reference \`${link}\` since this plan was archived`);
  }
}

for (const path of changelogModifications()) {
  failures.push(`changelog is immutable; \`${path}\` was modified in this PR`);
}

if (failures.length > 0) {
  logFail("CI plan-gate failures:", failures);
  process.exit(1);
}
