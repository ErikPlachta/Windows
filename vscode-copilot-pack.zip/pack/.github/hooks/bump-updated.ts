/**
 * Pre-commit hook: auto-bump `Updated:` in staged plan files and _INDEX.md.
 * Uses ISO datetime (YYYY-MM-DD HH:mm:ss) to match the template.
 *
 * Exit: always 0.
 */

import { readFileSync, writeFileSync, existsSync } from "node:fs";
import { execFileSync } from "node:child_process";

function nowIso(): string {
  const d = new Date();
  const pad = (n: number) => String(n).padStart(2, "0");
  return `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())} ` +
    `${pad(d.getHours())}:${pad(d.getMinutes())}:${pad(d.getSeconds())}`;
}

const NOW = nowIso();
const UPDATED_RE = /^(Updated:\s*)(.*?)(\s*(?:#.*)?)$/m;

function bump(path: string): void {
  if (!existsSync(path)) return;
  const text = readFileSync(path, "utf8");
  const m = UPDATED_RE.exec(text);
  if (!m) return; // field not present; validator will flag
  // Trim any existing value (could be blank, a date, or a datetime)
  const currentVal = m[2].trim();
  if (currentVal === NOW) return;
  const next = text.replace(UPDATED_RE, `$1${NOW}$3`);
  writeFileSync(path, next, "utf8");
  execFileSync("git", ["add", path]);
  process.stdout.write(`[bump-updated] ${path}: Updated: -> ${NOW}\n`);
}

for (const arg of process.argv.slice(2)) bump(arg);
