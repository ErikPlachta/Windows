/**
 * Pre-commit hook: reject content modifications to .github/docs/changelog/.
 * New files (A, R via /planner-archive) are allowed.
 *
 * Exit: 0 pass, 1 fail.
 */

import { git, stagedStatus, logFail } from "./_lib.ts";

const CHANGELOG_ROOT = ".github/docs/changelog/";

function renameHasContentChange(path: string): boolean {
  const diff = git("diff", "--cached", "--", path);
  for (const line of diff.split("\n")) {
    if (line.startsWith("+++") || line.startsWith("---")) continue;
    if (line.startsWith("+") || line.startsWith("-")) return true;
  }
  return false;
}

const rejected: string[] = [];
for (const arg of process.argv.slice(2)) {
  if (!arg.startsWith(CHANGELOG_ROOT)) continue;
  const status = stagedStatus(arg);
  if (status === "A") continue;
  if (status === "R") {
    if (renameHasContentChange(arg)) {
      rejected.push(
        `${arg}: renamed into changelog/ WITH content changes — archive entries must match the original plan verbatim`
      );
    }
    continue;
  }
  if (status === "M" || status === "D") {
    rejected.push(`${arg}: ${status} — .github/docs/changelog/ is immutable`);
  }
}

if (rejected.length > 0) {
  logFail("changelog immutability check failed:", rejected);
  process.stderr.write(
    "\nTo amend an archived plan, open a new plan with /planner-new that references it in ## Context.\n"
  );
  process.exit(1);
}
