/**
 * commit-msg hook: enforce conventional commit format scoped to a plan slug.
 * Format: <type>(<slug>): <summary, <=72 chars>
 *
 * Exit: 0 pass, 1 fail.
 */

import { readFileSync } from "node:fs";

const SUBJECT_RE = /^(feat|fix|chore|refactor|docs|spike)\((p\d{6}-[a-z0-9][a-z0-9-]*|[a-z0-9][a-z0-9-]*)\):\s+(.+)$/;
const EXEMPT_PREFIXES = ["Merge ", "Revert ", "fixup!", "squash!", "amend!"];

const msgPath = process.argv[2];
if (!msgPath) process.exit(0);

let msg: string;
try {
  msg = readFileSync(msgPath, "utf8");
} catch {
  process.exit(0);
}

const lines = msg.split("\n").filter((ln) => !ln.startsWith("#"));
const subject = (lines[0] ?? "").replace(/\s+$/, "");
if (!subject) process.exit(0); // git handles empty
if (EXEMPT_PREFIXES.some((p) => subject.startsWith(p))) process.exit(0);

const m = SUBJECT_RE.exec(subject);
if (!m) {
  process.stderr.write("commit message format rejected:\n");
  process.stderr.write(`  got:      ${subject}\n`);
  process.stderr.write("  expected: <type>(<slug>): <summary>\n");
  process.stderr.write("  types:    feat, fix, chore, refactor, docs, spike\n");
  process.stderr.write("  slug:     kebab-case, e.g. auth-refactor\n");
  process.exit(1);
}

if (subject.length > 72) {
  process.stderr.write(`commit subject too long: ${subject.length} chars (max 72)\n  ${subject}\n`);
  process.exit(1);
}

const body = lines.slice(2);
body.forEach((ln, i) => {
  if (ln.length > 100) {
    process.stderr.write(`warning: line ${i + 3} is ${ln.length} chars (>100): ${ln.slice(0, 60)}...\n`);
  }
});
