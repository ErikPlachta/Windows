/**
 * Shared utilities for plan-workflow hooks.
 * Kept dependency-free — only Node built-ins.
 */

import { execFileSync } from "node:child_process";

/**
 * Minimal flat-YAML parser for our frontmatter schema.
 * Supports `key: value` lines only — no nesting, no lists, no multiline.
 * Adequate for plan/log frontmatter as defined by the schema.
 */
export interface Frontmatter {
  fields: Record<string, string>;
  body: string;
}

const FRONTMATTER_RE = /^---\s*\n([\s\S]*?)\n---\s*\n([\s\S]*)$/;

export function parseFrontmatter(text: string): Frontmatter | null {
  const m = FRONTMATTER_RE.exec(text);
  if (!m) return null;
  const [, fmText, body] = m;
  const fields: Record<string, string> = {};
  for (const rawLine of fmText.split("\n")) {
    const line = rawLine.replace(/\s*#.*$/, ""); // strip comments
    if (!line.trim()) continue;
    const idx = line.indexOf(":");
    if (idx < 0) continue;
    const key = line.slice(0, idx).trim();
    const value = line.slice(idx + 1).trim();
    fields[key] = value;
  }
  return { fields, body };
}

export function todayIso(): string {
  return new Date().toISOString().slice(0, 10);
}

export function isIsoDate(s: string): boolean {
  return /^\d{4}-\d{2}-\d{2}$/.test(s);
}

export function git(...args: string[]): string {
  try {
    return execFileSync("git", args, { encoding: "utf8" });
  } catch {
    return "";
  }
}

/**
 * Staged diff status for a single path. Returns single-letter: A, M, D, R, ""
 */
export function stagedStatus(path: string): string {
  const out = git("diff", "--cached", "--name-status", "-z", "--", path);
  if (!out) return "";
  return out.split("\0")[0]?.charAt(0) ?? "";
}

export function fileAtHead(path: string): string | null {
  try {
    return execFileSync("git", ["show", `HEAD:${path}`], { encoding: "utf8", stdio: ["ignore", "pipe", "ignore"] });
  } catch {
    return null;
  }
}

export function logFail(header: string, messages: string[]): void {
  process.stderr.write(`${header}\n`);
  for (const m of messages) {
    process.stderr.write(`  - ${m}\n`);
  }
}
