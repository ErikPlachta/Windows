---
description: "Archive a completed plan group: verify preconditions, git mv pNNNNNN-slug/ to changelog/, commit."
agent: planner-workflow
argument-hint: "<group>"
---

# /planner-archive

## Input
`<group>` — e.g., `p000001-auth-overhaul`.

## Preconditions (abort if any fail)
1. `.github/docs/plans/<group>/_INDEX.md` exists.
2. `_INDEX.md` `status: completed`.
3. Every phase in Phases table is `completed`.
4. Every phase plan file has `status: completed`.
5. Current branch is the integration branch (or group's single branch).
6. Working tree clean.

## Protocol

### 1. Update `_INDEX.md`
- Bump `Updated:`.
- Append archival entry to `changelog:` field.

### 2. Move group directory
```bash
git mv .github/docs/plans/<group>/ .github/docs/changelog/<group>/
```

Single `git mv` on the directory moves `_INDEX.md`, all phase folders, and `_RESEARCH/` in one operation.

### 3. Update stale links
```bash
grep -rn ".github/docs/plans/<group>" . --exclude-dir=.git
```
Update hits to `.github/docs/changelog/<group>`.

### 4. Close open session logs
Any open session/task logs referencing this group → handoff to `session-logger`, run `/log-session-close`.

### 5. Reset CURRENT.md
Set all fields to `(none)`.

### 6. Archive commit
```bash
git add -A
git commit -m "chore(<group>): archive plan group to changelog"
```

### 7. Report
- Archived: `.github/docs/changelog/<group>/`
- Next: open merge PR. Title: `<type>(<group>): <group goal>`. Description links `_INDEX.md` in changelog and lists completed phases.

## Rules
- Use single `git mv` on the directory, not per-file.
- Do not archive with incomplete phases.
- Do not archive from `main`.
- Post-archive: files under `changelog/<group>/` are immutable.
