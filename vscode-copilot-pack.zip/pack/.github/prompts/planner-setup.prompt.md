---
description: "Verify the pack is correctly installed and VS Code settings enable full workflow (handoffs, subagent invocation, instruction loading)."
agent: agent
---

# /planner-setup

One-time setup verification and guided fixes.

## Checks

### 1. Required VS Code settings
Read `.vscode/settings.json` (workspace) and report the status of each. If missing or `false`, show the JSON to add and wait for confirmation.

| Setting | Expected | Why |
| --- | --- | --- |
| `github.copilot.chat.codeGeneration.useInstructionFiles` | `true` | Loads `.github/copilot-instructions.md` |
| `chat.agentFilesLocations` | includes `".github/agents": true` | Discovers custom agents |
| `chat.instructionsFilesLocations` | includes `".github/instructions": true` | Auto-loads scoped rules |
| `chat.promptFilesLocations` | includes `".github/prompts": true` | Registers slash commands |
| `chat.includeApplyingInstructions` | `true` | Applies `applyTo` globs |
| `chat.includeReferencedInstructions` | `true` | Loads Markdown-linked rules from prompts |
| `chat.subagents.allowInvocationsFromSubagents` | `true` | **Lets agents hand off/invoke each other** |

The last one is critical for this pack — without it, `@agent-name` invocations from inside another agent's turn are blocked, breaking handoff-driven workflows.

### 2. Pack files present
Grep for required paths:
- `.github/copilot-instructions.md`
- `.github/agents/planner-workflow.agent.md` (and gpt4o, gpt4 variants)
- `.github/agents/planner-reviewer.agent.md`
- `.github/agents/planner-validator.agent.md`
- `.github/agents/session-logger.agent.md`
- `.github/instructions/*.instructions.md` (5 files)
- `.github/prompts/planner-*.prompt.md` (6 files)
- `.github/prompts/log-*.prompt.md` + `logs-cleanup.prompt.md`
- `.github/prompts/branch-*.prompt.md`
- `.github/docs/templates/*.template.md` (4 files)
- `.github/docs/README.md`
- `.pre-commit-config.yaml`, `package.json`, `tsconfig.json`

Report missing files. Do NOT attempt to create them — direct user to re-extract the pack.

### 3. Node + pre-commit installed
Check:
- `node --version` — need ≥ 20.
- `npx tsx --version` — tsx runnable.
- `pre-commit --version` — installed.
- `.git/hooks/pre-commit` exists — hook actually installed.

Print install commands for anything missing:
```bash
npm install
pip install pre-commit    # or: brew install pre-commit
pre-commit install
pre-commit install --hook-type commit-msg
```

### 4. Data directories exist
Check presence of:
- `.github/docs/plans/`
- `.github/docs/plans/research/`
- `.github/docs/changelog/`
- `.github/docs/changelog/research/`
- `.github/docs/logs/`

If missing, offer to `mkdir -p` them and add `.gitkeep`s.

### 5. Current-plan indicator
Check for `.github/docs/plans/CURRENT.md`. If missing, offer to create it from the template at `.github/docs/templates/current-plan.template.md`.

## Guided Fixes

For each failed check, offer:
1. Show the exact fix (setting JSON, install command, file path).
2. Wait for user confirmation.
3. Apply / run.
4. Re-check.

## Required Settings — Exact JSON to Add

If the workspace has no `.vscode/settings.json`, create it with:

```json
{
  "github.copilot.chat.codeGeneration.useInstructionFiles": true,
  "chat.agentFilesLocations": { ".github/agents": true },
  "chat.instructionsFilesLocations": { ".github/instructions": true },
  "chat.promptFilesLocations": { ".github/prompts": true },
  "chat.includeApplyingInstructions": true,
  "chat.includeReferencedInstructions": true,
  "chat.subagents.allowInvocationsFromSubagents": true
}
```

If the file exists, merge these keys without overwriting unrelated settings. Show the diff before writing.

## Final Output
After all checks pass:
```
Setup verified:
  ✓ 7/7 VS Code settings correct
  ✓ All pack files present
  ✓ Node 20+, pre-commit, tsx installed, hooks active
  ✓ Data directories exist
  ✓ Current-plan indicator: <active-slug> | (none)

Ready. Next: /planner-new to create your first plan, or /planner-work <slug> to resume one.
```

If anything failed and was fixed: recommend restarting VS Code so agent discovery picks up changes.

## Rules
- Show diffs before writing any file or setting.
- Never install npm/pip packages silently — user approves commands.
- Setting names come from current VS Code docs. If a newer VS Code renamed one, flag the mismatch and suggest checking `code.visualstudio.com/docs/copilot/customization/`.
