---
description: "Grill a plan group or phase plan for gaps, risks, and unstated assumptions."
agent: planner-reviewer
argument-hint: "<group> | <group>/<phase>"
---

# /planner-review

## Input
- `<group>` — review the whole group (`_INDEX.md` + all phases).
- `<group>/<phase>` — review a single phase plan.

## Protocol

1. Read target file(s) + any `_RESEARCH/` entries referenced.
2. Deliver round 1 in the reviewer format:
   ```
   Target: <group>[/<phase>] — review round 1
   Strengths: …
   Questions:
     1. <pointed question>
     2. <pointed question>
     3. <pointed question>
   Expected outputs: <concrete plan changes>
   ```
3. Wait for answers. Do not edit the plan.
4. Subsequent rounds until user says done or diminishing returns (2–3 rounds).

## Lenses
- Goal clarity, measurable "done"
- Task sufficiency & rollback
- Assumptions, external deps
- Risk & blast radius
- Branch-map sanity (for group review)
- Cross-phase dependencies (for group review)

## Rules
Ask, don't answer. Call out concrete tasks the user should add. User makes edits via `planner-workflow`.
