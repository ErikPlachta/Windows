---
description: "Re-sync Copilot Chat's todo list UI from a plan file. Plan file always wins."
agent: agent
argument-hint: "<slug>"
---

# /plan-sync-todos

Re-mirror a plan's `## Tasks` checklist into Copilot Chat's built-in todo UI.

## Input
`<slug>` — plan slug. Required.

## When to Use
- Starting a fresh chat session on an existing plan.
- UI and plan file have drifted.
- Tasks added/removed/reordered in the plan file outside `/plan-work`.

## Protocol

1. **Find the file**: `.github/docs/plans/<slug>.md`. If not found, check `.github/docs/changelog/<slug>.md` and report the plan is archived. Abort in that case.
2. **Parse tasks**: extract `- [ ] N. <text>` and `- [x] N. <text>` under `## Tasks`. Preserve numbering and order.
3. **Clear and re-mirror**: clear existing Chat UI todo list, add each task, mark completed ones done.
4. **Report**:
   - Plan: `.github/docs/plans/<slug>.md` (`status: <status>`)
   - Total tasks: `<N>` (`<checked>` complete, `<unchecked>` remaining)
   - Next unchecked: `<N>. <summary>`
   - Suggest: switch to `Plan Workflow` agent and run `/plan-work <slug>`.

## Rules
- Plan file always wins. Discard UI state not in the plan.
- Do not edit the plan file.
- Do not auto-invoke `/plan-work`.
