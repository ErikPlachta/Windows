---
description: "Re-sync Copilot Chat's todo UI from a phase plan's progress trackers and acceptance criteria."
agent: agent
argument-hint: "<group>/<phase>"
---

# /planner-sync-todos

## Input
`<group>/<phase>` — e.g., `p000001-auth-overhaul/02` or `.../02.1`.

## Protocol

1. Resolve phase plan file at `plans/<group>/<NN>/<phase>_*.md`. If not found, check `changelog/` and report archived. Abort if archived.
2. Parse three sources into a single ordered todo list:
   - `## Problem Statement(s)` → each `### Problem_N` acceptance criteria (`- [ ]` / `- [x]`)
   - `## Phased Implementation Steps` → each `### Sub-phase N` as a parent todo
   - `## End of Plan Strategies` progress tracker rows (Testing, Coverage, Documentation) — track by status, not checkbox
3. Clear Chat UI todo list. Re-populate in order: problem criteria → sub-phases → end-strategies.
4. Report: counts per section, next unchecked item.

## Rules
- Phase plan always wins.
- Do not edit the plan file.
- Do not auto-run `/planner-work`.
