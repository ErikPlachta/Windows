---
description: "Write a task execution log tied to a plan task and its parent session."
agent: Session Logger
argument-hint: "<slug> <task-number>"
---

# /log-task

Create a task execution log for a specific plan task.

## Inputs
- `<slug>` — plan slug.
- `<task-number>` — the task number from the plan's `## Tasks` list.

## Protocol

1. **Find the parent session** — most recent `status: open` session log for the acting agent. If none, prompt user to `/log-session-open` first.
2. **Read the task text** from `.github/docs/plans/<slug>.md` under `## Tasks`, line starting `- [ ] <N>.` or `- [x] <N>.`.
3. **Generate file path**: `.github/docs/logs/<agent-name>/<YYYY-MM-DD>-<session-ulid>-t<N>.task.md`.
4. **Create file** from `.github/docs/templates/task-log.template.md`.
5. **Fill frontmatter**:
   - `agent`, `session_id` (from parent session), `plan_slug`, `task_number`
   - `task_text` (verbatim from plan)
   - `started: <ISO>`, `ended:` blank, `commit:` blank, `status: open`
6. **Commit**: `docs(logs): open task log <slug>/<N>`.
7. **Report** the file path. Tell user to call `/log-task` again (or a close variant) when the task is complete.

## Closing a task log

If called with a task-log path argument OR the task is marked complete in the plan:
1. Set `ended: <ISO>`, `status: closed`.
2. Fill `commit:` with the SHA of the task's commit (from `git log`).
3. Fill `## Outcome` with a 1–3 sentence summary of what was done.
4. Commit: `docs(logs): close task log <slug>/<N>`.

## Rules
- Tie to a session via `session_id`. Do not create a task log without a parent session.
- Append-only body. Do not rewrite prior entries.
- Redact secrets with `<redacted>`.
