---
description: "Stress-test a plan by grilling the user about gaps, risks, and unstated assumptions before work begins."
agent: Plan Reviewer
argument-hint: "<slug>"
---

# /plan-review

Hand off to the Plan Reviewer agent to grill a plan.

## Input
`<slug>` — plan slug. Required.

## Protocol

1. Read `.github/docs/plans/<slug>.md` and any files under `.github/docs/plans/research/<slug>/`.
2. Optionally grep the codebase for relevant context.
3. Deliver round 1 of questions per the format in `.github/agents/plan-reviewer.agent.md`:

```
Plan: <slug> — review round 1

Strengths:
  - <what's solid>

Questions:
  1. <pointed question>
  2. <pointed question>
  3. <pointed question>

What I'd expect after this round:
  - <concrete improvement>
```

4. Wait for answers. Do NOT edit the plan yourself.
5. On user response, deliver round 2 if gaps remain. Continue until "done" or diminishing returns (usually 2–3 rounds).

## Rules
- Ask, don't answer.
- Don't edit the plan — the user does that via `Plan Workflow`.
- When you spot a gap that should become a task, say so explicitly: "Consider adding a task: <concrete task>."
