---
description: "Validate a plan's frontmatter, body structure, and cross-references. Report findings; fix only on approval."
agent: Plan Validator
argument-hint: "<slug> | all"
---

# /plan-validate

Validate plan structure against the schema.

## Input
- `<slug>` — validate a single plan.
- `all` — validate every file under `.github/docs/plans/*.md`.

## Checks

See `.github/agents/plan-validator.agent.md` for the full check list. Summary:

**Frontmatter**
- Required fields present.
- `status` ∈ {draft, active, blocked, done}.
- `completed:` iff `status: done`.
- `modified:` ≥ `created:`.
- `branch:` matches `<type>/<slug>`.
- `title` matches H1.
- Dates are ISO 8601.

**Body**
- H1 matches `title:`.
- Required headings present.
- Tasks use consistent checkbox format and sequential numbering.
- `## Outcome` empty unless `status: done`.

**Cross-references**
- Linked research paths exist.
- Amendment links resolve.

**Drift**
- `branch:` matches current git branch (warn).
- `modified:` ≤ last git commit date on the file (warn).
- `status: done` → all tasks checked.
- `status: done` → archival commit exists on branch.

## Output

```
Plan: <slug> (status: <status>)
  ✓ Frontmatter valid
  ✗ Body: missing `## Outcome` heading
  ⚠ Drift: modified is 2026-04-15, last commit was 2026-04-20
```

Legend: `✓` pass, `✗` fail, `⚠` warning.

End with: "Fix these? (y/n)". Fix only on explicit approval, per-finding. Show diff before applying.

## Rules
- Read-mostly. Never auto-fix.
- Never touch `.github/docs/changelog/`.
- If fixing, bump `modified:` in the same commit as the fixes.
