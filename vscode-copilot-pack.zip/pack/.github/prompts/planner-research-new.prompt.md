---
description: "Create a new phase-scoped research note with optional asset folder."
agent: planner-workflow
argument-hint: "<group>/<phase> <description>"
---

# /planner-research-new

## Inputs
1. **Group/phase** — e.g., `p000001-auth-overhaul/02`.
2. **Description** — kebab-case, short (e.g., `jwt-vs-sessions`).
3. **With assets?** (y/n) — whether to create a sibling asset folder.

## Protocol

### 1. Pre-flight
- `plans/<group>/_INDEX.md` exists (not archived).
- `plans/<group>/_RESEARCH/<NN>/` exists; create if missing.

### 2. Determine N.M prefix
Scan `plans/<group>/_RESEARCH/<NN>/` for existing `N.M_*.md` files matching phase N.

- `N` = phase number (`01` → `1`, `02` → `2`).
- `M` = max existing `.M` for that N + 1, starting at 1.

Result: `N.M_<description>.md` (e.g., `2.3_jwt-vs-sessions.md`).

### 3. Create research file
Copy `.github/docs/templates/p000000_TEMPLATE_PLAN/_RESEARCH/01/1.1_RESEARCH_TEMPLATE.md` to target path. Substitute:
- `title: "Research: <description>"`
- `phase: "<NN>"` (matching folder)
- `sub-phase: "<N.M>"` (prefix of this file)
- `status: draft`
- `created: <today ISO>`

### 4. (Optional) Create asset folder
If user said yes:
```bash
mkdir -p .github/docs/plans/<group>/_RESEARCH/<NN>/<N.M>_<description>
```
Add a `.gitkeep` so git tracks the empty folder.

### 5. Update `_INDEX.md`
- Bump `Updated:`.
- If `## Research` section has a file list, append the new entry.

### 6. Commit
```bash
git add .github/docs/plans/<group>/_RESEARCH/<NN>/ .github/docs/plans/<group>/_INDEX.md
git commit -m "docs(<group>): research on <phase>/<description>"
```

### 7. Report
Path to new file, asset folder (if created), suggestion to open it and fill in Summary + Key Findings.

## Rules
- Prefix `N.M_` must match file. Asset folder name MUST match file name minus `.md`.
- Description is kebab-case, no spaces, no date suffix.
- Do not create research under `_RESEARCH/` root; always in `<NN>/` subfolder.
