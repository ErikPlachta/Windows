---
description: "Create and checkout a plan branch with the correct naming convention."
agent: agent
argument-hint: "<slug> [type]"
---

# /branch-new

Create a branch for an existing plan.

## Inputs
- `<slug>` — plan slug. Required.
- `[type]` — `feat` | `fix` | `chore` | `refactor` | `docs` | `spike`. If omitted, read from plan's `branch:` field.

## Protocol

1. **Read plan file** at `.github/docs/plans/<slug>.md`. Extract `branch:` if present.
2. **Determine branch name**:
   - If plan has `branch:` set → use it.
   - Else construct `<type>/<slug>` (prompt for type if needed).
3. **Pre-flight**:
   - Branch does not already exist (`git rev-parse --verify <branch>` fails).
   - Working tree is clean.
   - Current branch is `main` or the declared base.
4. **Create and checkout**:
   ```bash
   git checkout -b <type>/<slug>
   ```
5. **Update plan's `branch:` field** if it was blank. Bump `modified:` in the same commit: `chore(<slug>): set plan branch`.
6. **Report** the new branch and remind user of the commit format from `.github/instructions/commit-messages.instructions.md`.

## Rules
- Never overwrite an existing branch.
- Never leave plan `branch:` field and actual branch out of sync.
