---
description: "Close an open session log: set ended, fill Outcome, flip status."
agent: Session Logger
argument-hint: "[session-id | agent-name]"
---

# /log-session-close

Close an open session log.

## Inputs
- `session-id` or `agent-name` — which session to close. If omitted, list open sessions and ask.

## Protocol

1. **Find the open session**:
   - If `session-id` given, grep `.github/docs/logs/**/*.session.md` for `session_id: <id>`.
   - If `agent-name` given, find most recent `status: open` file under that agent's folder.
   - If neither, list all `status: open` sessions across agents and ask.
2. **Abort** if already `closed` or `aborted`.
3. **Fill `## Outcome`** — ask user for 2–4 sentences on what shipped, what's pending, follow-up.
4. **Update frontmatter**:
   - `ended: <ISO with TZ>`
   - `status: closed`
5. **Commit**: `docs(logs): close session <ulid-short>`.
6. **Report** the file path and closing summary.

## Aborted sessions

If the user says the session ended abnormally (crash, interrupt, context loss):
- Use `status: aborted` instead of `closed`.
- `## Outcome` should note the abort reason.
- Commit message: `docs(logs): abort session <ulid-short>`.

## Rules
- Append-only. Preserve the full `## Timeline`, `## Decisions`, etc.
- Never leave a session `open` past its end.
- One session = one close.
