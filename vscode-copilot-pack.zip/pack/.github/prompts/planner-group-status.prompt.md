---
description: "Report a plan group's state: phase completion, branch map drift, open sessions, next action."
agent: planner-validator
argument-hint: "[group]"
---

# /planner-group-status

## Input
- `<group>` — report on one group.
- (empty) — read CURRENT.md, report on the active group; if none, list all groups.

## Protocol

1. Read `_INDEX.md`.
2. Read each phase plan's frontmatter (`status`, `Branch`, `Updated`).
3. Run `git branch --list` to check which phase branches exist locally.
4. Scan `.github/docs/logs/*/` for open sessions referencing this group.
5. Scan `_RESEARCH/NN/` for research files: count per phase, status breakdown, asset folders.
6. Check for drift:
   - Phase folder count vs Phases table row count
   - Each phase's `Branch:` vs Branch Map
   - `_INDEX.md` group status vs phase status rollup
   - Research files referenced from phase plan bodies exist
   - Asset folders share prefix with their owning research file

## Output

```
Group: <group>
  Status:           <status>
  Pattern:          <single_branch | branch_per_phase | branch_per_subphase>
  Integration:      <branch>
  Base:             <base_branch>
  Updated:          <ISO>

Phases:
  01 completed    feat/<group>-01-<desc>      Updated 2026-04-22
  02 in_progress  feat/<group>-02-<desc>      Updated 2026-04-23   <-- current
  02.1 not_started feat/<group>-02.1-<desc>
  03 not_started  (branch not created yet)

Research:
  01/ 2 files (1 draft, 1 finalized), 1 asset folder
  02/ 1 file (draft), 0 asset folders

Drift: none

Open sessions:
  planner-workflow/2026-04-23-01JC.session.md (2h ago)

Next action: /planner-work <group>/02.1
```
