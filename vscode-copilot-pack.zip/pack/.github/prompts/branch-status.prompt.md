---
description: "Report current branch, its plan, and any drift between them."
agent: agent
---

# /branch-status

Report the current working state.

## Protocol

1. **Git state**:
   - `git rev-parse --abbrev-ref HEAD` → current branch
   - `git status --porcelain` → staged/unstaged
   - `git log -1 --format='%h %s'` → last commit

2. **Read current-plan indicator**: `.github/docs/plans/CURRENT.md`. Note `slug:`, `current_task:`, `last_touched:`.

3. **Find associated plan**:
   - Parse current branch as `<type>/<slug>`.
   - Look for `.github/docs/plans/<slug>.md`. If not found, check `.github/docs/changelog/<slug>.md`.
   - If neither, report "no plan associated with this branch" and stop.

4. **Plan state**: read frontmatter `status`, `modified`, count of checked/unchecked tasks.

5. **Drift checks**:
   - Plan `branch:` field matches actual branch?
   - `CURRENT.md` `slug:` matches branch slug?
   - `modified:` within last N commits on this branch?
   - If `status: done`, is there an archival commit on this branch? (`chore(<slug>): archive plan to changelog`)

6. **Open sessions**:
   - Scan `.github/docs/logs/*/` for any `status: open` sessions. Flag if stale (>24h).

## Output

```
Branch: refactor/auth-refactor
Last commit: a1b2c3d feat(auth-refactor): extract token validator
Working tree: clean

Plan: auth-refactor
  Location: .github/docs/plans/auth-refactor.md
  Status: active
  Modified: 2026-04-22
  Tasks: 3/7 complete
  Next: Task 4 — Add unit tests for validator

Drift: none detected

Open sessions:
  planner-workflow/2026-04-22-01JC7ZABC.session.md (started 2h ago — ok)
```

## Rules
- Read-only. Never modify anything.
- Suggest next action at the end: `/planner-work <slug>`, `/planner-archive <slug>`, `/log-session-close`, etc.
