---
description: "Add a sub-phase (NN.M) to an existing phase. Sub-phase plans sit in the parent phase folder."
agent: planner-workflow
argument-hint: "<group>/<phase> [subphase-title]"
---

# /planner-subphase-new

## Inputs
1. **Group/phase** — e.g., `p000001-auth-overhaul/02`.
2. **Sub-phase title**, **description**, **type**.

## Protocol

### 1. Pre-flight
- Parent phase folder exists: `plans/<group>/NN/`.
- Parent phase plan exists: `plans/<group>/NN/NN_*.md`.
- `_INDEX.md` exists.

### 2. Determine sub-phase number
Scan `plans/<group>/NN/` for existing `NN.M_*.md`; new sub-phase `M` = max + 1 starting at 1.

### 3. Create sub-phase plan
Write to `plans/<group>/NN/NN.M_<desc>_<YYYYMMDD>.md`. Use phase template; set:
- `phase: NN.M`
- `group: <group>`
- H1: `# Sub-phase NN.M: <title>`

### 4. Create sub-phase research folder (optional)
```bash
mkdir -p .github/docs/plans/<group>/_RESEARCH/NN
```
Sub-phases share the phase's research folder; create topic files with `NN.M_` prefix if needed.

### 5. Sub-phase branch (if pattern = `branch_per_subphase`)
```bash
git checkout <type>/<group>-NN-<parent-desc>
git checkout -b <type>/<group>-NN.M-<desc>
```
Set `Branch:` and `Base Branch:` accordingly.

### 6. Update `_INDEX.md`
- Add row to Phases table with phase `NN.M`.
- Add row to Branch Map.
- Bump `Updated:`.

### 7. Update parent phase plan
Add a `### Sub-phase NN.M` reference in the parent's `## Phased Implementation Steps` pointing at the new file.

### 8. Update CURRENT.md
Set `phase: NN.M`, update `plan_file` and `branch`.

### 9. Commit
```bash
git commit -m "chore(<group>): add sub-phase NN.M <desc>"
```
