---
description: "Validate a plan group: _INDEX consistency, phase filename conventions, branch map drift, frontmatter schema."
agent: planner-validator
argument-hint: "<group> | all"
---

# /planner-validate

## Input
- `<group>` — validate one group.
- `all` — validate every group under `plans/`.

## Checks

### _INDEX.md
- Required frontmatter fields present.
- `status` ∈ {not_started, in_progress, completed, deferred, pending_review, canceled}.
- `Updated:` ≥ `Created:`.
- Phases table row count == number of `NN/` folders.
- Each Phases row's `Plan` link resolves to an existing file.
- Branch Map row count matches Phases count (for `branch_per_phase`) or is 1 (for `single_branch`).
- Group status rolls up correctly from phase statuses.

### Phase folders
- Folder names: `NN/` zero-padded two digits.
- Each phase folder contains at least one `NN_*.md`.
- Filenames match `^(NN|NN\.M)_[a-z0-9-]+_\d{8}\.md$`.
- Sub-phase files (`NN.M_*`) have matching `NN_` parent plan in the same folder.

### Phase plan frontmatter
- All required fields present.
- `status` in vocabulary. No emoji anywhere.
- `group:` matches parent directory.
- `phase:` matches folder (and filename prefix).
- `Branch:` matches current branch OR is set (warn if divergent).
- H1 format: `# Phase NN: <title>` or `# Sub-phase NN.M: <title>`.
- `completed` plans have all progress-tracker rows showing `completed`.

### Phase plan body
- All required sections present in order.
- `## Session State` table has all 5 fields.
- `## Problem Statement(s)` has ≥ 1 Problem_N with acceptance criteria.
- `## Tasks` has all three sub-sections with required progress tracker tables.

### Research
- Files under `_RESEARCH/NN/` match `N.M_*.md` pattern.
- Asset folders (`N.M_*/`) share prefix with their owning file AND have matching description.
- Frontmatter has `phase`, `sub-phase`, `status`, `created`.
- `phase:` frontmatter matches parent `NN/` folder.
- `sub-phase:` frontmatter matches filename `N.M_` prefix.
- Research files referenced from phase plans (e.g., `_RESEARCH/01/1.1_topic.md` links in plan body) actually exist.

### Branch Map drift
- For each phase: `_INDEX.md` Branch Map entry matches phase plan's `Branch:` field.

## Output

```
Group: <group> (status: <status>)
  _INDEX:
    ✓ frontmatter valid
    ✗ Phases table has 3 rows but 4 NN/ folders exist
  Phase 01:
    ✓ naming
    ⚠ Branch Map says feat/X, phase plan Branch: is feat/Y
  Research:
    ✗ 1.1_topic.md missing `phase:` frontmatter
```

End with: "Fix these? (y/n)". Fix only on approval, per finding.
