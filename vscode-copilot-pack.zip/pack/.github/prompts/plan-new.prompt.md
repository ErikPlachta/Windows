---
description: "Scaffold a new plan: gather inputs, create branch, scaffold plan file from template, make scaffold commit."
agent: agent
argument-hint: "[slug]"
---

# /plan-new

Scaffold a new plan and its branch.

## Inputs to Gather
Ask one at a time if not provided:
1. **Slug** — `kebab-case`, short, stable.
2. **Title** — human-readable, mirrors the plan's H1.
3. **Type** — `feat` | `fix` | `chore` | `refactor` | `docs` | `spike`.
4. **Author** — default to the current git user (`git config user.name`).
5. **Ticket number** — optional; blank if none.

## Protocol
Show a diff before any write. Wait for approval at each step.

### 1. Pre-flight
- Current branch is `main` (or the agreed base). If not, warn and confirm.
- No file exists at `.github/docs/plans/<slug>.md` or `.github/docs/changelog/<slug>.md`. If either does, abort.
- Working tree is clean. If not, ask user to stash or commit first.

### 2. Create branch
```bash
git checkout -b <type>/<slug>
```

### 3. Create plan file
Copy `.github/docs/templates/plan.template.md` to `.github/docs/plans/<slug>.md`, substituting:
- `<TITLE>` → user-supplied title
- `<AUTHOR>` → user
- `<TYPE>/<SLUG>` → branch name
- `<TICKET>` → ticket or blank
- `<TODAY>` → today's ISO date in both `created:` and `modified:`

See the authoritative schema at `.github/instructions/plan-authoring.instructions.md`.

### 4. Scaffold commit
```bash
git add .github/docs/plans/<slug>.md
git commit -m "chore(<slug>): scaffold plan"
```

### 5. Mirror to Chat todo UI
If any initial tasks were provided, load them. Otherwise tell the user: "Plan scaffolded. Fill in `## Goal` and add tasks, then run `/plan-work <slug>`."

### 6. Suggest next step
- If the user hasn't used the Plan Reviewer yet: "Want me to hand off to `Plan Reviewer` to stress-test the plan before work begins?"
- Otherwise: "Ready. Run `/plan-work <slug>` when tasks are filled in."
