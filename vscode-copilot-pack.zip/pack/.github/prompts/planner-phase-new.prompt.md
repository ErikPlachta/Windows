---
description: "Add a new phase to an existing plan group. Creates NN/ folder, phase plan, optional phase branch, updates _INDEX.md."
agent: planner-workflow
argument-hint: "<group-slug> [phase-title]"
---

# /planner-phase-new

## Inputs
1. **Group slug** — e.g., `p000001-auth-overhaul`.
2. **Phase title** — short.
3. **Phase description** — one sentence.
4. **Type** — `feat` | `fix` | `chore` | `refactor` | `docs` | `spike`.

## Protocol

### 1. Pre-flight
- `.github/docs/plans/<group>/_INDEX.md` exists (not archived).
- Read `_INDEX.md` branching pattern and integration branch.
- Working tree clean.

### 2. Determine phase number
Scan `plans/<group>/` for existing `NN/` folders; new phase = max + 1, zero-padded.

### 3. Create folders
```bash
mkdir -p .github/docs/plans/<group>/NN
mkdir -p .github/docs/plans/<group>/_RESEARCH/NN
```

### 4. Create phase plan
Copy `.github/docs/templates/p000000_TEMPLATE_PLAN/01/01_PLAN_TEMPLATE.md` to `plans/<group>/NN/NN_<desc>_<YYYYMMDD>.md`. Substitute placeholders. Set `group:` and `phase:`.

### 5. Create phase branch (if pattern calls for it)
- `single_branch` — no new branch; use the group's existing branch.
- `branch_per_phase` — `git checkout -b <type>/<group>-NN-<desc>` from `integration/<group>`.
- `branch_per_subphase` — same as branch_per_phase for top-level phases.

Update phase plan's `Branch:` and `Base Branch:`.

### 6. Update `_INDEX.md`
- Append phase row to Phases table.
- Append row to Branch Map.
- Bump `Updated:`.

### 7. Update CURRENT.md
Point at the new phase.

### 8. Commit
```bash
git add .github/docs/plans/<group>/NN/ .github/docs/plans/<group>/_INDEX.md .github/docs/plans/<group>/_RESEARCH/NN/ .github/docs/plans/CURRENT.md
git commit -m "chore(<group>): add phase NN <desc>"
```

### 9. Report
Path to new phase, branch, next step (`/planner-work <group>/NN`).
