---
description: "Audit and clean up logs: close orphaned open sessions, compact old logs, report statistics."
agent: session-logger
argument-hint: "[--close-stale | --compact <days> | --report]"
---

# /logs-cleanup

Maintenance for `.github/docs/logs/`.

## Modes

### `--report` (default)
Audit only — no writes. Output:

```
.github/docs/logs/ summary:
  Agents tracked: <N>
  Total sessions: <N>  (open: X, closed: Y, aborted: Z)
  Total task logs:  <N>
  Oldest open session: <agent>/<ulid> started <ISO> — STALE if > 24h
  Oldest file: <path> (<date>)
  Disk size: <human>
```

### `--close-stale`
Close sessions with `status: open` and `started:` older than 24h (configurable). For each:
1. Set `status: aborted`.
2. Set `ended:` to the file's last git-modified timestamp.
3. Append to `## Outcome`: `Closed by /logs-cleanup — no explicit close recorded.`
4. Commit: `docs(logs): abort stale sessions (<N> closed)`.

Show the list before writing. Require approval.

### `--compact <days>`
For sessions `closed`/`aborted` older than `<days>`:
1. Move to `.github/docs/logs/<agent>/_archive/<YYYY-QN>/<filename>` (quarterly buckets).
2. Use `git mv` to preserve history.
3. Single commit: `docs(logs): compact logs older than <days> days (<N> files)`.

Show the list before moving. Require approval.

## Rules
- Never delete log files. Compaction is move-only.
- Never edit closed/aborted sessions in place except to mark them aborted under `--close-stale`.
- Do not touch logs currently referenced by an active plan's `## Context`.
- Archived logs (`_archive/`) are still readable; only the layout changes.

## Defaults
- Stale threshold: 24h.
- Default compact window: 90 days.
- Configurable via prompt args or by asking user interactively.
