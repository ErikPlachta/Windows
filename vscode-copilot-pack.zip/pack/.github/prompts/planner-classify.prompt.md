---
description: "Grade a request to decide if it's a new plan group, a new phase in an existing group, or a sub-phase. Returns a recommendation; user decides."
agent: planner-reviewer
argument-hint: "<describe the work>"
---

# /planner-classify

Decide the correct shape for incoming work.

## Grading Rubric

Score the request across these signals. Report each:

1. **Concern count** — how many distinct subsystems/layers does it touch? (1 / 2 / 3+)
2. **Estimated effort** — rough: <1d / 1-3d / >3d / >1w
3. **Phase boundaries** — are there natural research → design → build → migrate boundaries? (yes / no)
4. **Parallelizable?** — can parts ship independently? (yes / no)
5. **Flat task count** — if written as a flat list, how many tasks? (<5 / 5-10 / >10)
6. **Amends existing group?** — is this additional work on an existing plan group? (group slug / no)

## Recommendation

- **New phase in existing group** — `#6` names a group AND the work fits a new phase boundary → `/planner-phase-new <group>`.
- **New sub-phase in existing phase** — `#6` names a group AND current phase is in-progress AND the work is a natural fork of it → `/planner-subphase-new <group> <phase>`.
- **New plan group** — all new work, especially if #1 ≥ 2, #2 ≥ 1-3d, #3 yes, or #5 > 10 → `/planner-group-new`.

**There is no "simple plan" option.** All work is organized as plan groups with phases. Small work = single-phase group.

## Output

```
Classification for: "<user's request>"

Signals:
  Concerns:          <count>   - <list them>
  Effort:            <range>
  Phase boundaries:  <yes/no>  - <which>
  Parallelizable:    <yes/no>
  Flat task count:   <range>
  Extends group:     <slug or no>

Recommendation: <command>

Reasoning: <1-2 sentences>

Proceed? (y/n)
```

Wait for user confirmation. If `y`, hand off to the recommended command's agent. If `n`, ask what they'd prefer.

## Rules
- Do not scaffold anything in this prompt — only classify and recommend.
- If the user asks "just make it simple", still create a single-phase group. That is the simple case.
