---
description: "Open a new session log file for the current agent."
agent: session-logger
argument-hint: "[plan-slug]"
---

# /log-session-open

Create a new session log.

## Inputs
- `plan-slug` (optional) — scope the session to a plan.

## Protocol

1. **Determine agent name** — ask user which agent is driving, or infer from context. Kebab-case.
2. **Generate ULID** (fallback: `<ISO-datetime>-<6-random-alnum>`).
3. **Ensure directory exists**: `.github/docs/logs/<agent-name>/`.
4. **Create file** at `.github/docs/logs/<agent-name>/<YYYY-MM-DD>-<ulid>.session.md` from `.github/docs/templates/session-log.template.md`.
5. **Fill frontmatter**:
   - `agent`, `session_id`, `model` (ask if unclear), `started` (ISO with TZ)
   - `plan_slug` if provided
   - `branch` from `git rev-parse --abbrev-ref HEAD`
   - `status: open`, `ended:` blank
6. **Fill `## Intent`** — ask user for a one-sentence description of what they're about to do.
7. **Commit**: `docs(logs): open session <ulid-short>` where `<ulid-short>` is last 6 chars of ULID.
8. **Report** the file path and session ID. Tell user the log is append-only and will be closed via `/log-session-close`.

## Rules
- Do not open a duplicate open session for the same agent+day unless the user explicitly requests it.
- If an open session already exists, report it and ask whether to close it first.
