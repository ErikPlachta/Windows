---
description: "Work a plan: mirror tasks to Chat UI, execute the lowest unchecked task, commit, stop."
agent: Plan Workflow
argument-hint: "<slug>"
---

# /plan-work

Execute one task of an active plan, then stop.

## Input
`<slug>` — plan slug. Required.

## Pre-flight
1. Confirm `.github/docs/plans/<slug>.md` exists. If not, abort and suggest `/plan-new`.
2. Read the plan file in full. Print: `title`, `status`, current `modified:`, counts of checked/unchecked tasks.
3. Confirm current branch matches plan's `branch:` field. If not, offer `git checkout`.
4. If no open session log exists for this agent today, suggest `/log-session-open` first.

## Sync
Mirror the plan's `## Tasks` into Copilot Chat's built-in todo UI. Plan file is source of truth. Re-sync if drifted.

## Execute One Task (DO NOT chain)

1. **Pick** the lowest-numbered unchecked task. Restate in one sentence.
2. **Work**:
   - Research / decision → write to `.github/docs/plans/research/<slug>/<topic>.md`.
   - Code change → edit source. Show diff before applying.
   - Command → run in terminal. Show command first.
3. **Update plan file** in one diff: check the box, append a result note if non-obvious, bump `modified:` to today.
4. **Update Chat UI** todo.
5. **Commit** per `.github/instructions/commit-messages.instructions.md`. Checkbox + `modified:` bump ride with task's code in same commit. Research → separate `docs(<slug>): research on <topic>` commit.
6. **Log** (optional but recommended for substantive tasks): handoff to `Session Logger` and run `/log-task <slug> <N>`.
7. **Stop.** Output verbatim: `Task <N> complete. Next: Task <N+1> — <summary>. Proceed?` Wait for confirmation.

## On Plan Completion

If all boxes are now checked: do NOT archive automatically. Tell user: "All tasks complete. Review the plan, set `status: done`, then run `/plan-archive <slug>`."

Consider suggesting `/plan-validate <slug>` before archival.
