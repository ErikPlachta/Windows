---
description: "Scaffold a new plan group: directory pNNNNNN-slug/, _INDEX.md, first phase 01/, research skeleton, branch(es), scaffold commit."
agent: planner-workflow
argument-hint: "[slug]"
---

# /planner-group-new

Scaffold a new plan group.

## Inputs
1. **Slug** — kebab-case, short. Becomes `pNNNNNN-slug`.
2. **Title** — human-readable group title.
3. **Branching pattern** — `single_branch` | `branch_per_phase` | `branch_per_subphase`.
4. **Base branch** — usually `main` or `develop`.
5. **First phase title** and short description.
6. **First phase type** — `feat` | `fix` | `chore` | `refactor` | `docs` | `spike`.
7. **Author**, **ticket_number** (optional).

## Protocol
Show a diff before any write. Confirm each step.

### 1. Determine group number
- Scan `.github/docs/plans/p*/` and `.github/docs/changelog/p*/` for the highest `pNNNNNN` prefix.
- New group = highest + 1, zero-padded: `p000001`, `p000002`, ..., `p10`.

### 2. Pre-flight
- No folder exists at `.github/docs/plans/pNNNNNN-<slug>/` or `.github/docs/changelog/pNNNNNN-<slug>/`.
- Working tree clean.
- Current branch is `base_branch`.

### 3. Create integration branch (if pattern != single_branch)
```bash
git checkout -b integration/pNNNNNN-<slug>
```
For `single_branch`: create the group's single branch directly: `<type>/pNNNNNN-<slug>`.

### 4. Create group directory
```bash
mkdir -p .github/docs/plans/pNNNNNN-<slug>/01
mkdir -p .github/docs/plans/pNNNNNN-<slug>/_RESEARCH/01
```

### 5. Write `_INDEX.md`
Copy `.github/docs/templates/p000000_TEMPLATE_PLAN/_INDEX.md` to `plans/pNNNNNN-<slug>/_INDEX.md`. Substitute:
- Title, description
- `status: not_started`
- `integration_branch:` (or blank for `single_branch`)
- `base_branch:`
- `Created:`, `Updated:` → now datetime
- `Author:`
- `version: 0.1.0`
- Phases table: one row for phase 01 with placeholder filename
- Branch Map table: populated per pattern

### 6. Create first phase plan
Copy the phase template to `plans/pNNNNNN-<slug>/01/01_<first-phase-desc>_<YYYYMMDD>.md`. Substitute all `{{PLACEHOLDERS}}` per the authoritative schema (`.github/instructions/plan-authoring.instructions.md`).

### 7. Create phase branch (for `branch_per_phase` / `branch_per_subphase`)
```bash
git checkout integration/pNNNNNN-<slug>    # if not already
git checkout -b <type>/pNNNNNN-<slug>-01-<first-phase-desc>
```
Update the phase plan's `Branch:` field accordingly.

### 8. Update `_INDEX.md` Phases table
Set phase 01 row's filename to the actual created file. Set Branch Map row's branch to the actual branch.

### 9. Update CURRENT.md
```
group: pNNNNNN-<slug>
phase: 01
plan_file: .github/docs/plans/pNNNNNN-<slug>/01/01_<desc>_<YYYYMMDD>.md
branch: <current branch>
last_touched: <now ISO>
```

### 10. Scaffold commit
```bash
git add .github/docs/plans/pNNNNNN-<slug>/ .github/docs/plans/CURRENT.md
git commit -m "chore(pNNNNNN-<slug>): scaffold plan group"
```

### 11. Report
- Group: `pNNNNNN-<slug>` at `.github/docs/plans/pNNNNNN-<slug>/`
- Phase 01: `<path>`
- Branch(es) created: `<list>`
- Next: run `/planner-work pNNNNNN-<slug>/01` after filling in Goal and Tasks.
