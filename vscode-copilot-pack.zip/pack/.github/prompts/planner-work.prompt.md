---
description: "Work a phase plan: read _INDEX + phase plan, execute the lowest unchecked task, commit, stop."
agent: planner-workflow
argument-hint: "<group>/<phase>"
---

# /planner-work

## Input
`<group>/<phase>` — e.g., `p000001-auth-overhaul/02` or `p000001-auth-overhaul/02.1`.

## Pre-flight
1. Resolve the phase plan file under `plans/<group>/<NN>/` matching `<phase>_*.md` (or `<NN>/<NN.M>_*.md` for sub-phases).
2. Read `plans/<group>/_INDEX.md` — pattern, integration branch, phase status.
3. Read the phase plan in full.
4. Confirm current branch matches phase plan's `Branch:`. Offer `git checkout` if not.
5. If no open session log exists, suggest `/log-session-open`.

## Sync
Mirror phase plan's `## Phased Implementation Steps` sub-phase checklist AND the per-sub-phase task lists into Copilot Chat's todo UI. Plan file always wins.

## Execute One Task (DO NOT chain)

1. **Pick** the lowest unchecked acceptance criterion or sub-phase task. Restate in one sentence.
2. **Update CURRENT.md**: bump `last_touched:`.
3. **Update phase plan `## Session State`**: set `Last Action` (previous), `Next Action`, `Current Sub-phase`.
4. **Work**:
   - Research → write to `plans/<group>/_RESEARCH/<NN>/<N.M>_<desc>.md`.
   - Code → edit source, show diff.
   - Command → show, run.
5. **Update phase plan** in one diff: check the box, bump `Updated:`, append to `changelog:` if substantive.
6. **Update `_INDEX.md`** `Updated:` + phase row status if it changed.
7. **Commit** per `commit-messages.instructions.md`. Plan + `_INDEX.md` + CURRENT.md updates ride with task code. Research → separate commit.
8. **Stop.** Output: `Task <N> complete in phase <phase>. Next: <summary>. Proceed?`

## On Phase Completion
All tasks checked in this phase:
1. Set phase plan `status: completed`.
2. Update `_INDEX.md` Phases table row to `completed`.
3. Tell user: "Phase <phase> complete. Next: `/planner-phase-new <group>` for next phase, or `/planner-archive <group>` if this was the last phase."

Do NOT auto-advance to the next phase.

## On Group Completion
All phases `completed` → set `_INDEX.md` `status: completed`. Suggest `/planner-archive <group>`.
