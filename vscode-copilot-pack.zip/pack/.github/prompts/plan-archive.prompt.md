---
description: "Archive a completed plan: verify preconditions, fill Outcome, git mv to changelog, commit."
agent: Plan Workflow
argument-hint: "<slug>"
---

# /plan-archive

Archive a completed plan.

## Input
`<slug>` — plan slug. Required.

## Preconditions (ALL must pass — abort if any fail)
1. `.github/docs/plans/<slug>.md` exists.
2. Every task in `## Tasks` is checked.
3. Frontmatter `status: done`. If not, prompt: "Set `status: done` first?"
4. Current branch matches plan's `branch:` field.
5. Working tree is clean.

If any fails, print which and stop.

## Protocol
Show a diff before each step.

### 1. Update frontmatter
- `status: done`
- `completed: <today ISO>`
- `modified: <today ISO>`

### 2. Fill `## Outcome`
Prompt user for, or draft and confirm:
- 2–4 sentences summarizing what shipped.
- PR link(s).
- Any follow-up plans spawned.

### 3. Move files
```bash
git mv .github/docs/plans/<slug>.md .github/docs/changelog/<slug>.md
```

If research exists:
```bash
git mv .github/docs/plans/research/<slug>/ .github/docs/changelog/research/<slug>/
```

Use `git mv`, not delete + create. Preserves history.

### 4. Update stale links
```bash
grep -rn ".github/docs/plans/<slug>" . --exclude-dir=.git
```

For each hit, update path to `.github/docs/changelog/<slug>` and stage.

### 5. Close any open session logs
If there are open session logs under `.github/docs/logs/<agent>/` for this plan, handoff to `Session Logger` and run `/log-session-close` before archival commit.

### 6. Archive commit
```bash
git add -A
git commit -m "chore(<slug>): archive plan to changelog"
```

### 7. Report
- Archived: `.github/docs/changelog/<slug>.md`
- Commit: `chore(<slug>): archive plan to changelog`
- Next: open the merge PR. Title: `<type>(<slug>): <plan goal>`. Description links the changelog path and lists completed tasks.

## Do Not
- Archive from `main`.
- Archive with unchecked tasks.
- Archive with `status != done`.
- Edit archived files post-move.
