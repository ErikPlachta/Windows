# Databricks notebook source
# MAGIC %md
# MAGIC # run_tests
# MAGIC
# MAGIC **Auto-generated from:** `run_tests.py`
# MAGIC **Build timestamp:** 2025-12-22T22:33:16.490426+00:00
# MAGIC **Content hash:** ad2bdd20f0bc
# MAGIC
# MAGIC > Do not edit directly. Make changes in source and rebuild.

# COMMAND ----------

# MAGIC %run ./tests/databricks/runner
# MAGIC %run ./tests/databricks/_init
# MAGIC %run ./databricks_api_workspace/core/runtime/_init
# MAGIC %run ./databricks_api_workspace/main

# COMMAND ----------

"""Package Tests Runner - Run tests for databricks_api_workspace.

Deploy as a Databricks job/notebook to verify package installation.

Usage:
    # In Databricks notebook/job:
    from run_tests import run_all_tests
    results = run_all_tests()

    # Or run directly:
    # python run_tests.py

Available test functions:
    - run_all_tests(): Run all test suites
    - run_suite(name): Run specific suite by name
    - quick_verify(): Quick health check

Available suites:
    - runtime: Runtime detection tests
    - config: Config loading tests
    - cache: Cache tests
    - logging: Logging tests
    - sql: SQL utils tests
    - data: Data utils tests
    - auth: Auth tests
    - response: Response tests
    - routes: Routes tests
    - execute: Execute tests
"""

from __future__ import annotations

from typing import TYPE_CHECKING, Any

if TYPE_CHECKING:

__all__ = [
    "run_all_tests",
    "run_suite",
    "quick_verify",
    "main",
]


def run_all_tests(verbose: bool = True) -> dict[str, TestSuiteResult]:
    """Run all test suites.

    Args:
        verbose: Print detailed output.

    Returns:
        Dict mapping suite names to TestSuiteResult objects.

    Example:
        >>> results = run_all_tests()
        >>> total_passed = sum(s.passed for s in results.values())
    """

    return run_all(verbose=verbose)


def run_suite(name: str, verbose: bool = True) -> TestSuiteResult:
    """Run a specific test suite by name.

    Args:
        name: Suite name (runtime, config, cache, logging, sql, data, auth, response, routes, execute)
        verbose: Print detailed output.

    Returns:
        TestSuiteResult for the suite.

    Example:
        >>> result = run_suite("runtime")
        >>> print(f"Passed: {result.passed}, Failed: {result.failed}")
    """
        run_auth,
        run_cache,
        run_config,
        run_data,
        run_execute,
        run_logging,
        run_response,
        run_routes,
        run_runtime,
        run_sql,
    )

    suites = {
        "runtime": run_runtime,
        "config": run_config,
        "cache": run_cache,
        "logging": run_logging,
        "sql": run_sql,
        "data": run_data,
        "auth": run_auth,
        "response": run_response,
        "routes": run_routes,
        "execute": run_execute,
    }

    if name not in suites:
        raise ValueError(f"Unknown suite: {name}. Available: {list(suites.keys())}")

    return suites[name](verbose=verbose)


def quick_verify() -> dict[str, Any]:
    """Quick health check - verify runtime and basic functionality.

    Returns:
        Dict with verification results.

    Example:
        >>> result = quick_verify()
        >>> print(result["health_status"])
    """

    health = execute(operation="health", params={})

    return {
        "health_status": health.get("meta", {}).get("status", "unknown"),
        "is_databricks": is_databricks(),
        "is_local": is_local(),
    }


def main() -> None:
    """Entry point when run as Databricks notebook or local script."""

    # Databricks mode - get dbutils for widget support

    dbutils = get_dbutils()

    # Optional widget for suite selection
    dbutils.widgets.text("suite", "all")
    dbutils.widgets.text("verbose", "true")

    suite = dbutils.widgets.get("suite")
    verbose = dbutils.widgets.get("verbose").lower() == "true"

    if suite == "all":
        results = run_all_tests(verbose=verbose)
        total_passed = sum(s.passed for s in results.values())
        total_failed = sum(s.failed for s in results.values())
        print(f"Total: {total_passed} passed, {total_failed} failed")
    else:
        result = run_suite(suite, verbose=verbose)
        print(f"Suite {suite}: {result.passed} passed, {result.failed} failed")


