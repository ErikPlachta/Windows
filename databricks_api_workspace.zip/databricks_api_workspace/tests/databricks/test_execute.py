# Databricks notebook source
# MAGIC %md
# MAGIC # test_execute
# MAGIC
# MAGIC **Auto-generated from:** `test_execute.py`
# MAGIC **Build timestamp:** 2025-12-22T22:33:16.506501+00:00
# MAGIC **Content hash:** c5dff73b15d4
# MAGIC
# MAGIC > Do not edit directly. Make changes in source and rebuild.

# COMMAND ----------

# MAGIC %run ../../databricks_api_workspace/main

# COMMAND ----------

"""Execute tests for Databricks notebooks.

Standalone tests that can run without pytest.
"""

from __future__ import annotations

from collections.abc import Callable
from typing import Any

import pytest

pytestmark = pytest.mark.databricks


def test_execute_health() -> None:
    """execute('health') returns dict."""

    result = execute(operation="health", params={})
    assert isinstance(result, dict), f"Expected dict, got {type(result)}"
    assert "status" in result, "Missing status"


def test_help() -> None:
    """help() returns string."""

    result = main_help()
    assert isinstance(result, str), f"Expected str, got {type(result)}"
    assert len(result) > 0, "Empty help"


def get_execute_tests() -> list[Callable[[], Any]]:
    """Get execute test functions."""
    return [
        test_execute_health,
        test_help,
    ]
