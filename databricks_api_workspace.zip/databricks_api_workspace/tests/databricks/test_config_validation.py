# Databricks notebook source
# MAGIC %md
# MAGIC # test_config_validation
# MAGIC
# MAGIC **Auto-generated from:** `test_config_validation.py`
# MAGIC **Build timestamp:** 2025-12-22T22:33:16.503825+00:00
# MAGIC **Content hash:** dc180b9a3f47
# MAGIC
# MAGIC > Do not edit directly. Make changes in source and rebuild.

# COMMAND ----------

# MAGIC %run ../../databricks_api_workspace/core/runtime/_init
# MAGIC %run ../../databricks_api_workspace/core/config/_init
# MAGIC %run ../../databricks_api_workspace/core/routes/_init

# COMMAND ----------

"""Tests for config folder content validation.

These tests verify that all configuration files in the data/ folder
are valid and properly structured.
"""

import json
from pathlib import Path

import pytest


def get_data_dir() -> Path:
    """Get the data directory path."""

    return get_package_root() / "data"


@pytest.mark.databricks
class TestConfigJsonValidation:
    """Tests for config.json validation."""

    def test_config_json_exists(self):
        """config.json file exists."""
        config_path = get_data_dir() / "config.json"
        assert config_path.exists(), f"config.json not found at {config_path}"

    def test_config_json_is_valid_json(self):
        """config.json is valid JSON."""
        config_path = get_data_dir() / "config.json"
        with open(config_path) as f:
            data = json.load(f)
        assert isinstance(data, dict)

    def test_config_json_has_required_keys(self):
        """config.json has required top-level keys."""

        config = load_config()
        # Check for expected config sections
        assert isinstance(config, dict)

    def test_config_loads_via_api(self):
        """config.json loads correctly via load_config()."""

        config = load_config()
        assert config is not None


@pytest.mark.databricks
class TestRoutesValidation:
    """Tests for routes configuration validation."""

    def test_routes_directory_exists(self):
        """routes/ directory exists."""
        routes_dir = get_data_dir() / "routes"
        assert routes_dir.exists(), f"routes/ not found at {routes_dir}"
        assert routes_dir.is_dir()

    def test_builtin_routes_directory_exists(self):
        """_builtin/ subdirectory exists."""
        builtin_dir = get_data_dir() / "routes" / "_builtin"
        assert builtin_dir.exists(), f"_builtin/ not found at {builtin_dir}"

    def test_defaults_json_exists(self):
        """_defaults.json exists."""
        defaults_path = get_data_dir() / "routes" / "_defaults.json"
        assert defaults_path.exists(), f"_defaults.json not found at {defaults_path}"

    def test_defaults_json_is_valid_json(self):
        """_defaults.json is valid JSON."""
        defaults_path = get_data_dir() / "routes" / "_defaults.json"
        with open(defaults_path) as f:
            data = json.load(f)
        assert isinstance(data, dict)

    def test_all_route_files_are_valid_json(self):
        """All .json files in routes/ are valid JSON."""
        routes_dir = get_data_dir() / "routes"
        for json_file in routes_dir.rglob("*.json"):
            with open(json_file) as f:
                try:
                    data = json.load(f)
                    assert isinstance(data, (dict, list)), f"{json_file.name} is not dict/list"
                except json.JSONDecodeError as e:
                    pytest.fail(f"Invalid JSON in {json_file}: {e}")

    def test_builtin_health_route_exists(self):
        """health.json builtin route exists."""
        health_path = get_data_dir() / "routes" / "_builtin" / "health.json"
        assert health_path.exists()

    def test_builtin_auth_route_exists(self):
        """auth.json builtin route exists."""
        auth_path = get_data_dir() / "routes" / "_builtin" / "auth.json"
        assert auth_path.exists()

    def test_routes_load_via_api(self):
        """Routes load correctly via load_routes()."""

        routes = load_routes()
        assert isinstance(routes, list)
        assert len(routes) > 0

    def test_routes_have_required_fields(self):
        """Each route has required fields."""

        routes = load_routes()
        for route in routes:
            # _meta.title or name is required
            has_name = "name" in route or ("_meta" in route and "title" in route["_meta"])
            assert has_name, f"Route missing name/title: {route}"
            # route array or operation/handler is required
            has_route_def = "route" in route or "operation" in route or "handler" in route
            assert has_route_def, f"Route missing route definition: {route}"


@pytest.mark.databricks
class TestSchemasValidation:
    """Tests for JSON schema validation."""

    def test_schemas_directory_exists(self):
        """schemas/ directory exists."""
        schemas_dir = get_data_dir() / "schemas"
        assert schemas_dir.exists(), f"schemas/ not found at {schemas_dir}"

    def test_route_schema_exists(self):
        """route.schema.json exists."""
        schema_path = get_data_dir() / "schemas" / "route.schema.json"
        assert schema_path.exists()

    def test_defaults_schema_exists(self):
        """defaults.schema.json exists."""
        schema_path = get_data_dir() / "schemas" / "defaults.schema.json"
        assert schema_path.exists()

    def test_all_schema_files_are_valid_json(self):
        """All .json files in schemas/ are valid JSON."""
        schemas_dir = get_data_dir() / "schemas"
        for json_file in schemas_dir.rglob("*.json"):
            with open(json_file) as f:
                try:
                    data = json.load(f)
                    assert isinstance(data, dict), f"{json_file.name} is not a dict"
                except json.JSONDecodeError as e:
                    pytest.fail(f"Invalid JSON in {json_file}: {e}")

    def test_route_schema_has_schema_keyword(self):
        """route.schema.json has $schema keyword."""
        schema_path = get_data_dir() / "schemas" / "route.schema.json"
        with open(schema_path) as f:
            data = json.load(f)
        assert "$schema" in data or "type" in data

    def test_operations_schemas_directory(self):
        """operations/ subdirectory exists with schemas."""
        ops_dir = get_data_dir() / "schemas" / "operations"
        if ops_dir.exists():
            json_files = list(ops_dir.glob("*.json"))
            # If directory exists, it should have schemas
            assert len(json_files) >= 0  # May be empty


@pytest.mark.databricks
class TestQueriesValidation:
    """Tests for queries directory validation."""

    def test_queries_directory_exists(self):
        """queries/ directory exists."""
        queries_dir = get_data_dir() / "queries"
        assert queries_dir.exists(), f"queries/ not found at {queries_dir}"

    def test_queries_directory_structure(self):
        """queries/ is a valid directory."""
        queries_dir = get_data_dir() / "queries"
        assert queries_dir.is_dir()


@pytest.mark.databricks
class TestDataDirectoryStructure:
    """Tests for overall data directory structure."""

    def test_data_directory_exists(self):
        """data/ directory exists."""
        data_dir = get_data_dir()
        assert data_dir.exists()
        assert data_dir.is_dir()

    def test_required_subdirectories_exist(self):
        """Required subdirectories exist."""
        data_dir = get_data_dir()
        required = ["routes", "schemas", "queries"]
        for subdir in required:
            path = data_dir / subdir
            assert path.exists(), f"Required directory {subdir}/ not found"

    def test_config_json_in_data_root(self):
        """config.json is in data/ root."""
        config_path = get_data_dir() / "config.json"
        assert config_path.exists()

    def test_no_python_files_in_data(self):
        """No .py files in data/ (should be config only)."""
        data_dir = get_data_dir()
        py_files = list(data_dir.rglob("*.py"))
        assert len(py_files) == 0, f"Unexpected Python files in data/: {py_files}"


@pytest.mark.databricks
class TestConfigPathResolution:
    """Tests for config path resolution functions."""

    def test_get_config_dir_returns_path(self):
        """get_config_dir() returns a Path."""

        path = get_config_dir()
        assert isinstance(path, Path)

    def test_get_routes_dir_returns_path(self):
        """get_routes_dir() returns a Path."""

        path = get_routes_dir()
        assert isinstance(path, Path)

    def test_get_config_dir_exists(self):
        """get_config_dir() returns existing directory."""

        path = get_config_dir()
        assert path.exists()

    def test_get_routes_dir_exists(self):
        """get_routes_dir() returns existing directory."""

        path = get_routes_dir()
        assert path.exists()

    def test_get_package_root_contains_data(self):
        """get_package_root() contains data/ folder."""

        root = get_package_root()
        data_dir = root / "data"
        assert data_dir.exists()
