# Databricks notebook source
# MAGIC %md
# MAGIC # test_integration
# MAGIC
# MAGIC **Auto-generated from:** `test_integration.py`
# MAGIC **Build timestamp:** 2025-12-22T22:33:16.508337+00:00
# MAGIC **Content hash:** 1c3ac0c76ac3
# MAGIC
# MAGIC > Do not edit directly. Make changes in source and rebuild.

# COMMAND ----------

# MAGIC %run ../../databricks_api_workspace/main
# MAGIC %run ../../databricks_api_workspace/services/auth/_init
# MAGIC %run ../../databricks_api_workspace/services/_init
# MAGIC %run ../../databricks_api_workspace/services/operations/_init
# MAGIC %run ../../databricks_api_workspace/core/config/_init
# MAGIC %run ../../databricks_api_workspace/core/routes/_init

# COMMAND ----------

"""Integration tests for Databricks environment simulation.

End-to-end tests using mocks to simulate full Databricks workflows.
"""

from __future__ import annotations

from typing import Any

import pytest

pytestmark = pytest.mark.databricks


class TestExecuteEntryPoint:
    """Tests for main execute() entry point."""

    def test_execute_returns_dict(self) -> None:
        """execute() returns a dict."""

        result = execute(operation="health", params={})
        assert isinstance(result, dict)

    def test_execute_has_status(self) -> None:
        """execute result has status field."""

        result = execute(operation="health", params={})
        assert "status" in result

    def test_help_returns_string(self) -> None:
        """help() returns usage string."""

        result = main_help()
        assert isinstance(result, str)
        assert len(result) > 0
        assert "execute" in result.lower()


class TestAuthOperations:
    """Tests for auth operations."""

    def test_user_context_creation(self) -> None:
        """Can create user context directly."""

        ctx = UserContext(user_id="test-123", roles=["admin"])
        assert ctx is not None
        assert ctx.user_id == "test-123"
        assert "admin" in ctx.roles

    def test_anonymous_context_has_expected_fields(self) -> None:
        """Anonymous context has expected fields."""

        ctx = create_anonymous_context()
        assert hasattr(ctx, "user_id")
        assert hasattr(ctx, "roles")

    def test_user_context_has_role(self) -> None:
        """UserContext has_role works."""

        ctx = UserContext(user_id="test", roles=["admin", "viewer"])
        assert ctx.has_role("admin")
        assert ctx.has_role("viewer")
        assert not ctx.has_role("editor")

    def test_user_context_has_any_role(self) -> None:
        """UserContext has_any_role works."""

        ctx = UserContext(user_id="test", roles=["admin"])
        assert ctx.has_any_role(["admin", "viewer"])
        assert not ctx.has_any_role(["editor", "manager"])


class TestOperationsIntegration:
    """Tests for operation handlers integration."""

    def test_operations_module_imports(self) -> None:
        """Operations module imports successfully."""

        assert operations is not None

    def test_operations_handlers_import(self) -> None:
        """Operations handlers import successfully."""

        assert handlers is not None


class TestConfigIntegration:
    """Tests for config loading."""

    def test_config_loads(self) -> None:
        """Config loads successfully."""

        config = load_config()
        assert config is not None
        assert isinstance(config, dict)

    def test_routes_load(self) -> None:
        """Routes load successfully."""

        routes = load_routes()
        assert routes is not None
        assert isinstance(routes, list)


class TestWithPatchedRuntime:
    """Tests that use patched runtime for full simulation."""

    def test_mock_spark_sql(
        self,
        mock_spark: Any,
    ) -> None:
        """Mock Spark SQL execution works."""
        # sql() returns empty DataFrame by default
        df = mock_spark.sql("SELECT 1 as value")
        rows = df.collect()

        assert isinstance(rows, list)
        # Empty by default, but method works
        assert hasattr(df, "collect")

    def test_mock_dbutils_widgets(
        self,
        mock_dbutils: Any,
    ) -> None:
        """Mock dbutils widgets work."""
        result = mock_dbutils.widgets.get("test_widget")
        assert result == ""  # Default return value

    def test_mock_dbutils_secrets(
        self,
        mock_dbutils: Any,
    ) -> None:
        """Mock dbutils secrets work."""
        # Set up secret first
        mock_dbutils.secrets.set_secret("test", "key", "mock_secret_value")
        result = mock_dbutils.secrets.get(scope="test", key="key")
        assert result == "mock_secret_value"

    def test_mock_dbutils_fs(
        self,
        mock_dbutils: Any,
    ) -> None:
        """Mock dbutils fs works."""
        # Create path with unique name to avoid collision
        mock_dbutils.fs.put("/dbfs/test_integration/file.txt", "content", overwrite=True)
        result = mock_dbutils.fs.ls("/dbfs/test_integration")
        assert isinstance(result, list)

    def test_mock_spark_dataframe(
        self,
        mock_spark: Any,
    ) -> None:
        """Mock Spark DataFrame operations work."""
        # Use createDataFrame to test DataFrame ops
        df = mock_spark.createDataFrame([{"id": 1, "name": "test"}])

        # Test first()
        first = df.first()
        assert first is not None

        # Test count()
        count = df.count()
        assert count == 1

        # Test collect()
        rows = df.collect()
        assert len(rows) == 1
