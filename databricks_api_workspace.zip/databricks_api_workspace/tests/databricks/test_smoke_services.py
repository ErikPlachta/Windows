# Databricks notebook source
# MAGIC %md
# MAGIC # test_smoke_services
# MAGIC
# MAGIC **Auto-generated from:** `test_smoke_services.py`
# MAGIC **Build timestamp:** 2025-12-22T22:33:16.519362+00:00
# MAGIC **Content hash:** 9e74f94fabe4
# MAGIC
# MAGIC > Do not edit directly. Make changes in source and rebuild.

# COMMAND ----------

# MAGIC %run ../../databricks_api_workspace/services/auth/_init
# MAGIC %run ../../databricks_api_workspace/core/config/_init
# MAGIC %run ../../databricks_api_workspace/core/routes/_init
# MAGIC %run ../../databricks_api_workspace/main
# MAGIC %run ../../databricks_api_workspace/services/databricks_async_job/_init
# MAGIC %run ../../databricks_api_workspace/services/response/_init
# MAGIC %run ../../databricks_api_workspace/core/logging/_init
# MAGIC %run ../../databricks_api_workspace/core/validation_utils/_init

# COMMAND ----------

"""Smoke tests for individual services.

Tests each service in isolation with realistic usage patterns.
"""

from __future__ import annotations

from typing import TYPE_CHECKING

import pytest

if TYPE_CHECKING:
    pass

pytestmark = pytest.mark.databricks


class TestAuthServiceSmoke:
    """Auth service smoke tests."""

    def test_user_authentication_scenario(self) -> None:
        """Full user authentication scenario."""

        # Create anonymous user
        anon = create_anonymous_context()
        assert anon is not None

        # Create authenticated user with various roles
        user = UserContext(
            user_id="user-12345",
            roles=["developer", "analyst"],
            email="user@company.com",
        )

        assert user.user_id == "user-12345"
        assert user.has_role("developer")
        assert user.has_role("analyst")
        assert not user.has_role("admin")

    def test_role_based_access_scenario(self) -> None:
        """Role-based access control scenario."""

        # Admin user
        admin = UserContext(user_id="admin", roles=["admin", "superuser"])
        assert admin.has_any_role(["admin"])
        assert admin.has_any_role(["admin", "viewer"])

        # Viewer user
        viewer = UserContext(user_id="viewer", roles=["viewer"])
        assert not viewer.has_role("admin")
        assert viewer.has_role("viewer")

        # Check permission logic
        requires_admin = ["admin", "superuser"]
        assert admin.has_any_role(requires_admin)
        assert not viewer.has_any_role(requires_admin)

    def test_validate_operation_access(self) -> None:
        """Operation access validation."""

        # Create user with roles
        user = UserContext(user_id="test", roles=["admin"])

        # Validate access (returns bool)
        result = validate_operation_access(user, "health")
        # Result depends on config, just verify it returns bool
        assert isinstance(result, bool)


class TestConfigServiceSmoke:
    """Config service smoke tests."""

    def test_config_loading_scenario(self) -> None:
        """Full config loading scenario."""

        # Clear any existing cache
        clear_config_cache()

        # Load config
        config = load_config()
        assert config is not None
        assert isinstance(config, dict)

        # Verify expected keys exist
        # Config should have standard keys
        assert len(config) > 0

    def test_routes_loading_scenario(self) -> None:
        """Full routes loading scenario."""

        # Load routes
        routes = load_routes()
        assert routes is not None
        assert isinstance(routes, list)

        # Should have at least builtin routes
        assert len(routes) > 0

        # Check route structure
        for route in routes[:5]:  # Check first 5
            assert isinstance(route, dict)

    def test_config_with_defaults(self) -> None:
        """Config loading with defaults applied."""

        config = load_config()

        # Config should be usable
        assert config is not None


class TestExecutionServiceSmoke:
    """Execution service smoke tests."""

    def test_operation_execution_scenario(self) -> None:
        """Full operation execution scenario."""

        # Execute health check
        result = execute(operation="health", params={})

        assert isinstance(result, dict)
        assert "status" in result

    def test_operation_with_user_context(self) -> None:
        """Operation execution with user context."""

        result = execute(
            operation="health",
            params={},
            user_context={"user_id": "test-user", "roles": ["user"]},
        )

        assert isinstance(result, dict)


class TestAsyncJobLifecycle:
    """Async job service smoke tests."""

    def test_async_job_lifecycle_scenario(self) -> None:
        """Full async job lifecycle: create → update → complete."""

        # Generate job ID
        job_id = generate_job_id()
        assert job_id is not None
        assert len(job_id) > 0

        # Create job record with factory method
        record = AsyncJobRecord.create(
            job_id=job_id,
            operation="test_operation",
            user_id="test-user",
        )

        assert record.job_id == job_id
        assert record.status == AsyncStatus.PENDING

        # Mark running
        record.mark_running(databricks_run_id=123)
        assert record.status == AsyncStatus.RUNNING

        # Mark completed
        record.mark_completed(result_json='{"data": "test"}')
        assert record.status == AsyncStatus.COMPLETED
        assert record.is_terminal

    def test_async_status_transitions(self) -> None:
        """Test valid status transitions."""

        # Non-terminal
        assert not is_terminal_status(AsyncStatus.PENDING)
        assert not is_terminal_status(AsyncStatus.RUNNING)

        # Terminal
        assert is_terminal_status(AsyncStatus.COMPLETED)
        assert is_terminal_status(AsyncStatus.FAILED)
        assert is_terminal_status(AsyncStatus.CANCELLED)


class TestResponseServiceSmoke:
    """Response service smoke tests."""

    def test_success_response_creation(self) -> None:
        """Create success response."""
        import time


        response = build_response(
            data={"items": [1, 2, 3]},
            operation="test_op",
            start_time=time.time(),
        )

        # Response is an envelope dict
        assert isinstance(response, dict)
        # Check for expected envelope structure
        assert "data" in response or "_data" in response or len(response) > 0

    def test_error_response_creation(self) -> None:
        """Create error response."""
        import time


        response = build_error_response(
            operation="test_op",
            error_code="VALIDATION_ERROR",
            message="Invalid input",
            start_time=time.time(),
        )

        assert isinstance(response, dict)
        # Error response should have error info
        assert len(response) > 0


class TestLoggingServiceSmoke:
    """Logging service smoke tests."""

    def test_logging_functions(self) -> None:
        """Test logging functions work."""

        # Just verify it doesn't crash
        log_info("Smoke test log message", test=True)

    def test_log_levels(self) -> None:
        """Test different log levels."""

        assert LogLevel.DEBUG is not None
        assert LogLevel.INFO is not None
        assert LogLevel.WARNING is not None
        assert LogLevel.ERROR is not None


class TestValidationServiceSmoke:
    """Validation service smoke tests."""

    def test_schema_validation(self) -> None:
        """Schema validation scenario."""

        # Valid data
        schema = {"type": "object", "properties": {"name": {"type": "string"}}}
        data = {"name": "test"}

        errors = validate_against_schema(data, schema)
        assert errors == []

    def test_invalid_data_validation(self) -> None:
        """Invalid data produces errors."""

        schema = {"type": "object", "properties": {"name": {"type": "string"}}}
        data = {"name": 123}  # Wrong type

        errors = validate_against_schema(data, schema)
        assert len(errors) > 0
