# Databricks notebook source
# MAGIC %md
# MAGIC # test_logging
# MAGIC
# MAGIC **Auto-generated from:** `test_logging.py`
# MAGIC **Build timestamp:** 2025-12-22T22:33:16.509610+00:00
# MAGIC **Content hash:** aa827e5d8cb7
# MAGIC
# MAGIC > Do not edit directly. Make changes in source and rebuild.

# COMMAND ----------

# MAGIC %run ../../databricks_api_workspace/core/logging/_init

# COMMAND ----------

"""Logging tests for Databricks notebooks.

Standalone tests that can run without pytest.
"""

from __future__ import annotations

from collections.abc import Callable
from typing import Any

import pytest

pytestmark = pytest.mark.databricks


def test_log_info() -> None:
    """log_info() works."""

    log_info("Test log message")


def test_log_error() -> None:
    """log_error() works."""

    log_error("Test error message")


def test_log_level() -> None:
    """set_log_level() works."""

    original = get_log_level()
    set_log_level(LogLevel.DEBUG)
    current = get_log_level()
    set_log_level(original)

    assert current == LogLevel.DEBUG, f"Expected DEBUG, got {current}"


def get_logging_tests() -> list[Callable[[], Any]]:
    """Get logging test functions."""
    return [
        test_log_info,
        test_log_error,
        test_log_level,
    ]
