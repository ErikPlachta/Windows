# Databricks notebook source
# MAGIC %md
# MAGIC # __init__
# MAGIC
# MAGIC **Auto-generated from:** `__init__.py`
# MAGIC **Build timestamp:** 2025-12-22T22:33:16.522315+00:00
# MAGIC **Content hash:** de955dee5db4
# MAGIC
# MAGIC > Do not edit directly. Make changes in source and rebuild.

# COMMAND ----------

# MAGIC %run ../../databricks_api_workspace/core/runtime/_init

# COMMAND ----------

"""Databricks-specific tests with runner for notebooks.

Run tests directly in Databricks notebooks without pytest.
Auto-detects environment: uses real spark/dbutils in Databricks, mocks locally.

Usage in Databricks notebook:
    # Run all tests
    from tests.databricks import run_all
    results = run_all()

    # Run specific suite
    from tests.databricks import run_runtime, run_config
    run_runtime()

    # Get spark/dbutils (auto-detects environment)
    from tests.databricks import get_services
    spark, dbutils = get_services()

Example notebook cell:
    %python
    from tests.databricks import run_all, print_summary
    results = run_all()
    # results is dict of suite_name -> TestSuiteResult
"""

from __future__ import annotations

from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from typing import Any


def get_services() -> tuple[Any, Any]:
    """Get spark and dbutils - real in Databricks, mocks locally.

    Returns:
        Tuple of (spark, dbutils) - real services in Databricks,
        mock objects when running locally.

    Example:
        >>> spark, dbutils = get_services()
        >>> df = spark.sql("SELECT 1")
        >>> dbutils.widgets.get("param")
    """

    if is_databricks():

        return get_spark(), get_dbutils()
    else:
        from mocks import get_mock_dbutils, get_mock_spark

        return get_mock_spark(), get_mock_dbutils()


from .runner import (
    TestResult,
    TestSuiteResult,
    print_summary,
    run_suite,
    run_test,
)

# Import test functions and getters from individual modules
from .test_auth import (
    get_auth_tests,
    test_anonymous_context,
    test_user_context,
)
from .test_cache import (
    get_cache_tests,
    test_cache_invalidate,
    test_cache_roundtrip,
    test_clear_all_caches,
)
from .test_config import (
    get_config_tests,
    test_clear_config_cache,
    test_config_has_required_keys,
    test_load_config,
    test_load_routes,
)
from .test_data_utils import (
    get_data_tests,
    test_coalesce,
    test_first_row,
    test_first_row_empty,
    test_pluck,
)
from .test_execute import (
    get_execute_tests,
    test_execute_health,
    test_help,
)
from .test_logging import (
    get_logging_tests,
    test_log_error,
    test_log_info,
    test_log_level,
)
from .test_response import (
    get_response_tests,
    test_build_error_response,
    test_build_response,
    test_integrity_hash,
)
from .test_routes import (
    get_routes_tests,
    test_health_check,
    test_health_check_timestamp,
)
from .test_runtime import (
    get_runtime_tests,
    test_get_config_dir,
    test_get_dbutils,
    test_get_package_root,
    test_get_routes_dir,
    test_get_spark,
    test_is_databricks,
    test_is_local_false,
)
from .test_sql_utils import (
    get_sql_tests,
    test_escape_sql_string,
    test_safe_sql_identifier,
    test_substitute_params,
)


def get_all_tests() -> dict[str, list]:
    """Get all test suites.

    Returns:
        Dict mapping suite name to test functions.
    """
    return {
        "Runtime": get_runtime_tests(),
        "Config": get_config_tests(),
        "Cache": get_cache_tests(),
        "Logging": get_logging_tests(),
        "SQL Utils": get_sql_tests(),
        "Data Utils": get_data_tests(),
        "Auth": get_auth_tests(),
        "Response": get_response_tests(),
        "Routes": get_routes_tests(),
        "Execute": get_execute_tests(),
    }


def run_all(verbose: bool = True) -> dict[str, TestSuiteResult]:
    """Run all test suites.

    Args:
        verbose: Print results as tests run.

    Returns:
        Dict mapping suite name to TestSuiteResult.

    Example:
        >>> from tests.databricks import run_all
        >>> results = run_all()
        >>> total = sum(s.passed for s in results.values())
    """
    suites = get_all_tests()
    results = {}

    for name, tests in suites.items():
        results[name] = run_suite(tests, name, verbose=verbose)

    if verbose:
        print_summary(list(results.values()))

    return results


def run_runtime(verbose: bool = True) -> TestSuiteResult:
    """Run runtime tests."""
    return run_suite(get_runtime_tests(), "Runtime", verbose=verbose)


def run_config(verbose: bool = True) -> TestSuiteResult:
    """Run config tests."""
    return run_suite(get_config_tests(), "Config", verbose=verbose)


def run_cache(verbose: bool = True) -> TestSuiteResult:
    """Run cache tests."""
    return run_suite(get_cache_tests(), "Cache", verbose=verbose)


def run_logging(verbose: bool = True) -> TestSuiteResult:
    """Run logging tests."""
    return run_suite(get_logging_tests(), "Logging", verbose=verbose)


def run_sql(verbose: bool = True) -> TestSuiteResult:
    """Run SQL utils tests."""
    return run_suite(get_sql_tests(), "SQL Utils", verbose=verbose)


def run_data(verbose: bool = True) -> TestSuiteResult:
    """Run data utils tests."""
    return run_suite(get_data_tests(), "Data Utils", verbose=verbose)


def run_auth(verbose: bool = True) -> TestSuiteResult:
    """Run auth tests."""
    return run_suite(get_auth_tests(), "Auth", verbose=verbose)


def run_response(verbose: bool = True) -> TestSuiteResult:
    """Run response tests."""
    return run_suite(get_response_tests(), "Response", verbose=verbose)


def run_routes(verbose: bool = True) -> TestSuiteResult:
    """Run routes tests."""
    return run_suite(get_routes_tests(), "Routes", verbose=verbose)


def run_execute(verbose: bool = True) -> TestSuiteResult:
    """Run execute tests."""
    return run_suite(get_execute_tests(), "Execute", verbose=verbose)


__all__ = [
    # Services
    "get_services",
    # Runner
    "run_all",
    "run_runtime",
    "run_config",
    "run_cache",
    "run_logging",
    "run_sql",
    "run_data",
    "run_auth",
    "run_response",
    "run_routes",
    "run_execute",
    "run_test",
    "run_suite",
    "print_summary",
    "TestResult",
    "TestSuiteResult",
    # Test getters
    "get_all_tests",
    "get_runtime_tests",
    "get_config_tests",
    "get_cache_tests",
    "get_logging_tests",
    "get_sql_tests",
    "get_data_tests",
    "get_auth_tests",
    "get_response_tests",
    "get_routes_tests",
    "get_execute_tests",
    # Individual tests
    "test_is_databricks",
    "test_is_local_false",
    "test_get_package_root",
    "test_get_config_dir",
    "test_get_routes_dir",
    "test_get_spark",
    "test_get_dbutils",
    "test_load_config",
    "test_config_has_required_keys",
    "test_load_routes",
    "test_clear_config_cache",
    "test_cache_roundtrip",
    "test_cache_invalidate",
    "test_clear_all_caches",
    "test_log_info",
    "test_log_error",
    "test_log_level",
    "test_escape_sql_string",
    "test_safe_sql_identifier",
    "test_substitute_params",
    "test_first_row",
    "test_first_row_empty",
    "test_pluck",
    "test_coalesce",
    "test_anonymous_context",
    "test_user_context",
    "test_build_response",
    "test_build_error_response",
    "test_integrity_hash",
    "test_health_check",
    "test_health_check_timestamp",
    "test_execute_health",
    "test_help",
]
