# Databricks notebook source
# MAGIC %md
# MAGIC # test_smoke_scenarios
# MAGIC
# MAGIC **Auto-generated from:** `test_smoke_scenarios.py`
# MAGIC **Build timestamp:** 2025-12-22T22:33:16.516258+00:00
# MAGIC **Content hash:** 6b7c9cb7e28e
# MAGIC
# MAGIC > Do not edit directly. Make changes in source and rebuild.

# COMMAND ----------

# MAGIC %run ../../databricks_api_workspace/main
# MAGIC %run ../../databricks_api_workspace/core/config/_init
# MAGIC %run ../../databricks_api_workspace/core/routes/_init
# MAGIC %run ../../databricks_api_workspace/services/auth/_init
# MAGIC %run ../../databricks_api_workspace/services/response/_init
# MAGIC %run ../../databricks_api_workspace/services/databricks_async_job/_init

# COMMAND ----------

"""Smoke tests for end-to-end scenarios.

Realistic workflow tests simulating production usage patterns.
Uses mocks to simulate Databricks environment.
"""

from __future__ import annotations

from typing import TYPE_CHECKING, Any

import pytest

if TYPE_CHECKING:
    pass

pytestmark = pytest.mark.databricks


class TestAPIGatewayFlow:
    """End-to-end API Gateway flow tests."""

    def test_complete_health_check_flow(self) -> None:
        """Full health check: request → route → execute → response."""

        # Simulate real health check request
        result = execute(operation="health", params={})

        # Verify complete response structure
        assert isinstance(result, dict)
        assert "status" in result

    def test_complete_auth_flow_with_admin(self) -> None:
        """Auth flow with admin role accessing protected operation."""

        # Admin user
        result = execute(
            operation="health",
            params={},
            user_context={"user_id": "admin-user-123", "roles": ["admin"]},
        )

        assert isinstance(result, dict)
        assert "status" in result

    def test_complete_auth_flow_with_user_context(self) -> None:
        """Auth flow with user context."""

        # Regular user
        result = execute(
            operation="health",
            params={},
            user_context={"user_id": "regular-user", "roles": ["viewer"]},
        )

        assert isinstance(result, dict)

    def test_operation_with_params_flow(self) -> None:
        """Operation flow with parameters."""

        # Health operation (always works)
        result = execute(
            operation="health",
            params={"extra": "param"},
        )

        assert isinstance(result, dict)
        assert "status" in result

    def test_multiple_sequential_requests(self) -> None:
        """Multiple requests simulating real traffic."""

        # Just use health - always works
        for _ in range(3):
            result = execute(operation="health", params={})
            assert isinstance(result, dict)
            assert "status" in result


class TestConfigReloadScenario:
    """Config loading and caching scenarios."""

    def test_config_load_cache_reload(self) -> None:
        """Config load → cache hit → clear → reload."""

        # Initial load
        config1 = load_config()
        assert config1 is not None

        # Should be cached (same object)
        config2 = load_config()
        assert config2 is config1

        # Clear cache
        clear_config_cache()

        # Should reload (new object)
        config3 = load_config()
        assert config3 is not None

    def test_routes_load(self) -> None:
        """Routes load and validate structure."""

        routes = load_routes()

        assert isinstance(routes, list)
        assert len(routes) > 0

        # Each route should be a dict
        for route in routes:
            assert isinstance(route, dict)


class TestUserContextLifecycle:
    """User context creation and usage."""

    def test_user_context_full_lifecycle(self) -> None:
        """Create context → check roles → audit trail."""

        # Create
        ctx = UserContext(
            user_id="smoke-test-user",
            roles=["admin", "developer"],
            email="test@example.com",
        )

        # Check roles
        assert ctx.has_role("admin")
        assert ctx.has_role("developer")
        assert not ctx.has_role("superadmin")
        assert ctx.has_any_role(["admin", "viewer"])
        assert not ctx.has_any_role(["superadmin", "operator"])

        # Verify context data
        assert ctx.user_id == "smoke-test-user"

    def test_anonymous_to_authenticated_flow(self) -> None:
        """Anonymous context → authenticated context transition."""

        # Start anonymous
        anon = create_anonymous_context()
        assert anon.user_id is None or anon.user_id == "anonymous"

        # Upgrade to authenticated
        auth = UserContext(user_id="authenticated-user", roles=["user"])
        assert auth.user_id == "authenticated-user"


class TestResponseEnvelopeFlow:
    """Response building and validation."""

    def test_response_build_validate_serialize(self) -> None:
        """Build response → validate → serialize."""
        import time


        # Build success response
        response = build_response(
            data={"key": "value", "count": 42},
            operation="test_operation",
            start_time=time.time(),
        )

        assert isinstance(response, dict)
        # Envelope should have data
        assert "data" in response or len(response) > 0

    def test_error_response_flow(self) -> None:
        """Error response building."""
        import time


        response = build_error_response(
            operation="test_operation",
            error_code="TEST_ERROR",
            message="Test error message",
            start_time=time.time(),
        )

        assert isinstance(response, dict)


class TestExecutionWithMocks:
    """Execution scenarios with mock services."""

    def test_execute_with_mock_spark(self, spark: Any) -> None:
        """Execute operation with mocked Spark session."""
        # Verify mock is available
        assert spark is not None
        assert hasattr(spark, "sql")

        # Execute a SQL query
        df = spark.sql("SELECT 1 as test_value")
        assert df is not None

    def test_execute_with_mock_dbutils(self, dbutils: Any) -> None:
        """Execute operation with mocked dbutils."""
        assert dbutils is not None
        assert hasattr(dbutils, "widgets")
        assert hasattr(dbutils, "secrets")

        # Test widget
        _ = dbutils.widgets.get("test_widget")

        # Test secrets
        dbutils.secrets.set_secret("scope", "key", "value")
        secret = dbutils.secrets.get(scope="scope", key="key")
        assert secret == "value"


class TestAsyncJobScenario:
    """Async job lifecycle tests."""

    def test_async_job_submission(self) -> None:
        """Test async job submission flow."""

        # Generate job ID
        job_id = generate_job_id()
        assert job_id is not None

        # Create record using factory method
        record = AsyncJobRecord.create(
            job_id=job_id,
            operation="test_op",
        )

        assert record.status == AsyncStatus.PENDING
        assert not record.is_terminal

        # Mark running
        record.mark_running(databricks_run_id=12345)
        assert record.status == AsyncStatus.RUNNING

        # Mark completed
        record.mark_completed(result_json='{"done": true}')
        assert record.status == AsyncStatus.COMPLETED
        assert record.is_terminal
