# Databricks notebook source
# MAGIC %md
# MAGIC # test_sql_utils
# MAGIC
# MAGIC **Auto-generated from:** `test_sql_utils.py`
# MAGIC **Build timestamp:** 2025-12-22T22:33:16.520880+00:00
# MAGIC **Content hash:** 0d9503bc3622
# MAGIC
# MAGIC > Do not edit directly. Make changes in source and rebuild.

# COMMAND ----------

# MAGIC %run ../../databricks_api_workspace/core/sql_utils/_init

# COMMAND ----------

"""SQL utils tests for Databricks notebooks.

Standalone tests that can run without pytest.
"""

from __future__ import annotations

from collections.abc import Callable
from typing import Any

import pytest

pytestmark = pytest.mark.databricks


def test_escape_sql_string() -> None:
    """SQL string escaping works."""

    result = escape_sql_string("test'value")
    assert "'" not in result or "''" in result, f"Not escaped: {result}"


def test_safe_sql_identifier() -> None:
    """SQL identifier validation works."""

    result = safe_sql_identifier("valid_table")
    assert result == "valid_table", f"Changed: {result}"


def test_substitute_params() -> None:
    """Parameter substitution works."""

    template = "SELECT * FROM t WHERE id = :id"
    result = substitute_params(template, {"id": "123"})

    assert ":id" not in result, f"Param not substituted: {result}"
    assert "123" in result, f"Value not inserted: {result}"


def get_sql_tests() -> list[Callable[[], Any]]:
    """Get SQL utils test functions."""
    return [
        test_escape_sql_string,
        test_safe_sql_identifier,
        test_substitute_params,
    ]
