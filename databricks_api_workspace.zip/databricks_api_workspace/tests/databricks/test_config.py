# Databricks notebook source
# MAGIC %md
# MAGIC # test_config
# MAGIC
# MAGIC **Auto-generated from:** `test_config.py`
# MAGIC **Build timestamp:** 2025-12-22T22:33:16.501116+00:00
# MAGIC **Content hash:** 38433e1558c2
# MAGIC
# MAGIC > Do not edit directly. Make changes in source and rebuild.

# COMMAND ----------

# MAGIC %run ../../databricks_api_workspace/core/config/_init
# MAGIC %run ../../databricks_api_workspace/core/routes/_init
# MAGIC %run ../../databricks_api_workspace/core/config/loader

# COMMAND ----------

"""Config tests for Databricks notebooks.

Standalone tests that can run without pytest.
"""

from __future__ import annotations

from collections.abc import Callable
from typing import Any

import pytest

pytestmark = pytest.mark.databricks


def test_load_config() -> None:
    """Config loads successfully."""

    config = load_config()
    assert config is not None, "load_config() returned None"
    assert isinstance(config, dict), f"Expected dict, got {type(config)}"


def test_config_has_required_keys() -> None:
    """Config has required keys (operations, roles, env)."""

    config = load_config()
    required_keys = ["operations", "roles", "env"]
    for key in required_keys:
        assert key in config, f"Missing '{key}' key: {list(config.keys())}"


def test_load_routes() -> None:
    """Routes load successfully."""

    routes = load_routes()
    assert routes is not None, "load_routes() returned None"
    assert isinstance(routes, list), f"Expected list, got {type(routes)}"


def test_clear_config_cache() -> None:
    """clear_config_cache() works."""

    clear_config_cache()  # Should not raise


def get_config_tests() -> list[Callable[[], Any]]:
    """Get config test functions."""
    return [
        test_load_config,
        test_config_has_required_keys,
        test_load_routes,
        test_clear_config_cache,
    ]
