# Databricks notebook source
# MAGIC %md
# MAGIC # test_runtime
# MAGIC
# MAGIC **Auto-generated from:** `test_runtime.py`
# MAGIC **Build timestamp:** 2025-12-22T22:33:16.513513+00:00
# MAGIC **Content hash:** 45a0833ad0e4
# MAGIC
# MAGIC > Do not edit directly. Make changes in source and rebuild.

# COMMAND ----------

# MAGIC %run ../../databricks_api_workspace/core/_init

# COMMAND ----------

"""Runtime tests for Databricks notebooks.

Standalone tests that can run without pytest.
"""

from __future__ import annotations

from collections.abc import Callable
from typing import Any

import pytest

pytestmark = pytest.mark.databricks


def test_is_databricks() -> None:
    """is_databricks() returns True in Databricks."""

    result = runtime.is_databricks()
    assert result is True, f"Expected True, got {result}"


def test_is_local_false() -> None:
    """is_local() returns False in Databricks."""

    result = runtime.is_local()
    assert result is False, f"Expected False, got {result}"


def test_get_package_root() -> None:
    """get_package_root() returns existing path."""

    result = runtime.get_package_root()
    assert result.exists(), f"Path does not exist: {result}"


def test_get_config_dir() -> None:
    """get_config_dir() returns existing path."""

    result = runtime.get_config_dir()
    assert result.exists(), f"Path does not exist: {result}"


def test_get_routes_dir() -> None:
    """get_routes_dir() returns existing path."""

    result = runtime.get_routes_dir()
    assert result.exists(), f"Path does not exist: {result}"


def test_get_spark(spark: Any) -> None:
    """get_spark() returns SparkSession (real or mock based on environment)."""
    assert spark is not None, "get_spark() returned None"
    assert hasattr(spark, "sql"), "Missing sql method"


def test_get_dbutils(dbutils: Any) -> None:
    """get_dbutils() returns dbutils (real or mock based on environment)."""
    assert dbutils is not None, "get_dbutils() returned None"
    assert hasattr(dbutils, "widgets"), "Missing widgets"


def get_runtime_tests() -> list[Callable[[], Any]]:
    """Get runtime test functions."""
    return [
        test_is_databricks,
        test_is_local_false,
        test_get_package_root,
        test_get_config_dir,
        test_get_routes_dir,
        test_get_spark,
        test_get_dbutils,
    ]
