# Databricks notebook source
# MAGIC %md
# MAGIC # test_response
# MAGIC
# MAGIC **Auto-generated from:** `test_response.py`
# MAGIC **Build timestamp:** 2025-12-22T22:33:16.510824+00:00
# MAGIC **Content hash:** c63da378fe50
# MAGIC
# MAGIC > Do not edit directly. Make changes in source and rebuild.

# COMMAND ----------

# MAGIC %run ../../databricks_api_workspace/services/response/_init

# COMMAND ----------

"""Response tests for Databricks notebooks.

Standalone tests that can run without pytest.
"""

from __future__ import annotations

from collections.abc import Callable
from typing import Any

import pytest

pytestmark = pytest.mark.databricks


def test_build_response() -> None:
    """build_response() creates envelope."""

    result = build_response(data={"items": [1, 2]}, operation="test")

    assert isinstance(result, dict), f"Expected dict, got {type(result)}"
    assert "meta" in result, "Missing meta"
    assert "data" in result, "Missing data"


def test_build_error_response() -> None:
    """build_error_response() creates error envelope."""

    result = build_error_response(
        operation="test",
        error_code="ERR",
        message="Test error",
    )

    assert result.get("meta", {}).get("status") == "error"


def test_integrity_hash() -> None:
    """compute_integrity_hash() is deterministic."""

    hash1 = compute_integrity_hash({"a": 1})
    hash2 = compute_integrity_hash({"a": 1})
    hash3 = compute_integrity_hash({"a": 2})

    assert hash1 == hash2, "Same data should produce same hash"
    assert hash1 != hash3, "Different data should differ"


def get_response_tests() -> list[Callable[[], Any]]:
    """Get response test functions."""
    return [
        test_build_response,
        test_build_error_response,
        test_integrity_hash,
    ]
