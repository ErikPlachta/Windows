# Databricks notebook source
# MAGIC %md
# MAGIC # runner
# MAGIC
# MAGIC **Auto-generated from:** `runner.py`
# MAGIC **Build timestamp:** 2025-12-22T22:33:16.494314+00:00
# MAGIC **Content hash:** c00849c5e2ce
# MAGIC
# MAGIC > Do not edit directly. Make changes in source and rebuild.

# COMMAND ----------

"""Test runner for Databricks notebooks.

Run tests directly in Databricks notebooks without pytest.
Provides simple test execution with pretty output.

Usage in Databricks notebook:
    # Run all tests
    from tests.databricks import run_all
    results = run_all()

    # Run specific suite
    from tests.databricks import run_runtime, run_config
    run_runtime()
"""

from __future__ import annotations

import time
from collections.abc import Callable
from dataclasses import dataclass, field
from typing import Any


@dataclass
class TestResult:
    """Result of a single test."""

    name: str
    passed: bool
    duration_ms: float
    error: str | None = None


@dataclass
class TestSuiteResult:
    """Result of a test suite."""

    name: str
    results: list[TestResult] = field(default_factory=list)

    @property
    def passed(self) -> int:
        """Count of passed tests."""
        return sum(1 for r in self.results if r.passed)

    @property
    def failed(self) -> int:
        """Count of failed tests."""
        return sum(1 for r in self.results if not r.passed)

    @property
    def total(self) -> int:
        """Total test count."""
        return len(self.results)

    @property
    def total_duration_ms(self) -> float:
        """Total duration in milliseconds."""
        return sum(r.duration_ms for r in self.results)


def run_test(test_func: Callable[[], Any], name: str | None = None) -> TestResult:
    """Run a single test function.

    Args:
        test_func: Test function. Should raise on failure.
        name: Optional test name. Defaults to function name.

    Returns:
        TestResult with pass/fail status and timing.
    """
    test_name = name or test_func.__name__
    start = time.perf_counter()

    try:
        test_func()
        duration_ms = (time.perf_counter() - start) * 1000
        return TestResult(name=test_name, passed=True, duration_ms=duration_ms)
    except AssertionError as e:
        duration_ms = (time.perf_counter() - start) * 1000
        return TestResult(
            name=test_name,
            passed=False,
            duration_ms=duration_ms,
            error=str(e) or "Assertion failed",
        )
    except Exception as e:
        duration_ms = (time.perf_counter() - start) * 1000
        return TestResult(
            name=test_name,
            passed=False,
            duration_ms=duration_ms,
            error=f"{type(e).__name__}: {e}",
        )


def run_suite(
    tests: list[Callable[[], Any]],
    suite_name: str,
    verbose: bool = True,
) -> TestSuiteResult:
    """Run a suite of tests.

    Args:
        tests: List of test functions.
        suite_name: Name of the test suite.
        verbose: Print results as tests run.

    Returns:
        TestSuiteResult with all results.
    """
    suite = TestSuiteResult(name=suite_name)

    if verbose:
        print(f"\n{'=' * 60}")
        print(f" {suite_name}")
        print(f"{'=' * 60}")

    for test_func in tests:
        result = run_test(test_func)
        suite.results.append(result)

        if verbose:
            status = "PASS" if result.passed else "FAIL"
            symbol = "[+]" if result.passed else "[-]"
            print(f"  {symbol} {result.name} ({result.duration_ms:.1f}ms) {status}")
            if result.error:
                print(f"      Error: {result.error}")

    if verbose:
        print(f"\n  Summary: {suite.passed}/{suite.total} passed")
        print(f"  Duration: {suite.total_duration_ms:.1f}ms")

    return suite


def print_summary(suites: list[TestSuiteResult]) -> None:
    """Print overall test summary.

    Args:
        suites: List of test suite results.
    """
    total_passed = sum(s.passed for s in suites)
    total_failed = sum(s.failed for s in suites)
    total_duration = sum(s.total_duration_ms for s in suites)

    print(f"\n{'=' * 60}")
    print(" TEST SUMMARY")
    print(f"{'=' * 60}")

    for suite in suites:
        status = "PASS" if suite.failed == 0 else "FAIL"
        print(f"  {suite.name}: {suite.passed}/{suite.total} ({status})")

    print(f"\n  Total: {total_passed} passed, {total_failed} failed")
    print(f"  Duration: {total_duration:.1f}ms")

    if total_failed == 0:
        print("\n  [+] ALL TESTS PASSED")
    else:
        print(f"\n  [-] {total_failed} TESTS FAILED")
