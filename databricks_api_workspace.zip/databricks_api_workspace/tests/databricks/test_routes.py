# Databricks notebook source
# MAGIC %md
# MAGIC # test_routes
# MAGIC
# MAGIC **Auto-generated from:** `test_routes.py`
# MAGIC **Build timestamp:** 2025-12-22T22:33:16.511938+00:00
# MAGIC **Content hash:** 9f328e65e4ee
# MAGIC
# MAGIC > Do not edit directly. Make changes in source and rebuild.

# COMMAND ----------

# MAGIC %run ../../databricks_api_workspace/core/routes/_init

# COMMAND ----------

"""Routes tests for Databricks notebooks.

Standalone tests that can run without pytest.
"""

from __future__ import annotations

from collections.abc import Callable
from typing import Any

import pytest

pytestmark = pytest.mark.databricks


def test_health_check() -> None:
    """Health check returns healthy."""

    result = run_health_check()
    assert result.get("status") == "healthy", f"Expected healthy: {result}"


def test_health_check_timestamp() -> None:
    """Health check has timestamp."""

    result = run_health_check()
    assert "timestamp" in result, "Missing timestamp"


def get_routes_tests() -> list[Callable[[], Any]]:
    """Get routes test functions."""
    return [
        test_health_check,
        test_health_check_timestamp,
    ]
