# Databricks notebook source
# MAGIC %md
# MAGIC # test_data_utils
# MAGIC
# MAGIC **Auto-generated from:** `test_data_utils.py`
# MAGIC **Build timestamp:** 2025-12-22T22:33:16.505531+00:00
# MAGIC **Content hash:** 6044d123c973
# MAGIC
# MAGIC > Do not edit directly. Make changes in source and rebuild.

# COMMAND ----------

# MAGIC %run ../../databricks_api_workspace/core/data_utils/_init

# COMMAND ----------

"""Data utils tests for Databricks notebooks.

Standalone tests that can run without pytest.
"""

from __future__ import annotations

from collections.abc import Callable
from typing import Any

import pytest

pytestmark = pytest.mark.databricks


def test_first_row() -> None:
    """first_row() extracts first row."""

    rows = [{"id": 1}, {"id": 2}]
    result = first_row(rows)
    assert result == {"id": 1}, f"Expected first row, got {result}"


def test_first_row_empty() -> None:
    """first_row() handles empty list."""

    result = first_row([])
    assert result is None, f"Expected None, got {result}"


def test_pluck() -> None:
    """pluck() extracts column."""

    rows = [{"id": 1, "name": "a"}, {"id": 2, "name": "b"}]
    result = pluck(rows, "name")
    assert result == ["a", "b"], f"Expected ['a', 'b'], got {result}"


def test_coalesce() -> None:
    """coalesce() returns first non-None."""

    result = coalesce(None, None, "value", "other")
    assert result == "value", f"Expected 'value', got {result}"


def get_data_tests() -> list[Callable[[], Any]]:
    """Get data utils test functions."""
    return [
        test_first_row,
        test_first_row_empty,
        test_pluck,
        test_coalesce,
    ]
