# Databricks notebook source
# MAGIC %md
# MAGIC # test_auth
# MAGIC
# MAGIC **Auto-generated from:** `test_auth.py`
# MAGIC **Build timestamp:** 2025-12-22T22:33:16.497661+00:00
# MAGIC **Content hash:** 00e9b56218d7
# MAGIC
# MAGIC > Do not edit directly. Make changes in source and rebuild.

# COMMAND ----------

# MAGIC %run ../../databricks_api_workspace/services/auth/_init

# COMMAND ----------

"""Auth tests for Databricks notebooks.

Standalone tests that can run without pytest.
"""

from __future__ import annotations

from collections.abc import Callable
from typing import Any

import pytest

pytestmark = pytest.mark.databricks


def test_anonymous_context() -> None:
    """create_anonymous_context() works."""

    ctx = create_anonymous_context()
    assert ctx is not None, "Returned None"
    assert hasattr(ctx, "user_id"), "Missing user_id"


def test_user_context() -> None:
    """UserContext creation works."""

    ctx = UserContext(user_id="test-123", roles=["admin"])
    assert ctx.user_id == "test-123"
    assert ctx.has_role("admin")


def get_auth_tests() -> list[Callable[[], Any]]:
    """Get auth test functions."""
    return [
        test_anonymous_context,
        test_user_context,
    ]
