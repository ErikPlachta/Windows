# Databricks notebook source
# MAGIC %md
# MAGIC # test_cache
# MAGIC
# MAGIC **Auto-generated from:** `test_cache.py`
# MAGIC **Build timestamp:** 2025-12-22T22:33:16.499371+00:00
# MAGIC **Content hash:** 7da0dffe7cbc
# MAGIC
# MAGIC > Do not edit directly. Make changes in source and rebuild.

# COMMAND ----------

# MAGIC %run ../../databricks_api_workspace/core/cache/_init

# COMMAND ----------

"""Cache tests for Databricks notebooks.

Standalone tests that can run without pytest.
"""

from __future__ import annotations

from collections.abc import Callable
from typing import Any

import pytest

pytestmark = pytest.mark.databricks


def test_cache_roundtrip() -> None:
    """Cache set/get roundtrip works."""

    ns = CacheNamespace.QUERY
    clear_cache(ns)

    set_cached(ns, "test_key", {"value": 42})
    result = get_cached(ns, "test_key")

    assert result is not None, "Cache returned None"
    assert result.get("value") == 42, f"Expected 42, got {result.get('value')}"
    clear_cache(ns)


def test_cache_invalidate() -> None:
    """Cache invalidation works."""

    ns = CacheNamespace.QUERY
    clear_cache(ns)

    set_cached(ns, "test_inv", "data")
    invalidate(ns, "test_inv")
    result = get_cached(ns, "test_inv")

    assert result is None, f"Expected None, got {result}"


def test_clear_all_caches() -> None:
    """clear_all_caches() works."""

    clear_all_caches()  # Should not raise


def get_cache_tests() -> list[Callable[[], Any]]:
    """Get cache test functions."""
    return [
        test_cache_roundtrip,
        test_cache_invalidate,
        test_clear_all_caches,
    ]
