# Databricks notebook source
# MAGIC %md
# MAGIC # conftest
# MAGIC
# MAGIC **Auto-generated from:** `conftest.py`
# MAGIC **Build timestamp:** 2025-12-22T22:33:16.492124+00:00
# MAGIC **Content hash:** 0dbd27ded6e1
# MAGIC
# MAGIC > Do not edit directly. Make changes in source and rebuild.

# COMMAND ----------

# MAGIC %run ../../databricks_api_workspace/core/runtime/_init

# COMMAND ----------

"""Databricks test fixtures using mocks package.

Provides fixtures for pytest that auto-detect environment:
- In Databricks: uses real spark/dbutils
- Locally: uses mocks from mocks package
"""

from __future__ import annotations

from collections.abc import Generator
from typing import TYPE_CHECKING

import pytest

if TYPE_CHECKING:
    from typing import Any


@pytest.fixture(autouse=True)
def setup_environment(monkeypatch: pytest.MonkeyPatch) -> Generator[None, None, None]:
    """Set up test environment.

    Sets DATABRICKS_RUNTIME_VERSION for local testing to simulate Databricks.
    In actual Databricks, the env var is already set.
    """

    if not is_databricks():
        monkeypatch.setenv("DATABRICKS_RUNTIME_VERSION", "14.3")
    yield


@pytest.fixture
def spark() -> Any:
    """Get SparkSession - real in Databricks, mock locally.

    Note: When running via pytest locally, always use mocks even if
    DATABRICKS_RUNTIME_VERSION is set (for simulation purposes).
    """
    # Check original environment (before setup_environment may have set it)
    # If spark/dbutils globals don't exist, we're running locally
    try:
        import builtins

        if hasattr(builtins, "spark"):
            return builtins.spark
    except Exception:
        pass

    # Fall back to mock for local pytest runs
    from mocks import get_mock_spark

    return get_mock_spark()


@pytest.fixture
def dbutils() -> Any:
    """Get dbutils - real in Databricks, mock locally.

    Note: When running via pytest locally, always use mocks even if
    DATABRICKS_RUNTIME_VERSION is set (for simulation purposes).
    """
    # Check if dbutils exists as a builtin (real Databricks)
    try:
        import builtins

        if hasattr(builtins, "dbutils"):
            return builtins.dbutils
    except Exception:
        pass

    # Fall back to mock for local pytest runs
    from mocks import get_mock_dbutils

    return get_mock_dbutils()


@pytest.fixture
def patched_runtime(spark: Any, dbutils: Any) -> Generator[dict[str, Any], None, None]:
    """Provide spark and dbutils as a dict for tests that need both.

    Yields:
        Dict with 'spark' and 'dbutils' keys.
    """
    yield {"spark": spark, "dbutils": dbutils}
