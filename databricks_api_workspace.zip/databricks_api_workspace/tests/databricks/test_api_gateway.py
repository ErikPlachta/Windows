# Databricks notebook source
# MAGIC %md
# MAGIC # test_api_gateway
# MAGIC
# MAGIC **Auto-generated from:** `test_api_gateway.py`
# MAGIC **Build timestamp:** 2025-12-22T22:33:16.496350+00:00
# MAGIC **Content hash:** 4963bdf0294a
# MAGIC
# MAGIC > Do not edit directly. Make changes in source and rebuild.

# COMMAND ----------

# MAGIC %run ../../databricks_api_workspace/services/auth/_init

# COMMAND ----------

"""Tests for api_gateway.py - 100% coverage for main entry point."""

import pytest


@pytest.mark.databricks
class TestHandleRequestBasics:
    """Basic tests for handle_request function."""

    def test_returns_dict(self):
        """handle_request returns a dict."""
        from api_gateway import handle_request

        result = handle_request("list_routes")
        assert isinstance(result, dict)

    def test_with_empty_params(self):
        """handle_request works with empty params."""
        from api_gateway import handle_request

        result = handle_request("list_routes", params={})
        assert isinstance(result, dict)

    def test_with_none_params(self):
        """handle_request works with None params (defaults to {})."""
        from api_gateway import handle_request

        result = handle_request("list_routes", params=None)
        assert isinstance(result, dict)

    def test_with_empty_user_roles(self):
        """handle_request works with empty user_roles."""
        from api_gateway import handle_request

        result = handle_request("list_routes", user_roles=[])
        assert isinstance(result, dict)

    def test_with_none_user_roles(self):
        """handle_request works with None user_roles (defaults to [])."""
        from api_gateway import handle_request

        result = handle_request("list_routes", user_roles=None)
        assert isinstance(result, dict)


@pytest.mark.databricks
class TestUserContext:
    """Tests for user context handling."""

    def test_with_user_id_creates_user_context(self):
        """handle_request creates UserContext when user_id provided."""
        from api_gateway import handle_request

        result = handle_request("list_routes", user_id="test-user")
        assert isinstance(result, dict)

    def test_with_user_id_and_roles(self):
        """handle_request handles user_id with roles."""
        from api_gateway import handle_request

        result = handle_request(
            "list_routes",
            user_id="test-user",
            user_roles=["viewer", "editor"],
        )
        assert isinstance(result, dict)

    def test_without_user_id_creates_anonymous(self):
        """handle_request creates anonymous context without user_id."""
        from api_gateway import handle_request

        result = handle_request("list_routes")
        assert isinstance(result, dict)

    def test_anonymous_user_blocked_from_admin_ops(self):
        """Anonymous users cannot access admin operations."""
        from api_gateway import handle_request

        result = handle_request("config")
        assert result.get("meta", {}).get("status") == "error"


@pytest.mark.databricks
class TestCorrelationId:
    """Tests for correlation ID handling."""

    def test_correlation_id_in_builtin_meta(self):
        """correlation_id added to meta for builtin operations."""
        from api_gateway import handle_request

        result = handle_request("list_routes", correlation_id="corr-123")
        meta = result.get("meta", {})
        assert meta.get("correlation_id") == "corr-123"

    def test_no_correlation_id_when_not_provided(self):
        """correlation_id not added when not provided."""
        from api_gateway import handle_request

        result = handle_request("list_routes")
        meta = result.get("meta", {})
        assert "correlation_id" not in meta or meta.get("correlation_id") is None

    def test_correlation_id_with_metadata_key(self):
        """correlation_id works with metadata key (alternate response format)."""
        from api_gateway import handle_request

        # config uses standard response which has 'meta' not 'metadata'
        result = handle_request("config", user_id="admin", user_roles=["admin"], correlation_id="x")
        meta = result.get("meta", result.get("metadata", {}))
        assert meta.get("correlation_id") == "x"


@pytest.mark.databricks
class TestDebugMode:
    """Tests for debug mode output."""

    def test_debug_prints_request_info(self, capsys):
        """debug=True prints request information."""
        from api_gateway import handle_request

        handle_request("list_routes", debug=True)
        captured = capsys.readouterr()
        assert "=== API Gateway Request ===" in captured.out
        assert "Operation: list_routes" in captured.out

    def test_debug_prints_params(self, capsys):
        """debug=True prints params."""
        from api_gateway import handle_request

        handle_request("list_routes", params={"key": "value"}, debug=True)
        captured = capsys.readouterr()
        assert '"key": "value"' in captured.out

    def test_debug_prints_anonymous_user(self, capsys):
        """debug=True prints 'anonymous' when no user_id."""
        from api_gateway import handle_request

        handle_request("list_routes", debug=True)
        captured = capsys.readouterr()
        assert "User: anonymous" in captured.out

    def test_debug_prints_user_id(self, capsys):
        """debug=True prints user_id when provided."""
        from api_gateway import handle_request

        handle_request("list_routes", user_id="test-user", debug=True)
        captured = capsys.readouterr()
        assert "User: test-user" in captured.out

    def test_debug_prints_roles(self, capsys):
        """debug=True prints roles."""
        from api_gateway import handle_request

        handle_request("list_routes", user_roles=["admin"], debug=True)
        captured = capsys.readouterr()
        assert "admin" in captured.out

    def test_debug_prints_routing_message(self, capsys):
        """debug=True prints routing message for non-builtin ops."""
        from api_gateway import handle_request

        # 'health' is not a builtin, it goes through execute()
        handle_request("health", debug=True)
        captured = capsys.readouterr()
        assert "Routing through execute()" in captured.out

    def test_debug_prints_response_info(self, capsys):
        """debug=True prints response information."""
        from api_gateway import handle_request

        handle_request("list_routes", debug=True)
        captured = capsys.readouterr()
        assert "=== Response ===" in captured.out
        assert "Status:" in captured.out
        assert "Execution time:" in captured.out


@pytest.mark.databricks
class TestBuiltinListRoutes:
    """Tests for list_routes builtin operation."""

    def test_returns_routes_list(self):
        """list_routes returns routes list."""
        from api_gateway import handle_request

        result = handle_request("list_routes")
        assert "routes" in result.get("data", {})
        assert isinstance(result["data"]["routes"], list)

    def test_returns_count(self):
        """list_routes returns count."""
        from api_gateway import handle_request

        result = handle_request("list_routes")
        assert "count" in result.get("data", {})
        count = result["data"]["count"]
        routes = result["data"]["routes"]
        assert count == len(routes)

    def test_route_has_expected_fields(self):
        """Each route has expected fields."""
        from api_gateway import handle_request

        result = handle_request("list_routes")
        routes = result.get("data", {}).get("routes", [])
        if routes:
            route = routes[0]
            assert "name" in route
            assert "path" in route
            assert "method" in route
            assert "operation" in route
            assert "description" in route

    def test_returns_success_status(self):
        """list_routes returns success status."""
        from api_gateway import handle_request

        result = handle_request("list_routes")
        assert result.get("meta", {}).get("status") == "success"


@pytest.mark.databricks
class TestBuiltinConfig:
    """Tests for config builtin operation."""

    def test_requires_admin_role(self):
        """config requires admin role."""
        from api_gateway import handle_request

        result = handle_request("config")
        assert result.get("meta", {}).get("status") == "error"
        assert "UNAUTHORIZED" in str(result)

    def test_with_non_admin_role(self):
        """config rejected with non-admin role."""
        from api_gateway import handle_request

        result = handle_request("config", user_id="user1", user_roles=["viewer"])
        assert result.get("meta", {}).get("status") == "error"

    def test_with_admin_role_success(self):
        """config succeeds with admin role."""
        from api_gateway import handle_request

        result = handle_request("config", user_id="admin", user_roles=["admin"])
        assert result.get("meta", {}).get("status") == "success"

    def test_returns_config_data(self):
        """config returns config data."""
        from api_gateway import handle_request

        result = handle_request("config", user_id="admin", user_roles=["admin"])
        assert "config" in result.get("data", {})


@pytest.mark.databricks
class TestBuiltinRunTests:
    """Tests for run_tests builtin operation."""

    def test_requires_admin_role(self):
        """run_tests requires admin role."""
        from api_gateway import handle_request

        result = handle_request("run_tests")
        assert result.get("meta", {}).get("status") == "error"
        assert "UNAUTHORIZED" in str(result)

    def test_with_non_admin_role(self):
        """run_tests rejected with non-admin role."""
        from api_gateway import handle_request

        result = handle_request("run_tests", user_id="user1", user_roles=["viewer"])
        assert result.get("meta", {}).get("status") == "error"

    def test_with_admin_role_success(self):
        """run_tests succeeds with admin role."""
        from api_gateway import handle_request

        result = handle_request("run_tests", user_id="admin", user_roles=["admin"])
        assert result.get("meta", {}).get("status") == "success"

    def test_returns_test_results(self):
        """run_tests returns test results."""
        from api_gateway import handle_request

        result = handle_request("run_tests", user_id="admin", user_roles=["admin"])
        data = result.get("data", {})
        assert "passed" in data
        assert "failed" in data
        assert "total" in data
        assert "suites" in data


@pytest.mark.databricks
class TestNonBuiltinRouting:
    """Tests for routing non-builtin operations through execute()."""

    def test_health_routes_through_execute(self):
        """health operation routes through execute()."""
        from api_gateway import handle_request

        result = handle_request("health")
        # Health from execute returns {"status": "healthy", "timestamp": ...}
        assert "status" in result
        assert result["status"] == "healthy"

    def test_unknown_operation_raises(self):
        """Unknown operation raises ValueError."""
        from api_gateway import handle_request

        with pytest.raises(ValueError, match="Unknown operation type"):
            handle_request("nonexistent_operation_xyz")

    def test_execute_uses_user_context_dict(self):
        """execute receives user_context as dict when user_id provided."""
        from api_gateway import handle_request

        # This tests the user_context dict conversion at lines 104-106
        result = handle_request("health", user_id="test-user", user_roles=["viewer"])
        assert isinstance(result, dict)


@pytest.mark.databricks
class TestHandleBuiltinHelper:
    """Tests for _handle_builtin helper function."""

    def test_non_builtin_returns_none(self):
        """_handle_builtin returns None for non-builtin operations."""
        from api_gateway import _handle_builtin

        result = _handle_builtin(
            operation="some_custom_op",
            params={},
            user_context=create_anonymous_context(),
            start_time=0.0,
            correlation_id=None,
        )
        assert result is None

    def test_list_routes_returns_dict(self):
        """_handle_builtin returns dict for list_routes."""
        from api_gateway import _handle_builtin

        result = _handle_builtin(
            operation="list_routes",
            params={},
            user_context=create_anonymous_context(),
            start_time=0.0,
            correlation_id=None,
        )
        assert result is not None
        assert isinstance(result, dict)


@pytest.mark.databricks
class TestMainFunction:
    """Tests for main() entry point function."""

    def test_main_runs_local_mode(self, capsys):
        """main() runs in local mode and prints output."""
        from api_gateway import main

        main()
        captured = capsys.readouterr()