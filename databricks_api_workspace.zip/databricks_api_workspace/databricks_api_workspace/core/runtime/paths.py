# Databricks notebook source
# MAGIC %md
# MAGIC # paths
# MAGIC
# MAGIC **Auto-generated from:** `paths.py`
# MAGIC **Build timestamp:** 2025-12-22T22:33:16.525422+00:00
# MAGIC **Content hash:** bdccfc527e1b
# MAGIC
# MAGIC > Do not edit directly. Make changes in source and rebuild.

# COMMAND ----------

"""
databricks_api_workspace.core.runtime.paths - Package path utilities.

Provides utilities for resolving paths relative to the package root.
Works identically in local development and Databricks environments.

Functions:
    get_package_root(): Get path to databricks_api_workspace package root
    get_config_dir(): Get path to config directory
    get_routes_dir(): Get path to routes directory
    help(): Display module usage information
"""

from __future__ import annotations

from pathlib import Path

__all__ = [
    "get_package_root",
    "get_data_dir",
    "get_config_dir",
    "get_routes_dir",
    "help",
]


def get_package_root() -> Path:
    """Get path to databricks_api_workspace package root.

    Returns the absolute path to the package root directory,
    which contains config/, routes/, core/, services/, etc.

    Works identically in local development and Databricks.

    Returns:
        Path: Absolute path to package root.

    Example:
        >>> from databricks_api_workspace.core.runtime import get_package_root
        >>> root = get_package_root()
        >>> config_path = root / "config" / "config.json"
    """
    # __file__ is core/runtime/paths.py
    # parent.parent.parent gets us to databricks_api_workspace/
    return Path(__file__).parent.parent.parent.resolve()


def get_data_dir() -> Path:
    """Get path to library data directory.

    Contains library defaults: config.json, routes/, queries/, schemas/.

    Returns:
        Path: Absolute path to data directory.

    Example:
        >>> from databricks_api_workspace.core.runtime import get_data_dir
        >>> config_path = get_data_dir() / "config.json"
    """
    return get_package_root() / "data"


def get_config_dir() -> Path:
    """Get path to config directory (alias for get_data_dir).

    Returns:
        Path: Absolute path to data directory (contains config.json).

    Example:
        >>> from databricks_api_workspace.core.runtime import get_config_dir
        >>> schemas_dir = get_config_dir() / "schemas"
    """
    return get_data_dir()


def get_routes_dir() -> Path:
    """Get path to routes directory.

    Returns:
        Path: Absolute path to routes directory.

    Example:
        >>> from databricks_api_workspace.core.runtime import get_routes_dir
        >>> builtin = get_routes_dir() / "_builtin"
    """
    return get_data_dir() / "routes"


def help() -> str:
    """Display module usage information.

    Returns:
        str: Help text with available functions and examples.
    """
    return """
databricks_api_workspace.core.runtime.paths
==============================================

Package path utilities for resolving paths relative to package root.
Works identically in local development and Databricks environments.

Functions:
---------
  get_package_root() -> Path
      Get absolute path to databricks_api_workspace package root.

  get_data_dir() -> Path
      Get absolute path to data/ directory (library defaults).

  get_config_dir() -> Path
      Alias for get_data_dir() (contains config.json).

  get_routes_dir() -> Path
      Get absolute path to data/routes/ directory.

Examples:
--------
  from databricks_api_workspace.core.runtime import get_data_dir

  # Get config file
  config_path = get_data_dir() / "config.json"

  # Get schema file
  schema_path = get_data_dir() / "schemas" / "route.schema.json"

  # Get route file
  route_path = get_routes_dir() / "_builtin" / "health.json"
"""
