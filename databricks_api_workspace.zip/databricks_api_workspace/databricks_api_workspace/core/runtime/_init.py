# Databricks notebook source
# MAGIC %md
# MAGIC # __init__
# MAGIC
# MAGIC **Auto-generated from:** `__init__.py`
# MAGIC **Build timestamp:** 2025-12-22T22:33:16.529259+00:00
# MAGIC **Content hash:** e59d846f996f
# MAGIC
# MAGIC > Do not edit directly. Make changes in source and rebuild.

# COMMAND ----------

# MAGIC %run ../../core/runtime/environment
# MAGIC %run ../../core/runtime/paths
# MAGIC %run ../../core/runtime/services

# COMMAND ----------

"""
databricks_api_workspace.core.runtime - Runtime detection and services.

Provides unified API for both local development and Databricks execution.
Automatically detects environment and returns appropriate implementations.

Functions:
    is_databricks(): Check if running in Databricks
    is_local(): Check if running locally
    get_dbutils(): Get dbutils instance (real or mock)
    get_spark(): Get SparkSession (real or mock)
    get_package_root(): Get path to package root
    get_config_dir(): Get path to config directory
    get_routes_dir(): Get path to routes directory
    help(): Display module usage information

Example:
    >>> from databricks_api_workspace.core.runtime import is_databricks, get_spark
    >>> if is_databricks():
    ...     spark = get_spark()
"""

from __future__ import annotations

# Re-exports

__all__ = [
    # Environment
    "is_databricks",
    "is_local",
    # Services
    "get_dbutils",
    "get_spark",
    # Paths
    "get_package_root",
    "get_config_dir",
    "get_routes_dir",
    # Help
    "help",
]


def help() -> str:
    """Display runtime module usage information.

    Returns:
        str: Help text with all available functions and examples.

    Example:
        >>> from databricks_api_workspace.core import runtime
        >>> print(runtime.help())
    """
    return """
databricks_api_workspace.core.runtime
====================================

Runtime detection and Databricks service access.

Environment Detection:
---------------------
  is_databricks() -> bool
      True if running in Databricks cluster.

  is_local() -> bool
      True if running in local development.

Service Access:
--------------
  get_dbutils() -> Any
      Returns dbutils (real in Databricks, mock locally).

  get_spark() -> Any
      Returns SparkSession (real in Databricks, mock locally).

Path Utilities:
--------------
  get_package_root() -> Path
      Get absolute path to package root.

  get_config_dir() -> Path
      Get absolute path to config directory.

  get_routes_dir() -> Path
      Get absolute path to routes directory.

Quick Start:
-----------
  from databricks_api_workspace.core.runtime import (
      is_databricks,
      get_spark,
      get_config_dir,
  )

  # Check environment
  if is_databricks():
      print("Running in Databricks")

  # Get Spark session
  spark = get_spark()
  df = spark.sql("SELECT * FROM table")

  # Get config path
  config_path = get_config_dir() / "config.json"

Submodules:
----------
  _settings   - Runtime constants
  environment - is_databricks(), is_local()
  services    - get_dbutils(), get_spark()
  paths       - Package path utilities
"""
