# Databricks notebook source
# MAGIC %md
# MAGIC # environment
# MAGIC
# MAGIC **Auto-generated from:** `environment.py`
# MAGIC **Build timestamp:** 2025-12-22T22:33:16.523711+00:00
# MAGIC **Content hash:** d3a050c821b9
# MAGIC
# MAGIC > Do not edit directly. Make changes in source and rebuild.

# COMMAND ----------

# MAGIC %run ../../core/runtime/_settings

# COMMAND ----------

"""
databricks_api_workspace.core.runtime.environment - Environment detection.

Detects whether code is running in Databricks or local development environment.

Functions:
    is_databricks(): Check if running in Databricks
    is_local(): Check if running locally
    help(): Display module usage information
"""

from __future__ import annotations

import os


__all__ = [
    "is_databricks",
    "is_local",
    "help",
]


def is_databricks() -> bool:
    """Check if running in Databricks environment.

    Detects Databricks by checking for the DATABRICKS_RUNTIME_VERSION
    environment variable which is set by the Databricks runtime.

    Returns:
        bool: True if running in Databricks, False for local development.

    Example:
        >>> from databricks_api_workspace.core.runtime import is_databricks
        >>> if is_databricks():
        ...     print("Running in Databricks cluster")
        ... else:
        ...     print("Running locally")
    """
    return DATABRICKS_RUNTIME_VAR in os.environ


def is_local() -> bool:
    """Check if running in local development environment.

    Inverse of is_databricks() for readability.

    Returns:
        bool: True if running locally, False if in Databricks.

    Example:
        >>> from databricks_api_workspace.core.runtime import is_local
        >>> if is_local():
        ...     print("Using mock implementations")
    """
    return not is_databricks()


def help() -> str:
    """Display module usage information.

    Returns:
        str: Help text with available functions and examples.
    """
    return """
databricks_api_workspace.core.runtime.environment
====================================================

Environment detection functions.

Functions:
---------
  is_databricks() -> bool
      Returns True if running in Databricks cluster.
      Checks for DATABRICKS_RUNTIME_VERSION env var.

  is_local() -> bool
      Returns True if running in local development.
      Inverse of is_databricks().

Usage:
-----
  from databricks_api_workspace.core.runtime import is_databricks

  if is_databricks():
      # Use real Spark, dbutils
      pass
  else:
      # Use mocks for local development
      pass
"""
