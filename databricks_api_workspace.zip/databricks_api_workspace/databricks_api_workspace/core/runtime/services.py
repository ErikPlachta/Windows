# Databricks notebook source
# MAGIC %md
# MAGIC # services
# MAGIC
# MAGIC **Auto-generated from:** `services.py`
# MAGIC **Build timestamp:** 2025-12-22T22:33:16.526743+00:00
# MAGIC **Content hash:** 7b0cd52f67e7
# MAGIC
# MAGIC > Do not edit directly. Make changes in source and rebuild.

# COMMAND ----------

# MAGIC %run ../../core/runtime/environment

# COMMAND ----------

"""
databricks_api_workspace.core.runtime.services - Databricks service access.

Provides access to Databricks services (dbutils, SparkSession) with automatic
mock fallback for local development.

Functions:
    get_dbutils(): Get dbutils instance (real or mock)
    get_spark(): Get SparkSession (real or mock)
    help(): Display module usage information
"""

from __future__ import annotations

from typing import TYPE_CHECKING, Any


if TYPE_CHECKING:
    pass

__all__ = [
    "get_dbutils",
    "get_spark",
    "help",
]


def get_dbutils() -> Any:
    """Get dbutils instance (real or mock).

    In Databricks: Returns the real dbutils from the runtime.
    Locally: Returns MockDbutils for development.

    Returns:
        Any: Real dbutils in Databricks, MockDbutils locally.

    Raises:
        RuntimeError: If dbutils not available in Databricks environment.

    Example:
        >>> from databricks_api_workspace.core.runtime import get_dbutils
        >>> dbutils = get_dbutils()
        >>> dbutils.fs.ls("/mnt/data")
    """
    if is_databricks():  # pragma: no cover
        # In Databricks, dbutils is injected as a global
        # Access via IPython if available, otherwise check globals
        try:
            from IPython import get_ipython

            ipython = get_ipython()
            if ipython is not None:
                dbutils = ipython.user_ns.get("dbutils")
                if dbutils is not None:
                    return dbutils
        except ImportError:
            pass

        # Fallback: check if dbutils exists in builtins
        import builtins

        if hasattr(builtins, "dbutils"):
            return builtins.dbutils

        raise RuntimeError("dbutils not available in Databricks environment")
    else:
        from mocks.dbutils_mock import get_mock_dbutils

        return get_mock_dbutils()


def get_spark() -> Any:
    """Get SparkSession instance (real or mock).

    In Databricks: Returns the real SparkSession from the runtime.
    Locally: Returns MockSparkSession for development.

    Returns:
        Any: Real SparkSession in Databricks, MockSparkSession locally.

    Raises:
        RuntimeError: If spark not available in Databricks environment.

    Example:
        >>> from databricks_api_workspace.core.runtime import get_spark
        >>> spark = get_spark()
        >>> df = spark.sql("SELECT * FROM customers")
    """
    if is_databricks():  # pragma: no cover
        # In Databricks, spark is injected as a global
        try:
            from IPython import get_ipython

            ipython = get_ipython()
            if ipython is not None:
                spark = ipython.user_ns.get("spark")
                if spark is not None:
                    return spark
        except ImportError:
            pass

        # Fallback: check if spark exists in builtins
        import builtins

        if hasattr(builtins, "spark"):
            return builtins.spark

        raise RuntimeError("spark not available in Databricks environment")
    else:
        from mocks.spark_mock import get_mock_spark

        return get_mock_spark()


def help() -> str:
    """Display module usage information.

    Returns:
        str: Help text with available functions and examples.
    """
    return """
databricks_api_workspace.core.runtime.services
=================================================

Databricks service access with mock fallback.

Functions:
---------
  get_dbutils() -> Any
      Returns dbutils instance.
      - Databricks: Real dbutils from runtime
      - Local: MockDbutils from mocks module

  get_spark() -> Any
      Returns SparkSession instance.
      - Databricks: Real SparkSession from runtime
      - Local: MockSparkSession from mocks module

Usage:
-----
  from databricks_api_workspace.core.runtime import get_dbutils, get_spark

  # Get dbutils for file operations
  dbutils = get_dbutils()
  files = dbutils.fs.ls("/mnt/data")

  # Get spark for SQL queries
  spark = get_spark()
  df = spark.sql("SELECT * FROM table")

Notes:
-----
  - In Databricks, accesses globals via IPython or builtins
  - Locally, imports from mocks package
  - Raises RuntimeError if services unavailable in Databricks
"""
