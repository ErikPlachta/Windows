# Databricks notebook source
# MAGIC %md
# MAGIC # _settings
# MAGIC
# MAGIC **Auto-generated from:** `_settings.py`
# MAGIC **Build timestamp:** 2025-12-22T22:33:16.527908+00:00
# MAGIC **Content hash:** 2ca538af290b
# MAGIC
# MAGIC > Do not edit directly. Make changes in source and rebuild.

# COMMAND ----------

"""
databricks_api_workspace.core.runtime._settings - Runtime module configuration.

Constants and configuration values for runtime detection and services.

Functions:
    help(): Display module usage information

Constants:
    DATABRICKS_RUNTIME_VAR: Environment variable for Databricks detection
"""

from __future__ import annotations

__all__ = [
    "DATABRICKS_RUNTIME_VAR",
    "help",
]

# Environment variable set by Databricks runtime
DATABRICKS_RUNTIME_VAR: str = "DATABRICKS_RUNTIME_VERSION"


def help() -> str:
    """Display module usage information.

    Returns:
        str: Help text with module purpose and available constants.

    Example:
        >>> from databricks_api_workspace.core.runtime import _settings
        >>> print(_settings.help())
    """
    return """
databricks_api_workspace.core.runtime._settings
===============================================

Runtime configuration constants.

Constants:
---------
  DATABRICKS_RUNTIME_VAR  - Env var for Databricks detection
                            Value: "DATABRICKS_RUNTIME_VERSION"

Usage:
-----
  from databricks_api_workspace.core.runtime._settings import DATABRICKS_RUNTIME_VAR

  if DATABRICKS_RUNTIME_VAR in os.environ:
      print("Running in Databricks")
"""
