# Databricks notebook source
# MAGIC %md
# MAGIC # validator
# MAGIC
# MAGIC **Auto-generated from:** `validator.py`
# MAGIC **Build timestamp:** 2025-12-22T22:33:16.596873+00:00
# MAGIC **Content hash:** 10eb7e7e9c5b
# MAGIC
# MAGIC > Do not edit directly. Make changes in source and rebuild.

# COMMAND ----------

# MAGIC %run ../../core/routes/_settings
# MAGIC %run ../../core/routes/loader

# COMMAND ----------

"""
databricks_api_workspace.core.routes.validator - Route validation utilities.

Validate route definitions against expected schema and constraints.

Functions:
    validate_route(): Validate a single route definition
    validate_routes(): Validate all routes
    validate_param(): Validate a parameter definition
    validate_no_duplicate_paths(): Check for duplicate route paths
    validate_schema_files_exist(): Check referenced schema files exist
"""

from __future__ import annotations

from pathlib import Path
from typing import Any


__all__ = [
    "validate_route",
    "validate_routes",
    "validate_param",
    "validate_no_duplicate_paths",
    "validate_schema_files_exist",
    "RouteValidationError",
]


class RouteValidationError(Exception):
    """Raised when route validation fails."""

    def __init__(self, message: str, route_source: str | None = None):
        self.route_source = route_source
        super().__init__(f"{route_source}: {message}" if route_source else message)


def validate_param(param: dict[str, Any], route_source: str) -> list[str]:
    """Validate a parameter definition.

    Args:
        param: Parameter definition dict.
        route_source: Source file for error messages.

    Returns:
        List of validation error messages (empty if valid).
    """
    errors: list[str] = []

    # Required fields
    if "name" not in param:
        errors.append(f"{route_source}: param missing 'name'")
    if "source" not in param:
        errors.append(f"{route_source}: param missing 'source'")
    else:
        # Validate source format
        source = param["source"]
        prefix = source.split(".")[0] if "." in source else source

        if prefix not in PARAM_SOURCE_PREFIXES and source != "body":
            errors.append(
                f"{route_source}: invalid param source '{source}', "
                f"must start with {list(PARAM_SOURCE_PREFIXES)}"
            )

    return errors


def validate_route_version(
    version: dict[str, Any], route_source: str, version_idx: int
) -> list[str]:
    """Validate a route version definition.

    Args:
        version: Route version definition.
        route_source: Source file for error messages.
        version_idx: Index of this version in the route array.

    Returns:
        List of validation error messages.
    """
    errors: list[str] = []
    ctx = f"{route_source}[{version_idx}]"

    # Required fields
    if "version" not in version:
        errors.append(f"{ctx}: missing 'version'")
    if "path" not in version:
        errors.append(f"{ctx}: missing 'path'")
    if "method" not in version:
        errors.append(f"{ctx}: missing 'method'")
    elif version["method"].upper() not in SUPPORTED_HTTP_METHODS:
        errors.append(
            f"{ctx}: invalid method '{version['method']}', "
            f"must be one of {list(SUPPORTED_HTTP_METHODS)}"
        )
    if "logic" not in version:
        errors.append(f"{ctx}: missing 'logic' (notebook path)")

    # Validate params if present
    for param in version.get("params", []):
        errors.extend(validate_param(param, ctx))

    return errors


def _resolve_schema_path(
    schema_ref: str,
    route: dict[str, Any],
    base_path: Path | None,
) -> Path:
    """Resolve schema reference to absolute path.

    Schema paths can be:
    - Relative to route folder: "schemas/request.json"
    - Absolute from routes root: "/schemas/common.json"

    Args:
        schema_ref: Schema reference from route definition.
        route: Route definition dict.
        base_path: Base routes folder path.

    Returns:
        Resolved Path object.
    """
    if base_path is None:

        base_path = get_routes_path()

    resource = route.get("_resource")

    if schema_ref.startswith("/"):
        # Absolute from routes root
        return base_path / schema_ref.lstrip("/")
    elif resource and resource != "_builtin":
        # Relative to resource folder
        return base_path / resource / schema_ref
    else:
        # Relative to routes root
        return base_path / schema_ref


def validate_schema_files_exist(
    route: dict[str, Any],
    base_path: Path | None = None,
) -> list[str]:
    """Validate that referenced schema files exist.

    Checks _settings.validation.requestSchema and .responseSchema
    paths resolve to actual files.

    Args:
        route: Route definition dictionary.
        base_path: Base path for resolving schema paths.

    Returns:
        List of validation error messages.

    Example:
        >>> route = {"_settings": {"validation": {"requestSchema": "schemas/req.json"}}}
        >>> errors = validate_schema_files_exist(route)
        >>> if errors:
        ...     print(f"Missing schemas: {errors}")
    """
    errors: list[str] = []
    route_source = route.get("_source", "unknown")
    settings = route.get("_settings", {})
    validation = settings.get("validation", {})

    for schema_key in ("requestSchema", "responseSchema"):
        schema_ref = validation.get(schema_key)
        if schema_ref:
            schema_path = _resolve_schema_path(schema_ref, route, base_path)
            if not schema_path.exists():
                errors.append(f"{route_source}: {schema_key} file not found: {schema_ref}")

    return errors


def validate_route(
    route: dict[str, Any],
    queries_path: Path | None = None,
    routes_path: Path | None = None,
) -> list[str]:
    """Validate a single route definition.

    Checks:
    - Required fields present (_meta, _settings, route, auth)
    - Route versions have required fields
    - HTTP methods are valid
    - Param sources are valid
    - Referenced notebooks exist (if queries_path provided)
    - Referenced schema files exist (if routes_path provided)
    - At least one route version has isDefault=True

    Args:
        route: Route definition dictionary.
        queries_path: Optional path to queries folder for notebook validation.
        routes_path: Optional path to routes folder for schema file validation.

    Returns:
        List of validation error messages (empty if valid).
    """
    errors: list[str] = []
    route_source = route.get("_source", "unknown")

    # Check required top-level sections
    if "_meta" not in route:
        errors.append(f"{route_source}: missing '_meta' section")
    if "_settings" not in route:
        errors.append(f"{route_source}: missing '_settings' section")
    if "route" not in route:
        errors.append(f"{route_source}: missing 'route' section")
    if "auth" not in route:
        errors.append(f"{route_source}: missing 'auth' section")

    # Validate route versions
    route_versions = route.get("route", [])
    if not isinstance(route_versions, list):
        errors.append(f"{route_source}: 'route' must be an array")
        return errors

    if len(route_versions) == 0:
        errors.append(f"{route_source}: 'route' array is empty")
        return errors

    # Check for default version
    has_default = any(v.get("isDefault", False) for v in route_versions)
    if not has_default:
        errors.append(f"{route_source}: no route version has isDefault=true")

    # Validate each version
    for idx, version in enumerate(route_versions):
        errors.extend(validate_route_version(version, route_source, idx))

        # Check notebook exists if queries_path provided
        if queries_path and "logic" in version:
            notebook_path = queries_path / f"{version['logic']}.ipynb"
            if not notebook_path.exists():
                errors.append(
                    f"{route_source}[{idx}]: notebook not found: {version['logic']}.ipynb"
                )

    # Check schema files exist if routes_path provided
    if routes_path:
        errors.extend(validate_schema_files_exist(route, routes_path))

    return errors


def validate_no_duplicate_paths(routes: list[dict[str, Any]]) -> list[str]:
    """Check for duplicate route paths.

    Args:
        routes: List of route definitions.

    Returns:
        List of validation error messages for duplicates.
    """
    errors: list[str] = []
    seen: dict[str, str] = {}  # (method, path) -> source

    for route in routes:
        resource = route.get("_resource", "")
        route_source = route.get("_source", "unknown")

        for version in route.get("route", []):
            method = version.get("method", "GET").upper()
            path = version.get("path", "")
            version_str = version.get("version", "v1")

            # Build full path
            full_path = f"/{resource}{path}" if resource and resource != "_builtin" else path

            key = f"{method}:{full_path}:{version_str}"

            if key in seen:
                errors.append(
                    f"Duplicate route: {method} {full_path} (version {version_str}) "
                    f"defined in both {seen[key]} and {route_source}"
                )
            else:
                seen[key] = route_source

    return errors


def validate_routes(
    routes: list[dict[str, Any]],
    queries_path: Path | None = None,
    strict: bool = True,
    routes_path: Path | None = None,
) -> tuple[bool, list[str]]:
    """Validate all routes.

    Args:
        routes: List of route definitions.
        queries_path: Optional path to queries folder.
        strict: If True, raise on first error.
        routes_path: Optional path to routes folder for schema validation.

    Returns:
        Tuple of (is_valid, list of error messages).

    Raises:
        RouteValidationError: If strict=True and validation fails.
    """
    all_errors: list[str] = []

    # Validate each route
    for route in routes:
        errors = validate_route(route, queries_path, routes_path)
        all_errors.extend(errors)

    # Check for duplicate paths
    all_errors.extend(validate_no_duplicate_paths(routes))

    is_valid = len(all_errors) == 0

    if not is_valid and strict:
        raise RouteValidationError(
            f"Route validation failed with {len(all_errors)} error(s):\n"
            + "\n".join(f"  - {e}" for e in all_errors)
        )

    return is_valid, all_errors
