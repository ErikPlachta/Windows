# Databricks notebook source
# MAGIC %md
# MAGIC # audit
# MAGIC
# MAGIC **Auto-generated from:** `audit.py`
# MAGIC **Build timestamp:** 2025-12-22T22:33:16.589048+00:00
# MAGIC **Content hash:** 3fd78f2ed203
# MAGIC
# MAGIC > Do not edit directly. Make changes in source and rebuild.

# COMMAND ----------

# MAGIC %run ../../core/logging/core
# MAGIC %run ../../core/config/_init
# MAGIC %run ../../core/runtime/_init
# MAGIC %run ../../core/sql_utils/_init

# COMMAND ----------

"""
databricks_api_workspace.core.routes.audit - Route audit logging.

Log route state changes to Delta tables for compliance and debugging.

Functions:
    write_route_audit(): Write route state change to audit log
    query_route_audit(): Query audit records
    get_route_history(): Get change history for a route
    help(): Display module usage information
"""

from __future__ import annotations

import json
from datetime import datetime, timezone
from typing import TYPE_CHECKING, Any


if TYPE_CHECKING:
    pass

__all__ = [
    "write_route_audit",
    "query_route_audit",
    "get_route_history",
    "help",
]

# Default audit table name
DEFAULT_AUDIT_TABLE = "databricks_api_workspace.route_audit"


def write_route_audit(
    route_path: str,
    action: str,
    changed_by: str | None = None,
    previous_state: dict[str, Any] | None = None,
    new_state: dict[str, Any] | None = None,
    reason: str | None = None,
    correlation_id: str | None = None,
    extra_fields: dict[str, Any] | None = None,
) -> bool:
    """Write route state change to audit log.

    Records changes like enabled/disabled, modifications, deprecation.
    Writes to Delta table for compliance and debugging.

    Args:
        route_path: Route identifier (e.g., "customers/get-customer").
        action: Action type (e.g., "enabled", "disabled", "modified", "created", "deleted").
        changed_by: User/system that made the change.
        previous_state: State before change (subset of route JSON).
        new_state: State after change (subset of route JSON).
        reason: Reason for the change.
        correlation_id: Correlation ID for tracing.
        extra_fields: Additional fields to include.

    Returns:
        bool: True if write succeeded, False otherwise.

    Example:
        >>> write_route_audit(
        ...     route_path="customers/risk",
        ...     action="disabled",
        ...     changed_by="erik.plachta@example.com",
        ...     previous_state={"enabled": True},
        ...     new_state={"enabled": False},
        ...     reason="Emergency: timeout errors in prod",
        ... )
    """
    # Lazy imports to avoid circular dependencies

    # Check if audit logging is enabled
    if not get_config_value("audit.routes.enabled", True):
        return False

    table = get_config_value("audit.routes.table", DEFAULT_AUDIT_TABLE)

    try:
        record = {
            "event_id": f"{route_path}_{datetime.now(timezone.utc).timestamp()}",
            "timestamp_utc": datetime.now(timezone.utc).isoformat(),
            "route_path": route_path,
            "action": action,
            "changed_by": changed_by or "system",
            "previous_state_json": json.dumps(previous_state) if previous_state else None,
            "new_state_json": json.dumps(new_state) if new_state else None,
            "reason": reason,
            "correlation_id": correlation_id,
        }

        # Add extra fields
        if extra_fields:
            record.update(extra_fields)

        # Write to Delta
        spark = get_spark()
        from mocks.spark_mock import Row

        df = spark.createDataFrame([Row(**record)])
        df.write.format("delta").mode("append").saveAsTable(table)

        log_info(
            "Route audit log written",
            route_path=route_path,
            action=action,
            changed_by=record["changed_by"],
        )
        return True

    except Exception as e:  # pragma: no cover
        log_error(
            "Failed to write route audit log",
            error=str(e),
            route_path=route_path,
            action=action,
        )
        return False


def query_route_audit(
    route_path: str | None = None,
    action: str | None = None,
    changed_by: str | None = None,
    start_date: str | None = None,
    end_date: str | None = None,
    limit: int = 100,
) -> Any:
    """Query route audit records.

    Args:
        route_path: Filter by route path.
        action: Filter by action type.
        changed_by: Filter by who made the change.
        start_date: Filter by start date (ISO format).
        end_date: Filter by end date (ISO format).
        limit: Maximum records to return.

    Returns:
        Spark DataFrame with audit records.

    Example:
        >>> df = query_route_audit(route_path="customers/risk", action="disabled")
        >>> df.show()
    """
    # Lazy imports

    table = safe_sql_identifier(get_config_value("audit.routes.table", DEFAULT_AUDIT_TABLE))
    spark = get_spark()

    # Build query with escaped parameters
    conditions = []
    if route_path:
        conditions.append(f"route_path = '{escape_sql_string(route_path)}'")
    if action:
        conditions.append(f"action = '{escape_sql_string(action)}'")
    if changed_by:
        conditions.append(f"changed_by = '{escape_sql_string(changed_by)}'")
    if start_date:
        conditions.append(f"timestamp_utc >= '{escape_sql_string(start_date)}'")
    if end_date:
        conditions.append(f"timestamp_utc <= '{escape_sql_string(end_date)}'")

    where_clause = f"WHERE {' AND '.join(conditions)}" if conditions else ""

    query = f"""
        SELECT *
        FROM {table}
        {where_clause}
        ORDER BY timestamp_utc DESC
        LIMIT {int(limit)}
    """

    return spark.sql(query)


def get_route_history(
    route_path: str,
    limit: int = 50,
) -> list[dict[str, Any]]:
    """Get change history for a specific route.

    Returns audit records as a list of dicts for easy processing.

    Args:
        route_path: Route path to get history for.
        limit: Maximum records to return.

    Returns:
        List of audit records as dicts.

    Example:
        >>> history = get_route_history("customers/risk")
        >>> for record in history:
        ...     print(f"{record['timestamp_utc']}: {record['action']} by {record['changed_by']}")
    """
    df = query_route_audit(route_path=route_path, limit=limit)

    # Convert to list of dicts
    try:
        return [row.asDict() for row in df.collect()]
    except Exception:
        # If DataFrame operations fail (e.g., in tests), return empty list
        return []


def help() -> str:
    """Display module usage information.

    Returns:
        str: Help text with audit logging usage.
    """
    return """
databricks_api_workspace.core.routes.audit
==========================================

Route audit logging to Delta tables.

Functions:
---------
  write_route_audit(route_path, action, changed_by=None, ...)
      Write route state change to audit log.
      Actions: "enabled", "disabled", "modified", "created", "deleted"

  query_route_audit(route_path=None, action=None, ...)
      Query audit records with filters.
      Returns Spark DataFrame.

  get_route_history(route_path, limit=50)
      Get change history for a specific route.
      Returns list of dicts.

Configuration:
-------------
  audit.routes.enabled - Enable/disable audit logging (default: True)
  audit.routes.table   - Delta table name (default: databricks_api_workspace.route_audit)

Usage:
-----
  from databricks_api_workspace.core.routes.audit import (
      write_route_audit,
      get_route_history,
  )

  # Log route disabled
  write_route_audit(
      route_path="customers/risk",
      action="disabled",
      changed_by="admin@example.com",
      reason="Emergency maintenance",
  )

  # Get route history
  history = get_route_history("customers/risk")
  for record in history:
      print(f"{record['action']} at {record['timestamp_utc']}")

Audit Record Schema:
------------------
  - event_id: Unique event identifier
  - timestamp_utc: When the change occurred
  - route_path: Route identifier
  - action: What changed (enabled, disabled, modified, etc.)
  - changed_by: Who made the change
  - previous_state_json: State before change
  - new_state_json: State after change
  - reason: Why the change was made
  - correlation_id: For tracing across systems
"""
