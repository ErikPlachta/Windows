# Databricks notebook source
# MAGIC %md
# MAGIC # schema_validation
# MAGIC
# MAGIC **Auto-generated from:** `schema_validation.py`
# MAGIC **Build timestamp:** 2025-12-22T22:33:16.595554+00:00
# MAGIC **Content hash:** 000b379a46e3
# MAGIC
# MAGIC > Do not edit directly. Make changes in source and rebuild.

# COMMAND ----------

# MAGIC %run ../../core/validation_utils/schema
# MAGIC %run ../../core/routes/registry
# MAGIC %run ../../core/routes/loader

# COMMAND ----------

"""
databricks_api_workspace.core.routes.schema_validation - Route schema validation.

Validate request/response against route-defined schemas.

Functions:
    get_route_schema(): Load schema for a route
    validate_route_request(): Validate request against route schema
    validate_route_response(): Validate response against route schema
    help(): Display module usage information
"""

from __future__ import annotations

from pathlib import Path
from typing import TYPE_CHECKING, Any


if TYPE_CHECKING:

__all__ = [
    "get_route_schema",
    "validate_route_request",
    "validate_route_response",
    "help",
]


def get_route_schema(
    route: Route,
    schema_type: str,
    routes_path: Path | None = None,
) -> dict[str, Any] | None:
    """Load schema file for a route.

    Supports both camelCase (route JSON) and snake_case keys:
    - requestSchema / request_schema
    - responseSchema / response_schema

    Args:
        route: Route definition object.
        schema_type: Schema type: "request" or "response".
        routes_path: Base path for routes folder.

    Returns:
        Schema dict or None if not defined.

    Example:
        >>> schema = get_route_schema(route, "request")
        >>> if schema:
        ...     errors = validate_against_schema(params, schema)
    """
    # Access raw route data
    settings = route.raw.get("_settings", {})
    validation = settings.get("validation", {})

    # Support both camelCase and snake_case
    camel_key = f"{schema_type}Schema"  # requestSchema, responseSchema
    snake_key = f"{schema_type}_schema"  # request_schema, response_schema

    schema_ref = validation.get(camel_key) or validation.get(snake_key)

    if not schema_ref:
        return None

    # Resolve schema path
    if routes_path is None:

        routes_path = get_routes_path()

    resource = route.resource

    if schema_ref.startswith("/"):
        # Absolute from routes root
        schema_path = routes_path / schema_ref.lstrip("/")
    elif resource and resource != "_builtin":
        # Relative to resource folder
        schema_path = routes_path / resource / schema_ref
    else:
        # Relative to routes root
        schema_path = routes_path / schema_ref

    if not schema_path.exists():
        return None

    return load_schema(schema_path)


def validate_route_request(
    route: Route,
    params: dict[str, Any],
    routes_path: Path | None = None,
) -> None:
    """Validate request params against route's request schema.

    Args:
        route: Route definition with schema reference.
        params: Request parameters to validate.
        routes_path: Base path for routes folder.

    Raises:
        ValidationError: If validation fails.

    Example:
        >>> validate_route_request(route, {"customer_id": "123"})
    """
    schema = get_route_schema(route, "request", routes_path)
    if not schema:
        return  # No schema defined, skip validation

    errors = validate_against_schema(params, schema, "request")
    if errors:
        raise ValidationError(
            f"Request validation failed for route {route.full_path}",
            errors=errors,
        )


def validate_route_response(
    route: Route,
    response: dict[str, Any],
    routes_path: Path | None = None,
) -> None:
    """Validate response against route's response schema.

    Args:
        route: Route definition with schema reference.
        response: Response data to validate.
        routes_path: Base path for routes folder.

    Raises:
        ValidationError: If validation fails.

    Example:
        >>> validate_route_response(route, {"data": {"status": "ok"}})
    """
    schema = get_route_schema(route, "response", routes_path)
    if not schema:
        return  # No schema defined, skip validation

    errors = validate_against_schema(response, schema, "response")
    if errors:
        raise ValidationError(
            f"Response validation failed for route {route.full_path}",
            errors=errors,
        )


def help() -> str:
    """Display module usage information.

    Returns:
        str: Help text with route schema validation usage.
    """
    return """
databricks_api_workspace.core.routes.schema_validation
======================================================

Route-specific schema validation for request/response data.

Functions:
---------
  get_route_schema(route, schema_type, routes_path=None) -> dict | None
      Load schema for a route.
      schema_type: "request" or "response"
      Returns None if no schema defined.

  validate_route_request(route, params, routes_path=None) -> None
      Validate request params against route's requestSchema.
      Raises ValidationError if validation fails.

  validate_route_response(route, response, routes_path=None) -> None
      Validate response against route's responseSchema.
      Raises ValidationError if validation fails.

Schema References:
-----------------
  Routes define schemas in _settings.validation:
    {
      "_settings": {
        "validation": {
          "requestSchema": "schemas/request.json",
          "responseSchema": "schemas/response.json"
        }
      }
    }

  Supports both camelCase and snake_case:
    - requestSchema / request_schema
    - responseSchema / response_schema

Path Resolution:
---------------
  - Absolute (starts with /): /schemas/common.json -> routes/schemas/common.json
  - Relative: schemas/req.json -> routes/{resource}/schemas/req.json

Usage:
-----
  from databricks_api_workspace.core.routes.schema_validation import (
      validate_route_request,
      validate_route_response,
  )

  # Before execution
  validate_route_request(route, mapped_params)

  # After execution
  validate_route_response(route, result_data)
"""
