# Databricks notebook source
# MAGIC %md
# MAGIC # _settings
# MAGIC
# MAGIC **Auto-generated from:** `_settings.py`
# MAGIC **Build timestamp:** 2025-12-22T22:33:16.598133+00:00
# MAGIC **Content hash:** 558fe9310d93
# MAGIC
# MAGIC > Do not edit directly. Make changes in source and rebuild.

# COMMAND ----------

"""
databricks_api_workspace.core.routes settings (private).

Default constants for route loading and validation. These are compile-time
defaults that can be overridden at runtime via external config files.

Constants:
    ROUTES_DEFAULT_PATH: Default path for routes folder
    ROUTES_BUILTIN_PATH: Path for built-in routes
    ROUTES_DEFAULTS_FILE: Name of defaults file
    VALIDATION_STRICT: Whether to fail on validation errors
    VALIDATION_TIMEOUT_DEFAULT: Default route timeout in seconds
    VALIDATION_RATE_LIMIT_DEFAULT: Default requests per minute
    SUPPORTED_HTTP_METHODS: Allowed HTTP methods
    PARAM_SOURCE_PREFIXES: Valid param source prefixes
"""

from __future__ import annotations

__all__ = [
    "ROUTES_DEFAULT_PATH",
    "ROUTES_BUILTIN_PATH",
    "ROUTES_DEFAULTS_FILE",
    "VALIDATION_STRICT",
    "VALIDATION_TIMEOUT_DEFAULT",
    "VALIDATION_RATE_LIMIT_DEFAULT",
    "SUPPORTED_HTTP_METHODS",
    "PARAM_SOURCE_PREFIXES",
    "API_VERSION_HEADER",
    "API_VERSION_QUERY_PARAM",
]

# -----------------------------------------------------------------------------
# Route Paths
# -----------------------------------------------------------------------------

# Default path for routes folder (relative to package root)
ROUTES_DEFAULT_PATH: str = "data/routes"

# Path for built-in routes (relative to routes folder)
ROUTES_BUILTIN_PATH: str = "_builtin"

# Name of defaults file at each level
ROUTES_DEFAULTS_FILE: str = "_defaults.json"

# -----------------------------------------------------------------------------
# Validation Settings
# -----------------------------------------------------------------------------

# Whether to fail startup on validation errors (can be overridden via config)
VALIDATION_STRICT: bool = True

# Default timeout for route execution (seconds)
VALIDATION_TIMEOUT_DEFAULT: int = 30

# Default rate limit (requests per minute)
VALIDATION_RATE_LIMIT_DEFAULT: int = 60

# -----------------------------------------------------------------------------
# HTTP Configuration
# -----------------------------------------------------------------------------

# Supported HTTP methods
SUPPORTED_HTTP_METHODS: frozenset[str] = frozenset({"GET", "POST", "PUT", "PATCH", "DELETE"})

# API version selection
API_VERSION_HEADER: str = "X-API-Version"
API_VERSION_QUERY_PARAM: str = "api_version"

# -----------------------------------------------------------------------------
# Parameter Source Configuration
# -----------------------------------------------------------------------------

# Valid param source prefixes for mapping request data to notebook params
PARAM_SOURCE_PREFIXES: frozenset[str] = frozenset({"path", "query", "body", "header"})
