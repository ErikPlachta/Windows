# Databricks notebook source
# MAGIC %md
# MAGIC # health
# MAGIC
# MAGIC **Auto-generated from:** `health.py`
# MAGIC **Build timestamp:** 2025-12-22T22:33:16.590565+00:00
# MAGIC **Content hash:** 94447b446746
# MAGIC
# MAGIC > Do not edit directly. Make changes in source and rebuild.

# COMMAND ----------

# MAGIC %run ../../core/routes/_settings
# MAGIC %run ../../core/routes/loader
# MAGIC %run ../../core/routes/validator

# COMMAND ----------

"""
databricks_api_workspace.core.routes.health - Route health checks.

Scheduled health checks and on-change validation triggers.

Functions:
    run_health_check(): Run comprehensive health check on routes
    get_routes_hash(): Compute hash of route files for change detection
    check_routes_changed(): Check if routes have changed since last check
    help(): Display module usage information
"""

from __future__ import annotations

import hashlib
from datetime import datetime, timezone
from pathlib import Path
from typing import Any


__all__ = [
    "run_health_check",
    "get_routes_hash",
    "check_routes_changed",
    "help",
]

# Cache for route hash to detect changes
_routes_hash_cache: dict[str, str] = {}


def get_routes_hash(routes_path: Path | str | None = None) -> str:
    """Compute hash of route files for change detection.

    Creates a SHA-256 hash of all route JSON files' contents.
    Used to detect when routes have been modified.

    Args:
        routes_path: Path to routes folder (default: package routes/).

    Returns:
        SHA-256 hash string.

    Example:
        >>> hash1 = get_routes_hash()
        >>> # ... modify route files ...
        >>> hash2 = get_routes_hash()
        >>> if hash1 != hash2:
        ...     print("Routes changed!")
    """
    routes_p = Path(routes_path) if routes_path else get_routes_path()

    if not routes_p.exists():
        return ""

    hasher = hashlib.sha256()

    # Sort files for consistent ordering
    route_files = sorted(routes_p.rglob("*.json"))

    for file_path in route_files:
        # Skip builtin routes for change detection (they're package-managed)
        if ROUTES_BUILTIN_PATH in str(file_path):
            continue

        try:
            content = file_path.read_text()
            # Include path in hash to detect renames
            hasher.update(str(file_path.relative_to(routes_p)).encode())
            hasher.update(content.encode())
        except OSError:
            # File might be locked or deleted, skip
            continue

    return hasher.hexdigest()


def check_routes_changed(
    routes_path: Path | str | None = None,
    cache_key: str = "default",
) -> tuple[bool, str]:
    """Check if routes have changed since last check.

    Compares current hash with cached hash.
    Call periodically or on triggers to detect changes.

    Args:
        routes_path: Path to routes folder.
        cache_key: Cache key for storing hash (use different keys for different paths).

    Returns:
        Tuple of (changed: bool, current_hash: str).

    Example:
        >>> changed, current_hash = check_routes_changed()
        >>> if changed:
        ...     # Re-validate routes
        ...     validate_startup(strict=True)
    """
    current_hash = get_routes_hash(routes_path)
    previous_hash = _routes_hash_cache.get(cache_key, "")

    changed = current_hash != previous_hash
    _routes_hash_cache[cache_key] = current_hash

    return changed, current_hash


def run_health_check(
    routes_path: Path | str | None = None,
    queries_path: Path | str | None = None,
    check_notebooks: bool = False,
) -> dict[str, Any]:
    """Run comprehensive health check on routes.

    Performs validation and optionally checks notebook accessibility.
    Designed for scheduled execution (e.g., Databricks Jobs).

    Args:
        routes_path: Path to routes folder.
        queries_path: Path to queries folder.
        check_notebooks: If True, verify notebooks exist (I/O intensive).

    Returns:
        Health check result dict with:
        - status: "healthy" | "degraded" | "unhealthy"
        - timestamp: ISO timestamp
        - routes_count: Number of routes loaded
        - validation_errors: List of validation errors
        - routes_hash: Current hash for change detection
        - changed_since_last_check: Whether routes changed

    Example:
        >>> result = run_health_check(check_notebooks=True)
        >>> if result["status"] != "healthy":
        ...     alert_on_call(result["validation_errors"])
    """
    routes_p = Path(routes_path) if routes_path else get_routes_path()
    queries_p = Path(queries_path) if queries_path else None

    result: dict[str, Any] = {
        "timestamp": datetime.now(timezone.utc).isoformat(),
        "routes_path": str(routes_p),
        "queries_path": str(queries_p) if queries_p else None,
    }

    # Check if routes changed
    changed, routes_hash = check_routes_changed(routes_p)
    result["routes_hash"] = routes_hash
    result["changed_since_last_check"] = changed

    # Load and validate routes
    try:
        raw_routes = load_routes(routes_p)
        result["routes_count"] = len(raw_routes)

        # Validate (non-strict to collect all errors)
        queries_for_validation = queries_p if check_notebooks else None
        is_valid, errors = validate_routes(raw_routes, queries_for_validation, strict=False)

        result["validation_errors"] = errors
        result["is_valid"] = is_valid

        # Determine status
        if is_valid and len(errors) == 0:
            result["status"] = "healthy"
        elif is_valid:
            # Valid but with warnings
            result["status"] = "degraded"
        else:
            result["status"] = "unhealthy"

    except Exception as e:
        result["status"] = "unhealthy"
        result["routes_count"] = 0
        result["is_valid"] = False
        result["validation_errors"] = [f"Failed to load routes: {e}"]

    return result


def help() -> str:
    """Display module usage information.

    Returns:
        str: Help text with health check usage.
    """
    return """
databricks_api_workspace.core.routes.health
===========================================

Route health checks and change detection.

Functions:
---------
  run_health_check(routes_path=None, queries_path=None, check_notebooks=False)
      Run comprehensive health check on routes.
      Returns status: "healthy" | "degraded" | "unhealthy"

  get_routes_hash(routes_path=None) -> str
      Compute SHA-256 hash of route files.
      Use for change detection.

  check_routes_changed(routes_path=None, cache_key="default") -> (bool, str)
      Check if routes changed since last check.
      Returns (changed, current_hash).

Usage:
-----
  from databricks_api_workspace.core.routes.health import (
      run_health_check,
      check_routes_changed,
  )

  # Scheduled health check (e.g., Databricks Job)
  result = run_health_check(check_notebooks=True)
  if result["status"] != "healthy":
      send_alert(result["validation_errors"])

  # On-change validation trigger
  changed, _ = check_routes_changed()
  if changed:
      from databricks_api_workspace.core.routes import validate_startup
      validate_startup(strict=True)

Integration with Databricks Jobs:
-------------------------------
  Create a scheduled job that calls run_health_check() periodically.
  Log results to Delta table for monitoring.
"""
