# Databricks notebook source
# MAGIC %md
# MAGIC # loader
# MAGIC
# MAGIC **Auto-generated from:** `loader.py`
# MAGIC **Build timestamp:** 2025-12-22T22:33:16.591938+00:00
# MAGIC **Content hash:** de51815fdd83
# MAGIC
# MAGIC > Do not edit directly. Make changes in source and rebuild.

# COMMAND ----------

# MAGIC %run ../../core/routes/_settings
# MAGIC %run ../../core/runtime/_init

# COMMAND ----------

"""
databricks_api_workspace.core.routes.loader - Route loading utilities.

Load route definitions from JSON files with cascading defaults inheritance.

Functions:
    load_routes(): Load all routes from routes folder
    load_route_file(): Load a single route JSON file
    load_defaults(): Load defaults file at given path
    merge_defaults(): Merge route with cascading defaults
    deep_merge(): Deep merge two dictionaries
    validate_defaults_structure(): Validate defaults against schema
"""

from __future__ import annotations

import json
from pathlib import Path
from typing import Any


__all__ = [
    "load_routes",
    "load_route_file",
    "load_defaults",
    "merge_defaults",
    "deep_merge",
    "get_routes_path",
    "validate_defaults_structure",
]

# Cache for defaults schema
_defaults_schema: dict[str, Any] | None = None


def _get_defaults_schema() -> dict[str, Any]:
    """Load defaults schema from config/schemas/defaults.schema.json.

    Returns:
        Schema dictionary, or empty dict if file doesn't exist.
    """
    global _defaults_schema

    if _defaults_schema is not None:
        return _defaults_schema

    schema_path = get_config_dir() / "schemas" / "defaults.schema.json"

    if not schema_path.exists():
        _defaults_schema = {}
        return _defaults_schema

    with schema_path.open() as f:
        _defaults_schema = json.load(f)

    return _defaults_schema


def validate_defaults_structure(
    defaults: dict[str, Any],
    source_file: Path | str,
) -> list[str]:
    """Validate defaults structure against schema.

    Checks that _defaults.json conforms to expected structure.

    Args:
        defaults: Loaded defaults dictionary.
        source_file: Path to defaults file for error messages.

    Returns:
        List of validation error messages (empty if valid).

    Example:
        >>> defaults = {"_settings": {"enabled": "not_a_boolean"}}
        >>> errors = validate_defaults_structure(defaults, "routes/_defaults.json")
        >>> if errors:
        ...     print(f"Invalid defaults: {errors}")
    """
    errors: list[str] = []
    schema = _get_defaults_schema()

    if not schema:
        # No schema file, skip validation
        return errors

    source = str(source_file)

    # Check additionalProperties constraint
    if schema.get("additionalProperties") is False:
        allowed_keys = set(schema.get("properties", {}).keys())
        for key in defaults.keys():
            if key not in allowed_keys:
                errors.append(f"{source}: unexpected property '{key}'")

    # Validate property types
    properties = schema.get("properties", {})

    for key, value in defaults.items():
        if key in properties:
            expected_type = properties[key].get("type")
            if expected_type == "object" and not isinstance(value, dict):
                errors.append(f"{source}: '{key}' must be an object")
            elif expected_type == "array" and not isinstance(value, list):
                errors.append(f"{source}: '{key}' must be an array")
            elif expected_type == "boolean" and not isinstance(value, bool):
                errors.append(f"{source}: '{key}' must be a boolean")
            elif expected_type == "string" and not isinstance(value, str):
                errors.append(f"{source}: '{key}' must be a string")
            elif expected_type == "integer" and not isinstance(value, int):
                errors.append(f"{source}: '{key}' must be an integer")

    return errors


def get_routes_path(base_path: Path | str | None = None) -> Path:
    """Get the routes folder path.

    Args:
        base_path: Optional base path. If None, uses package-relative path.

    Returns:
        Path to routes folder.
    """
    if base_path is not None:
        return Path(base_path)

    # Default: package root / routes
    return get_package_root() / ROUTES_DEFAULT_PATH


def load_defaults(path: Path, validate: bool = True) -> dict[str, Any]:
    """Load defaults file from a directory.

    Args:
        path: Directory path to load _defaults.json from.
        validate: Whether to validate defaults structure against schema.

    Returns:
        Defaults dictionary, or empty dict if file doesn't exist.

    Raises:
        ValueError: If validate=True and defaults structure is invalid.
    """
    defaults_file = path / ROUTES_DEFAULTS_FILE
    if not defaults_file.exists():
        return {}

    with defaults_file.open() as f:
        defaults = json.load(f)

    if validate:
        errors = validate_defaults_structure(defaults, defaults_file)
        if errors:
            raise ValueError(
                f"Invalid _defaults.json at {defaults_file}:\n"
                + "\n".join(f"  - {e}" for e in errors)
            )

    return defaults


def deep_merge(base: dict[str, Any], overlay: dict[str, Any]) -> dict[str, Any]:
    """Deep merge two dictionaries.

    Inheritance rules:
    - Objects: deep merge (overlay overrides base)
    - Arrays: replace (no merge)
    - Primitives: replace

    Args:
        base: Base dictionary.
        overlay: Overlay dictionary (takes precedence).

    Returns:
        Merged dictionary.
    """
    result = base.copy()

    for key, value in overlay.items():
        if key in result and isinstance(result[key], dict) and isinstance(value, dict):
            result[key] = deep_merge(result[key], value)
        else:
            result[key] = value

    return result


def merge_defaults(
    route: dict[str, Any],
    resource_defaults: dict[str, Any],
    global_defaults: dict[str, Any],
) -> dict[str, Any]:
    """Merge route with cascading defaults.

    Order: global -> resource -> route (route wins).

    Args:
        route: Route definition.
        resource_defaults: Resource-level defaults.
        global_defaults: Global defaults.

    Returns:
        Route with merged defaults.
    """
    # Start with global defaults
    merged = global_defaults.copy()

    # Merge resource defaults
    merged = deep_merge(merged, resource_defaults)

    # Merge route (route wins)
    merged = deep_merge(merged, route)

    return merged


def load_route_file(file_path: Path) -> dict[str, Any]:
    """Load a single route JSON file.

    Args:
        file_path: Path to route JSON file.

    Returns:
        Route definition dictionary.

    Raises:
        json.JSONDecodeError: If file is not valid JSON.
        FileNotFoundError: If file doesn't exist.
    """
    with file_path.open() as f:
        return json.load(f)


def load_routes(
    base_path: Path | str | None = None,
    include_builtin: bool = True,
) -> list[dict[str, Any]]:
    """Load all routes from routes folder.

    Discovers routes by scanning folder structure:
    - routes/_defaults.json (global defaults)
    - routes/_builtin/*.json (built-in routes)
    - routes/{resource}/_defaults.json (resource defaults)
    - routes/{resource}/*.json (route definitions)

    Args:
        base_path: Optional base path to routes folder.
        include_builtin: Whether to include _builtin/ routes.

    Returns:
        List of route definitions with merged defaults.
    """
    routes_path = get_routes_path(base_path)

    if not routes_path.exists():
        return []

    # Load global defaults
    global_defaults = load_defaults(routes_path)

    routes: list[dict[str, Any]] = []

    # Scan for resource folders and route files
    for item in routes_path.iterdir():
        if item.is_file() and item.suffix == ".json":
            # Skip defaults file
            if item.name == ROUTES_DEFAULTS_FILE:
                continue
            # Top-level route file
            route = load_route_file(item)
            route["_source"] = str(item.relative_to(routes_path))
            route["_resource"] = None
            merged = merge_defaults(route, {}, global_defaults)
            routes.append(merged)

        elif item.is_dir():
            # Skip builtin if not requested
            if item.name == ROUTES_BUILTIN_PATH and not include_builtin:
                continue

            # Resource folder
            resource_name = item.name
            resource_defaults = load_defaults(item)

            for route_file in item.glob("*.json"):
                # Skip defaults file
                if route_file.name == ROUTES_DEFAULTS_FILE:
                    continue

                route = load_route_file(route_file)
                route["_source"] = str(route_file.relative_to(routes_path))
                route["_resource"] = resource_name

                merged = merge_defaults(route, resource_defaults, global_defaults)
                routes.append(merged)

    return routes
