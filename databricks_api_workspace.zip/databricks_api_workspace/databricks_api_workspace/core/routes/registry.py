# Databricks notebook source
# MAGIC %md
# MAGIC # registry
# MAGIC
# MAGIC **Auto-generated from:** `registry.py`
# MAGIC **Build timestamp:** 2025-12-22T22:33:16.594015+00:00
# MAGIC **Content hash:** 554580053488
# MAGIC
# MAGIC > Do not edit directly. Make changes in source and rebuild.

# COMMAND ----------

# MAGIC %run ../../core/routes/_settings
# MAGIC %run ../../core/routes/loader
# MAGIC %run ../../core/routes/validator

# COMMAND ----------

"""
databricks_api_workspace.core.routes.registry - Route registry.

Central registry for loaded and validated routes.

Classes:
    Route: Dataclass representing a single route version.
    RouteRegistry: Registry for managing routes.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from pathlib import Path
from typing import Any


__all__ = [
    "Route",
    "RouteRegistry",
]


@dataclass
class Route:
    """Represents a single route version."""

    # Identity
    source: str
    resource: str | None
    version: str

    # HTTP
    path: str
    method: str
    full_path: str

    # Execution
    logic: str
    params: list[dict[str, Any]]
    is_async: bool

    # Settings
    enabled: bool
    deprecated: bool
    timeout_seconds: int
    rate_limit_rpm: int

    # Auth
    auth_required: bool
    auth_roles: list[str]

    # Metadata
    title: str
    description: str
    is_default: bool
    tags: list[str] = field(default_factory=list)

    # Raw definition for advanced use
    raw: dict[str, Any] = field(default_factory=dict, repr=False)


class RouteRegistry:
    """Registry for managing loaded routes.

    Provides route lookup by path, method, version, and resource.
    """

    def __init__(self) -> None:
        self._routes: list[Route] = []
        self._by_path: dict[str, list[Route]] = {}
        self._by_resource: dict[str, list[Route]] = {}

    @classmethod
    def load(
        cls,
        routes_path: Path | str | None = None,
        queries_path: Path | str | None = None,
        validate: bool = True,
        strict: bool | None = None,
    ) -> RouteRegistry:
        """Load routes from folder and create registry.

        Args:
            routes_path: Path to routes folder.
            queries_path: Path to queries folder (for notebook validation).
            validate: Whether to validate routes.
            strict: Whether to fail on validation errors (default from settings).

        Returns:
            Populated RouteRegistry.
        """
        registry = cls()

        # Load raw routes
        raw_routes = load_routes(routes_path)

        # Validate if requested
        if validate:
            q_path = Path(queries_path) if queries_path else None
            validate_routes(
                raw_routes,
                queries_path=q_path,
                strict=strict if strict is not None else VALIDATION_STRICT,
            )

        # Convert to Route objects
        for raw in raw_routes:
            routes = cls._parse_route(raw)
            for route in routes:
                registry._add_route(route)

        return registry

    @classmethod
    def _parse_route(cls, raw: dict[str, Any]) -> list[Route]:
        """Parse raw route dict into Route objects.

        Args:
            raw: Raw route definition with merged defaults.

        Returns:
            List of Route objects (one per version).
        """
        routes: list[Route] = []

        source = raw.get("_source", "unknown")
        resource = raw.get("_resource")
        meta = raw.get("_meta", {})
        settings = raw.get("_settings", {})
        auth = raw.get("auth", {})

        for version_def in raw.get("route", []):
            # Build full path
            path = version_def.get("path", "/")
            full_path = f"/{resource}{path}" if resource and resource != "_builtin" else path

            route = Route(
                # Identity
                source=source,
                resource=resource,
                version=version_def.get("version", "v1"),
                # HTTP
                path=path,
                method=version_def.get("method", "GET").upper(),
                full_path=full_path,
                # Execution
                logic=version_def.get("logic", ""),
                params=version_def.get("params", []),
                is_async=version_def.get("async", False),
                # Settings
                enabled=settings.get("enabled", True),
                deprecated=version_def.get("deprecated", settings.get("deprecated", False)),
                timeout_seconds=settings.get("timeout", {}).get("seconds", 30),
                rate_limit_rpm=settings.get("rateLimit", {}).get("requestsPerMinute", 60),
                # Auth
                auth_required=auth.get("required", True),
                auth_roles=auth.get("roles", []),
                # Metadata
                title=version_def.get("title", meta.get("title", "")),
                description=version_def.get("description", meta.get("purpose", "")),
                is_default=version_def.get("isDefault", False),
                tags=meta.get("tags", []),
                # Raw
                raw=raw,
            )
            routes.append(route)

        return routes

    def _add_route(self, route: Route) -> None:
        """Add a route to the registry."""
        self._routes.append(route)

        # Index by path
        key = f"{route.method}:{route.full_path}"
        if key not in self._by_path:
            self._by_path[key] = []
        self._by_path[key].append(route)

        # Index by resource
        resource = route.resource or "_root"
        if resource not in self._by_resource:
            self._by_resource[resource] = []
        self._by_resource[resource].append(route)

    def get_all(self, include_disabled: bool = False) -> list[Route]:
        """Get all routes.

        Args:
            include_disabled: Whether to include disabled routes.

        Returns:
            List of all routes.
        """
        if include_disabled:
            return list(self._routes)
        return [r for r in self._routes if r.enabled]

    def get_by_path(
        self,
        method: str,
        path: str,
        version: str | None = None,
    ) -> Route | None:
        """Get route by HTTP method and path.

        Args:
            method: HTTP method.
            path: URL path.
            version: API version (uses default if None).

        Returns:
            Matching Route or None.
        """
        key = f"{method.upper()}:{path}"
        routes = self._by_path.get(key, [])

        if not routes:
            return None

        # Filter enabled routes
        enabled = [r for r in routes if r.enabled]
        if not enabled:
            return None

        # Find matching version
        if version:
            for route in enabled:
                if route.version == version:
                    return route

        # Return default version
        for route in enabled:
            if route.is_default:
                return route

        # Fallback to first enabled
        return enabled[0] if enabled else None

    def get_by_resource(self, resource: str) -> list[Route]:
        """Get all routes for a resource.

        Args:
            resource: Resource name (folder name).

        Returns:
            List of routes for the resource.
        """
        return [r for r in self._by_resource.get(resource, []) if r.enabled]

    def resolve_version(
        self,
        method: str,
        path: str,
        headers: dict[str, str] | None = None,
        query_params: dict[str, str] | None = None,
    ) -> Route | None:
        """Resolve route with version from headers or query params.

        Version selection priority:
        1. X-API-Version header
        2. api_version query param
        3. Default version (isDefault=True)

        Args:
            method: HTTP method.
            path: URL path.
            headers: Request headers.
            query_params: Query parameters.

        Returns:
            Resolved Route or None.
        """
        version = None

        # Check header
        if headers:
            version = headers.get(API_VERSION_HEADER)

        # Check query param
        if not version and query_params:
            version = query_params.get(API_VERSION_QUERY_PARAM)

        return self.get_by_path(method, path, version)

    def list_resources(self) -> list[str]:
        """List all resource names.

        Returns:
            List of resource names.
        """
        return list(self._by_resource.keys())

    def __len__(self) -> int:
        return len(self._routes)

    def __iter__(self):
        return iter(self._routes)
