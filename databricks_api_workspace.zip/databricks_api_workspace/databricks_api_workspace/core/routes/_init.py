# Databricks notebook source
# MAGIC %md
# MAGIC # __init__
# MAGIC
# MAGIC **Auto-generated from:** `__init__.py`
# MAGIC **Build timestamp:** 2025-12-22T22:33:16.599945+00:00
# MAGIC **Content hash:** ebc8b50515b3
# MAGIC
# MAGIC > Do not edit directly. Make changes in source and rebuild.

# COMMAND ----------

# MAGIC %run ../../core/routes/audit
# MAGIC %run ../../core/routes/health
# MAGIC %run ../../core/routes/loader
# MAGIC %run ../../core/routes/registry
# MAGIC %run ../../core/routes/schema_validation
# MAGIC %run ../../core/routes/validator

# COMMAND ----------

"""
databricks_api_workspace.core.routes - Route loading and management.

Load route definitions from JSON files with cascading defaults inheritance.
Provides validation and a registry for route lookup.

Classes:
    Route: Dataclass representing a single route version.
    RouteRegistry: Registry for managing routes.
    RouteValidationError: Raised when route validation fails.

Functions:
    load_routes(): Load all routes from routes folder
    load_route_file(): Load a single route JSON file
    load_defaults(): Load defaults file at given path
    merge_defaults(): Merge route with cascading defaults
    validate_route(): Validate a single route definition
    validate_routes(): Validate all routes
    help(): Display module usage information

Example:
    >>> from databricks_api_workspace.core.routes import RouteRegistry
    >>> registry = RouteRegistry.load("routes/")
    >>> route = registry.get_by_path("GET", "/customers/{id}")
"""

from __future__ import annotations

from pathlib import Path
from typing import Any


__all__ = [
    # Classes
    "Route",
    "RouteRegistry",
    "RouteValidationError",
    # Loading
    "load_routes",
    "load_route_file",
    "load_defaults",
    "merge_defaults",
    "deep_merge",
    "get_routes_path",
    "validate_defaults_structure",
    # Validation
    "validate_route",
    "validate_routes",
    "validate_startup",
    "validate_schema_files_exist",
    # Schema Validation
    "get_route_schema",
    "validate_route_request",
    "validate_route_response",
    # Health
    "run_health_check",
    "get_routes_hash",
    "check_routes_changed",
    # Audit
    "write_route_audit",
    "query_route_audit",
    "get_route_history",
    # Help
    "help",
]


def validate_startup(
    routes_path: Path | str | None = None,
    queries_path: Path | str | None = None,
    strict: bool = True,
) -> dict[str, Any]:
    """Run startup validation for routes.

    Validates all route definitions and optionally checks that referenced
    notebooks exist. Call at application startup to fail fast on errors.

    Args:
        routes_path: Path to routes folder (default: package routes/).
        queries_path: Path to queries folder for notebook validation.
        strict: If True, raise on validation errors.

    Returns:
        Validation result dict with:
        - is_valid: bool
        - routes_count: int
        - errors: list[str]

    Raises:
        RouteValidationError: If strict=True and validation fails.

    Example:
        >>> from databricks_api_workspace.core.routes import validate_startup
        >>> result = validate_startup(strict=True)  # Raises on error
        >>> print(f"Loaded {result['routes_count']} routes")
    """
    routes_p = Path(routes_path) if routes_path else get_routes_path()
    queries_p = Path(queries_path) if queries_path else None

    # Load routes
    raw_routes = load_routes(routes_p)

    # Validate
    is_valid, errors = validate_routes(raw_routes, queries_p, strict=strict)

    return {
        "is_valid": is_valid,
        "routes_count": len(raw_routes),
        "errors": errors,
        "routes_path": str(routes_p),
        "queries_path": str(queries_p) if queries_p else None,
    }


def help() -> str:
    """Display routes module usage information.

    Returns:
        str: Help text with all available classes, functions, and examples.

    Example:
        >>> from databricks_api_workspace.core import routes
        >>> print(routes.help())
    """
    return """
databricks_api_workspace.core.routes
====================================

Route loading, validation, and registry.

Classes:
-------
  Route              - Dataclass representing a route version
  RouteRegistry      - Registry for managing loaded routes
  RouteValidationError - Raised on validation failure

Loading Functions:
-----------------
  load_routes(base_path=None, include_builtin=True) -> list[dict]
  load_route_file(file_path: Path) -> dict
  load_defaults(path: Path) -> dict
  merge_defaults(route, resource_defaults, global_defaults) -> dict
  deep_merge(base: dict, overlay: dict) -> dict
  get_routes_path(base_path=None) -> Path

Validation Functions:
--------------------
  validate_route(route: dict, queries_path=None) -> list[str]
  validate_routes(routes, queries_path=None, strict=True) -> tuple[bool, list[str]]

Quick Start:
-----------
  from databricks_api_workspace.core.routes import RouteRegistry

  # Load and validate routes
  registry = RouteRegistry.load("routes/")

  # Get route by path
  route = registry.get_by_path("GET", "/customers/{id}")

  # Resolve with version header
  route = registry.resolve_version(
      "GET", "/customers/{id}",
      headers={"X-API-Version": "v2"}
  )

  # List all routes
  for route in registry.get_all():
      print(f"{route.method} {route.full_path} -> {route.logic}")

Route JSON Schema:
-----------------
  {
    "_meta": { "title", "purpose", "ownership", "tags" },
    "_settings": { "enabled", "timeout", "rateLimit", "cache" },
    "route": [
      { "version", "path", "method", "logic", "params", "isDefault" }
    ],
    "auth": { "required", "roles" }
  }

Submodules:
----------
  _settings  - Configuration constants
  loader     - Route loading functions
  validator  - Route validation functions
  registry   - RouteRegistry class
"""
