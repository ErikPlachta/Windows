# Databricks notebook source
# MAGIC %md
# MAGIC # params
# MAGIC
# MAGIC **Auto-generated from:** `params.py`
# MAGIC **Build timestamp:** 2025-12-22T22:33:16.567541+00:00
# MAGIC **Content hash:** 8fe6e66f1d15
# MAGIC
# MAGIC > Do not edit directly. Make changes in source and rebuild.

# COMMAND ----------

# MAGIC %run ../../core/sql_utils/_settings

# COMMAND ----------

"""
databricks_api_workspace.core.sql_utils.params - Parameter handling.

Substitute and validate parameters in SQL templates.

Functions:
    substitute_params(): Replace :param placeholders with values
    validate_params(): Check all required params are provided
    help(): Display module usage information
"""

from __future__ import annotations

import re
from typing import Any


__all__ = [
    "substitute_params",
    "validate_params",
    "help",
]


def substitute_params(template: str, params: dict[str, Any]) -> str:
    """Substitute named parameters in SQL template.

    Handles :param_name style parameters with proper escaping.
    Supports None, bool, int, float, str, and list/tuple values.

    Args:
        template: SQL template with :param_name placeholders.
        params: Parameter name -> value mapping.

    Returns:
        str: SQL with parameters substituted.

    Example:
        >>> sql = substitute_params(
        ...     "SELECT * FROM t WHERE id = :id AND name = :name",
        ...     {"id": 123, "name": "O'Brien"}
        ... )
        >>> print(sql)
        SELECT * FROM t WHERE id = 123 AND name = 'O''Brien'
    """
    result = template

    for key, value in params.items():
        placeholder = f":{key}"
        if placeholder not in result:
            continue

        formatted = _format_value(value)
        result = result.replace(placeholder, formatted)

    return result


def _format_value(value: Any) -> str:
    """Format a value for SQL interpolation.

    Args:
        value: Value to format.

    Returns:
        str: SQL-safe formatted value.
    """
    if value is None:
        return "NULL"
    elif isinstance(value, bool):
        return "TRUE" if value else "FALSE"
    elif isinstance(value, (int, float)):
        return str(value)
    elif isinstance(value, str):
        # Escape single quotes
        escaped = value.replace("'", "''")
        return f"'{escaped}'"
    elif isinstance(value, (list, tuple)):
        # Format as SQL list
        items = [_format_value(item) for item in value]
        return f"({', '.join(items)})"
    else:
        # Default: convert to string and quote
        return f"'{str(value)}'"


def validate_params(template: str, params: dict[str, Any]) -> list[str]:
    """Validate that all required parameters are provided.

    Finds all :param_name placeholders in template and checks
    that params contains values for each.

    Args:
        template: SQL template with :param_name placeholders.
        params: Parameter values to validate.

    Returns:
        list[str]: List of missing parameter names (empty if all present).

    Example:
        >>> template = "SELECT * FROM t WHERE id = :id AND name = :name"
        >>> missing = validate_params(template, {"id": 123})
        >>> print(missing)
        ['name']
    """
    required = set(re.findall(PARAM_PATTERN, template))
    provided = set(params.keys())
    missing = required - provided
    return list(missing)


def help() -> str:
    """Display module usage information.

    Returns:
        str: Help text with parameter handling usage.
    """
    return """
databricks_api_workspace.core.sql_utils.params
=====================================================

SQL parameter substitution and validation.

Functions:
---------
  substitute_params(template, params) -> str
      Replace :param_name placeholders with values.

  validate_params(template, params) -> list[str]
      Return list of missing parameter names.

Supported Value Types:
--------------------
  None     -> NULL
  bool     -> TRUE / FALSE
  int      -> 123
  float    -> 1.23
  str      -> 'escaped''value'
  list     -> (1, 2, 3) or ('a', 'b')

Usage:
-----
  from databricks_api_workspace.core.sql_utils import (
      substitute_params,
      validate_params,
  )

  template = "SELECT * FROM t WHERE id = :id AND status IN :statuses"
  params = {"id": 123, "statuses": ["active", "pending"]}

  # Check for missing params first
  missing = validate_params(template, params)
  if missing:
      raise ValueError(f"Missing params: {missing}")

  # Substitute params
  sql = substitute_params(template, params)
  # Result: SELECT * FROM t WHERE id = 123 AND status IN ('active', 'pending')

Security Note:
-------------
  This uses simple string substitution. For better security,
  use Spark SQL parameters or prepared statements when available.
"""
