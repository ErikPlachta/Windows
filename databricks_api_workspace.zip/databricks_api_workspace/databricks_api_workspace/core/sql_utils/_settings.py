# Databricks notebook source
# MAGIC %md
# MAGIC # _settings
# MAGIC
# MAGIC **Auto-generated from:** `_settings.py`
# MAGIC **Build timestamp:** 2025-12-22T22:33:16.570788+00:00
# MAGIC **Content hash:** 5bc10deaee52
# MAGIC
# MAGIC > Do not edit directly. Make changes in source and rebuild.

# COMMAND ----------

"""
databricks_api_workspace.core.sql_utils.settings - SQL utility constants.

Single source of truth for SQL safety and parameter constants.

Constants:
    PARAM_PATTERN: Regex for :param_name placeholders
    UUID_PATTERN: Regex for UUID validation
    MAX_IDENTIFIER_PARTS: Max parts in qualified name (catalog.schema.table)
    IDENTIFIER_PATTERN: Regex for valid SQL identifiers
"""

from __future__ import annotations

__all__ = [
    "PARAM_PATTERN",
    "UUID_PATTERN",
    "MAX_IDENTIFIER_PARTS",
    "IDENTIFIER_PATTERN",
]

# -----------------------------------------------------------------------------
# Patterns
# -----------------------------------------------------------------------------

# Regex pattern for :param_name placeholders
PARAM_PATTERN: str = r":([a-zA-Z_][a-zA-Z0-9_]*)"

# Regex pattern for UUID validation
UUID_PATTERN: str = r"^[a-fA-F0-9]{8}-[a-fA-F0-9]{4}-[a-fA-F0-9]{4}-[a-fA-F0-9]{4}-[a-fA-F0-9]{12}$"

# Max parts in qualified SQL identifier (catalog.schema.table)
MAX_IDENTIFIER_PARTS: int = 3

# Valid SQL identifier pattern (letters, digits, underscores; starts with letter/_)
IDENTIFIER_PATTERN: str = r"^[a-zA-Z_][a-zA-Z0-9_]*$"
