# Databricks notebook source
# MAGIC %md
# MAGIC # safety
# MAGIC
# MAGIC **Auto-generated from:** `safety.py`
# MAGIC **Build timestamp:** 2025-12-22T22:33:16.569228+00:00
# MAGIC **Content hash:** 19995cd852b1
# MAGIC
# MAGIC > Do not edit directly. Make changes in source and rebuild.

# COMMAND ----------

# MAGIC %run ../../core/sql_utils/_settings

# COMMAND ----------

"""
databricks_api_workspace.core.sql_utils.safety - SQL safety utilities.

Functions to prevent SQL injection attacks.

Functions:
    escape_sql_string(): Escape string for SQL interpolation
    safe_sql_identifier(): Validate table/column names
    validate_uuid_format(): Check UUID format
    safe_job_id(): Validate job ID format
    help(): Display module usage information
"""

from __future__ import annotations

import re


__all__ = [
    "escape_sql_string",
    "safe_sql_identifier",
    "validate_uuid_format",
    "safe_job_id",
    "help",
]


def escape_sql_string(value: str | None) -> str:
    """Escape string value for safe SQL interpolation.

    Escapes single quotes by doubling them, preventing SQL injection.

    Args:
        value: String value to escape. None returns empty string.

    Returns:
        str: Escaped string safe for SQL string literals.

    Example:
        >>> escape_sql_string("O'Brien")
        "O''Brien"
        >>> escape_sql_string("'; DROP TABLE--")
        "''; DROP TABLE--"
    """
    if value is None:
        return ""
    return str(value).replace("'", "''")


def safe_sql_identifier(value: str) -> str:
    """Validate and return SQL identifier (table/column name).

    Only allows alphanumeric characters, underscores, and dots
    (for qualified names). Each part must start with letter or underscore.

    Args:
        value: Identifier to validate. Can be simple (users) or qualified
            (schema.table or catalog.schema.table).

    Returns:
        str: The validated identifier (unchanged if valid).

    Raises:
        ValueError: If identifier is empty or contains invalid characters.

    Example:
        >>> safe_sql_identifier("users")
        'users'
        >>> safe_sql_identifier("catalog.schema.table")
        'catalog.schema.table'
        >>> safe_sql_identifier("123bad")  # Raises ValueError
    """
    if not value:
        raise ValueError("SQL identifier cannot be empty")

    # Split qualified names (schema.table or catalog.schema.table)
    parts = value.split(".")
    if len(parts) > MAX_IDENTIFIER_PARTS:
        raise ValueError(
            f"Invalid SQL identifier: {value!r}. Too many parts (max: {MAX_IDENTIFIER_PARTS})."
        )

    # Validate each part
    for part in parts:
        if not part:
            raise ValueError(f"Invalid SQL identifier: {value!r}. Empty part found.")
        if not re.match(IDENTIFIER_PATTERN, part):
            raise ValueError(
                f"Invalid SQL identifier: {value!r}. "
                "Each part must contain only letters, digits, underscores, "
                "and start with a letter or underscore."
            )

    return value


def validate_uuid_format(value: str) -> bool:
    """Check if value matches UUID format.

    Args:
        value: String to validate.

    Returns:
        bool: True if valid UUID format, False otherwise.

    Example:
        >>> validate_uuid_format("12345678-1234-1234-1234-123456789012")
        True
        >>> validate_uuid_format("not-a-uuid")
        False
    """
    return bool(re.match(UUID_PATTERN, value))


def safe_job_id(value: str) -> str:
    """Validate job ID format for safe SQL use.

    Job IDs should be UUIDs. Validates format before using in queries.

    Args:
        value: Job ID to validate.

    Returns:
        str: The validated job ID (unchanged if valid).

    Raises:
        ValueError: If job ID is empty or invalid format.

    Example:
        >>> safe_job_id("12345678-1234-1234-1234-123456789012")
        '12345678-1234-1234-1234-123456789012'
        >>> safe_job_id("invalid")  # Raises ValueError
    """
    if not value:
        raise ValueError("Job ID cannot be empty")

    if not validate_uuid_format(value):
        raise ValueError(f"Invalid job ID format: {value!r}. Expected UUID format.")

    return value


def help() -> str:
    """Display module usage information.

    Returns:
        str: Help text with safety utilities usage.
    """
    return """
databricks_api_workspace.core.sql_utils.safety
======================================================

SQL safety utilities to prevent injection attacks.

Functions:
---------
  escape_sql_string(value) -> str
      Escape single quotes in strings.
      None -> "", "O'Brien" -> "O''Brien"

  safe_sql_identifier(value) -> str
      Validate table/column names.
      Only allows: letters, digits, underscores, dots.
      Raises ValueError if invalid.

  validate_uuid_format(value) -> bool
      Check if string matches UUID format.

  safe_job_id(value) -> str
      Validate job ID (must be UUID format).
      Raises ValueError if invalid.

Usage:
-----
  from databricks_api_workspace.core.sql_utils import (
      escape_sql_string,
      safe_sql_identifier,
      safe_job_id,
  )

  # Escape user input for string literals
  safe_name = escape_sql_string(user_input)
  query = f"SELECT * FROM users WHERE name = '{safe_name}'"

  # Validate table names (prevents injection via identifiers)
  table = safe_sql_identifier(table_name)  # Raises if invalid
  query = f"SELECT * FROM {table}"

  # Validate job IDs before use
  job_id = safe_job_id(request_job_id)  # Raises if not UUID

Security Notes:
--------------
  - Always escape user-provided strings
  - Always validate identifiers from user input
  - Prefer parameterized queries when available
  - These utilities are defense-in-depth measures
"""
