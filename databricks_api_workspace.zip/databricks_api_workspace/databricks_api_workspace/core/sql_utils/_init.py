# Databricks notebook source
# MAGIC %md
# MAGIC # __init__
# MAGIC
# MAGIC **Auto-generated from:** `__init__.py`
# MAGIC **Build timestamp:** 2025-12-22T22:33:16.571831+00:00
# MAGIC **Content hash:** effd7bf9389c
# MAGIC
# MAGIC > Do not edit directly. Make changes in source and rebuild.

# COMMAND ----------

# MAGIC %run ../../core/sql_utils/_settings
# MAGIC %run ../../core/sql_utils/params
# MAGIC %run ../../core/sql_utils/safety

# COMMAND ----------

"""
databricks_api_workspace.core.sql_utils - SQL safety and parameter utilities.

Core utilities for SQL injection prevention and parameter handling.

Functions:
    escape_sql_string(): Escape string for SQL interpolation
    safe_sql_identifier(): Validate table/column names
    validate_uuid_format(): Check UUID format
    safe_job_id(): Validate job ID format
    substitute_params(): Replace :param placeholders with values
    validate_params(): Check all required params are provided
    help(): Display module usage information

Usage:
    >>> from databricks_api_workspace.core.sql_utils import (
    ...     escape_sql_string,
    ...     safe_sql_identifier,
    ...     substitute_params,
    ... )
"""

from __future__ import annotations


__all__ = [
    # Safety functions
    "escape_sql_string",
    "safe_sql_identifier",
    "validate_uuid_format",
    "safe_job_id",
    # Param functions
    "substitute_params",
    "validate_params",
    # Constants
    "PARAM_PATTERN",
    "UUID_PATTERN",
    "MAX_IDENTIFIER_PARTS",
    "IDENTIFIER_PATTERN",
    # Help
    "help",
]


def help() -> str:
    """Display module usage information.

    Returns:
        str: Help text with sql_utils usage.
    """
    return """
databricks_api_workspace.core.sql_utils
==========================================

SQL safety and parameter utilities.

Safety Functions:
----------------
  escape_sql_string(value) -> str
      Escape single quotes in strings for SQL.

  safe_sql_identifier(value) -> str
      Validate table/column names. Raises ValueError if invalid.

  validate_uuid_format(value) -> bool
      Check if string matches UUID format.

  safe_job_id(value) -> str
      Validate job ID (must be UUID format).

Parameter Functions:
------------------
  substitute_params(template, params) -> str
      Replace :param_name placeholders with values.

  validate_params(template, params) -> list[str]
      Return list of missing parameter names.

Constants:
---------
  PARAM_PATTERN - Regex for :param placeholders
  UUID_PATTERN - Regex for UUID validation
  MAX_IDENTIFIER_PARTS - Max parts in qualified name (3)
  IDENTIFIER_PATTERN - Regex for SQL identifiers

Usage:
-----
  from databricks_api_workspace.core.sql_utils import (
      escape_sql_string,
      safe_sql_identifier,
      substitute_params,
  )

  # Escape user input
  name = escape_sql_string(user_input)

  # Validate identifiers
  table = safe_sql_identifier(table_name)

  # Substitute params
  sql = substitute_params("SELECT * FROM t WHERE id = :id", {"id": 123})
"""
