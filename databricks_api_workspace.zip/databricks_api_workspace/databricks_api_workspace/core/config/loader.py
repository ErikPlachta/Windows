# Databricks notebook source
# MAGIC %md
# MAGIC # loader
# MAGIC
# MAGIC **Auto-generated from:** `loader.py`
# MAGIC **Build timestamp:** 2025-12-22T22:33:16.543961+00:00
# MAGIC **Content hash:** df543462fcae
# MAGIC
# MAGIC > Do not edit directly. Make changes in source and rebuild.

# COMMAND ----------

# MAGIC %run ../../core/config/_settings
# MAGIC %run ../../core/runtime/paths

# COMMAND ----------

"""
databricks_api_workspace.core.config.loader - Configuration loading.

Load and access config from package config/ directory.
Supports both JSON and YAML config files with environment overlays.

Functions:
    load_config(): Load config from package (cached)
    get_operation_config(): Get config for a specific operation
    get_schema_path(): Get path to schema file
    get_config_value(): Get config value by dot-separated key
    clear_config_cache(): Clear cached config
    set_config_path(): Set custom config path
    get_config_path(): Get current config path
    load_yaml_config(): Load config from YAML file
    load_config_with_overlay(): Load config with environment overlay
    help(): Display module usage information
"""

from __future__ import annotations

import json
import threading
from pathlib import Path
from typing import Any


# YAML support is optional
try:
    import yaml

    HAS_YAML = True
except ImportError:
    HAS_YAML = False

__all__ = [
    "load_config",
    "get_operation_config",
    "get_schema_path",
    "get_config_value",
    "clear_config_cache",
    "set_config_path",
    "get_config_path",
    "load_yaml_config",
    "load_config_with_overlay",
    "deep_merge",
    "help",
]

# Thread lock for global state mutations
_config_lock = threading.Lock()

# Custom config path (None = use default)
_config_path: str | None = get_config_path_from_env()

# Cached config (per-process)
_cached_config: dict[str, Any] | None = None


def _get_default_config_path() -> Path:
    """Get default config file path."""
    return get_config_dir() / DEFAULT_CONFIG_FILE


def load_config(force_reload: bool = False) -> dict[str, Any]:
    """Load effective config from package config directory.

    Config is cached per-process. Use force_reload=True to refresh.
    Thread-safe.

    Args:
        force_reload: Force reload from disk even if cached.

    Returns:
        dict: Config dictionary.

    Raises:
        FileNotFoundError: If config file doesn't exist.
        json.JSONDecodeError: If config is invalid JSON.

    Example:
        >>> config = load_config()
        >>> print(config.get("version"))
    """
    global _cached_config

    # Quick check without lock for performance
    if _cached_config is not None and not force_reload:
        return _cached_config

    with _config_lock:
        # Double-check after acquiring lock
        if _cached_config is None or force_reload:
            config_file = Path(_config_path) if _config_path else _get_default_config_path()

            with config_file.open() as f:
                _cached_config = json.load(f)

        return _cached_config


def get_operation_config(operation: str) -> dict[str, Any]:
    """Get config for a specific operation.

    Args:
        operation: Operation name (e.g., 'get_customer_detail').

    Returns:
        dict: Operation config dictionary.

    Raises:
        ValueError: If operation not found in config.

    Example:
        >>> op_config = get_operation_config("get_customer_detail")
        >>> print(op_config.get("query"))
    """
    config = load_config()
    operations = config.get("operations", {})
    if operation not in operations:
        available = list(operations.keys())
        raise ValueError(f"Unknown operation: '{operation}'. Available: {available}")
    return operations[operation]


def get_schema_path(schema_ref: str) -> Path:
    """Get path to schema file.

    Args:
        schema_ref: Schema reference (e.g., 'operations/get_customer_detail.request.json').

    Returns:
        Path: Absolute path to schema file.

    Example:
        >>> path = get_schema_path("operations/get_customer.request.json")
        >>> print(path)
    """
    return get_config_dir() / DEFAULT_SCHEMAS_DIR / schema_ref


def get_config_value(key: str, default: Any = None) -> Any:
    """Get a config value by key path.

    Args:
        key: Dot-separated key path (e.g., 'telemetry.enabled').
        default: Default value if key not found.

    Returns:
        Config value or default.

    Example:
        >>> enabled = get_config_value("telemetry.enabled", False)
    """
    config = load_config()
    parts = key.split(".")
    value: Any = config
    for part in parts:
        if isinstance(value, dict) and part in value:
            value = value[part]
        else:
            return default
    return value


def clear_config_cache() -> None:
    """Clear the cached config.

    Useful for testing or forcing a reload.
    Thread-safe.

    Example:
        >>> clear_config_cache()
        >>> config = load_config()  # Reloads from disk
    """
    global _cached_config
    with _config_lock:
        _cached_config = None


def set_config_path(path: str | None) -> None:
    """Set custom config path.

    Useful for testing with different config files.
    Thread-safe: clears cache when path changes.

    Args:
        path: Absolute path to config file, or None to use default.

    Example:
        >>> set_config_path("/custom/config.json")
        >>> set_config_path(None)  # Reset to default
    """
    global _config_path, _cached_config
    with _config_lock:
        _config_path = path
        _cached_config = None  # Clear cache when path changes


def get_config_path() -> Path:
    """Get current config path.

    Returns:
        Path: Current config file path.
    """
    if _config_path:
        return Path(_config_path)
    return _get_default_config_path()


def load_yaml_config(path: str | Path) -> dict[str, Any]:
    """Load config from YAML file.

    Requires pyyaml: pip install databricks_api_workspace[yaml]

    Args:
        path: Path to YAML config file.

    Returns:
        dict: Config dictionary.

    Raises:
        ImportError: If pyyaml not installed.
        FileNotFoundError: If config file doesn't exist.

    Example:
        >>> config = load_yaml_config("config/app.yaml")
    """
    if not HAS_YAML:
        raise ImportError(
            "pyyaml not installed. Install with: pip install databricks_api_workspace[yaml]"
        )

    config_file = Path(path)
    with config_file.open() as f:
        return yaml.safe_load(f) or {}


def load_config_with_overlay(
    base_path: str | Path,
    env: str | None = None,
) -> dict[str, Any]:
    """Load config with environment overlay.

    Loads base config and merges environment-specific overrides.
    Supports both JSON and YAML based on file extension.

    Args:
        base_path: Path to base config file.
        env: Environment name (e.g., 'dev', 'prod'). If None, uses
            ENVIRONMENT env var or 'dev' default.

    Returns:
        dict: Merged config dictionary.

    Example:
        >>> config = load_config_with_overlay("config/base.yaml")
        >>> config = load_config_with_overlay("config/base.yaml", env="prod")
    """
    env = env or get_environment_from_env()

    # Load base config
    base_config = _load_file(base_path)

    # Determine overlay path
    path_obj = Path(base_path)
    overlay_name = f"{path_obj.stem}.{env}{path_obj.suffix}"
    overlay_path = path_obj.parent / overlay_name

    # Try to load overlay
    try:
        overlay_config = _load_file(overlay_path)
        return deep_merge(base_config, overlay_config)
    except FileNotFoundError:
        return base_config


def _load_file(path: str | Path) -> dict[str, Any]:
    """Load config file based on extension.

    Args:
        path: Path to config file.

    Returns:
        dict: Config dictionary.
    """
    config_file = Path(path)
    path_str = str(path)

    if path_str.endswith((".yaml", ".yml")):
        if not HAS_YAML:
            raise ImportError("pyyaml required for YAML files")
        with config_file.open() as f:
            return yaml.safe_load(f) or {}
    else:
        with config_file.open() as f:
            return json.load(f)


def deep_merge(base: dict[str, Any], overlay: dict[str, Any]) -> dict[str, Any]:
    """Deep merge two dictionaries.

    Overlay values override base values. Nested dicts are merged recursively.

    Args:
        base: Base dictionary.
        overlay: Overlay dictionary (takes precedence).

    Returns:
        dict: Merged dictionary.

    Example:
        >>> base = {"a": 1, "b": {"c": 2}}
        >>> overlay = {"b": {"d": 3}}
        >>> result = deep_merge(base, overlay)
        >>> print(result)
        {"a": 1, "b": {"c": 2, "d": 3}}
    """
    result = base.copy()

    for key, value in overlay.items():
        if key in result and isinstance(result[key], dict) and isinstance(value, dict):
            result[key] = deep_merge(result[key], value)
        else:
            result[key] = value

    return result


def help() -> str:
    """Display module usage information.

    Returns:
        str: Help text with loader functions.
    """
    return """
databricks_api_workspace.core.config.loader
==============================================

Configuration loading functions.

Core Functions:
--------------
  load_config(force_reload=False) -> dict
      Load config from package config/ directory (cached per-process).

  get_operation_config(operation: str) -> dict
      Get config for a specific operation.

  get_schema_path(schema_ref: str) -> Path
      Get path to schema file in config/schemas/.

  get_config_value(key: str, default=None) -> Any
      Get config value by dot-separated key path.

Cache Management:
----------------
  clear_config_cache() -> None
      Clear cached config.

  set_config_path(path: str | None) -> None
      Set custom config path (clears cache).

  get_config_path() -> Path
      Get current config path.

YAML Support:
------------
  load_yaml_config(path: str) -> dict
      Load config from YAML file.
      Requires: pip install databricks_api_workspace[yaml]

Environment Overlays:
--------------------
  load_config_with_overlay(base_path, env=None) -> dict
      Load base config and merge environment overlay.
      Example: base.yaml + base.prod.yaml

  deep_merge(base: dict, overlay: dict) -> dict
      Deep merge two dictionaries.

Usage:
-----
  from databricks_api_workspace.core.config import load_config

  config = load_config()
  op_config = get_operation_config("get_customer")
"""
