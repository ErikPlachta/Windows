# Databricks notebook source
# MAGIC %md
# MAGIC # drift
# MAGIC
# MAGIC **Auto-generated from:** `drift.py`
# MAGIC **Build timestamp:** 2025-12-22T22:33:16.542645+00:00
# MAGIC **Content hash:** 4ab0832a201c
# MAGIC
# MAGIC > Do not edit directly. Make changes in source and rebuild.

# COMMAND ----------

"""
databricks_api_workspace.core.config.drift - Config drift detection.

Utilities for detecting and reporting configuration differences.

Functions:
    detect_config_drift(): Detect differences between configs
    help(): Display module usage information
"""

from __future__ import annotations

from typing import Any

__all__ = [
    "detect_config_drift",
    "help",
]


def detect_config_drift(
    expected: dict[str, Any],
    actual: dict[str, Any],
    path: str = "",
) -> list[str]:
    """Detect differences between expected and actual config.

    Useful for validating config consistency across environments.

    Args:
        expected: Expected config state.
        actual: Actual config state.
        path: Current path prefix (for recursion).

    Returns:
        list[str]: List of drift descriptions.

    Example:
        >>> expected = {"version": "1.0", "features": {"auth": True}}
        >>> actual = {"version": "1.1", "features": {"auth": False}}
        >>> drifts = detect_config_drift(expected, actual)
        >>> for drift in drifts:
        ...     print(f"DRIFT: {drift}")
        DRIFT: Value mismatch at version: 1.0 != 1.1
        DRIFT: Value mismatch at features.auth: True != False
    """
    drifts: list[str] = []

    # Check for missing keys
    for key in expected:
        full_path = f"{path}.{key}" if path else key
        if key not in actual:
            drifts.append(f"Missing key: {full_path}")
        elif isinstance(expected[key], dict) and isinstance(actual[key], dict):
            drifts.extend(detect_config_drift(expected[key], actual[key], full_path))
        elif expected[key] != actual[key]:
            drifts.append(f"Value mismatch at {full_path}: {expected[key]} != {actual[key]}")

    # Check for extra keys
    for key in actual:
        full_path = f"{path}.{key}" if path else key
        if key not in expected:
            drifts.append(f"Extra key: {full_path}")

    return drifts


def help() -> str:
    """Display module usage information.

    Returns:
        str: Help text with drift detection usage.
    """
    return """
databricks_api_workspace.core.config.drift
=============================================

Config drift detection utilities.

Functions:
---------
  detect_config_drift(expected, actual, path="") -> list[str]
      Detect differences between expected and actual config.
      Returns list of drift descriptions.

Drift Types:
-----------
  "Missing key: <path>"      - Key exists in expected but not actual
  "Extra key: <path>"        - Key exists in actual but not expected
  "Value mismatch at <path>" - Values differ at path

Usage:
-----
  from databricks_api_workspace.core.config import detect_config_drift

  expected = {"version": "1.0", "debug": False}
  actual = {"version": "1.1", "debug": True, "extra": "value"}

  drifts = detect_config_drift(expected, actual)

  if drifts:
      print("Config drift detected:")
      for drift in drifts:
          print(f"  - {drift}")
  else:
      print("No drift detected")

Output:
  Config drift detected:
    - Value mismatch at version: 1.0 != 1.1
    - Value mismatch at debug: False != True
    - Extra key: extra
"""
