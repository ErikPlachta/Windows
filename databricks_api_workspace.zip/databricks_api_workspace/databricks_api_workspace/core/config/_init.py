# Databricks notebook source
# MAGIC %md
# MAGIC # __init__
# MAGIC
# MAGIC **Auto-generated from:** `__init__.py`
# MAGIC **Build timestamp:** 2025-12-22T22:33:16.546404+00:00
# MAGIC **Content hash:** bdb8b5e3cccb
# MAGIC
# MAGIC > Do not edit directly. Make changes in source and rebuild.

# COMMAND ----------

# MAGIC %run ../../core/config/drift
# MAGIC %run ../../core/config/loader

# COMMAND ----------

"""
databricks_api_workspace.core.config - Configuration module.

Load and access config from package directory.
Supports both JSON and YAML config files with environment overlays.

Functions:
    load_config(): Load config (cached)
    get_operation_config(): Get config for a specific operation
    get_schema_path(): Get schema file path
    get_config_value(): Get config value by dot-separated key
    clear_config_cache(): Clear cached config
    set_config_path(): Set custom config path
    get_config_path(): Get current config path
    load_yaml_config(): Load config from YAML file
    load_config_with_overlay(): Load config with environment overlay
    deep_merge(): Deep merge two dictionaries
    detect_config_drift(): Detect config differences
    help(): Display module usage information

Example:
    >>> from databricks_api_workspace.core.config import load_config
    >>> config = load_config()
    >>> op_config = get_operation_config("get_customer_detail")
"""

from __future__ import annotations

# Re-exports

__all__ = [
    # Core loading
    "load_config",
    "get_operation_config",
    "get_schema_path",
    "get_config_value",
    # Cache management
    "clear_config_cache",
    "set_config_path",
    "get_config_path",
    # YAML/overlay
    "load_yaml_config",
    "load_config_with_overlay",
    "deep_merge",
    # Drift detection
    "detect_config_drift",
    # Help
    "help",
]


def help() -> str:
    """Display config module usage information.

    Returns:
        str: Help text with all available functions and examples.

    Example:
        >>> from databricks_api_workspace.core import config
        >>> print(config.help())
    """
    return """
databricks_api_workspace.core.config
===================================

Configuration loading and management.

Core Loading:
------------
  load_config(force_reload=False) -> dict
  get_operation_config(operation: str) -> dict
  get_schema_path(schema_ref: str) -> str
  get_config_value(key: str, default=None) -> Any

Cache Management:
----------------
  clear_config_cache() -> None
  set_config_path(path: str) -> None
  get_config_path() -> str

YAML Support:
------------
  load_yaml_config(path: str) -> dict
  load_config_with_overlay(base_path, env=None) -> dict
  deep_merge(base: dict, overlay: dict) -> dict

Drift Detection:
---------------
  detect_config_drift(expected, actual, path="") -> list[str]

Quick Start:
-----------
  from databricks_api_workspace.core.config import (
      load_config, get_operation_config,
  )
  config = load_config()
  op_config = get_operation_config("get_customer_detail")

Environment Variables:
---------------------
  DATABRICKS_API2_CONFIG_PATH - Override config file path
  ENVIRONMENT - Set environment for overlays (dev, prod, etc.)

Submodules:
----------
  _settings - Configuration constants
  loader - Config loading functions
  drift - Drift detection utilities
"""
