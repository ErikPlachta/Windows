# Databricks notebook source
# MAGIC %md
# MAGIC # _settings
# MAGIC
# MAGIC **Auto-generated from:** `_settings.py`
# MAGIC **Build timestamp:** 2025-12-22T22:33:16.544955+00:00
# MAGIC **Content hash:** 1b63fa2b5677
# MAGIC
# MAGIC > Do not edit directly. Make changes in source and rebuild.

# COMMAND ----------

"""
databricks_api_workspace.core.config._settings - Config module settings.

Single source of truth for configuration loading constants.

Functions:
    help(): Display module usage information

Constants:
    CONFIG_PATH_ENV_VAR: Environment variable for config path override
    DEFAULT_CONFIG_FILE: Default config filename
    DEFAULT_SCHEMAS_DIR: Default schemas directory name
    DEFAULT_ENVIRONMENT: Default environment name
    ENVIRONMENT_ENV_VAR: Environment variable for environment name
"""

from __future__ import annotations

import os

__all__ = [
    "CONFIG_PATH_ENV_VAR",
    "DEFAULT_CONFIG_FILE",
    "DEFAULT_SCHEMAS_DIR",
    "DEFAULT_ENVIRONMENT",
    "ENVIRONMENT_ENV_VAR",
    "get_config_path_from_env",
    "get_environment_from_env",
    "help",
]

# Environment variable for config path override (absolute path)
CONFIG_PATH_ENV_VAR: str = "DATABRICKS_API_CONFIG_PATH"

# Default config filename (relative to package config/ dir)
DEFAULT_CONFIG_FILE: str = "config.json"

# Default schemas directory name (relative to package config/ dir)
DEFAULT_SCHEMAS_DIR: str = "schemas"

# Environment variable for environment name
ENVIRONMENT_ENV_VAR: str = "ENVIRONMENT"

# Default environment name
DEFAULT_ENVIRONMENT: str = "dev"


def get_config_path_from_env() -> str | None:
    """Get config path override from environment.

    Returns:
        str | None: Config path from env var, or None to use default.
    """
    return os.getenv(CONFIG_PATH_ENV_VAR)


def get_environment_from_env() -> str:
    """Get environment name from environment or default.

    Returns:
        str: Environment name from env var or default.
    """
    return os.getenv(ENVIRONMENT_ENV_VAR, DEFAULT_ENVIRONMENT)


def help() -> str:
    """Display module usage information.

    Returns:
        str: Help text with module constants.
    """
    return """
databricks_api_workspace.core.config._settings
===============================================

Configuration loading constants.

Constants:
---------
  CONFIG_PATH_ENV_VAR = "DATABRICKS_API_CONFIG_PATH"
      Environment variable to override config path (absolute path).

  DEFAULT_CONFIG_FILE = "config.json"
      Default config filename in package config/ directory.

  DEFAULT_SCHEMAS_DIR = "schemas"
      Default schemas directory name.

  ENVIRONMENT_ENV_VAR = "ENVIRONMENT"
      Environment variable for environment name.

  DEFAULT_ENVIRONMENT = "dev"
      Default environment when not specified.

Functions:
---------
  get_config_path_from_env() -> str | None
      Get config path override from env var.

  get_environment_from_env() -> str
      Get environment name from env var or default.

Usage:
-----
  # Override config path via environment (must be absolute path)
  export DATABRICKS_API_CONFIG_PATH="/custom/path/config.json"

  # Override environment
  export ENVIRONMENT="prod"
"""
