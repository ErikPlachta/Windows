# Databricks notebook source
# MAGIC %md
# MAGIC # codes
# MAGIC
# MAGIC **Auto-generated from:** `codes.py`
# MAGIC **Build timestamp:** 2025-12-22T22:33:16.531753+00:00
# MAGIC **Content hash:** 3bc88418c04f
# MAGIC
# MAGIC > Do not edit directly. Make changes in source and rebuild.

# COMMAND ----------

# MAGIC %run ../../core/errors/_settings

# COMMAND ----------

"""
databricks_api_workspace.core.errors.codes - Error code registry and helpers.

Extensible error code system with registry for module-specific errors.
Configuration is imported from config.py - no hardcoded values here.

Classes:
    ErrorDefinition: Defines an error code with metadata
    ErrorRegistry: Registry for error codes

Functions:
    register_error(): Register a new error code
    register_errors_from_config(): Register errors from config list
    get_error(): Get error definition by code
    get_http_status(): Get HTTP status for error code
    is_error(): Check if code is registered
    is_client_error(): Check if error is 4xx
    is_server_error(): Check if error is 5xx
    is_retryable(): Check if error may succeed on retry
    help(): Display module usage information
"""

from __future__ import annotations

import threading
from dataclasses import dataclass
from enum import Enum
from typing import TYPE_CHECKING


if TYPE_CHECKING:
    pass

__all__ = [
    "ErrorCode",
    "ErrorDefinition",
    "ErrorRegistry",
    "register_error",
    "register_errors_from_config",
    "get_error",
    "get_http_status",
    "is_error",
    "is_client_error",
    "is_server_error",
    "is_retryable",
    "list_errors",
    "help",
]


class ErrorCode(str, Enum):
    """Standard error codes for API responses.

    Provides enum-based access to error codes for type safety.
    """

    # 400 Bad Request
    INVALID_PARAMS = "INVALID_PARAMS"
    MISSING_REQUIRED_FIELD = "MISSING_REQUIRED_FIELD"
    INVALID_JSON = "INVALID_JSON"
    INVALID_TYPE = "INVALID_TYPE"

    # 401 Unauthorized
    UNAUTHORIZED = "UNAUTHORIZED"
    INVALID_TOKEN = "INVALID_TOKEN"
    TOKEN_EXPIRED = "TOKEN_EXPIRED"

    # 403 Forbidden
    FORBIDDEN = "FORBIDDEN"
    INSUFFICIENT_PERMISSIONS = "INSUFFICIENT_PERMISSIONS"
    OPERATION_NOT_ALLOWED = "OPERATION_NOT_ALLOWED"

    # 404 Not Found
    OPERATION_NOT_FOUND = "OPERATION_NOT_FOUND"
    RESOURCE_NOT_FOUND = "RESOURCE_NOT_FOUND"
    USER_NOT_FOUND = "USER_NOT_FOUND"

    # 422 Unprocessable Entity
    SCHEMA_VALIDATION_FAILED = "SCHEMA_VALIDATION_FAILED"
    CONTRACT_VIOLATION = "CONTRACT_VIOLATION"

    # 429 Too Many Requests
    RATE_LIMIT_EXCEEDED = "RATE_LIMIT_EXCEEDED"

    # 500 Internal Server Error
    EXECUTION_ERROR = "EXECUTION_ERROR"
    INTERNAL_ERROR = "INTERNAL_ERROR"
    DATABASE_ERROR = "DATABASE_ERROR"

    # 503 Service Unavailable
    SERVICE_UNAVAILABLE = "SERVICE_UNAVAILABLE"
    CLUSTER_UNAVAILABLE = "CLUSTER_UNAVAILABLE"

    # 504 Gateway Timeout
    OPERATION_TIMEOUT = "OPERATION_TIMEOUT"


@dataclass(frozen=True)
class ErrorDefinition:
    """Definition of an error code with metadata.

    Attributes:
        code: Unique error code string (e.g., "INVALID_PARAMS").
        http_status: HTTP status code (e.g., 400, 500).
        retryable: Whether the error may succeed on retry.
        category: Error category for grouping (e.g., "validation", "auth").
        description: Human-readable description.

    Example:
        >>> err = ErrorDefinition(
        ...     code="CUSTOM_ERROR",
        ...     http_status=400,
        ...     retryable=False,
        ...     category="validation",
        ...     description="Custom validation error",
        ... )
    """

    code: str
    http_status: int = DEFAULT_HTTP_STATUS
    retryable: bool = False
    category: str = "general"
    description: str = ""

    @classmethod
    def from_config(cls, config: ErrorConfig) -> ErrorDefinition:
        """Create ErrorDefinition from config dict.

        Args:
            config: ErrorConfig dict from config.py.

        Returns:
            ErrorDefinition instance.
        """
        return cls(
            code=config["code"],
            http_status=config["http_status"],
            retryable=config["retryable"],
            category=config["category"],
            description=config["description"],
        )


class ErrorRegistry:
    """Thread-safe registry for error code definitions.

    Modules can register their own error codes. The registry provides
    lookup functions for HTTP status, retryability, etc.

    Example:
        >>> registry = ErrorRegistry()
        >>> registry.register(ErrorDefinition("MY_ERROR", 400, False, "custom"))
        >>> registry.get("MY_ERROR").http_status
        400
    """

    def __init__(self) -> None:
        """Initialize empty registry."""
        self._errors: dict[str, ErrorDefinition] = {}
        self._lock = threading.Lock()

    def register(self, error: ErrorDefinition) -> None:
        """Register an error definition.

        Args:
            error: Error definition to register.

        Raises:
            ValueError: If code already registered (prevents silent override).
        """
        with self._lock:
            if error.code in self._errors:
                raise ValueError(f"Error code already registered: {error.code}")
            self._errors[error.code] = error

    def register_many(self, errors: list[ErrorDefinition]) -> None:
        """Register multiple error definitions.

        Args:
            errors: List of error definitions to register.
        """
        for error in errors:
            self.register(error)

    def get(self, code: str) -> ErrorDefinition | None:
        """Get error definition by code.

        Args:
            code: Error code to look up.

        Returns:
            ErrorDefinition if found, None otherwise.
        """
        return self._errors.get(code)

    def exists(self, code: str) -> bool:
        """Check if error code is registered.

        Args:
            code: Error code to check.

        Returns:
            True if code is registered.
        """
        return code in self._errors

    def list_all(self) -> list[ErrorDefinition]:
        """List all registered error definitions.

        Returns:
            List of all registered error definitions.
        """
        return list(self._errors.values())

    def list_by_category(self, category: str) -> list[ErrorDefinition]:
        """List error definitions by category.

        Args:
            category: Category to filter by.

        Returns:
            List of error definitions in the category.
        """
        return [e for e in self._errors.values() if e.category == category]


# Global registry instance
_registry = ErrorRegistry()


def register_error(
    code: str,
    http_status: int = DEFAULT_HTTP_STATUS,
    retryable: bool = False,
    category: str = "general",
    description: str = "",
) -> ErrorDefinition:
    """Register a new error code in the global registry.

    Convenience function for registering errors without creating
    ErrorDefinition manually.

    Args:
        code: Unique error code string.
        http_status: HTTP status code.
        retryable: Whether error may succeed on retry.
        category: Error category for grouping.
        description: Human-readable description.

    Returns:
        The registered ErrorDefinition.

    Example:
        >>> register_error("MY_MODULE_ERROR", 400, False, "my_module")
    """
    error = ErrorDefinition(code, http_status, retryable, category, description)
    _registry.register(error)
    return error


def register_errors_from_config(errors: list[ErrorConfig]) -> list[ErrorDefinition]:
    """Register errors from a config list.

    Useful for modules to register their errors from their config.py.

    Args:
        errors: List of ErrorConfig dicts.

    Returns:
        List of registered ErrorDefinition objects.

    Example:
        >>> from my_module.config import MY_MODULE_ERRORS
        >>> register_errors_from_config(MY_MODULE_ERRORS)
    """
    registered = []
    for config in errors:
        error = ErrorDefinition.from_config(config)
        try:
            _registry.register(error)
            registered.append(error)
        except ValueError:
            pass  # Already registered
    return registered


def get_error(code: str) -> ErrorDefinition | None:
    """Get error definition by code.

    Args:
        code: Error code to look up.

    Returns:
        ErrorDefinition if found, None otherwise.
    """
    return _registry.get(code)


def get_http_status(code: str, default: int = DEFAULT_HTTP_STATUS) -> int:
    """Get HTTP status code for an error code.

    Args:
        code: Error code string.
        default: Default status if code not found.

    Returns:
        HTTP status code.

    Example:
        >>> get_http_status("INVALID_PARAMS")
        400
    """
    error = _registry.get(code)
    return error.http_status if error else default


def is_error(code: str) -> bool:
    """Check if code is a registered error code.

    Args:
        code: Code to check.

    Returns:
        True if code is registered.
    """
    return _registry.exists(code)


def is_client_error(code: str) -> bool:
    """Check if error code represents a client error (4xx).

    Args:
        code: Error code to check.

    Returns:
        True if error is 4xx client error.
    """
    status = get_http_status(code)
    return 400 <= status < 500


def is_server_error(code: str) -> bool:
    """Check if error code represents a server error (5xx).

    Args:
        code: Error code to check.

    Returns:
        True if error is 5xx server error.
    """
    status = get_http_status(code)
    return 500 <= status < 600


def is_retryable(code: str) -> bool:
    """Check if error is potentially retryable.

    Args:
        code: Error code to check.

    Returns:
        True if operation may succeed on retry.
    """
    error = _registry.get(code)
    return error.retryable if error else False


def list_errors(category: str | None = None) -> list[ErrorDefinition]:
    """List registered error definitions.

    Args:
        category: Optional category filter.

    Returns:
        List of error definitions.
    """
    if category:
        return _registry.list_by_category(category)
    return _registry.list_all()


# -----------------------------------------------------------------------------
# Register standard errors from config on module load
# -----------------------------------------------------------------------------

register_errors_from_config(STANDARD_ERRORS)


def help() -> str:
    """Display module usage information.

    Returns:
        str: Help text with registry usage and functions.
    """
    return """
databricks_api_workspace.core.errors.codes
=============================================

Extensible error code registry.
Configuration loaded from errors/config.py.

Registering Custom Errors:
-------------------------
  # Option 1: Direct registration
  from databricks_api_workspace.core.errors import register_error
  register_error("MY_ERROR", 400, False, "my_module", "Description")

  # Option 2: From config (recommended for modules)
  # In your_module/config.py:
  MY_ERRORS = [
      {"code": "MY_ERROR", "http_status": 400, "retryable": False,
       "category": "my_module", "description": "My error"},
  ]

  # In your_module/__init__.py:
  from databricks_api_workspace.core.errors import register_errors_from_config
  from your_module.config import MY_ERRORS
  register_errors_from_config(MY_ERRORS)

Lookup Functions:
----------------
  get_error(code) -> ErrorDefinition | None
  get_http_status(code, default=500) -> int
  is_error(code) -> bool
  is_client_error(code) -> bool
  is_server_error(code) -> bool
  is_retryable(code) -> bool
  list_errors(category=None) -> list[ErrorDefinition]

Standard Error Categories:
-------------------------
  validation - Input validation errors (400, 422)
  auth       - Authentication/authorization (401, 403)
  not_found  - Resource not found (404)
  rate_limit - Rate limiting (429)
  server     - Server errors (500, 503, 504)
"""
