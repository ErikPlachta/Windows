# Databricks notebook source
# MAGIC %md
# MAGIC # exceptions
# MAGIC
# MAGIC **Auto-generated from:** `exceptions.py`
# MAGIC **Build timestamp:** 2025-12-22T22:33:16.533205+00:00
# MAGIC **Content hash:** 713753b9c34c
# MAGIC
# MAGIC > Do not edit directly. Make changes in source and rebuild.

# COMMAND ----------

# MAGIC %run ../../core/errors/codes

# COMMAND ----------

"""
databricks_api_workspace.core.errors.exceptions - Exception classes.

API exception classes with error code support.

Classes:
    APIError: Base exception for API errors
    ValidationError: Request validation failed
    AuthorizationError: Permission denied
    NotFoundError: Resource not found
    OperationNotFoundError: Operation not found

Functions:
    help(): Display module usage information
"""

from __future__ import annotations

from typing import Any


__all__ = [
    "APIError",
    "ValidationError",
    "AuthorizationError",
    "NotFoundError",
    "OperationNotFoundError",
    "help",
]


class APIError(Exception):
    """Base exception for API errors with error code support.

    Provides structured error information for API responses.

    Attributes:
        error_code: Error code string.
        message: Human-readable error message.
        details: Additional error details dict.
        http_status: HTTP status code.

    Example:
        >>> raise APIError("INVALID_PARAMS", "Missing required field: name")
    """

    def __init__(
        self,
        error_code: str,
        message: str,
        details: dict[str, Any] | None = None,
    ) -> None:
        """Initialize API error.

        Args:
            error_code: Error code string (e.g., "INVALID_PARAMS").
            message: Human-readable error message.
            details: Additional error context.
        """
        self.error_code = error_code
        self.message = message
        self.details = details or {}
        self.http_status = get_http_status(error_code)
        super().__init__(message)

    def to_dict(self) -> dict[str, Any]:
        """Convert to error response dict.

        Returns:
            Dict suitable for JSON serialization in API response.
        """
        return {
            "error_code": self.error_code,
            "message": self.message,
            "details": self.details,
        }


class ValidationError(APIError):
    """Raised when request validation fails.

    Example:
        >>> raise ValidationError("Invalid email format", errors=["email"])
    """

    def __init__(self, message: str, errors: list[str] | None = None) -> None:
        """Initialize validation error.

        Args:
            message: Validation error message.
            errors: List of specific validation errors.
        """
        super().__init__(
            "SCHEMA_VALIDATION_FAILED",
            message,
            {"errors": errors or []},
        )


class AuthorizationError(APIError):
    """Raised when user lacks required permissions.

    Example:
        >>> raise AuthorizationError(required_roles=["admin"])
    """

    def __init__(
        self,
        message: str = "Insufficient permissions",
        required_roles: list[str] | None = None,
    ) -> None:
        """Initialize authorization error.

        Args:
            message: Authorization error message.
            required_roles: List of roles that would grant access.
        """
        super().__init__(
            "FORBIDDEN",
            message,
            {"required_roles": required_roles or []},
        )


class NotFoundError(APIError):
    """Raised when a resource is not found.

    Example:
        >>> raise NotFoundError("customer", "12345")
    """

    def __init__(
        self,
        resource_type: str,
        resource_id: str,
    ) -> None:
        """Initialize not found error.

        Args:
            resource_type: Type of resource (e.g., "customer").
            resource_id: ID of the missing resource.
        """
        super().__init__(
            "RESOURCE_NOT_FOUND",
            f"{resource_type} not found: {resource_id}",
            {"resource_type": resource_type, "resource_id": resource_id},
        )


class OperationNotFoundError(APIError):
    """Raised when an operation doesn't exist.

    Example:
        >>> raise OperationNotFoundError("get_unknown_data")
    """

    def __init__(self, operation: str) -> None:
        """Initialize operation not found error.

        Args:
            operation: Name of the missing operation.
        """
        super().__init__(
            "OPERATION_NOT_FOUND",
            f"Operation not found: {operation}",
            {"operation": operation},
        )


def help() -> str:
    """Display module usage information.

    Returns:
        str: Help text with exception classes.
    """
    return """
databricks_api_workspace.core.errors.exceptions
==================================================

API exception classes.

Exception Hierarchy:
-------------------
  APIError (base)
    ├── ValidationError      - Input validation failed (422)
    ├── AuthorizationError   - Permission denied (403)
    ├── NotFoundError        - Resource not found (404)
    └── OperationNotFoundError - Operation not found (404)

APIError Attributes:
-------------------
  error_code   - String error code
  message      - Human-readable message
  details      - Additional context dict
  http_status  - HTTP status code

Usage:
-----
  from databricks_api_workspace.core.errors import (
      APIError,
      ValidationError,
      NotFoundError,
  )

  # Raise with error code
  raise APIError("DATABASE_ERROR", "Connection failed")

  # Use specialized exceptions
  raise ValidationError("Invalid input", errors=["email", "phone"])
  raise NotFoundError("customer", "12345")

  # Convert to response dict
  try:
      do_something()
  except APIError as e:
      return {"status": "error", **e.to_dict()}
"""
