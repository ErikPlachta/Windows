# Databricks notebook source
# MAGIC %md
# MAGIC # handlers
# MAGIC
# MAGIC **Auto-generated from:** `handlers.py`
# MAGIC **Build timestamp:** 2025-12-22T22:33:16.534956+00:00
# MAGIC **Content hash:** 722b43ad3fd1
# MAGIC
# MAGIC > Do not edit directly. Make changes in source and rebuild.

# COMMAND ----------

# MAGIC %run ../../core/errors/_settings
# MAGIC %run ../../core/errors/exceptions
# MAGIC %run ../../core/logging/_init

# COMMAND ----------

"""
databricks_api_workspace.core.errors.handlers - Error handling utilities.

Decorators and utilities for graceful error handling.

Functions:
    handle_errors(): Decorator for wrapping functions with error handling
    truncate_str(): Truncate strings for logging
    help(): Display module usage information
"""

from __future__ import annotations

import functools
import inspect
from collections.abc import Callable
from typing import Any, TypeVar


__all__ = [
    "handle_errors",
    "truncate_str",
    "help",
]

T = TypeVar("T")


def handle_errors(
    error_code: str = "EXECUTION_ERROR",
    reraise: bool = True,
    log: bool = True,
) -> Callable[[Callable[..., T]], Callable[..., T]]:
    """Decorator for graceful error handling.

    Wraps function with try/catch, logs exceptions, and optionally converts
    to APIError with context.

    Args:
        error_code: Default error code for unhandled exceptions.
        reraise: If True, re-raise as APIError. If False, return None.
        log: If True, log exceptions.

    Returns:
        Decorated function.

    Example:
        >>> @handle_errors(error_code="DATABASE_ERROR")
        ... def query_database(query: str) -> dict:
        ...     return db.execute(query)

        >>> @handle_errors(reraise=False)
        ... def optional_operation() -> dict | None:
        ...     # Returns None on error instead of raising
        ...     pass
    """

    def decorator(func: Callable[..., T]) -> Callable[..., T]:
        @functools.wraps(func)
        def wrapper(*args: Any, **kwargs: Any) -> T:
            try:
                return func(*args, **kwargs)
            except APIError:
                # Already handled, re-raise as-is
                raise
            except Exception as e:
                # Get context
                filename = inspect.getfile(func)
                method_name = func.__name__

                if log:
                    _log_error(
                        f"Error in {method_name}",
                        e,
                        filename=filename,
                        method=method_name,
                        args=truncate_str(str(args)),
                        kwargs=truncate_str(str(kwargs)),
                    )

                if reraise:
                    raise APIError(
                        error_code,
                        str(e),
                        {
                            "filename": filename,
                            "method": method_name,
                            "original_error": type(e).__name__,
                        },
                    ) from e

                return None  # type: ignore[return-value]

        return wrapper

    return decorator


def truncate_str(s: str, max_len: int | None = None) -> str:
    """Truncate string for logging.

    Args:
        s: String to truncate.
        max_len: Maximum length. Defaults to ERROR_MESSAGE_TRUNCATION_LENGTH.

    Returns:
        Truncated string with "..." suffix if truncated.
    """
    if max_len is None:
        max_len = ERROR_MESSAGE_TRUNCATION_LENGTH

    if len(s) <= max_len:
        return s
    return s[: max_len - 3] + "..."


def _log_error(
    message: str,
    exception: Exception,
    **context: Any,
) -> None:
    """Log an error with context.

    Uses lazy import to avoid circular dependency with logging module.

    Args:
        message: Error message.
        exception: The exception that occurred.
        **context: Additional context to log.
    """
    try:

        log_exception(message, exception, **context)
    except ImportError:
        # Logging module not available, use print as fallback
        print(f"ERROR: {message}: {exception}")


def help() -> str:
    """Display module usage information.

    Returns:
        str: Help text with handler usage.
    """
    return """
databricks_api_workspace.core.errors.handlers
================================================

Error handling decorators and utilities.

handle_errors Decorator:
-----------------------
  Wraps functions with error handling:
  - Catches exceptions and converts to APIError
  - Logs errors with context (filename, method, args)
  - Optionally returns None instead of raising

  Parameters:
    error_code: str = "EXECUTION_ERROR"
        Default error code for unhandled exceptions.

    reraise: bool = True
        If True, re-raise as APIError.
        If False, return None on error.

    log: bool = True
        If True, log exceptions.

Usage:
-----
  from databricks_api_workspace.core.errors import handle_errors

  # Basic usage - wraps with EXECUTION_ERROR
  @handle_errors()
  def my_function():
      pass

  # Custom error code
  @handle_errors(error_code="DATABASE_ERROR")
  def query_database():
      pass

  # Return None instead of raising
  @handle_errors(reraise=False)
  def optional_operation():
      pass

  # Silent failures (no logging)
  @handle_errors(log=False, reraise=False)
  def best_effort():
      pass

Utilities:
---------
  truncate_str(s, max_len=200) -> str
      Truncate string for logging.
"""
