# Databricks notebook source
# MAGIC %md
# MAGIC # _settings
# MAGIC
# MAGIC **Auto-generated from:** `_settings.py`
# MAGIC **Build timestamp:** 2025-12-22T22:33:16.536305+00:00
# MAGIC **Content hash:** 0cf6341b2d5a
# MAGIC
# MAGIC > Do not edit directly. Make changes in source and rebuild.

# COMMAND ----------

"""
databricks_api_workspace.core.errors.config - Error module configuration.

Single source of truth for error handling configuration.
All error definitions and constants are defined here.

Functions:
    help(): Display module usage information

Constants:
    ERROR_MESSAGE_TRUNCATION_LENGTH: Max length for error messages in logs
    DEFAULT_HTTP_STATUS: Default HTTP status for unknown error codes
    STANDARD_ERRORS: List of standard error definitions

Types:
    ErrorConfig: TypedDict for error configuration
"""

from __future__ import annotations

from typing import TypedDict

__all__ = [
    "ERROR_MESSAGE_TRUNCATION_LENGTH",
    "DEFAULT_HTTP_STATUS",
    "STANDARD_ERRORS",
    "ErrorConfig",
    "help",
]


class ErrorConfig(TypedDict):
    """Configuration for a single error code.

    Attributes:
        code: Unique error code string.
        http_status: HTTP status code.
        retryable: Whether the error may succeed on retry.
        category: Error category for grouping.
        description: Human-readable description.
    """

    code: str
    http_status: int
    retryable: bool
    category: str
    description: str


# Maximum length for error message truncation in logs
ERROR_MESSAGE_TRUNCATION_LENGTH: int = 200

# Default HTTP status for unknown/unregistered error codes
DEFAULT_HTTP_STATUS: int = 500

# -----------------------------------------------------------------------------
# Standard Error Definitions
# Single source of truth - codes.py imports from here
# -----------------------------------------------------------------------------

STANDARD_ERRORS: list[ErrorConfig] = [
    # 400 Bad Request - Validation errors
    {
        "code": "INVALID_PARAMS",
        "http_status": 400,
        "retryable": False,
        "category": "validation",
        "description": "Invalid parameters",
    },
    {
        "code": "MISSING_REQUIRED_FIELD",
        "http_status": 400,
        "retryable": False,
        "category": "validation",
        "description": "Missing required field",
    },
    {
        "code": "INVALID_JSON",
        "http_status": 400,
        "retryable": False,
        "category": "validation",
        "description": "Invalid JSON format",
    },
    {
        "code": "INVALID_TYPE",
        "http_status": 400,
        "retryable": False,
        "category": "validation",
        "description": "Invalid type",
    },
    # 401 Unauthorized - Auth errors
    {
        "code": "UNAUTHORIZED",
        "http_status": 401,
        "retryable": False,
        "category": "auth",
        "description": "Unauthorized",
    },
    {
        "code": "INVALID_TOKEN",
        "http_status": 401,
        "retryable": False,
        "category": "auth",
        "description": "Invalid token",
    },
    {
        "code": "TOKEN_EXPIRED",
        "http_status": 401,
        "retryable": False,
        "category": "auth",
        "description": "Token expired",
    },
    # 403 Forbidden - Permission errors
    {
        "code": "FORBIDDEN",
        "http_status": 403,
        "retryable": False,
        "category": "auth",
        "description": "Forbidden",
    },
    {
        "code": "INSUFFICIENT_PERMISSIONS",
        "http_status": 403,
        "retryable": False,
        "category": "auth",
        "description": "Insufficient permissions",
    },
    {
        "code": "OPERATION_NOT_ALLOWED",
        "http_status": 403,
        "retryable": False,
        "category": "auth",
        "description": "Operation not allowed",
    },
    # 404 Not Found
    {
        "code": "OPERATION_NOT_FOUND",
        "http_status": 404,
        "retryable": False,
        "category": "not_found",
        "description": "Operation not found",
    },
    {
        "code": "RESOURCE_NOT_FOUND",
        "http_status": 404,
        "retryable": False,
        "category": "not_found",
        "description": "Resource not found",
    },
    {
        "code": "USER_NOT_FOUND",
        "http_status": 404,
        "retryable": False,
        "category": "not_found",
        "description": "User not found",
    },
    # 422 Unprocessable Entity - Schema errors
    {
        "code": "SCHEMA_VALIDATION_FAILED",
        "http_status": 422,
        "retryable": False,
        "category": "validation",
        "description": "Schema validation failed",
    },
    {
        "code": "CONTRACT_VIOLATION",
        "http_status": 422,
        "retryable": False,
        "category": "validation",
        "description": "Contract violation",
    },
    # 429 Too Many Requests - Retryable
    {
        "code": "RATE_LIMIT_EXCEEDED",
        "http_status": 429,
        "retryable": True,
        "category": "rate_limit",
        "description": "Rate limit exceeded",
    },
    # 500 Internal Server Error - Retryable
    {
        "code": "EXECUTION_ERROR",
        "http_status": 500,
        "retryable": True,
        "category": "server",
        "description": "Execution error",
    },
    {
        "code": "INTERNAL_ERROR",
        "http_status": 500,
        "retryable": True,
        "category": "server",
        "description": "Internal server error",
    },
    {
        "code": "DATABASE_ERROR",
        "http_status": 500,
        "retryable": True,
        "category": "server",
        "description": "Database error",
    },
    # 503 Service Unavailable - Retryable
    {
        "code": "SERVICE_UNAVAILABLE",
        "http_status": 503,
        "retryable": True,
        "category": "server",
        "description": "Service unavailable",
    },
    {
        "code": "CLUSTER_UNAVAILABLE",
        "http_status": 503,
        "retryable": True,
        "category": "server",
        "description": "Cluster unavailable",
    },
    # 504 Gateway Timeout - Retryable
    {
        "code": "OPERATION_TIMEOUT",
        "http_status": 504,
        "retryable": True,
        "category": "server",
        "description": "Operation timeout",
    },
]


def help() -> str:
    """Display module usage information.

    Returns:
        str: Help text with module constants.
    """
    return """
databricks_api_workspace.core.errors.config
==========================================

Single source of truth for error configuration.

Constants:
---------
  ERROR_MESSAGE_TRUNCATION_LENGTH = 200
      Maximum length for error messages in logs.

  DEFAULT_HTTP_STATUS = 500
      Default HTTP status for unknown error codes.

  STANDARD_ERRORS: list[ErrorConfig]
      List of standard error definitions.
      Each entry is a dict with: code, http_status, retryable, category, description

ErrorConfig TypedDict:
---------------------
  code: str           - Unique error code (e.g., "INVALID_PARAMS")
  http_status: int    - HTTP status code (e.g., 400)
  retryable: bool     - Whether error may succeed on retry
  category: str       - Error category (validation, auth, not_found, server)
  description: str    - Human-readable description

Categories:
----------
  validation  - Input validation errors (400, 422)
  auth        - Authentication/authorization (401, 403)
  not_found   - Resource not found (404)
  rate_limit  - Rate limiting (429)
  server      - Server errors (500, 503, 504)

Usage:
-----
  from databricks_api_workspace.core.errors.config import STANDARD_ERRORS

  # Iterate over standard errors
  for err in STANDARD_ERRORS:
      print(f"{err['code']} -> {err['http_status']}")

  # Add custom error to your module's config
  MY_MODULE_ERRORS = [
      {"code": "MY_ERROR", "http_status": 400, "retryable": False,
       "category": "my_module", "description": "Custom error"},
  ]
"""
