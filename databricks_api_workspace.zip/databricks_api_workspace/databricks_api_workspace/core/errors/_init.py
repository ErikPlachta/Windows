# Databricks notebook source
# MAGIC %md
# MAGIC # __init__
# MAGIC
# MAGIC **Auto-generated from:** `__init__.py`
# MAGIC **Build timestamp:** 2025-12-22T22:33:16.537502+00:00
# MAGIC **Content hash:** 02e03c73f24b
# MAGIC
# MAGIC > Do not edit directly. Make changes in source and rebuild.

# COMMAND ----------

# MAGIC %run ../../core/errors/codes
# MAGIC %run ../../core/errors/exceptions
# MAGIC %run ../../core/errors/handlers

# COMMAND ----------

"""
databricks_api_workspace.core.errors - Error handling module.

Extensible error code registry and exception classes.

Classes:
    ErrorDefinition: Defines an error code with metadata
    ErrorRegistry: Registry for error codes
    APIError: Base exception for API errors
    ValidationError: Request validation failed
    AuthorizationError: Permission denied
    NotFoundError: Resource not found
    OperationNotFoundError: Operation not found

Functions:
    register_error(): Register a new error code
    get_error(): Get error definition by code
    get_http_status(): Get HTTP status for error code
    is_error(): Check if code is registered
    is_client_error(): Check if error is 4xx
    is_server_error(): Check if error is 5xx
    is_retryable(): Check if error may succeed on retry
    list_errors(): List registered error definitions
    handle_errors(): Decorator for error handling
    truncate_str(): Truncate strings for logging
    help(): Display module usage information

Example:
    >>> from databricks_api_workspace.core.errors import APIError, register_error
    >>> register_error("MY_ERROR", 400, False, "custom")
    >>> raise APIError("MY_ERROR", "Something went wrong")
"""

from __future__ import annotations

# Re-exports

__all__ = [
    # Enum
    "ErrorCode",
    # Classes
    "ErrorDefinition",
    "ErrorRegistry",
    "APIError",
    "ValidationError",
    "AuthorizationError",
    "NotFoundError",
    "OperationNotFoundError",
    # Registry functions
    "register_error",
    "register_errors_from_config",
    "get_error",
    "get_http_status",
    "is_error",
    "is_client_error",
    "is_server_error",
    "is_retryable",
    "list_errors",
    # Handlers
    "handle_errors",
    "truncate_str",
    # Help
    "help",
]


def help() -> str:
    """Display error module usage information.

    Returns:
        str: Help text with all available classes, functions, and examples.

    Example:
        >>> from databricks_api_workspace.core import errors
        >>> print(errors.help())
    """
    return """
databricks_api_workspace.core.errors
===================================

Error handling with extensible error code registry.

Error Registry:
--------------
  register_error(code, http_status, retryable, category, description)
      Register a custom error code.

  get_error(code) -> ErrorDefinition | None
  get_http_status(code, default=500) -> int
  is_error(code) -> bool
  is_client_error(code) -> bool
  is_server_error(code) -> bool
  is_retryable(code) -> bool
  list_errors(category=None) -> list[ErrorDefinition]

Exception Classes:
-----------------
  APIError(error_code, message, details=None)
  ValidationError(message, errors=None)
  AuthorizationError(message, required_roles=None)
  NotFoundError(resource_type, resource_id)
  OperationNotFoundError(operation)

Error Handler:
-------------
  @handle_errors(error_code="EXECUTION_ERROR", reraise=True, log=True)

Quick Start:
-----------
  from databricks_api_workspace.core.errors import (
      APIError, register_error, handle_errors,
  )

  register_error("MY_ERROR", 400, False, "my_module")

  @handle_errors(error_code="DATABASE_ERROR")
  def query_database():
      pass

Submodules:
----------
  _settings - Error configuration constants
  codes - ErrorDefinition, ErrorRegistry
  exceptions - APIError and subclasses
  handlers - handle_errors decorator
"""
