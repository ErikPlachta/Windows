# Databricks notebook source
# MAGIC %md
# MAGIC # __init__
# MAGIC
# MAGIC **Auto-generated from:** `__init__.py`
# MAGIC **Build timestamp:** 2025-12-22T22:33:16.541547+00:00
# MAGIC **Content hash:** ca8c7515cbb0
# MAGIC
# MAGIC > Do not edit directly. Make changes in source and rebuild.

# COMMAND ----------

# MAGIC %run ../../core/cache/_settings
# MAGIC %run ../../core/cache/core

# COMMAND ----------

"""
databricks_api_workspace.core.cache - Unified cache module.

Thread-safe singleton cache with namespace support and TTL.
A single cache service for all modules to use.

Classes:
    CacheNamespace: Enum of cache namespaces
    CacheEntry: Dataclass for cache entries with TTL
    UnifiedCache: Thread-safe singleton cache

Functions:
    get_cache(): Get the singleton cache instance
    get_cached(): Get a cached value
    set_cached(): Set a cached value
    invalidate(): Invalidate a cache key
    clear_cache(): Clear a namespace
    clear_all_caches(): Clear all caches

Example:
    >>> from databricks_api_workspace.core.cache import (
    ...     CacheNamespace, get_cached, set_cached,
    ... )
    >>> set_cached(CacheNamespace.CONFIG, "main", {"version": "1.0"})
    >>> config = get_cached(CacheNamespace.CONFIG, "main")
"""

from __future__ import annotations


__all__ = [
    # Classes
    "CacheNamespace",
    "CacheEntry",
    "UnifiedCache",
    # Functions
    "get_cache",
    "get_cached",
    "get_stats",
    "set_cached",
    "invalidate",
    "clear_cache",
    "clear_all_caches",
    # Settings
    "DEFAULT_TTL_SECONDS",
    "CONFIG_TTL_SECONDS",
    "QUERY_TTL_SECONDS",
    "SCHEMA_TTL_SECONDS",
    "USER_TTL_SECONDS",
    "HANDLER_TTL_SECONDS",
    "MAX_CACHE_SIZE",
    # Help
    "help",
]


def help() -> str:
    """Display module usage information."""
    return """
databricks_api_workspace.core.cache
==================================

Unified cache service for all modules.

Namespaces:
----------
  CacheNamespace.CONFIG   - Configuration (1h TTL)
  CacheNamespace.QUERY    - Query templates (1h TTL)
  CacheNamespace.SCHEMA   - JSON schemas (1h TTL)
  CacheNamespace.USER     - User context (5m TTL)
  CacheNamespace.HANDLER  - Handlers (no expiry)

Quick Start:
-----------
  from databricks_api_workspace.core.cache import (
      CacheNamespace, get_cached, set_cached,
  )

  # Store a value
  set_cached(CacheNamespace.CONFIG, "main", {"version": "1.0"})

  # Retrieve a value
  config = get_cached(CacheNamespace.CONFIG, "main")

  # With custom TTL
  set_cached(CacheNamespace.USER, "session", data, ttl_seconds=60)

Functions:
---------
  get_cache() -> UnifiedCache
  get_cached(namespace, key, default=None) -> Any
  set_cached(namespace, key, value, ttl_seconds=None) -> None
  invalidate(namespace, key) -> bool
  clear_cache(namespace) -> int
  clear_all_caches() -> int

Classes:
-------
  CacheEntry(value, ttl_seconds=300)
    .is_expired() -> bool
    .touch() -> None

  UnifiedCache() - Singleton
    .get(namespace, key, default=None) -> Any
    .set(namespace, key, value, ttl_seconds=None) -> None
    .invalidate(namespace, key) -> bool
    .clear(namespace) -> int
    .clear_all() -> int
    .stats() -> dict

Settings:
--------
  DEFAULT_TTL_SECONDS = 300 (5 minutes)
  CONFIG_TTL_SECONDS = 3600 (1 hour)
  QUERY_TTL_SECONDS = 3600 (1 hour)
  SCHEMA_TTL_SECONDS = 3600 (1 hour)
  USER_TTL_SECONDS = 300 (5 minutes)
  HANDLER_TTL_SECONDS = 0 (never expires)
  MAX_CACHE_SIZE = 1000 (per namespace)
"""
