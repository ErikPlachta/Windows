# Databricks notebook source
# MAGIC %md
# MAGIC # _settings
# MAGIC
# MAGIC **Auto-generated from:** `_settings.py`
# MAGIC **Build timestamp:** 2025-12-22T22:33:16.540429+00:00
# MAGIC **Content hash:** 6279208a8772
# MAGIC
# MAGIC > Do not edit directly. Make changes in source and rebuild.

# COMMAND ----------

"""
databricks_api_workspace.core.cache.settings - Cache configuration.

Single source of truth for cache configuration.

Constants:
    DEFAULT_TTL_SECONDS: Default cache entry TTL
    CONFIG_TTL_SECONDS: Config cache TTL
    QUERY_TTL_SECONDS: Query template cache TTL
    SCHEMA_TTL_SECONDS: Schema cache TTL
    USER_TTL_SECONDS: User context cache TTL
    HANDLER_TTL_SECONDS: Handler cache TTL
    MAX_CACHE_SIZE: Maximum entries per namespace
"""

from __future__ import annotations

__all__ = [
    "DEFAULT_TTL_SECONDS",
    "CONFIG_TTL_SECONDS",
    "QUERY_TTL_SECONDS",
    "SCHEMA_TTL_SECONDS",
    "USER_TTL_SECONDS",
    "HANDLER_TTL_SECONDS",
    "MAX_CACHE_SIZE",
    "help",
]

# Default TTL for cache entries (5 minutes)
DEFAULT_TTL_SECONDS: int = 300

# Config cache - long TTL (config rarely changes)
CONFIG_TTL_SECONDS: int = 3600  # 1 hour

# Query template cache - long TTL (templates rarely change)
QUERY_TTL_SECONDS: int = 3600  # 1 hour

# Schema cache - long TTL (schemas rarely change)
SCHEMA_TTL_SECONDS: int = 3600  # 1 hour

# User context cache - shorter TTL (roles may change)
USER_TTL_SECONDS: int = 300  # 5 minutes

# Handler cache - no TTL (handlers are static)
HANDLER_TTL_SECONDS: int = 0  # Never expires

# Maximum entries per namespace (0 = unlimited)
MAX_CACHE_SIZE: int = 1000


def help() -> str:
    """Display module usage information."""
    return """
databricks_api_workspace.core.cache.settings
============================================

Cache configuration constants.

TTL Settings:
------------
  DEFAULT_TTL_SECONDS = 300 (5 minutes)
  CONFIG_TTL_SECONDS = 3600 (1 hour)
  QUERY_TTL_SECONDS = 3600 (1 hour)
  SCHEMA_TTL_SECONDS = 3600 (1 hour)
  USER_TTL_SECONDS = 300 (5 minutes)
  HANDLER_TTL_SECONDS = 0 (never expires)

Size Limits:
-----------
  MAX_CACHE_SIZE = 1000 (per namespace)

TTL of 0 means entries never expire (except on clear).
"""
