# Databricks notebook source
# MAGIC %md
# MAGIC # core
# MAGIC
# MAGIC **Auto-generated from:** `core.py`
# MAGIC **Build timestamp:** 2025-12-22T22:33:16.539081+00:00
# MAGIC **Content hash:** 8678951e1bfb
# MAGIC
# MAGIC > Do not edit directly. Make changes in source and rebuild.

# COMMAND ----------

# MAGIC %run ../../core/cache/_settings

# COMMAND ----------

"""
databricks_api_workspace.core.cache.core - Unified cache implementation.

Thread-safe unified cache with namespace support and TTL.

Classes:
    CacheNamespace: Enum of cache namespaces
    CacheEntry: Dataclass for cache entries with TTL
    UnifiedCache: Thread-safe singleton cache

Functions:
    get_cache(): Get the singleton cache instance
    get_cached(): Get a cached value
    set_cached(): Set a cached value
    invalidate(): Invalidate a cache key
    clear_cache(): Clear a namespace
    clear_all_caches(): Clear all caches
"""

from __future__ import annotations

import threading
from dataclasses import dataclass, field
from enum import Enum
from time import time
from typing import Any


__all__ = [
    "CacheNamespace",
    "CacheEntry",
    "UnifiedCache",
    "get_cache",
    "get_cached",
    "get_stats",
    "set_cached",
    "invalidate",
    "clear_cache",
    "clear_all_caches",
    "help",
]


class CacheNamespace(str, Enum):
    """Cache namespaces for different data types.

    Each namespace has its own TTL and storage.
    """

    CONFIG = "config"
    QUERY = "query"
    SCHEMA = "schema"
    USER = "user"
    HANDLER = "handler"


# TTL mapping per namespace
_NAMESPACE_TTL: dict[CacheNamespace, int] = {
    CacheNamespace.CONFIG: CONFIG_TTL_SECONDS,
    CacheNamespace.QUERY: QUERY_TTL_SECONDS,
    CacheNamespace.SCHEMA: SCHEMA_TTL_SECONDS,
    CacheNamespace.USER: USER_TTL_SECONDS,
    CacheNamespace.HANDLER: HANDLER_TTL_SECONDS,
}


@dataclass
class CacheEntry:
    """A cached value with metadata.

    Attributes:
        value: The cached value.
        created_at: Timestamp when entry was created.
        ttl_seconds: Time-to-live in seconds (0 = never expires).
        hits: Number of times this entry was accessed.
    """

    value: Any
    created_at: float = field(default_factory=time)
    ttl_seconds: int = DEFAULT_TTL_SECONDS
    hits: int = 0

    def is_expired(self) -> bool:
        """Check if entry has expired.

        Returns:
            True if expired, False otherwise.
        """
        if self.ttl_seconds <= 0:
            return False  # Never expires
        return time() - self.created_at > self.ttl_seconds

    def touch(self) -> None:
        """Record a cache hit."""
        self.hits += 1


class UnifiedCache:
    """Thread-safe unified cache with namespace support.

    Singleton pattern ensures only one cache instance exists.

    Example:
        >>> cache = UnifiedCache()
        >>> cache.set(CacheNamespace.CONFIG, "main", {"version": "1.0"})
        >>> config = cache.get(CacheNamespace.CONFIG, "main")
    """

    _instance: UnifiedCache | None = None
    _lock: threading.Lock = threading.Lock()

    def __new__(cls) -> UnifiedCache:
        """Create or return singleton instance."""
        if cls._instance is None:
            with cls._lock:
                if cls._instance is None:
                    instance = super().__new__(cls)
                    instance._init_storage()
                    cls._instance = instance
        return cls._instance

    def _init_storage(self) -> None:
        """Initialize cache storage."""
        self._storage: dict[CacheNamespace, dict[str, CacheEntry]] = {
            ns: {} for ns in CacheNamespace
        }
        self._ns_locks: dict[CacheNamespace, threading.Lock] = {
            ns: threading.Lock() for ns in CacheNamespace
        }

    def get(
        self,
        namespace: CacheNamespace,
        key: str,
        default: Any = None,
    ) -> Any:
        """Get a cached value.

        Args:
            namespace: Cache namespace.
            key: Cache key.
            default: Default value if not found or expired.

        Returns:
            Cached value or default.
        """
        with self._ns_locks[namespace]:
            entry = self._storage[namespace].get(key)

            if entry is None:
                return default

            if entry.is_expired():
                del self._storage[namespace][key]
                return default

            entry.touch()
            return entry.value

    def set(
        self,
        namespace: CacheNamespace,
        key: str,
        value: Any,
        ttl_seconds: int | None = None,
    ) -> None:
        """Set a cached value.

        Args:
            namespace: Cache namespace.
            key: Cache key.
            value: Value to cache.
            ttl_seconds: TTL override (uses namespace default if None).
        """
        if ttl_seconds is None:
            ttl_seconds = _NAMESPACE_TTL.get(namespace, DEFAULT_TTL_SECONDS)

        entry = CacheEntry(value=value, ttl_seconds=ttl_seconds)

        with self._ns_locks[namespace]:
            # Enforce size limit
            if MAX_CACHE_SIZE > 0 and len(self._storage[namespace]) >= MAX_CACHE_SIZE:
                self._evict_oldest(namespace)

            self._storage[namespace][key] = entry

    def _evict_oldest(self, namespace: CacheNamespace) -> None:
        """Evict oldest entry from namespace (must hold lock)."""
        if not self._storage[namespace]:
            return

        oldest_key = min(
            self._storage[namespace].keys(),
            key=lambda k: self._storage[namespace][k].created_at,
        )
        del self._storage[namespace][oldest_key]

    def invalidate(self, namespace: CacheNamespace, key: str) -> bool:
        """Invalidate a specific cache entry.

        Args:
            namespace: Cache namespace.
            key: Cache key.

        Returns:
            True if entry was removed, False if not found.
        """
        with self._ns_locks[namespace]:
            if key in self._storage[namespace]:
                del self._storage[namespace][key]
                return True
            return False

    def clear(self, namespace: CacheNamespace) -> int:
        """Clear all entries in a namespace.

        Args:
            namespace: Cache namespace to clear.

        Returns:
            Number of entries cleared.
        """
        with self._ns_locks[namespace]:
            count = len(self._storage[namespace])
            self._storage[namespace].clear()
            return count

    def clear_all(self) -> int:
        """Clear all caches.

        Returns:
            Total number of entries cleared.
        """
        total = 0
        for namespace in CacheNamespace:
            total += self.clear(namespace)
        return total

    def stats(self) -> dict[str, Any]:
        """Get cache statistics.

        Returns:
            dict with counts per namespace and total.
        """
        stats: dict[str, Any] = {"namespaces": {}, "total": 0}

        for namespace in CacheNamespace:
            with self._ns_locks[namespace]:
                count = len(self._storage[namespace])
                stats["namespaces"][namespace.value] = count
                stats["total"] += count

        return stats


# Singleton instance
_cache: UnifiedCache | None = None


def get_cache() -> UnifiedCache:
    """Get the singleton cache instance.

    Returns:
        UnifiedCache: The global cache instance.
    """
    global _cache
    if _cache is None:
        _cache = UnifiedCache()
    return _cache


def get_cached(namespace: CacheNamespace, key: str, default: Any = None) -> Any:
    """Convenience function to get cached value.

    Args:
        namespace: Cache namespace.
        key: Cache key.
        default: Default if not found.

    Returns:
        Cached value or default.
    """
    return get_cache().get(namespace, key, default)


def set_cached(
    namespace: CacheNamespace,
    key: str,
    value: Any,
    ttl_seconds: int | None = None,
) -> None:
    """Convenience function to set cached value.

    Args:
        namespace: Cache namespace.
        key: Cache key.
        value: Value to cache.
        ttl_seconds: Optional TTL override.
    """
    get_cache().set(namespace, key, value, ttl_seconds)


def invalidate(namespace: CacheNamespace, key: str) -> bool:
    """Convenience function to invalidate cache entry.

    Args:
        namespace: Cache namespace.
        key: Cache key.

    Returns:
        True if removed, False if not found.
    """
    return get_cache().invalidate(namespace, key)


def clear_cache(namespace: CacheNamespace) -> int:
    """Convenience function to clear a namespace.

    Args:
        namespace: Cache namespace.

    Returns:
        Number of entries cleared.
    """
    return get_cache().clear(namespace)


def clear_all_caches() -> int:
    """Convenience function to clear all caches.

    Returns:
        Total entries cleared.
    """
    return get_cache().clear_all()


def get_stats() -> dict[str, Any]:
    """Get cache statistics.

    Returns:
        dict: Statistics with counts per namespace and total.
    """
    return get_cache().stats()


def help() -> str:
    """Display module usage information."""
    return """
databricks_api_workspace.core.cache.core
===========================================

Unified cache with namespace support and TTL.

Namespaces:
----------
  CacheNamespace.CONFIG   - Configuration cache (1h TTL)
  CacheNamespace.QUERY    - Query template cache (1h TTL)
  CacheNamespace.SCHEMA   - JSON schema cache (1h TTL)
  CacheNamespace.USER     - User context cache (5m TTL)
  CacheNamespace.HANDLER  - Handler cache (no expiry)

Classes:
-------
  CacheEntry(value, ttl_seconds=300)
    .is_expired() -> bool
    .touch() -> None

  UnifiedCache() - Singleton
    .get(namespace, key, default=None) -> Any
    .set(namespace, key, value, ttl_seconds=None) -> None
    .invalidate(namespace, key) -> bool
    .clear(namespace) -> int
    .clear_all() -> int
    .stats() -> dict

Convenience Functions:
--------------------
  get_cache() -> UnifiedCache
  get_cached(namespace, key, default=None) -> Any
  set_cached(namespace, key, value, ttl_seconds=None) -> None
  invalidate(namespace, key) -> bool
  clear_cache(namespace) -> int
  clear_all_caches() -> int

Example:
-------
  from databricks_api_workspace.core.cache import (
      CacheNamespace, get_cached, set_cached,
  )

  # Store config
  set_cached(CacheNamespace.CONFIG, "main", {"version": "1.0"})

  # Retrieve config
  config = get_cached(CacheNamespace.CONFIG, "main")
"""
