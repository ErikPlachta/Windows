# Databricks notebook source
# MAGIC %md
# MAGIC # formatters
# MAGIC
# MAGIC **Auto-generated from:** `formatters.py`
# MAGIC **Build timestamp:** 2025-12-22T22:33:16.574179+00:00
# MAGIC **Content hash:** aeef6e410883
# MAGIC
# MAGIC > Do not edit directly. Make changes in source and rebuild.

# COMMAND ----------

# MAGIC %run ../../core/data_utils/_settings

# COMMAND ----------

"""
databricks_api_workspace.core.data_utils.formatters - Data formatting utilities.

Functions for formatting and transforming data values.

Functions:
    coalesce(): Return first non-None value
    format_date(): Format date string
    format_currency(): Format currency string
    help(): Display module usage information
"""

from __future__ import annotations

from typing import Any


__all__ = [
    "coalesce",
    "format_date",
    "format_currency",
    "help",
]


def coalesce(*values: Any) -> Any:
    """Return first non-None value.

    Args:
        *values: Values to check.

    Returns:
        First non-None value, or None if all None.

    Example:
        >>> coalesce(None, None, "default")
        "default"
    """
    for v in values:
        if v is not None:
            return v
    return None


def format_date(value: Any) -> str:
    """Format value as date string (YYYY-MM-DD).

    Args:
        value: Date value (str, datetime, or None).

    Returns:
        Formatted date string or empty string.
    """
    if value is None:
        return ""
    return str(value)[:DATE_FORMAT_LENGTH]


def format_currency(value: Any, currency: str = DEFAULT_CURRENCY) -> str:
    """Format value as currency string.

    Args:
        value: Numeric value.
        currency: Currency code.

    Returns:
        Formatted currency string.

    Example:
        >>> format_currency(1234.5)
        "1,234.50 USD"
    """
    if value is None:
        return f"0.00 {currency}"
    return f"{float(value):,.2f} {currency}"


def help() -> str:
    """Display module usage information.

    Returns:
        str: Help text with formatter usage.
    """
    return """
databricks_api_workspace.core.data_utils.formatters
==========================================================

Data formatting utilities.

Functions:
---------
  coalesce(*values) -> Any
      Return first non-None value.

  format_date(value) -> str
      Format as YYYY-MM-DD date string.

  format_currency(value, currency="USD") -> str
      Format as currency string with thousands separator.

Usage:
-----
  from databricks_api_workspace.core.data_utils import (
      coalesce,
      format_date,
      format_currency,
  )

  # Get first non-None value
  name = coalesce(row.get("display_name"), row.get("name"), "Unknown")

  # Format date
  date_str = format_date(row.get("created_at"))  # "2024-01-15"

  # Format currency
  balance_str = format_currency(1234.5)  # "1,234.50 USD"
"""
