# Databricks notebook source
# MAGIC %md
# MAGIC # _settings
# MAGIC
# MAGIC **Auto-generated from:** `_settings.py`
# MAGIC **Build timestamp:** 2025-12-22T22:33:16.577009+00:00
# MAGIC **Content hash:** edbe4bc1b5e8
# MAGIC
# MAGIC > Do not edit directly. Make changes in source and rebuild.

# COMMAND ----------

"""
databricks_api_workspace.core.data_utils.settings - Data utility constants.

Single source of truth for data utility configuration.

Constants:
    DEFAULT_CURRENCY: Default currency code for formatting
    DATE_FORMAT_LENGTH: Characters to keep for date formatting
"""

from __future__ import annotations

__all__ = [
    "DEFAULT_CURRENCY",
    "DATE_FORMAT_LENGTH",
]

# Default currency code for format_currency()
DEFAULT_CURRENCY: str = "USD"

# Number of characters to keep for date formatting (YYYY-MM-DD)
DATE_FORMAT_LENGTH: int = 10
