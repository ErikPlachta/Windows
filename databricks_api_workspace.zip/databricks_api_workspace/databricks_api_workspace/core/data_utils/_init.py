# Databricks notebook source
# MAGIC %md
# MAGIC # __init__
# MAGIC
# MAGIC **Auto-generated from:** `__init__.py`
# MAGIC **Build timestamp:** 2025-12-22T22:33:16.578671+00:00
# MAGIC **Content hash:** bdc8d72fad5e
# MAGIC
# MAGIC > Do not edit directly. Make changes in source and rebuild.

# COMMAND ----------

# MAGIC %run ../../core/data_utils/_settings
# MAGIC %run ../../core/data_utils/formatters
# MAGIC %run ../../core/data_utils/helpers

# COMMAND ----------

"""
databricks_api_workspace.core.data_utils - Data manipulation utilities.

Core utilities for extracting and formatting row data from query results.

Functions:
    first_row(): Get first row from results
    last_row(): Get last row from results
    pluck(): Extract field from all rows
    pluck_unique(): Extract unique values
    row_count(): Count rows
    has_rows(): Check if has rows
    get_field(): Safely get field from row
    coalesce(): Return first non-None value
    format_date(): Format date string
    format_currency(): Format currency string
    help(): Display module usage information

Usage:
    >>> from databricks_api_workspace.core.data_utils import (
    ...     first_row,
    ...     pluck,
    ...     format_currency,
    ... )
"""

from __future__ import annotations


# Dict of common mapper functions for eval contexts
MAPPER_FUNCTIONS = {
    "first_row": first_row,
    "last_row": last_row,
    "pluck": pluck,
    "pluck_unique": pluck_unique,
    "row_count": row_count,
    "has_rows": has_rows,
    "get_field": get_field,
    "coalesce": coalesce,
    "format_date": format_date,
    "format_currency": format_currency,
}

__all__ = [
    # Row helpers
    "first_row",
    "last_row",
    "pluck",
    "pluck_unique",
    "row_count",
    "has_rows",
    "get_field",
    # Formatters
    "coalesce",
    "format_date",
    "format_currency",
    # Mapper dict
    "MAPPER_FUNCTIONS",
    # Constants
    "DEFAULT_CURRENCY",
    "DATE_FORMAT_LENGTH",
    # Help
    "help",
]


def help() -> str:
    """Display module usage information.

    Returns:
        str: Help text with data_utils usage.
    """
    return """
databricks_api_workspace.core.data_utils
============================================

Data manipulation utilities for query results.

Row Helpers:
-----------
  first_row(rows) -> dict | None
  last_row(rows) -> dict | None
  pluck(rows, key) -> list
  pluck_unique(rows, key) -> list
  row_count(rows) -> int
  has_rows(rows) -> bool
  get_field(row, key, default=None) -> Any

Formatters:
----------
  coalesce(*values) -> Any
  format_date(value) -> str
  format_currency(value, currency="USD") -> str

Usage:
-----
  from databricks_api_workspace.core.data_utils import (
      first_row,
      pluck,
      format_currency,
  )

  # Get customer from results
  customer = first_row(results)

  # Extract all IDs
  ids = pluck(results, "id")

  # Format for display
  balance = format_currency(account["balance"])
"""
