# Databricks notebook source
# MAGIC %md
# MAGIC # helpers
# MAGIC
# MAGIC **Auto-generated from:** `helpers.py`
# MAGIC **Build timestamp:** 2025-12-22T22:33:16.576080+00:00
# MAGIC **Content hash:** 186dd44994ab
# MAGIC
# MAGIC > Do not edit directly. Make changes in source and rebuild.

# COMMAND ----------

"""
databricks_api_workspace.core.data_utils.helpers - Row extraction utilities.

Functions for extracting data from query result rows.

Functions:
    first_row(): Get first row
    last_row(): Get last row
    pluck(): Extract field from all rows
    pluck_unique(): Extract unique field values
    row_count(): Count rows
    has_rows(): Check if has rows
    get_field(): Safely get field from row
    help(): Display module usage information
"""

from __future__ import annotations

from typing import Any

__all__ = [
    "first_row",
    "last_row",
    "pluck",
    "pluck_unique",
    "row_count",
    "has_rows",
    "get_field",
    "help",
]


def first_row(rows: list[dict[str, Any]] | None) -> dict[str, Any] | None:
    """Get first row from results.

    Args:
        rows: List of row dicts.

    Returns:
        First row or None if empty/None.

    Example:
        >>> first_row([{"id": 1}, {"id": 2}])
        {"id": 1}
    """
    if not rows:
        return None
    return rows[0]


def last_row(rows: list[dict[str, Any]] | None) -> dict[str, Any] | None:
    """Get last row from results.

    Args:
        rows: List of row dicts.

    Returns:
        Last row or None if empty/None.

    Example:
        >>> last_row([{"id": 1}, {"id": 2}])
        {"id": 2}
    """
    if not rows:
        return None
    return rows[-1]


def pluck(rows: list[dict[str, Any]] | None, key: str) -> list[Any]:
    """Extract single field from all rows.

    Args:
        rows: List of row dicts.
        key: Field name to extract.

    Returns:
        List of values for the field.

    Example:
        >>> pluck([{"id": 1}, {"id": 2}], "id")
        [1, 2]
    """
    if not rows:
        return []
    return [row.get(key) for row in rows]


def pluck_unique(rows: list[dict[str, Any]] | None, key: str) -> list[Any]:
    """Extract unique values of a field from all rows.

    Preserves order of first occurrence.

    Args:
        rows: List of row dicts.
        key: Field name to extract.

    Returns:
        List of unique values.

    Example:
        >>> pluck_unique([{"type": "A"}, {"type": "A"}, {"type": "B"}], "type")
        ["A", "B"]
    """
    if not rows:
        return []
    seen: set[Any] = set()
    result: list[Any] = []
    for row in rows:
        val = row.get(key)
        if val not in seen:
            seen.add(val)
            result.append(val)
    return result


def row_count(rows: list[dict[str, Any]] | None) -> int:
    """Get number of rows.

    Args:
        rows: List of row dicts.

    Returns:
        Number of rows, or 0 if None.
    """
    return len(rows) if rows else 0


def has_rows(rows: list[dict[str, Any]] | None) -> bool:
    """Check if results have any rows.

    Args:
        rows: List of row dicts.

    Returns:
        True if at least one row exists.
    """
    return bool(rows)


def get_field(row: dict[str, Any] | None, key: str, default: Any = None) -> Any:
    """Safely get field from row.

    Args:
        row: Row dict or None.
        key: Field name.
        default: Default value if missing.

    Returns:
        Field value or default.

    Example:
        >>> get_field({"name": "Test"}, "name")
        "Test"
        >>> get_field(None, "name", "N/A")
        "N/A"
    """
    if not row:
        return default
    return row.get(key, default)


def help() -> str:
    """Display module usage information.

    Returns:
        str: Help text with row helper usage.
    """
    return """
databricks_api_workspace.core.data_utils.helpers
=======================================================

Row extraction utilities for query results.

Functions:
---------
  first_row(rows) -> dict | None
      Get first row from results.

  last_row(rows) -> dict | None
      Get last row from results.

  pluck(rows, key) -> list
      Extract single field from all rows.

  pluck_unique(rows, key) -> list
      Extract unique values of a field.

  row_count(rows) -> int
      Get number of rows.

  has_rows(rows) -> bool
      Check if results have any rows.

  get_field(row, key, default=None) -> Any
      Safely get field from row.

Usage:
-----
  from databricks_api_workspace.core.data_utils import (
      first_row,
      pluck,
      has_rows,
  )

  if has_rows(results):
      customer = first_row(results)
      all_ids = pluck(results, "id")
"""
