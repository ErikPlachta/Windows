# Databricks notebook source
# MAGIC %md
# MAGIC # checks
# MAGIC
# MAGIC **Auto-generated from:** `checks.py`
# MAGIC **Build timestamp:** 2025-12-22T22:33:16.581395+00:00
# MAGIC **Content hash:** 34e8c8d16557
# MAGIC
# MAGIC > Do not edit directly. Make changes in source and rebuild.

# COMMAND ----------

# MAGIC %run ../../core/runtime/_init
# MAGIC %run ../../core/validation_utils/_settings
# MAGIC %run ../../core/config/_init

# COMMAND ----------

"""
databricks_api_workspace.core.validation_utils.checks - Validation check implementations.

Individual check type implementations for the validation runner.

Functions:
    check_file_exists(): Check if a file exists
    check_json_valid(): Check if file contains valid JSON
    check_schema_valid(): Check if file validates against JSON schema
    check_config_key(): Check if config key exists with expected type
    check_module_imports(): Check if Python module can be imported
    run_custom_validator(): Run a custom validation function
    help(): Display module usage information
"""

from __future__ import annotations

import importlib
import json
from pathlib import Path
from typing import Any


__all__ = [
    "check_file_exists",
    "check_json_valid",
    "check_schema_valid",
    "check_config_key",
    "check_module_imports",
    "run_custom_validator",
    "help",
]


def _get_config_dir() -> Path:
    """Get path to main config directory."""
    return get_package_root() / "data"


def check_file_exists(check: dict[str, Any]) -> dict[str, Any]:
    """Check if a file exists.

    Args:
        check: Check definition with 'path' and optional 'skip_if_missing'.

    Returns:
        Result dict with passed, name, type, path, and message/error.
    """
    path = check.get("path", "")
    skip_if_missing = check.get("skip_if_missing", False)

    if not path.startswith("/"):
        path = str(_get_config_dir().parent / path)

    result: dict[str, Any] = {
        "name": check.get("name", "file_exists"),
        "type": "file_exists",
        "path": path,
    }

    file_path = Path(path)
    if file_path.exists():
        result["passed"] = True
        result["message"] = f"File exists: {path}"
    elif skip_if_missing:
        result["passed"] = True
        result["skipped"] = True
        result["message"] = f"File not found (skipped): {path}"
    else:
        result["passed"] = False
        result["error"] = f"File not found: {path}"

    return result


def check_json_valid(check: dict[str, Any]) -> dict[str, Any]:
    """Check if a file contains valid JSON.

    Args:
        check: Check definition with 'path'.

    Returns:
        Result dict with passed, name, type, path, and message/error.
    """
    path = check.get("path", "")

    if not path.startswith("/"):
        path = str(_get_config_dir().parent / path)

    result: dict[str, Any] = {
        "name": check.get("name", "json_valid"),
        "type": "json_valid",
        "path": path,
    }

    file_path = Path(path)
    if not file_path.exists():
        result["passed"] = False
        result["error"] = f"File not found: {path}"
        return result

    try:
        with open(file_path) as f:
            json.load(f)
        result["passed"] = True
        result["message"] = f"Valid JSON: {path}"
    except json.JSONDecodeError as e:
        result["passed"] = False
        result["error"] = f"Invalid JSON: {e.msg} at line {e.lineno}"

    return result


def check_schema_valid(check: dict[str, Any]) -> dict[str, Any]:
    """Check if a file validates against a JSON schema.

    Args:
        check: Check definition with 'path' and 'schema_ref'.

    Returns:
        Result dict with passed, name, type, path, schema_ref, and message/error.
    """
    path = check.get("path", "")
    schema_ref = check.get("schema_ref", "")

    result: dict[str, Any] = {
        "name": check.get("name", "schema_valid"),
        "type": "schema_valid",
        "path": path,
        "schema_ref": schema_ref,
    }

    if not path.startswith("/"):
        path = str(_get_config_dir().parent / path)
    if not schema_ref.startswith("/"):
        schema_ref = str(_get_config_dir().parent / schema_ref)

    file_path = Path(path)
    schema_path = Path(schema_ref)

    if not file_path.exists():
        result["passed"] = False
        result["error"] = f"File not found: {path}"
        return result

    if not schema_path.exists():
        result["passed"] = False
        result["error"] = f"Schema not found: {schema_ref}"
        return result

    try:
        import jsonschema

        with open(file_path) as f:
            data = json.load(f)
        with open(schema_path) as f:
            schema = json.load(f)

        jsonschema.validate(data, schema)
        result["passed"] = True
        result["message"] = "Valid against schema"
    except ImportError:
        result["passed"] = True
        result["skipped"] = True
        result["message"] = "jsonschema not installed, skipping validation"
    except Exception as e:
        result["passed"] = False
        result["error"] = f"Validation failed: {e}"

    return result


def check_config_key(check: dict[str, Any]) -> dict[str, Any]:
    """Check if a config key exists and has expected type.

    Args:
        check: Check definition with 'config_key' and optional 'expected_type'.

    Returns:
        Result dict with passed, name, type, config_key, and message/error.
    """
    config_key = check.get("config_key", "")
    expected_type = check.get("expected_type")

    result: dict[str, Any] = {
        "name": check.get("name", "config_key_exists"),
        "type": "config_key_exists",
        "config_key": config_key,
    }

    try:

        config = load_config()

        value = config
        for key in config_key.split("."):
            if isinstance(value, dict) and key in value:
                value = value[key]
            else:
                result["passed"] = False
                result["error"] = f"Config key not found: {config_key}"
                return result

        result["passed"] = True
        result["message"] = f"Config key exists: {config_key}"

        if expected_type:
            expected = TYPE_MAP.get(expected_type)
            if expected and not isinstance(value, expected):
                result["passed"] = False
                result["error"] = f"Expected {expected_type}, got {type(value).__name__}"

    except Exception as e:
        result["passed"] = False
        result["error"] = f"Config check failed: {e}"

    return result


def check_module_imports(check: dict[str, Any]) -> dict[str, Any]:
    """Check if a Python module can be imported.

    Args:
        check: Check definition with 'module'.

    Returns:
        Result dict with passed, name, type, module, and message/error.
    """
    module_name = check.get("module", "")

    result: dict[str, Any] = {
        "name": check.get("name", "module_imports"),
        "type": "module_imports",
        "module": module_name,
    }

    try:
        importlib.import_module(module_name)
        result["passed"] = True
        result["message"] = f"Module imports: {module_name}"
    except ImportError as e:
        result["passed"] = False
        result["error"] = f"Import failed: {e}"

    return result


def run_custom_validator(check: dict[str, Any]) -> dict[str, Any]:
    """Run a custom validation function.

    Args:
        check: Check definition with 'custom_validator' (module.function path).

    Returns:
        Result dict with passed, name, type, validator, and message/error.
    """
    validator_path = check.get("custom_validator", "")

    result: dict[str, Any] = {
        "name": check.get("name", "custom"),
        "type": "custom",
        "validator": validator_path,
    }

    if "." not in validator_path:
        result["passed"] = False
        result["error"] = "Invalid validator path (must be module.function)"
        return result

    module_path, func_name = validator_path.rsplit(".", 1)

    try:
        module = importlib.import_module(module_path)
        validator_func = getattr(module, func_name)
        validation_result = validator_func(check)

        if isinstance(validation_result, dict):
            result.update(validation_result)
        elif isinstance(validation_result, bool):
            result["passed"] = validation_result
        else:
            result["passed"] = bool(validation_result)

    except ImportError as e:
        result["passed"] = False
        result["error"] = f"Could not import validator module: {e}"
    except AttributeError:
        result["passed"] = False
        result["error"] = f"Function {func_name} not found in {module_path}"
    except Exception as e:
        result["passed"] = False
        result["error"] = f"Validator error: {e}"

    return result


def help() -> str:
    """Display module usage information.

    Returns:
        str: Help text with check implementations.
    """
    return """
databricks_api_workspace.core.validation_utils.checks
============================================================

Validation check implementations.

Check Functions:
---------------
  check_file_exists(check) -> dict
      Check if file exists at path.
      Options: path, skip_if_missing

  check_json_valid(check) -> dict
      Check if file contains valid JSON.
      Options: path

  check_schema_valid(check) -> dict
      Validate file against JSON Schema.
      Options: path, schema_ref

  check_config_key(check) -> dict
      Check config key exists with expected type.
      Options: config_key, expected_type

  check_module_imports(check) -> dict
      Check Python module can be imported.
      Options: module

  run_custom_validator(check) -> dict
      Run custom validation function.
      Options: custom_validator (module.function)

Check Definition Format:
-----------------------
  {
    "type": "file_exists",
    "name": "check_name",
    "path": "path/to/file",
    "skip_if_missing": false
  }

Return Format:
-------------
  {
    "name": "check_name",
    "type": "check_type",
    "passed": true/false,
    "message": "success message",  # if passed
    "error": "error message"       # if failed
  }
"""
