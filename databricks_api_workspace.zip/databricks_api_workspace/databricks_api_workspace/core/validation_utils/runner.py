# Databricks notebook source
# MAGIC %md
# MAGIC # runner
# MAGIC
# MAGIC **Auto-generated from:** `runner.py`
# MAGIC **Build timestamp:** 2025-12-22T22:33:16.583003+00:00
# MAGIC **Content hash:** e0e114ad67da
# MAGIC
# MAGIC > Do not edit directly. Make changes in source and rebuild.

# COMMAND ----------

# MAGIC %run ../../core/runtime/_init
# MAGIC %run ../../core/validation_utils/checks

# COMMAND ----------

"""
databricks_api_workspace.core.validation_utils.runner - Validation runner.

Execute validation checks defined in JSON config files.

Functions:
    load_validation_config(): Load validation config
    run_validation(): Run named validation suite
    run_all_validations(): Run all validation suites
    help(): Display module usage information
"""

from __future__ import annotations

import json
from pathlib import Path
from typing import Any


__all__ = [
    "load_validation_config",
    "run_validation",
    "run_all_validations",
    "help",
]


def _get_validation_dir() -> Path:
    """Get path to validation config directory."""
    return get_config_dir() / "validation"


def load_validation_config(validation_name: str) -> dict[str, Any] | None:
    """Load a validation config file by name.

    Args:
        validation_name: Name of validation (without .json extension).

    Returns:
        Parsed validation config or None if not found.

    Example:
        >>> config = load_validation_config("config")
        >>> print(config["name"])
    """
    validation_dir = _get_validation_dir()
    config_path = validation_dir / f"{validation_name}.json"

    if not config_path.exists():
        return None

    try:
        with open(config_path) as f:
            return json.load(f)
    except Exception:
        return None


def run_validation(validation_name: str) -> dict[str, Any]:
    """Run a named validation suite.

    Args:
        validation_name: Name of validation config file (without .json).

    Returns:
        dict: Result with name, description, success, checks.

    Example:
        >>> result = run_validation("config")
        >>> print(result["success"])
    """
    config = load_validation_config(validation_name)

    if config is None:
        return {
            "name": validation_name,
            "description": "Unknown validation",
            "success": False,
            "error": f"Validation config not found: {validation_name}.json",
            "checks": [],
        }

    results: dict[str, Any] = {
        "name": config["name"],
        "description": config.get("description", ""),
        "success": True,
        "checks": [],
    }

    for check in config.get("checks", []):
        check_result = _run_check(check)
        results["checks"].append(check_result)
        if not check_result["passed"]:
            results["success"] = False

    return results


def run_all_validations() -> dict[str, Any]:
    """Run all validation configs in the validation directory.

    Returns:
        dict: Result with success bool and suites list.

    Example:
        >>> results = run_all_validations()
        >>> for suite in results["suites"]:
        ...     print(f"{suite['name']}: {suite['success']}")
    """
    validation_dir = _get_validation_dir()

    if not validation_dir.exists():
        return {
            "success": False,
            "error": "Validation directory not found",
            "suites": [],
        }

    results: dict[str, Any] = {
        "success": True,
        "suites": [],
    }

    # Find all .json files except _schema.json
    for config_file in sorted(validation_dir.glob("*.json")):
        if config_file.name.startswith("_"):
            continue

        validation_name = config_file.stem
        suite_result = run_validation(validation_name)
        results["suites"].append(suite_result)

        if not suite_result["success"]:
            results["success"] = False

    return results


def _run_check(check: dict[str, Any]) -> dict[str, Any]:
    """Execute a single validation check.

    Args:
        check: Check definition from config.

    Returns:
        Check result with passed, name, type, and optional message/error.
    """
    check_type = check.get("type", "unknown")
    check_name = check.get("name", "unnamed")

    result: dict[str, Any] = {
        "name": check_name,
        "type": check_type,
        "passed": False,
    }

    try:
        if check_type == "file_exists":
            result = check_file_exists(check)
        elif check_type == "json_valid":
            result = check_json_valid(check)
        elif check_type == "schema_valid":
            result = check_schema_valid(check)
        elif check_type == "config_key_exists":
            result = check_config_key(check)
        elif check_type == "module_imports":
            result = check_module_imports(check)
        elif check_type == "custom":
            result = run_custom_validator(check)
        else:
            result["error"] = f"Unknown check type: {check_type}"

    except Exception as e:
        result["error"] = str(e)
        result["passed"] = False

    return result


def help() -> str:
    """Display module usage information.

    Returns:
        str: Help text with runner usage.
    """
    return """
databricks_api_workspace.core.validation_utils.runner
============================================================

Data-driven validation runner.

Functions:
---------
  load_validation_config(name) -> dict | None
      Load validation config by name.

  run_validation(name) -> dict
      Run a single validation suite.

  run_all_validations() -> dict
      Run all validation suites.

Check Types:
-----------
  file_exists     - Check file exists
  json_valid      - Check valid JSON
  schema_valid    - Check against JSON Schema
  config_key_exists - Check config key exists
  module_imports  - Check module imports
  custom          - Run custom validator function

Config Format:
-------------
  {
    "name": "suite_name",
    "description": "Suite description",
    "checks": [
      {"type": "file_exists", "name": "check_name", "path": "path/to/file"},
      {"type": "json_valid", "path": "config/file.json"},
      {"type": "module_imports", "module": "databricks_api_workspace.core"}
    ]
  }

Usage:
-----
  from databricks_api_workspace.core.validation_utils import (
      run_validation,
      run_all_validations,
  )

  # Run single suite
  result = run_validation("config")
  if not result["success"]:
      for check in result["checks"]:
          if not check["passed"]:
              print(f"FAIL: {check['name']}: {check.get('error')}")

  # Run all suites
  results = run_all_validations()
  print(f"Overall: {'PASS' if results['success'] else 'FAIL'}")
"""
