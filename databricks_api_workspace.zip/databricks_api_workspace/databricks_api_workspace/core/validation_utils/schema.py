# Databricks notebook source
# MAGIC %md
# MAGIC # schema
# MAGIC
# MAGIC **Auto-generated from:** `schema.py`
# MAGIC **Build timestamp:** 2025-12-22T22:33:16.584685+00:00
# MAGIC **Content hash:** 1da3bfc80a39
# MAGIC
# MAGIC > Do not edit directly. Make changes in source and rebuild.

# COMMAND ----------

# MAGIC %run ../../core/validation_utils/_settings
# MAGIC %run ../../core/config/_init

# COMMAND ----------

"""
databricks_api_workspace.core.validation_utils.schema - JSON Schema validation.

Generic schema loading and validation utilities.

Classes:
    ValidationError: Raised when validation fails

Functions:
    load_schema(): Load JSON schema from path
    validate_against_schema(): Validate data against schema
    clear_schema_cache(): Clear schema cache
    help(): Display module usage information
"""

from __future__ import annotations

import json
from pathlib import Path
from typing import Any


__all__ = [
    "ValidationError",
    "load_schema",
    "validate_against_schema",
    "clear_schema_cache",
    "validate_request",
    "validate_response",
    "help",
]

# Schema cache
_schema_cache: dict[str, dict[str, Any]] = {}


class ValidationError(Exception):
    """Raised when validation fails.

    Attributes:
        message: Error message.
        errors: List of specific validation errors.
    """

    def __init__(self, message: str, errors: list[str] | None = None) -> None:
        self.message = message
        self.errors = errors or []
        super().__init__(message)


def load_schema(
    schema_path: str | Path,
    use_cache: bool = True,
) -> dict[str, Any]:
    """Load a JSON schema from file path.

    Args:
        schema_path: Path to schema file.
        use_cache: Whether to use cached schema.

    Returns:
        dict: Schema dictionary.

    Raises:
        FileNotFoundError: If schema file doesn't exist.
        json.JSONDecodeError: If schema is invalid JSON.

    Example:
        >>> schema = load_schema("/path/to/schema.json")
    """
    cache_key = str(schema_path)

    if use_cache and cache_key in _schema_cache:
        return _schema_cache[cache_key]

    path = Path(schema_path)
    with open(path) as f:
        schema = json.load(f)

    if use_cache:
        _schema_cache[cache_key] = schema

    return schema


def validate_against_schema(
    instance: Any,
    schema: dict[str, Any],
    context: str = "data",
) -> list[str]:
    """Validate instance against JSON Schema.

    Uses jsonschema library if available, otherwise basic validation.

    Args:
        instance: Data to validate.
        schema: JSON Schema.
        context: Context for error messages.

    Returns:
        list[str]: Validation error messages (empty if valid).

    Example:
        >>> errors = validate_against_schema({"name": "test"}, schema)
        >>> if errors:
        ...     raise ValidationError("Invalid", errors=errors)
    """
    try:
        import jsonschema

        validator = jsonschema.Draft7Validator(schema)
        errors = []
        for error in validator.iter_errors(instance):
            path = ".".join(str(p) for p in error.path) or context
            errors.append(f"{path}: {error.message}")
        return errors
    except ImportError:  # pragma: no cover
        # Fallback: basic type checking
        return _basic_validate(instance, schema, context)


def _basic_validate(
    instance: Any,
    schema: dict[str, Any],
    path: str = "root",
) -> list[str]:
    """Basic validation without jsonschema library.

    Checks type, required properties, and enum values.

    Args:
        instance: Data to validate.
        schema: JSON Schema.
        path: Current path for error messages.

    Returns:
        list[str]: Validation error messages.
    """
    errors: list[str] = []

    # Type checking
    schema_type = schema.get("type")
    if schema_type:
        expected_type = TYPE_MAP.get(schema_type)
        if expected_type and not isinstance(instance, expected_type):
            errors.append(f"{path}: expected {schema_type}, got {type(instance).__name__}")
            return errors

    # Required properties (for objects)
    if schema_type == "object" and isinstance(instance, dict):
        required = schema.get("required", [])
        for prop in required:
            if prop not in instance:
                errors.append(f"{path}: missing required property '{prop}'")

        # Validate properties
        properties = schema.get("properties", {})
        for prop, prop_schema in properties.items():
            if prop in instance:
                errors.extend(_basic_validate(instance[prop], prop_schema, f"{path}.{prop}"))

    # Enum checking
    enum_values = schema.get("enum")
    if enum_values is not None and instance not in enum_values:
        errors.append(f"{path}: value must be one of {enum_values}")

    return errors


def clear_schema_cache() -> None:
    """Clear the schema cache.

    Example:
        >>> clear_schema_cache()
        >>> schema = load_schema("my_schema.json")  # Reloads from disk
    """
    _schema_cache.clear()


def validate_request(operation: str, params: dict[str, Any]) -> None:
    """Validate request params against operation's request schema.

    Args:
        operation: Operation name.
        params: Request parameters.

    Raises:
        ValidationError: If validation fails.

    Example:
        >>> validate_request("get_customer", {"customer_id": "123"})
    """

    op_config = get_operation_config(operation)
    schema_ref = op_config.get("request_schema")

    if not schema_ref:
        return  # No schema defined, skip validation

    # Get schema path from package config
    schema_path = get_schema_path(schema_ref)
    schema = load_schema(schema_path)

    # Wrap params in envelope if schema expects it
    instance = params
    if schema.get("properties", {}).get("data"):
        instance = {"data": params}

    errors = validate_against_schema(instance, schema, "request")
    if errors:
        raise ValidationError(
            f"Request validation failed for '{operation}'",
            errors=errors,
        )


def validate_response(operation: str, envelope: dict[str, Any]) -> None:
    """Validate response envelope against operation's response schema.

    Args:
        operation: Operation name.
        envelope: Response envelope.

    Raises:
        ValidationError: If validation fails.

    Example:
        >>> validate_response("get_customer", response_envelope)
    """

    op_config = get_operation_config(operation)
    schema_ref = op_config.get("response_schema")

    if not schema_ref:
        return  # No schema defined, skip validation

    # Get schema path from package config
    schema_path = get_schema_path(schema_ref)
    schema = load_schema(schema_path)
    errors = validate_against_schema(envelope, schema, "response")
    if errors:
        raise ValidationError(
            f"Response validation failed for '{operation}'",
            errors=errors,
        )


def help() -> str:
    """Display module usage information.

    Returns:
        str: Help text with schema validation usage.
    """
    return """
databricks_api_workspace.core.validation_utils.schema
============================================================

Generic JSON Schema validation utilities.

Classes:
-------
  ValidationError(message, errors)
      Raised when validation fails.
      errors: list[str] of specific issues.

Functions:
---------
  load_schema(schema_path, use_cache=True) -> dict
      Load JSON schema from file path.

  validate_against_schema(instance, schema, context="data") -> list[str]
      Validate data against schema. Returns list of errors.

  clear_schema_cache() -> None
      Clear the cached schemas.

Usage:
-----
  from databricks_api_workspace.core.validation_utils import (
      load_schema,
      validate_against_schema,
      ValidationError,
  )

  schema = load_schema("/path/to/schema.json")
  errors = validate_against_schema(data, schema)
  if errors:
      raise ValidationError("Validation failed", errors=errors)

Dependencies:
------------
  - jsonschema (optional): Full JSON Schema validation
  - Without jsonschema: Basic type/required/enum checking
"""
