# Databricks notebook source
# MAGIC %md
# MAGIC # __init__
# MAGIC
# MAGIC **Auto-generated from:** `__init__.py`
# MAGIC **Build timestamp:** 2025-12-22T22:33:16.587089+00:00
# MAGIC **Content hash:** e8bcfe904c29
# MAGIC
# MAGIC > Do not edit directly. Make changes in source and rebuild.

# COMMAND ----------

# MAGIC %run ../../core/validation_utils/_settings
# MAGIC %run ../../core/validation_utils/checks
# MAGIC %run ../../core/validation_utils/runner
# MAGIC %run ../../core/validation_utils/schema

# COMMAND ----------

"""
databricks_api_workspace.core.validation_utils - Validation utilities.

Schema loading, validation, and data-driven validation runner.

Classes:
    ValidationError: Raised when validation fails

Functions:
    load_schema(): Load JSON schema from file
    validate_against_schema(): Validate data against schema
    clear_schema_cache(): Clear schema cache
    load_validation_config(): Load validation config
    run_validation(): Run named validation suite
    run_all_validations(): Run all validation suites
    check_file_exists(): Check if file exists
    check_json_valid(): Check if file contains valid JSON
    check_schema_valid(): Validate file against schema
    check_config_key(): Check config key exists
    check_module_imports(): Check module can be imported
    run_custom_validator(): Run custom validation function
    help(): Display module usage information

Usage:
    >>> from databricks_api_workspace.core.validation_utils import (
    ...     load_schema,
    ...     validate_against_schema,
    ...     ValidationError,
    ... )
"""

from __future__ import annotations


__all__ = [
    # Schema validation
    "ValidationError",
    "load_schema",
    "validate_against_schema",
    "clear_schema_cache",
    "validate_request",
    "validate_response",
    # Validation runner
    "load_validation_config",
    "run_validation",
    "run_all_validations",
    # Check implementations
    "check_file_exists",
    "check_json_valid",
    "check_schema_valid",
    "check_config_key",
    "check_module_imports",
    "run_custom_validator",
    # Constants
    "TYPE_MAP",
    "REQUIRED_META_FIELDS",
    "VALID_STATUSES",
    "REQUIRED_ERROR_FIELDS",
    # Help
    "help",
]


def help() -> str:
    """Display module usage information.

    Returns:
        str: Help text with validation_utils usage.
    """
    return """
databricks_api_workspace.core.validation_utils
==================================================

Schema loading, validation, and data-driven validation runner.

Classes:
-------
  ValidationError(message, errors)
      Raised when validation fails.
      errors: list[str] of specific issues.

Schema Functions:
----------------
  load_schema(schema_path, use_cache=True) -> dict
      Load JSON schema from file path.

  validate_against_schema(instance, schema, context="data") -> list[str]
      Validate data against schema. Returns list of errors.

  clear_schema_cache() -> None
      Clear the cached schemas.

Validation Runner:
-----------------
  load_validation_config(name) -> dict | None
      Load validation config by name.

  run_validation(name) -> dict
      Run a single validation suite.

  run_all_validations() -> dict
      Run all validation suites.

Check Implementations:
--------------------
  check_file_exists(check) -> dict
  check_json_valid(check) -> dict
  check_schema_valid(check) -> dict
  check_config_key(check) -> dict
  check_module_imports(check) -> dict
  run_custom_validator(check) -> dict

Constants:
---------
  TYPE_MAP - JSON Schema type to Python type mapping
  REQUIRED_META_FIELDS - Required response meta fields
  VALID_STATUSES - Valid status values
  REQUIRED_ERROR_FIELDS - Required error object fields

Usage:
-----
  from databricks_api_workspace.core.validation_utils import (
      load_schema,
      validate_against_schema,
      ValidationError,
      run_validation,
  )

  # Schema validation
  schema = load_schema("/path/to/schema.json")
  errors = validate_against_schema(data, schema)
  if errors:
      raise ValidationError("Validation failed", errors=errors)

  # Run validation suite
  result = run_validation("config")
  if not result["success"]:
      for check in result["checks"]:
          if not check["passed"]:
              print(f"FAIL: {check['name']}")
"""
