# Databricks notebook source
# MAGIC %md
# MAGIC # _settings
# MAGIC
# MAGIC **Auto-generated from:** `_settings.py`
# MAGIC **Build timestamp:** 2025-12-22T22:33:16.585893+00:00
# MAGIC **Content hash:** 2be5fe35a741
# MAGIC
# MAGIC > Do not edit directly. Make changes in source and rebuild.

# COMMAND ----------

"""
databricks_api_workspace.core.validation_utils.settings - Validation constants.

Single source of truth for validation-related constants.

Constants:
    TYPE_MAP: Python type mapping for JSON Schema types
    REQUIRED_META_FIELDS: Required fields in response meta
    VALID_STATUSES: Valid status values for responses
    REQUIRED_ERROR_FIELDS: Required fields in error object
"""

from __future__ import annotations

__all__ = [
    "TYPE_MAP",
    "REQUIRED_META_FIELDS",
    "VALID_STATUSES",
    "REQUIRED_ERROR_FIELDS",
]

# JSON Schema type to Python type mapping
TYPE_MAP: dict[str, type | tuple[type, ...]] = {
    "string": str,
    "integer": int,
    "number": (int, float),
    "boolean": bool,
    "array": list,
    "object": dict,
    "null": type(None),
}

# Required fields in response meta
REQUIRED_META_FIELDS: frozenset[str] = frozenset(
    {
        "execution_id",
        "status",
        "operation",
        "timestamp_utc",
    }
)

# Valid status values
VALID_STATUSES: frozenset[str] = frozenset({"success", "error"})

# Required fields in error object
REQUIRED_ERROR_FIELDS: frozenset[str] = frozenset(
    {
        "error_code",
        "message",
    }
)
