# Databricks notebook source
# MAGIC %md
# MAGIC # telemetry
# MAGIC
# MAGIC **Auto-generated from:** `telemetry.py`
# MAGIC **Build timestamp:** 2025-12-22T22:33:16.562056+00:00
# MAGIC **Content hash:** 34e8596b57a4
# MAGIC
# MAGIC > Do not edit directly. Make changes in source and rebuild.

# COMMAND ----------

# MAGIC %run ../../core/logging/_settings
# MAGIC %run ../../core/logging/core
# MAGIC %run ../../core/config/_init
# MAGIC %run ../../core/runtime/_init
# MAGIC %run ../../core/sql_utils/_init

# COMMAND ----------

"""
databricks_api_workspace.core.logging.telemetry - Telemetry utilities.

Write and query execution telemetry to Delta tables.

Functions:
    write_telemetry(): Write execution record
    query_telemetry(): Query telemetry records
    get_operation_stats(): Get operation statistics
    help(): Display module usage information
"""

from __future__ import annotations

import json
from datetime import datetime, timezone
from typing import TYPE_CHECKING, Any


if TYPE_CHECKING:
    pass

__all__ = [
    "write_telemetry",
    "query_telemetry",
    "get_operation_stats",
    "help",
]


def _redact_sensitive(params: dict[str, Any]) -> str:
    """Redact sensitive fields from params for logging.

    Args:
        params: Original parameters.

    Returns:
        JSON string with sensitive fields redacted.
    """

    def redact(obj: Any) -> Any:
        if isinstance(obj, dict):
            return {
                k: "[REDACTED]" if k.lower() in SENSITIVE_KEYS else redact(v)
                for k, v in obj.items()
            }
        elif isinstance(obj, list):
            return [redact(item) for item in obj]
        return obj

    redacted = redact(params)
    return json.dumps(redacted, default=str)


def write_telemetry(
    operation: str,
    params: dict[str, Any],
    envelope: dict[str, Any],
    extra_fields: dict[str, Any] | None = None,
) -> bool:
    """Write execution telemetry to Delta table.

    Telemetry is written asynchronously (best-effort).
    Failures are logged but don't raise exceptions.

    Args:
        operation: Operation name.
        params: Request parameters (sensitive fields redacted).
        envelope: Response envelope.
        extra_fields: Additional fields to include.

    Returns:
        bool: True if write succeeded, False otherwise.

    Example:
        >>> write_telemetry(
        ...     operation="get_customer",
        ...     params={"customer_id": "123"},
        ...     envelope=response_envelope,
        ... )
    """
    # Lazy imports to avoid circular dependencies

    # Check if telemetry is enabled
    if not get_config_value("telemetry.enabled", False):
        return False

    table = get_config_value("telemetry.table", "databricks_api_workspace.telemetry")

    try:
        meta = envelope.get("meta", {})
        error_info = envelope.get("error")

        record = {
            "execution_id": meta.get("execution_id", ""),
            "operation": operation,
            "status": meta.get("status", "unknown"),
            "duration_ms": meta.get("duration_ms", 0),
            "timestamp_utc": meta.get("timestamp_utc", datetime.now(timezone.utc).isoformat()),
            "correlation_id": meta.get("correlation_id"),
            "params_json": _redact_sensitive(params),
            "error_code": error_info.get("error_code") if error_info else None,
            "error_message": error_info.get("message") if error_info else None,
        }

        # Add extra fields
        if extra_fields:
            record.update(extra_fields)

        # Write to Delta
        spark = get_spark()
        from mocks.spark_mock import Row

        df = spark.createDataFrame([Row(**record)])
        df.write.format("delta").mode("append").saveAsTable(table)

        log_info(
            "Telemetry written",
            execution_id=record["execution_id"],
            operation=operation,
        )
        return True

    except Exception as e:  # pragma: no cover
        log_error(
            "Failed to write telemetry",
            error=str(e),
            operation=operation,
        )
        return False


def query_telemetry(
    operation: str | None = None,
    status: str | None = None,
    start_date: str | None = None,
    end_date: str | None = None,
    limit: int = 100,
) -> Any:
    """Query telemetry records.

    Args:
        operation: Filter by operation name.
        status: Filter by status ('success' or 'error').
        start_date: Filter by start date (ISO format).
        end_date: Filter by end date (ISO format).
        limit: Maximum records to return.

    Returns:
        Spark DataFrame with telemetry records.

    Example:
        >>> df = query_telemetry(operation="get_customer", status="error")
        >>> df.show()
    """
    # Lazy imports

    table = safe_sql_identifier(
        get_config_value("telemetry.table", "databricks_api_workspace.telemetry")
    )
    spark = get_spark()

    # Build query with escaped parameters
    conditions = []
    if operation:
        conditions.append(f"operation = '{escape_sql_string(operation)}'")
    if status:
        conditions.append(f"status = '{escape_sql_string(status)}'")
    if start_date:
        conditions.append(f"timestamp_utc >= '{escape_sql_string(start_date)}'")
    if end_date:
        conditions.append(f"timestamp_utc <= '{escape_sql_string(end_date)}'")

    where_clause = f"WHERE {' AND '.join(conditions)}" if conditions else ""

    query = f"""
        SELECT *
        FROM {table}
        {where_clause}
        ORDER BY timestamp_utc DESC
        LIMIT {limit}
    """

    return spark.sql(query)


def get_operation_stats(
    operation: str,
    days: int = 7,
) -> dict[str, Any]:
    """Get operation statistics.

    Computes aggregates for the specified operation over recent days.

    Args:
        operation: Operation name.
        days: Number of days to analyze.

    Returns:
        dict: Statistics with counts, avg duration, error rate.

    Example:
        >>> stats = get_operation_stats("get_customer", days=7)
        >>> print(f"Error rate: {stats['error_rate']}%")
    """
    # Lazy imports

    table = safe_sql_identifier(
        get_config_value("telemetry.table", "databricks_api_workspace.telemetry")
    )
    spark = get_spark()
    safe_operation = escape_sql_string(operation)

    query = f"""
        SELECT
            COUNT(*) as total_calls,
            SUM(CASE WHEN status = 'success' THEN 1 ELSE 0 END) as success_count,
            SUM(CASE WHEN status = 'error' THEN 1 ELSE 0 END) as error_count,
            AVG(duration_ms) as avg_duration_ms,
            MAX(duration_ms) as max_duration_ms,
            MIN(duration_ms) as min_duration_ms
        FROM {table}
        WHERE operation = '{safe_operation}'
        AND timestamp_utc >= date_sub(current_date(), {int(days)})
    """

    result = spark.sql(query).first()
    if result is None:
        return {
            "operation": operation,
            "total_calls": 0,
            "success_count": 0,
            "error_count": 0,
            "error_rate": 0.0,
            "avg_duration_ms": 0,
            "max_duration_ms": 0,
            "min_duration_ms": 0,
        }

    # Requires actual Spark result with data  # pragma: no cover
    total = result.total_calls or 0
    errors = result.error_count or 0
    error_rate = (errors / total * 100) if total > 0 else 0.0

    return {
        "operation": operation,
        "total_calls": total,
        "success_count": result.success_count or 0,
        "error_count": errors,
        "error_rate": round(error_rate, 2),
        "avg_duration_ms": round(result.avg_duration_ms or 0, 2),
        "max_duration_ms": result.max_duration_ms or 0,
        "min_duration_ms": result.min_duration_ms or 0,
    }


def help() -> str:
    """Display module usage information.

    Returns:
        str: Help text with telemetry usage.
    """
    return """
databricks_api_workspace.core.logging.telemetry
=================================================

Execution telemetry to Delta tables.

Functions:
---------
  write_telemetry(operation, params, envelope, extra_fields=None) -> bool
      Write execution record to Delta table.

  query_telemetry(operation=None, status=None, ...) -> DataFrame
      Query telemetry records with filters.

  get_operation_stats(operation, days=7) -> dict
      Get aggregated statistics for operation.

Configuration:
-------------
  telemetry.enabled - Enable/disable telemetry (default: False)
  telemetry.table   - Delta table name (default: databricks_api_workspace.telemetry)

Usage:
-----
  from databricks_api_workspace.core.logging import (
      write_telemetry,
      query_telemetry,
      get_operation_stats,
  )

  # Write telemetry after operation
  write_telemetry(
      operation="get_customer",
      params={"customer_id": "123"},
      envelope=response_envelope,
  )

  # Query recent errors
  df = query_telemetry(operation="get_customer", status="error")
  df.show()

  # Get statistics
  stats = get_operation_stats("get_customer", days=7)
  print(f"Error rate: {stats['error_rate']}%")
  print(f"Avg duration: {stats['avg_duration_ms']}ms")

Security:
--------
  - Sensitive fields (password, token, etc.) are automatically redacted
  - Params are stored as JSON string with redactions
"""
