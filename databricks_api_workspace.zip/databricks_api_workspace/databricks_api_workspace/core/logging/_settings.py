# Databricks notebook source
# MAGIC %md
# MAGIC # _settings
# MAGIC
# MAGIC **Auto-generated from:** `_settings.py`
# MAGIC **Build timestamp:** 2025-12-22T22:33:16.564753+00:00
# MAGIC **Content hash:** c1982eaefd07
# MAGIC
# MAGIC > Do not edit directly. Make changes in source and rebuild.

# COMMAND ----------

"""
databricks_api_workspace.core.logging.settings - Logging module configuration.

Single source of truth for logging constants and defaults.

Constants:
    DEFAULT_LOG_LEVEL: Default log level from env or INFO
    LOG_SOURCE: Source identifier for log entries
    SENSITIVE_KEYS: Keys to redact in telemetry
    LOG_LEVEL_ENV_VAR: Environment variable for log level
"""

from __future__ import annotations

import os

__all__ = [
    "DEFAULT_LOG_LEVEL",
    "LOG_SOURCE",
    "SENSITIVE_KEYS",
    "LOG_LEVEL_ENV_VAR",
]

# Environment variable for log level
LOG_LEVEL_ENV_VAR: str = "LOG_LEVEL"

# Default log level (from env or INFO)
DEFAULT_LOG_LEVEL: str = os.getenv(LOG_LEVEL_ENV_VAR, "INFO").upper()

# Source identifier for log entries
LOG_SOURCE: str = "databricks_api_workspace"

# Sensitive keys to redact in telemetry (verified 2025-12-15)
SENSITIVE_KEYS: frozenset[str] = frozenset(
    {
        "password",
        "secret",
        "token",
        "api_key",
        "apikey",
        "credential",
        "ssn",
        "social_security",
        "credit_card",
        "card_number",
    }
)
