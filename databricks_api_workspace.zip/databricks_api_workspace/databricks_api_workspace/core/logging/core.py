# Databricks notebook source
# MAGIC %md
# MAGIC # core
# MAGIC
# MAGIC **Auto-generated from:** `core.py`
# MAGIC **Build timestamp:** 2025-12-22T22:33:16.552615+00:00
# MAGIC **Content hash:** e5e2be6c0226
# MAGIC
# MAGIC > Do not edit directly. Make changes in source and rebuild.

# COMMAND ----------

# MAGIC %run ../../core/logging/_settings
# MAGIC %run ../../core/logging/context
# MAGIC %run ../../core/logging/levels

# COMMAND ----------

"""
databricks_api_workspace.core.logging.core - Core logging functions.

Structured JSON logging with level filtering and context injection.

Functions:
    log_debug(), log_info(), log_warning(), log_error(), log_critical()
    log_exception(): Log with stack trace
    debug(), info(), warning(), error(): Convenience aliases
    help(): Display module usage information
"""

from __future__ import annotations

import json
import sys
import traceback
from datetime import datetime, timezone
from typing import Any


__all__ = [
    "log_debug",
    "log_info",
    "log_warning",
    "log_error",
    "log_critical",
    "log_exception",
    "debug",
    "info",
    "warning",
    "error",
    "help",
]


def _format_log_entry(
    level: str,
    message: str,
    extra: dict[str, Any] | None = None,
) -> str:
    """Format a structured log entry as JSON.

    Args:
        level: Log level (INFO, ERROR, etc.).
        message: Log message.
        extra: Additional fields to include.

    Returns:
        JSON-formatted log entry string.
    """
    entry = {
        "timestamp": datetime.now(timezone.utc).isoformat(),
        "level": level,
        "message": message,
        "source": LOG_SOURCE,
    }

    # Add context fields
    entry.update(get_log_context())

    # Add extra fields
    if extra:
        entry.update(extra)

    return json.dumps(entry, default=str)


def _emit_log(level: LogLevel, message: str, **extra: Any) -> None:
    """Emit a log entry.

    Args:
        level: Log level.
        message: Log message.
        **extra: Additional fields.
    """
    if not should_log(level):
        return

    log_line = _format_log_entry(level.name, message, extra if extra else None)

    # In Databricks, print goes to driver logs
    # Using stderr for consistency with logging module
    print(log_line, file=sys.stderr)


def log_debug(message: str, **extra: Any) -> None:
    """Log at DEBUG level.

    Args:
        message: Log message.
        **extra: Additional fields to include.

    Example:
        >>> log_debug("Variable state", x=123, y="abc")
    """
    _emit_log(LogLevel.DEBUG, message, **extra)


def log_info(message: str, **extra: Any) -> None:
    """Log at INFO level.

    Args:
        message: Log message.
        **extra: Additional fields to include.

    Example:
        >>> log_info("Config loaded", config_hash="abc123")
    """
    _emit_log(LogLevel.INFO, message, **extra)


def log_warning(message: str, **extra: Any) -> None:
    """Log at WARNING level.

    Args:
        message: Log message.
        **extra: Additional fields to include.

    Example:
        >>> log_warning("Deprecated API used", method="old_method")
    """
    _emit_log(LogLevel.WARNING, message, **extra)


def log_error(message: str, **extra: Any) -> None:
    """Log at ERROR level.

    Args:
        message: Log message.
        **extra: Additional fields to include.

    Example:
        >>> log_error("Query failed", error_code="SQL_ERROR", query="SELECT...")
    """
    _emit_log(LogLevel.ERROR, message, **extra)


def log_critical(message: str, **extra: Any) -> None:
    """Log at CRITICAL level.

    Args:
        message: Log message.
        **extra: Additional fields to include.

    Example:
        >>> log_critical("System shutdown required", reason="disk_full")
    """
    _emit_log(LogLevel.CRITICAL, message, **extra)


def log_exception(message: str, exc: Exception, **extra: Any) -> None:
    """Log an exception with stack trace.

    Logs at ERROR level with exception details.

    Args:
        message: Log message.
        exc: Exception to log.
        **extra: Additional fields to include.

    Example:
        >>> try:
        ...     risky_operation()
        ... except Exception as e:
        ...     log_exception("Operation failed", e, operation="risky")
    """
    extra["exception_type"] = type(exc).__name__
    extra["exception_message"] = str(exc)
    extra["stack_trace"] = traceback.format_exc()
    _emit_log(LogLevel.ERROR, message, **extra)


# Convenience aliases
def debug(msg: str, **kwargs: Any) -> None:
    """Log debug message (alias for log_debug).

    Args:
        msg: Log message.
        **kwargs: Additional context fields.
    """
    log_debug(msg, **kwargs)


def info(msg: str, **kwargs: Any) -> None:
    """Log info message (alias for log_info).

    Args:
        msg: Log message.
        **kwargs: Additional context fields.
    """
    log_info(msg, **kwargs)


def warning(msg: str, **kwargs: Any) -> None:
    """Log warning message (alias for log_warning).

    Args:
        msg: Log message.
        **kwargs: Additional context fields.
    """
    log_warning(msg, **kwargs)


def error(msg: str, **kwargs: Any) -> None:
    """Log error message (alias for log_error).

    Args:
        msg: Log message.
        **kwargs: Additional context fields.
    """
    log_error(msg, **kwargs)


def help() -> str:
    """Display module usage information.

    Returns:
        str: Help text with core logging usage.
    """
    return """
databricks_api_workspace.core.logging.core
=============================================

Core structured JSON logging functions.

Functions:
---------
  log_debug(message, **extra) -> None
  log_info(message, **extra) -> None
  log_warning(message, **extra) -> None
  log_error(message, **extra) -> None
  log_critical(message, **extra) -> None
  log_exception(message, exc, **extra) -> None

Aliases:
-------
  debug(), info(), warning(), error()

Log Entry Format:
----------------
  {
    "timestamp": "2024-01-01T12:00:00.000000+00:00",
    "level": "INFO",
    "message": "Your message",
    "source": "databricks_api_workspace",
    "correlation_id": "from-context",
    "your_extra_field": "value"
  }

Usage:
-----
  from databricks_api_workspace.core.logging import (
      log_info,
      log_error,
      log_exception,
  )

  # Basic logging
  log_info("Starting operation", operation="get_customer")

  # Error with context
  log_error("Query failed", error_code="SQL_ERROR", query=query[:100])

  # Exception with stack trace
  try:
      risky_operation()
  except Exception as e:
      log_exception("Operation failed", e, operation="risky")

Notes:
-----
  - Output goes to stderr (compatible with Databricks driver logs)
  - Messages filtered by current log level
  - Context from set_log_context() included automatically
"""
