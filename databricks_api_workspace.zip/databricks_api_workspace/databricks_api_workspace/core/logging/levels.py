# Databricks notebook source
# MAGIC %md
# MAGIC # levels
# MAGIC
# MAGIC **Auto-generated from:** `levels.py`
# MAGIC **Build timestamp:** 2025-12-22T22:33:16.557242+00:00
# MAGIC **Content hash:** eef5b294f7bf
# MAGIC
# MAGIC > Do not edit directly. Make changes in source and rebuild.

# COMMAND ----------

# MAGIC %run ../../core/logging/_settings

# COMMAND ----------

"""
databricks_api_workspace.core.logging.levels - Log level management.

Log level enumeration and level control functions.

Classes:
    LogLevel: Log level enumeration

Functions:
    get_log_level(): Get current level
    set_log_level(): Set global level
    set_min_log_level(): Backward-compatible alias
    should_log(): Check if level should be logged
    help(): Display module usage information
"""

from __future__ import annotations

from enum import IntEnum
from typing import Any


__all__ = [
    "LogLevel",
    "get_log_level",
    "set_log_level",
    "set_min_log_level",
    "should_log",
    "help",
]


class LogLevel(IntEnum):
    """Log level enumeration.

    Higher values are more severe. Messages are only logged
    if their level >= current level.

    Example:
        >>> LogLevel.DEBUG < LogLevel.INFO
        True
    """

    DEBUG = 0
    INFO = 1
    WARNING = 2
    ERROR = 3
    CRITICAL = 4


# Current log level (module-level state)
_current_level: LogLevel = LogLevel[DEFAULT_LOG_LEVEL]


def get_log_level() -> LogLevel:
    """Get current log level.

    Returns:
        LogLevel: Current log level.

    Example:
        >>> level = get_log_level()
        >>> print(level.name)
        INFO
    """
    return _current_level


def set_log_level(level: LogLevel | str) -> None:
    """Set global log level.

    Args:
        level: Log level (enum or string name).

    Example:
        >>> set_log_level(LogLevel.DEBUG)
        >>> set_log_level("WARNING")
    """
    global _current_level
    if isinstance(level, str):
        level = LogLevel[level.upper()]
    _current_level = level


def set_min_log_level(level: str) -> None:
    """Set minimum log level (backward-compatible alias).

    Args:
        level: Minimum level to log (DEBUG, INFO, WARNING, ERROR, CRITICAL).
    """
    set_log_level(level)


def should_log(level: LogLevel) -> bool:
    """Check if level should be logged based on current level.

    Args:
        level: Level to check.

    Returns:
        bool: True if level >= current level.
    """
    return level >= _current_level


class DebugContext:
    """Context manager for temporary debug logging.

    Temporarily enables DEBUG level logging within the context,
    then restores the previous level.

    Example:
        >>> with DebugContext():
        ...     some_function()  # Logs at DEBUG level
        >>> # Previous level restored
    """

    def __init__(self) -> None:
        """Initialize context manager."""
        self.previous_level = _current_level

    def __enter__(self) -> DebugContext:
        """Enter context - enable DEBUG level.

        Returns:
            Self for context manager protocol.
        """
        set_log_level(LogLevel.DEBUG)
        return self

    def __exit__(self, *args: Any) -> None:
        """Exit context - restore previous level.

        Args:
            *args: Exception info (ignored).
        """
        set_log_level(self.previous_level)


def help() -> str:
    """Display module usage information.

    Returns:
        str: Help text with level management usage.
    """
    return """
databricks_api_workspace.core.logging.levels
===============================================

Log level enumeration and management.

LogLevel Enum:
-------------
  DEBUG = 0     - Detailed debug information
  INFO = 1      - General information
  WARNING = 2   - Warning conditions
  ERROR = 3     - Error conditions
  CRITICAL = 4  - Critical conditions

Functions:
---------
  get_log_level() -> LogLevel
      Get current log level.

  set_log_level(level) -> None
      Set global log level (enum or string).

  set_min_log_level(level) -> None
      Backward-compatible alias for set_log_level.

  should_log(level) -> bool
      Check if level should be logged.

DebugContext:
------------
  Context manager for temporary DEBUG logging.

Usage:
-----
  from databricks_api_workspace.core.logging import (
      LogLevel,
      set_log_level,
      DebugContext,
  )

  # Set level
  set_log_level(LogLevel.WARNING)  # Only WARNING+ logged
  set_log_level("DEBUG")           # All levels logged

  # Temporary debug logging
  with DebugContext():
      # DEBUG level enabled here
      pass
  # Previous level restored

Environment:
-----------
  LOG_LEVEL env var sets initial level (default: INFO).
"""
