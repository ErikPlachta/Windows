# Databricks notebook source
# MAGIC %md
# MAGIC # context
# MAGIC
# MAGIC **Auto-generated from:** `context.py`
# MAGIC **Build timestamp:** 2025-12-22T22:33:16.547726+00:00
# MAGIC **Content hash:** 69213f68e926
# MAGIC
# MAGIC > Do not edit directly. Make changes in source and rebuild.

# COMMAND ----------

"""
databricks_api_workspace.core.logging.context - Log context management.

Manage request-scoped context that is included in all log entries.

Functions:
    set_log_context(): Set context values
    clear_log_context(): Clear all context
    get_log_context(): Get current context
    help(): Display module usage information
"""

from __future__ import annotations

from typing import Any

__all__ = [
    "set_log_context",
    "clear_log_context",
    "get_log_context",
    "help",
]

# Request-scoped context (simple dict for notebooks/scripts)
_context: dict[str, Any] = {}


def set_log_context(**kwargs: Any) -> None:
    """Set context values for all subsequent log messages.

    Context is included in every log entry until cleared.

    Common context fields:
    - correlation_id: Request correlation ID for tracing
    - user_id: User identifier
    - operation: Current operation name

    Args:
        **kwargs: Context key-value pairs.

    Example:
        >>> set_log_context(correlation_id="abc-123", user_id="user-456")
        >>> log_info("Starting operation")  # Includes correlation_id, user_id
    """
    _context.update(kwargs)


def clear_log_context() -> None:
    """Clear all context values.

    Call at end of request to prevent context leakage
    to subsequent requests.

    Example:
        >>> set_log_context(correlation_id="abc-123")
        >>> try:
        ...     process_request()
        ... finally:
        ...     clear_log_context()
    """
    _context.clear()


def get_log_context() -> dict[str, Any]:
    """Get current log context.

    Returns a copy to prevent external modification.

    Returns:
        dict: Copy of current context dictionary.

    Example:
        >>> set_log_context(operation="get_customer")
        >>> ctx = get_log_context()
        >>> ctx["operation"]
        'get_customer'
    """
    return dict(_context)


def help() -> str:
    """Display module usage information.

    Returns:
        str: Help text with context management usage.
    """
    return """
databricks_api_workspace.core.logging.context
================================================

Log context management for request-scoped data.

Functions:
---------
  set_log_context(**kwargs) -> None
      Add key-value pairs to context.

  clear_log_context() -> None
      Clear all context values.

  get_log_context() -> dict
      Get copy of current context.

Usage:
-----
  from databricks_api_workspace.core.logging import (
      set_log_context,
      clear_log_context,
      log_info,
  )

  # Set context at request start
  set_log_context(
      correlation_id=request.headers.get("X-Correlation-ID"),
      user_id=request.user_id,
      operation="get_customer",
  )

  try:
      # All logs include context
      log_info("Processing request")  # Includes correlation_id, user_id, operation
      process_request()
      log_info("Request complete")
  finally:
      # Always clear at end
      clear_log_context()

Common Context Fields:
--------------------
  correlation_id - Request tracing ID
  user_id        - User identifier
  operation      - Current operation name
  tenant_id      - Multi-tenant identifier
  request_id     - Unique request ID

Notes:
-----
  - Context is thread-local in multi-threaded apps
  - For notebooks/scripts, uses simple module dict
  - Always clear context to prevent leakage
"""
