# Databricks notebook source
# MAGIC %md
# MAGIC # __init__
# MAGIC
# MAGIC **Auto-generated from:** `__init__.py`
# MAGIC **Build timestamp:** 2025-12-22T22:33:16.566296+00:00
# MAGIC **Content hash:** be506fe68fb3
# MAGIC
# MAGIC > Do not edit directly. Make changes in source and rebuild.

# COMMAND ----------

# MAGIC %run ../../core/logging/context
# MAGIC %run ../../core/logging/core
# MAGIC %run ../../core/logging/levels
# MAGIC %run ../../core/logging/telemetry

# COMMAND ----------

"""
databricks_api_workspace.core.logging - Logging and telemetry module.

Structured JSON logging with context injection and telemetry.

Classes:
    LogLevel: Log level enumeration
    DebugContext: Context manager for temporary debug logging

Functions:
    log_debug(), log_info(), log_warning(), log_error(), log_critical()
    log_exception(): Log with stack trace
    debug(), info(), warning(), error(): Convenience aliases
    get_log_level(), set_log_level(): Level management
    set_log_context(), clear_log_context(), get_log_context(): Context
    write_telemetry(): Write to Delta table
    query_telemetry(): Query telemetry records
    get_operation_stats(): Get operation statistics
    help(): Display module usage information

Example:
    >>> from databricks_api_workspace.core.logging import (
    ...     log_info,
    ...     set_log_context,
    ... )
    >>> set_log_context(correlation_id="abc-123")
    >>> log_info("Operation started", operation="get_customer")
"""

from __future__ import annotations

# Re-exports

__all__ = [
    # Enum
    "LogLevel",
    "DebugContext",
    # Level management
    "get_log_level",
    "set_log_level",
    "set_min_log_level",
    # Context
    "set_log_context",
    "clear_log_context",
    "get_log_context",
    # Core logging
    "log_debug",
    "log_info",
    "log_warning",
    "log_error",
    "log_critical",
    "log_exception",
    # Convenience
    "debug",
    "info",
    "warning",
    "error",
    # Telemetry
    "write_telemetry",
    "query_telemetry",
    "get_operation_stats",
    # Help
    "help",
]


def help() -> str:
    """Display logging module usage information.

    Returns:
        str: Help text with all available functions and examples.

    Example:
        >>> from databricks_api_workspace.core import logging
        >>> print(logging.help())
    """
    return """
databricks_api_workspace.core.logging
====================================

Structured JSON logging with context injection and telemetry.

Log Levels:
----------
  LogLevel.DEBUG, INFO, WARNING, ERROR, CRITICAL
  get_log_level() -> LogLevel
  set_log_level(level) -> None

Context:
-------
  set_log_context(**kwargs) -> None
  clear_log_context() -> None
  get_log_context() -> dict

Core Logging:
------------
  log_debug(message, **extra) -> None
  log_info(message, **extra) -> None
  log_warning(message, **extra) -> None
  log_error(message, **extra) -> None
  log_critical(message, **extra) -> None
  log_exception(message, exc, **extra) -> None

Convenience: debug(), info(), warning(), error()

Debug Context Manager:
--------------------
  with DebugContext():
      # DEBUG level enabled here

Telemetry:
---------
  write_telemetry(operation, params, envelope) -> bool
  query_telemetry(operation=None, status=None, ...) -> DataFrame
  get_operation_stats(operation, days=7) -> dict

Quick Start:
-----------
  from databricks_api_workspace.core.logging import (
      set_log_context, log_info,
  )
  set_log_context(correlation_id="abc-123")
  log_info("Starting operation")

Environment:
-----------
  LOG_LEVEL - Set initial log level (default: INFO)

Submodules:
----------
  _settings - Logging configuration constants
  levels - Log level management
  context - Log context management
  core - Core logging functions
  telemetry - Telemetry utilities
"""
