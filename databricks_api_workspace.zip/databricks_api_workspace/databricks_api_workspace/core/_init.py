# Databricks notebook source
# MAGIC %md
# MAGIC # __init__
# MAGIC
# MAGIC **Auto-generated from:** `__init__.py`
# MAGIC **Build timestamp:** 2025-12-22T22:33:16.657815+00:00
# MAGIC **Content hash:** b23a078075c0
# MAGIC
# MAGIC > Do not edit directly. Make changes in source and rebuild.

# COMMAND ----------

# MAGIC %run ../core/cache/_init
# MAGIC %run ../core/config/_init
# MAGIC %run ../core/data_utils/_init
# MAGIC %run ../core/errors/_init
# MAGIC %run ../core/logging/_init
# MAGIC %run ../core/routes/_init
# MAGIC %run ../core/runtime/_init
# MAGIC %run ../core/sql_utils/_init
# MAGIC %run ../core/validation_utils/_init

# COMMAND ----------

"""
databricks_api_workspace.core - Foundation layer utilities.

Core provides all reusable building blocks used across services:
    runtime: Environment detection (Databricks, local)
    errors: Error types, codes, handlers
    cache: Unified caching with namespaces
    config: Config loading, drift detection
    logging: Logging, telemetry, context
    sql_utils: SQL escaping, params, safety
    data_utils: Row helpers (first_row, pluck, formatters)
    validation_utils: Schema loading, validation, checks
    routes: Route loading, validation, registry

Usage:
    >>> from databricks_api_workspace.core import (
    ...     APIError,
    ...     UnifiedCache,
    ...     load_config,
    ...     log_info,
    ...     escape_sql_string,
    ...     first_row,
    ...     RouteRegistry,
    ... )
"""

from __future__ import annotations

# Cache

# Config

# Data Utils

# Errors

# Logging

# Routes

# Runtime

# SQL Utils

# Validation Utils

__all__: list[str] = [
    # Runtime
    "is_databricks",
    "is_local",
    "get_spark",
    "get_dbutils",
    "get_package_root",
    "get_config_dir",
    "get_routes_dir",
    # Errors
    "ErrorCode",
    "ErrorDefinition",
    "ErrorRegistry",
    "APIError",
    "ValidationError",
    "AuthorizationError",
    "NotFoundError",
    "OperationNotFoundError",
    "register_error",
    "register_errors_from_config",
    "get_error",
    "get_http_status",
    "is_error",
    "is_client_error",
    "is_server_error",
    "is_retryable",
    "list_errors",
    "handle_errors",
    "truncate_str",
    # Cache
    "CacheNamespace",
    "CacheEntry",
    "UnifiedCache",
    "get_cache",
    "get_cached",
    "get_stats",
    "set_cached",
    "invalidate",
    "clear_cache",
    "clear_all_caches",
    # Config
    "load_config",
    "get_config_value",
    "get_operation_config",
    "get_schema_path",
    "clear_config_cache",
    "set_config_path",
    "get_config_path",
    "load_yaml_config",
    "load_config_with_overlay",
    "deep_merge",
    "detect_config_drift",
    # Logging
    "LogLevel",
    "DebugContext",
    "get_log_level",
    "set_log_level",
    "set_min_log_level",
    "set_log_context",
    "clear_log_context",
    "get_log_context",
    "log_debug",
    "log_info",
    "log_warning",
    "log_error",
    "log_critical",
    "log_exception",
    "debug",
    "info",
    "warning",
    "error",
    "write_telemetry",
    "query_telemetry",
    "get_operation_stats",
    # SQL Utils
    "escape_sql_string",
    "safe_sql_identifier",
    "validate_uuid_format",
    "safe_job_id",
    "substitute_params",
    "validate_params",
    "PARAM_PATTERN",
    "UUID_PATTERN",
    "MAX_IDENTIFIER_PARTS",
    "IDENTIFIER_PATTERN",
    # Data Utils
    "first_row",
    "last_row",
    "pluck",
    "pluck_unique",
    "row_count",
    "has_rows",
    "get_field",
    "coalesce",
    "format_date",
    "format_currency",
    "DEFAULT_CURRENCY",
    "DATE_FORMAT_LENGTH",
    # Validation Utils
    "SchemaValidationError",
    "load_schema",
    "validate_against_schema",
    "clear_schema_cache",
    "load_validation_config",
    "run_validation",
    "run_all_validations",
    "check_file_exists",
    "check_json_valid",
    "check_schema_valid",
    "check_config_key",
    "check_module_imports",
    "run_custom_validator",
    "TYPE_MAP",
    "REQUIRED_META_FIELDS",
    "VALID_STATUSES",
    "REQUIRED_ERROR_FIELDS",
    # Routes
    "Route",
    "RouteRegistry",
    "RouteValidationError",
    "load_routes",
    "validate_routes",
    "validate_startup",
    # Routes - Health
    "run_health_check",
    "get_routes_hash",
    "check_routes_changed",
    # Routes - Audit
    "write_route_audit",
    "query_route_audit",
    "get_route_history",
    # Help
    "help",
]


def help() -> str:
    """Display core module usage information."""
    return __doc__ or ""
