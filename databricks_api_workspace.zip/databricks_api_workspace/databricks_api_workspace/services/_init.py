# Databricks notebook source
# MAGIC %md
# MAGIC # __init__
# MAGIC
# MAGIC **Auto-generated from:** `__init__.py`
# MAGIC **Build timestamp:** 2025-12-22T22:33:16.660113+00:00
# MAGIC **Content hash:** 9b38de7990e6
# MAGIC
# MAGIC > Do not edit directly. Make changes in source and rebuild.

# COMMAND ----------

# MAGIC %run ../services/_init
# MAGIC %run ../services/execution/_init
# MAGIC %run ../services/query/_init
# MAGIC %run ../services/response/_init
# MAGIC %run ../services/validation/_init

# COMMAND ----------

"""
databricks_api_workspace.services - Business logic services.

Services provide thin orchestration layers for domain-specific operations:
    query: Query execution (uses core/sql_utils)
    validation: Contracts (uses core/validation_utils)
    response: Envelope building (uses core/data_utils)
    databricks_async_job: Job lifecycle management
    auth: RBAC, user context
    operations: Operation execution framework
    http: FastAPI routing, Azure bridge
    execution: Notebook execution engine (routes/queries)

Usage:
    >>> from databricks_api_workspace.services import (
    ...     execute_query,
    ...     build_response,
    ...     validate_request_contract,
    ...     NotebookRunner,
    ... )
"""

from __future__ import annotations

# Service modules (for module-level imports)

# Execution service

# Query service

# Response service

# Validation service

__all__: list[str] = [
    # Service modules
    "auth",
    "execution",
    "http",
    "operations",
    # Query service
    "load_query",
    "execute_query",
    "execute_query_by_name",
    "clear_query_cache",
    "set_queries_path",
    "get_queries_path",
    # Response service
    "build_response",
    "build_error_response",
    "build_async_response",
    "compute_integrity_hash",
    "verify_integrity_hash",
    # Validation service
    "ContractViolationError",
    "validate_request_contract",
    "validate_response_contract",
    "require_valid_request",
    "require_valid_response",
    "is_valid_request",
    "is_valid_response",
    # Execution service
    "NotebookResult",
    "NotebookRunner",
    "NotebookExecutionError",
    "ParamMappingError",
    "map_params",
    "extract_value",
    "wrap_result_envelope",
    # Help
    "help",
]


def help() -> str:
    """Display services module usage information."""
    return __doc__ or ""
