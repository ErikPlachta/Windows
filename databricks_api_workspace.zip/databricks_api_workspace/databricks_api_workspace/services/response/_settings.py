# Databricks notebook source
# MAGIC %md
# MAGIC # _settings
# MAGIC
# MAGIC **Auto-generated from:** `_settings.py`
# MAGIC **Build timestamp:** 2025-12-22T22:33:16.614022+00:00
# MAGIC **Content hash:** 7cf44655acd1
# MAGIC
# MAGIC > Do not edit directly. Make changes in source and rebuild.

# COMMAND ----------

"""
databricks_api_workspace.services.response.settings - Response service configuration.

Constants for response envelope building.

Constants:
    SCHEMA_VERSION: Current response schema version
    SUCCESS_STATUS: Status string for success
    ERROR_STATUS: Status string for error
    ASYNC_STATUS_SUBMITTED: Status for async job submission
"""

from __future__ import annotations

__all__ = [
    "SCHEMA_VERSION",
    "SUCCESS_STATUS",
    "ERROR_STATUS",
    "ASYNC_STATUS_SUBMITTED",
]

# Response schema version
SCHEMA_VERSION: str = "2.0.0"

# Status constants
SUCCESS_STATUS: str = "success"
ERROR_STATUS: str = "error"
ASYNC_STATUS_SUBMITTED: str = "submitted"
