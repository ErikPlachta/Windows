# Databricks notebook source
# MAGIC %md
# MAGIC # envelope
# MAGIC
# MAGIC **Auto-generated from:** `envelope.py`
# MAGIC **Build timestamp:** 2025-12-22T22:33:16.611925+00:00
# MAGIC **Content hash:** ceeb3848b1bd
# MAGIC
# MAGIC > Do not edit directly. Make changes in source and rebuild.

# COMMAND ----------

# MAGIC %run ../../services/response/_settings
# MAGIC %run ../../services/response/integrity

# COMMAND ----------

"""
databricks_api_workspace.services.response.envelope - Response envelope building.

Build standardized response envelopes with metadata.

Functions:
    build_response(): Build success/error response envelope
    build_error_response(): Build error response convenience
    build_async_response(): Build async job response
    help(): Display module usage information
"""

from __future__ import annotations

import time
import uuid
from datetime import datetime, timezone
from typing import Any


__all__ = [
    "build_response",
    "build_error_response",
    "build_async_response",
    "help",
]


def build_response(
    data: dict[str, Any] | None,
    operation: str,
    status: str = SUCCESS_STATUS,
    error: dict[str, Any] | None = None,
    start_time: float | None = None,
    correlation_id: str | None = None,
    include_hash: bool = True,
    hash_salt: str = "",
) -> dict[str, Any]:
    """Build standardized response envelope.

    Creates a consistent response structure with metadata including
    execution ID, timestamps, duration, and optional integrity hash.

    Args:
        data: Response data (None for errors).
        operation: Operation name.
        status: Status string ('success' or 'error').
        error: Error details dict (for error responses).
        start_time: Start timestamp for duration calculation.
        correlation_id: Request correlation ID for tracing.
        include_hash: Whether to include integrity hash.
        hash_salt: Salt for integrity hash.

    Returns:
        dict: Response envelope with meta, data, error fields.

    Example:
        >>> envelope = build_response(
        ...     data={"customer_id": "123"},
        ...     operation="get_customer",
        ...     start_time=time.time() - 0.5,
        ... )
        >>> envelope["meta"]["status"]
        'success'
    """
    now = datetime.now(timezone.utc)
    duration_ms = int((time.time() - start_time) * 1000) if start_time else 0

    envelope: dict[str, Any] = {
        "meta": {
            "execution_id": str(uuid.uuid4()),
            "operation": operation,
            "status": status,
            "timestamp_utc": now.isoformat(),
            "duration_ms": duration_ms,
            "schema_version": SCHEMA_VERSION,
        },
        "data": data if status == SUCCESS_STATUS else None,
        "error": error,
    }

    if correlation_id:
        envelope["meta"]["correlation_id"] = correlation_id

    if include_hash and data is not None:
        envelope["meta"]["integrity_hash"] = compute_integrity_hash(data, hash_salt)

    return envelope


def build_error_response(
    operation: str,
    error_code: str,
    message: str,
    start_time: float | None = None,
    correlation_id: str | None = None,
    details: dict[str, Any] | None = None,
) -> dict[str, Any]:
    """Build error response envelope.

    Convenience function for building error responses.

    Args:
        operation: Operation name.
        error_code: Error code (e.g., 'VALIDATION_ERROR').
        message: Human-readable error message.
        start_time: Start timestamp for duration calculation.
        correlation_id: Request correlation ID.
        details: Additional error details dict.

    Returns:
        dict: Error response envelope.

    Example:
        >>> envelope = build_error_response(
        ...     operation="get_customer",
        ...     error_code="NOT_FOUND",
        ...     message="Customer not found",
        ... )
    """
    error_info: dict[str, Any] = {
        "error_code": error_code,
        "message": message,
    }

    if details:
        error_info["details"] = details

    return build_response(
        data=None,
        operation=operation,
        status=ERROR_STATUS,
        error=error_info,
        start_time=start_time,
        correlation_id=correlation_id,
        include_hash=False,
    )


def build_async_response(
    operation: str,
    job_id: str,
    correlation_id: str | None = None,
) -> dict[str, Any]:
    """Build async job submission response.

    Response indicates job was submitted for async processing.

    Args:
        operation: Operation name.
        job_id: Async job ID for status polling.
        correlation_id: Request correlation ID.

    Returns:
        dict: Async submission response envelope.

    Example:
        >>> envelope = build_async_response(
        ...     operation="large_export",
        ...     job_id="abc-123",
        ... )
        >>> envelope["data"]["status"]
        'submitted'
    """
    return build_response(
        data={
            "job_id": job_id,
            "status": ASYNC_STATUS_SUBMITTED,
            "poll_url": f"/jobs/{job_id}/status",
            "result_url": f"/jobs/{job_id}/result",
        },
        operation=operation,
        status=SUCCESS_STATUS,
        correlation_id=correlation_id,
        include_hash=False,
    )


def help() -> str:
    """Display module usage information.

    Returns:
        str: Help text with envelope building usage.
    """
    return """
databricks_api_workspace.services.response.envelope
===========================================================

Response envelope building utilities.

Functions:
---------
  build_response(data, operation, ...) -> dict
      Build complete response envelope with metadata.

  build_error_response(operation, error_code, message, ...) -> dict
      Convenience for error responses.

  build_async_response(operation, job_id, ...) -> dict
      Build async job submission response.

Envelope Structure:
------------------
  {
    "meta": {
      "execution_id": "uuid-string",
      "operation": "operation_name",
      "status": "success" | "error",
      "timestamp_utc": "ISO-8601",
      "duration_ms": 123,
      "schema_version": "2.0.0",
      "correlation_id": "optional",
      "integrity_hash": "sha256-hex"
    },
    "data": { ... } | null,
    "error": { "error_code": "...", "message": "..." } | null
  }

Usage:
-----
  from databricks_api_workspace.services.response import (
      build_response,
      build_error_response,
  )

  # Success response
  start = time.time()
  data = {"customer": {"id": 123, "name": "Test"}}
  envelope = build_response(
      data=data,
      operation="get_customer",
      start_time=start,
      correlation_id=request_id,
  )

  # Error response
  envelope = build_error_response(
      operation="get_customer",
      error_code="NOT_FOUND",
      message="Customer not found",
      details={"customer_id": requested_id},
  )
"""
