# Databricks notebook source
# MAGIC %md
# MAGIC # __init__
# MAGIC
# MAGIC **Auto-generated from:** `__init__.py`
# MAGIC **Build timestamp:** 2025-12-22T22:33:16.615089+00:00
# MAGIC **Content hash:** 455b56d69165
# MAGIC
# MAGIC > Do not edit directly. Make changes in source and rebuild.

# COMMAND ----------

# MAGIC %run ../../services/response/_settings
# MAGIC %run ../../services/response/envelope
# MAGIC %run ../../services/response/integrity

# COMMAND ----------

"""
databricks_api_workspace.services.response - Response envelope service.

Build standardized response envelopes with metadata and integrity.

Functions:
    build_response(): Build success/error response envelope
    build_error_response(): Build error response convenience
    build_async_response(): Build async job response
    compute_integrity_hash(): Compute hash for data
    verify_integrity_hash(): Verify response hash
    help(): Display module usage information

Note:
    Data manipulation utilities (first_row, pluck, format_currency, etc.)
    are in databricks_api_workspace.core.data_utils

Usage:
    >>> from databricks_api_workspace.services.response import (
    ...     build_response,
    ...     build_error_response,
    ... )
"""

from __future__ import annotations


__all__ = [
    # Envelope building
    "build_response",
    "build_error_response",
    "build_async_response",
    # Integrity
    "compute_integrity_hash",
    "verify_integrity_hash",
    # Settings
    "SCHEMA_VERSION",
    "SUCCESS_STATUS",
    "ERROR_STATUS",
    "ASYNC_STATUS_SUBMITTED",
    # Help
    "help",
]


def help() -> str:
    """Display module usage information.

    Returns:
        str: Help text with response service usage.
    """
    return """
databricks_api_workspace.services.response
==============================================

Response envelope building service.

Functions:
---------
  build_response(data, operation, ...) -> dict
      Build complete response envelope with metadata.

  build_error_response(operation, error_code, message, ...) -> dict
      Convenience for error responses.

  build_async_response(operation, job_id, ...) -> dict
      Build async job submission response.

  compute_integrity_hash(data, salt="") -> str
      Compute SHA-256 hash of data.

  verify_integrity_hash(envelope, salt="") -> bool
      Verify response envelope integrity.

Data Utilities:
--------------
  For data manipulation, see databricks_api_workspace.core.data_utils:
  - first_row(), last_row()
  - pluck(), pluck_unique()
  - format_date(), format_currency()
  - coalesce()

Usage:
-----
  from databricks_api_workspace.services.response import (
      build_response,
      build_error_response,
      verify_integrity_hash,
  )
  from databricks_api_workspace.core.data_utils import (
      first_row,
      format_currency,
  )

  # Build success response
  import time
  start = time.time()
  data = {"customer": {"id": 123, "name": "Test"}}
  envelope = build_response(
      data=data,
      operation="get_customer",
      start_time=start,
  )

  # Extract and format data
  customer = first_row(results)
  customer["balance"] = format_currency(customer["balance"])
"""
