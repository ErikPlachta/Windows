# Databricks notebook source
# MAGIC %md
# MAGIC # integrity
# MAGIC
# MAGIC **Auto-generated from:** `integrity.py`
# MAGIC **Build timestamp:** 2025-12-22T22:33:16.613149+00:00
# MAGIC **Content hash:** ffad02997edd
# MAGIC
# MAGIC > Do not edit directly. Make changes in source and rebuild.

# COMMAND ----------

"""
databricks_api_workspace.services.response.integrity - Integrity hash utilities.

Compute and verify SHA-256 hashes for response data.

Functions:
    compute_integrity_hash(): Compute hash for data
    verify_integrity_hash(): Verify response hash
    help(): Display module usage information
"""

from __future__ import annotations

import hashlib
import json
from typing import Any

__all__ = [
    "compute_integrity_hash",
    "verify_integrity_hash",
    "help",
]


def compute_integrity_hash(data: Any, salt: str = "") -> str:
    """Compute SHA-256 hash for response verification.

    Deterministically serializes data to JSON and computes hash.
    Useful for detecting tampering or corruption.

    Args:
        data: Data to hash (will be JSON-serialized).
        salt: Optional salt to include in hash.

    Returns:
        str: Hex-encoded SHA-256 hash string.

    Example:
        >>> hash_val = compute_integrity_hash({"id": 123})
        >>> len(hash_val)
        64
    """
    serialized = json.dumps(data, sort_keys=True, default=str).encode("utf-8")
    return hashlib.sha256(salt.encode("utf-8") + serialized).hexdigest()


def verify_integrity_hash(
    envelope: dict[str, Any],
    salt: str = "",
) -> bool:
    """Verify response integrity hash.

    Recomputes hash from envelope data and compares to stored hash.

    Args:
        envelope: Response envelope to verify.
        salt: Salt used when hash was created.

    Returns:
        bool: True if hash is valid, False otherwise.

    Example:
        >>> envelope = build_response(data={"id": 1}, operation="test")
        >>> verify_integrity_hash(envelope)
        True
    """
    if "meta" not in envelope or "integrity_hash" not in envelope["meta"]:
        return False

    if envelope.get("data") is None:
        return False

    expected_hash = envelope["meta"]["integrity_hash"]
    actual_hash = compute_integrity_hash(envelope["data"], salt)
    return expected_hash == actual_hash


def help() -> str:
    """Display module usage information.

    Returns:
        str: Help text with integrity utilities usage.
    """
    return """
databricks_api_workspace.services.response.integrity
============================================================

Response integrity hash utilities.

Functions:
---------
  compute_integrity_hash(data, salt="") -> str
      Compute SHA-256 hash of data.
      Uses deterministic JSON serialization.

  verify_integrity_hash(envelope, salt="") -> bool
      Verify response envelope integrity.
      Returns True if hash matches.

Usage:
-----
  from databricks_api_workspace.services.response import (
      compute_integrity_hash,
      verify_integrity_hash,
  )

  # Compute hash
  data = {"customer_id": "123", "name": "Test"}
  hash_val = compute_integrity_hash(data)

  # Verify envelope
  is_valid = verify_integrity_hash(envelope)
  if not is_valid:
      raise ValueError("Response integrity check failed")

Security Notes:
--------------
  - Use salt for additional security
  - Hash detects tampering but not replay attacks
  - Combine with timestamps for stronger verification
"""
