# Databricks notebook source
# MAGIC %md
# MAGIC # azure_bridge
# MAGIC
# MAGIC **Auto-generated from:** `azure_bridge.py`
# MAGIC **Build timestamp:** 2025-12-22T22:33:16.631026+00:00
# MAGIC **Content hash:** ef6b1d2689cd
# MAGIC
# MAGIC > Do not edit directly. Make changes in source and rebuild.

# COMMAND ----------

# MAGIC %run ../../services/http/_settings
# MAGIC %run ../../services/operations/_init

# COMMAND ----------

"""Azure Functions bridge for databricks_api_workspace.

Provides integration between Azure Functions and Databricks workspace,
supporting both direct execution and Jobs API-based remote execution.

Examples:
    Direct execution in Azure Function::

        from databricks_api_workspace.services.http import AzureBridge

        bridge = AzureBridge()
        result = bridge.execute_direct("get_customer_detail_v1", {"customer_id": "C123"})

    Remote execution via Jobs API::

        bridge = AzureBridge(mode="remote")
        result = await bridge.execute_remote("get_customer_detail_v1", {"customer_id": "C123"})
"""

from __future__ import annotations

import json
import os
from dataclasses import dataclass, field
from enum import Enum
from typing import Any


try:
    from databricks.sdk import WorkspaceClient
    from databricks.sdk.service.jobs import RunLifeCycleState, RunResultState

    HAS_DATABRICKS_SDK = True
except ImportError:
    HAS_DATABRICKS_SDK = False


class ExecutionMode(str, Enum):
    """Execution mode for the bridge."""

    DIRECT = "direct"
    REMOTE = "remote"


@dataclass
class BridgeConfig:
    """Configuration for Azure bridge."""

    mode: ExecutionMode = ExecutionMode.DIRECT
    databricks_host: str | None = None
    databricks_token: str | None = None
    cluster_id: str | None = None
    notebook_base_path: str = DEFAULT_NOTEBOOK_BASE_PATH
    timeout_seconds: int = DEFAULT_TIMEOUT_SECONDS
    poll_interval_seconds: float = DEFAULT_POLL_INTERVAL_SECONDS

    @classmethod
    def from_env(cls) -> BridgeConfig:
        """Create config from environment variables.

        Environment Variables:
            DATABRICKS_HOST: Databricks workspace URL
            DATABRICKS_TOKEN: Databricks API token
            DATABRICKS_CLUSTER_ID: Default cluster ID for job execution
            EXECUTION_MODE: 'direct' or 'remote'
        """
        return cls(
            mode=ExecutionMode(os.getenv(ENV_EXECUTION_MODE, DEFAULT_EXECUTION_MODE)),
            databricks_host=os.getenv(ENV_DATABRICKS_HOST),
            databricks_token=os.getenv(ENV_DATABRICKS_TOKEN),
            cluster_id=os.getenv(ENV_DATABRICKS_CLUSTER_ID),
        )


@dataclass
class ExecutionResult:
    """Result of operation execution."""

    success: bool
    data: dict[str, Any] | None = None
    error: str | None = None
    run_id: int | None = None
    metadata: dict[str, Any] = field(default_factory=dict)


class AzureBridge:
    """Bridge between Azure Functions and Databricks workspace.

    Supports two execution modes:
    - direct: Execute operations locally (same process)
    - remote: Submit notebook jobs via Databricks Jobs API

    Args:
        config: Bridge configuration. If not provided, loads from environment.

    Attributes:
        config: Current configuration.
        client: Databricks SDK client (only for remote mode).
    """

    def __init__(self, config: BridgeConfig | None = None) -> None:
        """Initialize the Azure bridge."""
        self.config = config or BridgeConfig.from_env()
        self._client: Any = None

    @property
    def client(self) -> Any:
        """Get or create Databricks workspace client."""
        if self._client is None:
            if not HAS_DATABRICKS_SDK:
                raise ImportError(
                    "databricks-sdk not installed. "
                    "Install with: pip install databricks_api_workspace[azure]"
                )
            self._client = WorkspaceClient(
                host=self.config.databricks_host,
                token=self.config.databricks_token,
            )
        return self._client

    def execute_direct(
        self,
        operation_name: str,
        params: dict[str, Any],
        debug: bool = False,
    ) -> ExecutionResult:
        """Execute operation directly in current process.

        Args:
            operation_name: Name of the operation.
            params: Operation parameters.
            debug: Enable debug mode.

        Returns:
            Execution result.
        """
        try:

            executor = Executor()
            result = executor.execute(
                operation_name=operation_name,
                params=params,
                debug=debug,
            )
            return ExecutionResult(success=True, data=result)

        except Exception as e:
            return ExecutionResult(success=False, error=str(e))

    async def execute_remote(
        self,
        operation_name: str,
        params: dict[str, Any],
        debug: bool = False,
    ) -> ExecutionResult:
        """Execute operation remotely via Databricks Jobs API.

        Submits a notebook job to Databricks and polls for completion.

        Args:
            operation_name: Name of the operation.
            params: Operation parameters.
            debug: Enable debug mode.

        Returns:
            Execution result with run_id.
        """
        import asyncio

        try:
            notebook_path = f"{self.config.notebook_base_path}/{operation_name}"

            # Submit job
            loop = asyncio.get_running_loop()
            run = await loop.run_in_executor(
                None,
                lambda: self.client.jobs.submit(
                    run_name=f"azure_bridge_{operation_name}",
                    tasks=[
                        {
                            "task_key": "main",
                            "notebook_task": {
                                "notebook_path": notebook_path,
                                "base_parameters": {
                                    "params": json.dumps(params),
                                    "debug": str(debug).lower(),
                                },
                            },
                            "existing_cluster_id": self.config.cluster_id,
                        }
                    ],
                ),
            )

            # Poll for completion
            result = await self._poll_run(run.run_id)
            return result

        except Exception as e:
            return ExecutionResult(success=False, error=str(e))

    async def _poll_run(self, run_id: int) -> ExecutionResult:
        """Poll job run until completion."""
        import asyncio
        import time

        start_time = time.time()
        loop = asyncio.get_running_loop()

        while True:
            elapsed = time.time() - start_time
            if elapsed > self.config.timeout_seconds:
                return ExecutionResult(
                    success=False,
                    error=f"Timeout after {self.config.timeout_seconds}s",
                    run_id=run_id,
                )

            run = await loop.run_in_executor(None, lambda: self.client.jobs.get_run(run_id))

            state = run.state.life_cycle_state
            if state == RunLifeCycleState.TERMINATED:
                result_state = run.state.result_state

                if result_state == RunResultState.SUCCESS:
                    data = self._extract_output(run)
                    return ExecutionResult(
                        success=True,
                        data=data,
                        run_id=run_id,
                        metadata={"run_page_url": run.run_page_url},
                    )
                else:
                    return ExecutionResult(
                        success=False,
                        error=f"Run failed: {run.state.state_message}",
                        run_id=run_id,
                    )

            await asyncio.sleep(self.config.poll_interval_seconds)

    def _extract_output(self, run: Any) -> dict[str, Any] | None:
        """Extract notebook output from run."""
        if run.tasks and len(run.tasks) > 0:
            task = run.tasks[0]
            if hasattr(task, "notebook_output") and task.notebook_output:
                result_str = task.notebook_output.result
                if result_str:
                    try:
                        return json.loads(result_str)
                    except json.JSONDecodeError:
                        return {"raw": result_str}
        return None

    def execute(
        self,
        operation_name: str,
        params: dict[str, Any],
        debug: bool = False,
    ) -> ExecutionResult:
        """Execute operation using configured mode.

        Args:
            operation_name: Name of the operation.
            params: Operation parameters.
            debug: Enable debug mode.

        Returns:
            Execution result.
        """
        if self.config.mode == ExecutionMode.DIRECT:
            return self.execute_direct(operation_name, params, debug)
        else:
            import asyncio

            return asyncio.run(self.execute_remote(operation_name, params, debug))
