# Databricks notebook source
# MAGIC %md
# MAGIC # __init__
# MAGIC
# MAGIC **Auto-generated from:** `__init__.py`
# MAGIC **Build timestamp:** 2025-12-22T22:33:16.635114+00:00
# MAGIC **Content hash:** 31c2ad4ce868
# MAGIC
# MAGIC > Do not edit directly. Make changes in source and rebuild.

# COMMAND ----------

# MAGIC %run ../../services/http/azure_bridge

# COMMAND ----------

"""
databricks_api_workspace.services.http - HTTP and API module.

FastAPI router and Azure Functions integration for exposing
operations via HTTP endpoints.

Classes:
    AzureBridge: Bridge between Azure Functions and Databricks
    BridgeConfig: Configuration for Azure bridge
    ExecutionMode: Execution mode enum (direct/remote)
    ExecutionResult: Result of operation execution
    HealthResponse: Health check response model (requires FastAPI)
    ExecuteRequest: Execution request model (requires FastAPI)
    ExecuteResponse: Execution response model (requires FastAPI)

Functions:
    create_router(): Create FastAPI router (requires FastAPI)
    health_check(): Get service health status (requires FastAPI)
    help(): Display module usage information

Optional Dependencies:
    pip install databricks_api_workspace[http]  # For FastAPI router
    pip install databricks_api_workspace[azure] # For Databricks SDK

Example:
    >>> from databricks_api_workspace.services.http import AzureBridge
    >>> bridge = AzureBridge()
    >>> result = bridge.execute("get_customer", {"id": 123})
"""

from __future__ import annotations

# Azure bridge is always available

__all__ = [
    # Azure Bridge
    "AzureBridge",
    "BridgeConfig",
    "ExecutionMode",
    "ExecutionResult",
    # Help
    "help",
]

# FastAPI router components (optional):
#   from databricks_api_workspace.services.http.router import create_router, health_check


def help() -> str:
    """Display HTTP module usage information.

    Returns:
        str: Help text with all available functions and examples.

    Example:
        >>> from databricks_api_workspace.services import http
        >>> print(http.help())
    """
    return """
databricks_api_workspace.services.http
=================================

FastAPI router and Azure Functions integration.

Azure Bridge (always available):
-------------------------------
  ExecutionMode.DIRECT, REMOTE

  BridgeConfig(mode, databricks_host, databricks_token, cluster_id, ...)
    .from_env() -> BridgeConfig

  ExecutionResult(success, data, error, run_id, metadata)

  AzureBridge(config=None)
    .execute(operation_name, params, debug=False) -> ExecutionResult
    .execute_direct(operation_name, params, debug=False) -> ExecutionResult
    .execute_remote(operation_name, params, debug=False) -> ExecutionResult

FastAPI Router (requires fastapi):
---------------------------------
  HealthResponse(status, version)
  ExecuteRequest(data, debug)
  ExecuteResponse(request_id, status, data, error)

  health_check() -> HealthResponse
  create_router(executor=None) -> APIRouter

Quick Start - Azure Bridge:
--------------------------
  from databricks_api_workspace.services.http import AzureBridge
  bridge = AzureBridge()
  result = bridge.execute("get_customer", {"id": 123})

Quick Start - FastAPI:
---------------------
  from fastapi import FastAPI
  from databricks_api_workspace.services.http import create_router

  app = FastAPI()
  router = create_router()
  app.include_router(router, prefix="/api/v1")

Environment Variables:
--------------------
  DATABRICKS_HOST - Databricks workspace URL
  DATABRICKS_TOKEN - Databricks API token
  DATABRICKS_CLUSTER_ID - Default cluster ID
  EXECUTION_MODE - 'direct' or 'remote'

Submodules:
----------
  _settings - HTTP configuration constants
  router - FastAPI router (optional)
  azure_bridge - Azure Functions bridge
"""
