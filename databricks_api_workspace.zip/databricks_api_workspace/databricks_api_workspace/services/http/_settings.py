# Databricks notebook source
# MAGIC %md
# MAGIC # _settings
# MAGIC
# MAGIC **Auto-generated from:** `_settings.py`
# MAGIC **Build timestamp:** 2025-12-22T22:33:16.633859+00:00
# MAGIC **Content hash:** 5533d3e03eb9
# MAGIC
# MAGIC > Do not edit directly. Make changes in source and rebuild.

# COMMAND ----------

"""HTTP module configuration constants.

Single source of truth for HTTP/API settings.
"""

from __future__ import annotations

# API version
API_VERSION = "0.1.0"

# Default Azure bridge settings
DEFAULT_NOTEBOOK_BASE_PATH = "/Workspace/operations"
DEFAULT_TIMEOUT_SECONDS = 300
DEFAULT_POLL_INTERVAL_SECONDS = 5.0

# Environment variable names
ENV_DATABRICKS_HOST = "DATABRICKS_HOST"
ENV_DATABRICKS_TOKEN = "DATABRICKS_TOKEN"
ENV_DATABRICKS_CLUSTER_ID = "DATABRICKS_CLUSTER_ID"
ENV_EXECUTION_MODE = "EXECUTION_MODE"

# Default execution mode
DEFAULT_EXECUTION_MODE = "direct"
