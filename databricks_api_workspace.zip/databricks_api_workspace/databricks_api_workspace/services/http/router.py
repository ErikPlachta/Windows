# Databricks notebook source
# MAGIC %md
# MAGIC # router
# MAGIC
# MAGIC **Auto-generated from:** `router.py`
# MAGIC **Build timestamp:** 2025-12-22T22:33:16.632849+00:00
# MAGIC **Content hash:** ed0bc2e881ba
# MAGIC
# MAGIC > Do not edit directly. Make changes in source and rebuild.

# COMMAND ----------

# MAGIC %run ../../services/http/_settings
# MAGIC %run ../../services/operations/_init

# COMMAND ----------

"""FastAPI router for operations.

Provides HTTP endpoints for executing operations and health checks.

Examples:
    Create and mount router::

        from fastapi import FastAPI
        from databricks_api_workspace.services.http import create_router

        app = FastAPI()
        router = create_router()
        app.include_router(router, prefix="/api/v1")
"""

from __future__ import annotations

import uuid
from typing import TYPE_CHECKING, Any

from fastapi import APIRouter, HTTPException
from pydantic import BaseModel, Field


if TYPE_CHECKING:


class HealthResponse(BaseModel):
    """Health check response."""

    status: str = Field(description="Service status")
    version: str = Field(description="API version")


class ExecuteRequest(BaseModel):
    """Operation execution request."""

    data: dict[str, Any] = Field(description="Operation parameters")
    debug: bool = Field(default=False, description="Enable debug mode")


class ExecuteResponse(BaseModel):
    """Operation execution response."""

    request_id: str = Field(description="Unique request identifier")
    status: str = Field(description="Execution status")
    data: dict[str, Any] | None = Field(default=None, description="Result data")
    error: str | None = Field(default=None, description="Error message if failed")


def health_check() -> HealthResponse:
    """Return service health status.

    Returns:
        HealthResponse: Health check response with status and version.
    """
    return HealthResponse(status="healthy", version=API_VERSION)


def create_router(executor: Executor | None = None) -> APIRouter:
    """Create FastAPI router for operations.

    Args:
        executor: Pre-configured executor instance. If not provided, creates default.

    Returns:
        FastAPI router with operation endpoints.
    """
    router = APIRouter(tags=["operations"])

    @router.get("/health", response_model=HealthResponse)
    async def get_health() -> HealthResponse:
        """Health check endpoint."""
        return health_check()

    @router.post("/execute/{operation_name}", response_model=ExecuteResponse)
    async def execute_operation(
        operation_name: str,
        request: ExecuteRequest,
    ) -> ExecuteResponse:
        """Execute an operation by name.

        Args:
            operation_name: Name of the operation to execute.
            request: Request body with operation parameters.

        Returns:
            Execution result.
        """
        request_id = str(uuid.uuid4())

        try:
            # Import executor lazily to avoid circular imports
            if executor is None:

                exec_instance = Executor()
            else:
                exec_instance = executor

            result = exec_instance.execute(
                operation_name=operation_name,
                params=request.data,
                debug=request.debug,
            )

            return ExecuteResponse(
                request_id=request_id,
                status="success",
                data=result,
            )

        except KeyError as e:
            raise HTTPException(status_code=404, detail=f"Operation not found: {e}") from e
        except ValueError as e:
            raise HTTPException(status_code=400, detail=str(e)) from e
        except Exception as e:
            return ExecuteResponse(
                request_id=request_id,
                status="error",
                error=str(e),
            )

    return router
