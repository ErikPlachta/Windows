# Databricks notebook source
# MAGIC %md
# MAGIC # contracts
# MAGIC
# MAGIC **Auto-generated from:** `contracts.py`
# MAGIC **Build timestamp:** 2025-12-22T22:33:16.607894+00:00
# MAGIC **Content hash:** 91ea68b9328a
# MAGIC
# MAGIC > Do not edit directly. Make changes in source and rebuild.

# COMMAND ----------

# MAGIC %run ../../services/validation/_settings

# COMMAND ----------

"""
databricks_api_workspace.services.validation.contracts - Contract validation.

Enforce envelope structure beyond JSON Schema validation.

Classes:
    ContractViolationError: Raised when contract violated

Functions:
    validate_request_contract(): Validate request structure
    validate_response_contract(): Validate response structure
    require_valid_request(): Raise if request invalid
    require_valid_response(): Raise if response invalid
    is_valid_request(): Check if request valid
    is_valid_response(): Check if response valid
    help(): Display module usage information
"""

from __future__ import annotations

from typing import Any


__all__ = [
    "ContractViolationError",
    "validate_request_contract",
    "validate_response_contract",
    "require_valid_request",
    "require_valid_response",
    "is_valid_request",
    "is_valid_response",
    "help",
]


class ContractViolationError(Exception):
    """Raised when request/response violates contract.

    Attributes:
        operation: Operation name.
        violations: List of violation messages.
    """

    def __init__(self, operation: str, violations: list[str]) -> None:
        self.operation = operation
        self.violations = violations
        message = f"Contract violations for '{operation}': {'; '.join(violations)}"
        super().__init__(message)


def validate_request_contract(
    operation: str,
    params: Any,
) -> list[str]:
    """Validate request structure.

    Checks structural requirements beyond JSON Schema.

    Args:
        operation: Operation name.
        params: Request parameters.

    Returns:
        list[str]: Violation messages (empty if valid).

    Example:
        >>> violations = validate_request_contract("get_customer", {"id": 123})
        >>> if violations:
        ...     print("Invalid:", violations)
    """
    violations: list[str] = []

    # params must be a dict
    if not isinstance(params, dict):
        violations.append(f"params must be a dict, got {type(params).__name__}")
        return violations

    # operation must be non-empty string
    if not operation or not isinstance(operation, str):
        violations.append("operation must be a non-empty string")

    return violations


def validate_response_contract(
    operation: str,
    envelope: Any,
) -> list[str]:
    """Validate response envelope structure.

    Checks:
    - envelope is dict
    - meta field exists with required subfields
    - status is 'success' or 'error'
    - success status requires non-null data
    - error status requires non-null error with required fields

    Args:
        operation: Operation name.
        envelope: Response envelope.

    Returns:
        list[str]: Violation messages (empty if valid).

    Example:
        >>> violations = validate_response_contract("get_customer", envelope)
        >>> assert len(violations) == 0
    """
    violations: list[str] = []

    # envelope must be dict
    if not isinstance(envelope, dict):
        violations.append(f"envelope must be a dict, got {type(envelope).__name__}")
        return violations

    # meta field required
    if "meta" not in envelope:
        violations.append("envelope missing 'meta' field")
    else:
        meta = envelope["meta"]
        if not isinstance(meta, dict):
            violations.append("meta must be a dict")
        else:
            # Required meta fields
            for field in REQUIRED_META_FIELDS:
                if field not in meta:
                    violations.append(f"meta missing '{field}'")

            # Status value check
            if "status" in meta and meta["status"] not in VALID_STATUSES:
                violations.append(
                    f"meta.status must be one of {VALID_STATUSES}, got '{meta['status']}'"
                )

    # Must have data or error
    if "data" not in envelope and "error" not in envelope:
        violations.append("envelope must have 'data' or 'error' field")

    # Status-data consistency
    meta = envelope.get("meta", {})
    status = meta.get("status")

    if status == "success":
        if envelope.get("data") is None:
            violations.append("success status requires non-null data")
        if envelope.get("error") is not None:
            violations.append("success status should not have error")

    if status == "error":
        if envelope.get("error") is None:
            violations.append("error status requires non-null error")
        else:
            error = envelope["error"]
            if not isinstance(error, dict):
                violations.append("error must be a dict")
            else:
                for field in REQUIRED_ERROR_FIELDS:
                    if field not in error:
                        violations.append(f"error missing '{field}'")

    return violations


def require_valid_request(operation: str, params: Any) -> None:
    """Raise if request violates contract.

    Args:
        operation: Operation name.
        params: Request parameters.

    Raises:
        ContractViolationError: If violations found.

    Example:
        >>> require_valid_request("get_customer", {"id": 123})
    """
    violations = validate_request_contract(operation, params)
    if violations:
        raise ContractViolationError(operation, violations)


def require_valid_response(operation: str, envelope: Any) -> None:
    """Raise if response violates contract.

    Args:
        operation: Operation name.
        envelope: Response envelope.

    Raises:
        ContractViolationError: If violations found.

    Example:
        >>> require_valid_response("get_customer", envelope)
    """
    violations = validate_response_contract(operation, envelope)
    if violations:
        raise ContractViolationError(operation, violations)


def is_valid_request(operation: str, params: Any) -> bool:
    """Check if request is valid.

    Args:
        operation: Operation name.
        params: Request parameters.

    Returns:
        bool: True if valid, False otherwise.

    Example:
        >>> if is_valid_request("get_customer", params):
        ...     process(params)
    """
    return len(validate_request_contract(operation, params)) == 0


def is_valid_response(operation: str, envelope: Any) -> bool:
    """Check if response is valid.

    Args:
        operation: Operation name.
        envelope: Response envelope.

    Returns:
        bool: True if valid, False otherwise.

    Example:
        >>> assert is_valid_response("get_customer", envelope)
    """
    return len(validate_response_contract(operation, envelope)) == 0


def help() -> str:
    """Display module usage information.

    Returns:
        str: Help text with contract validation usage.
    """
    return """
databricks_api_workspace.services.validation.contracts
==============================================================

Contract validation for request/response structure.

Classes:
-------
  ContractViolationError(operation, violations)
      Raised when contract is violated.
      violations: list[str] of specific issues.

Validation Functions:
-------------------
  validate_request_contract(operation, params) -> list[str]
      Validate request structure. Returns violations list.

  validate_response_contract(operation, envelope) -> list[str]
      Validate response structure. Returns violations list.

Raise-on-Error Functions:
------------------------
  require_valid_request(operation, params) -> None
      Raises ContractViolationError if invalid.

  require_valid_response(operation, envelope) -> None
      Raises ContractViolationError if invalid.

Boolean Check Functions:
-----------------------
  is_valid_request(operation, params) -> bool
  is_valid_response(operation, envelope) -> bool

Response Contract:
-----------------
  Required envelope structure:
  {
    "meta": {
      "execution_id": str,
      "status": "success" | "error",
      "operation": str,
      "timestamp_utc": str
    },
    "data": {...} | null,  // required if status=success
    "error": {             // required if status=error
      "error_code": str,
      "message": str
    } | null
  }

Usage:
-----
  from databricks_api_workspace.services.validation import (
      require_valid_request,
      require_valid_response,
      ContractViolationError,
  )

  try:
      require_valid_request(operation, params)
      result = process(params)
      require_valid_response(operation, result)
  except ContractViolationError as e:
      print(f"Contract violated: {e.violations}")
"""
