# Databricks notebook source
# MAGIC %md
# MAGIC # __init__
# MAGIC
# MAGIC **Auto-generated from:** `__init__.py`
# MAGIC **Build timestamp:** 2025-12-22T22:33:16.610584+00:00
# MAGIC **Content hash:** 1b863557cd99
# MAGIC
# MAGIC > Do not edit directly. Make changes in source and rebuild.

# COMMAND ----------

# MAGIC %run ../../services/validation/_settings
# MAGIC %run ../../services/validation/contracts

# COMMAND ----------

"""
databricks_api_workspace.services.validation - Validation service.

Contract validation for request/response structures.

Classes:
    ContractViolationError: Raised when contract violated

Functions:
    validate_request_contract(): Validate request structure
    validate_response_contract(): Validate response structure
    require_valid_request(): Raise if request invalid
    require_valid_response(): Raise if response invalid
    is_valid_request(): Check if request valid
    is_valid_response(): Check if response valid
    help(): Display module usage information

Note:
    Schema validation utilities (load_schema, validate_against_schema, etc.)
    are in databricks_api_workspace.core.validation_utils

Usage:
    >>> from databricks_api_workspace.services.validation import (
    ...     require_valid_request,
    ...     require_valid_response,
    ...     ContractViolationError,
    ... )
"""

from __future__ import annotations


__all__ = [
    # Contract validation
    "ContractViolationError",
    "validate_request_contract",
    "validate_response_contract",
    "require_valid_request",
    "require_valid_response",
    "is_valid_request",
    "is_valid_response",
    # Settings (from core)
    "REQUIRED_META_FIELDS",
    "VALID_STATUSES",
    "REQUIRED_ERROR_FIELDS",
    # Help
    "help",
]


def help() -> str:
    """Display module usage information.

    Returns:
        str: Help text with validation service usage.
    """
    return """
databricks_api_workspace.services.validation
================================================

Contract validation service for request/response structures.

Classes:
-------
  ContractViolationError(operation, violations)
      Raised when contract is violated.

Functions:
---------
  validate_request_contract(operation, params) -> list[str]
      Validate request structure. Returns violations list.

  validate_response_contract(operation, envelope) -> list[str]
      Validate response structure. Returns violations list.

  require_valid_request(operation, params) -> None
      Raises ContractViolationError if invalid.

  require_valid_response(operation, envelope) -> None
      Raises ContractViolationError if invalid.

  is_valid_request(operation, params) -> bool
  is_valid_response(operation, envelope) -> bool

Schema Validation:
-----------------
  For JSON Schema validation, see databricks_api_workspace.core.validation_utils:
  - load_schema()
  - validate_against_schema()
  - ValidationError
  - run_validation()
  - run_all_validations()

Usage:
-----
  from databricks_api_workspace.services.validation import (
      require_valid_request,
      require_valid_response,
      ContractViolationError,
  )
  from databricks_api_workspace.core.validation_utils import (
      load_schema,
      validate_against_schema,
  )

  # Contract validation
  try:
      require_valid_request(operation, params)
      result = process(params)
      require_valid_response(operation, result)
  except ContractViolationError as e:
      print(f"Contract violated: {e.violations}")

  # Schema validation
  schema = load_schema("/path/to/schema.json")
  errors = validate_against_schema(data, schema)
"""
