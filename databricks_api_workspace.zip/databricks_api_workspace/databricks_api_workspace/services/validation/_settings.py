# Databricks notebook source
# MAGIC %md
# MAGIC # _settings
# MAGIC
# MAGIC **Auto-generated from:** `_settings.py`
# MAGIC **Build timestamp:** 2025-12-22T22:33:16.609221+00:00
# MAGIC **Content hash:** b93a21c7b291
# MAGIC
# MAGIC > Do not edit directly. Make changes in source and rebuild.

# COMMAND ----------

# MAGIC %run ../../core/validation_utils/_settings

# COMMAND ----------

"""
databricks_api_workspace.services.validation.settings - Validation service configuration.

Re-exports validation constants from core/validation_utils.
Service-specific settings can be added here if needed.

Note:
    Core validation constants (TYPE_MAP, REQUIRED_META_FIELDS, etc.)
    are in databricks_api_workspace.core.validation_utils.settings
"""

from __future__ import annotations


__all__ = [
    "REQUIRED_META_FIELDS",
    "VALID_STATUSES",
    "REQUIRED_ERROR_FIELDS",
]
