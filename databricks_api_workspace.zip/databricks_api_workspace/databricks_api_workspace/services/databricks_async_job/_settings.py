# Databricks notebook source
# MAGIC %md
# MAGIC # _settings
# MAGIC
# MAGIC **Auto-generated from:** `_settings.py`
# MAGIC **Build timestamp:** 2025-12-22T22:33:16.621226+00:00
# MAGIC **Content hash:** 172025622a15
# MAGIC
# MAGIC > Do not edit directly. Make changes in source and rebuild.

# COMMAND ----------

"""
databricks_api_workspace.services.databricks_async_job.settings - Async job configuration.

Single source of truth for async job settings.

Constants:
    DEFAULT_ASYNC_JOBS_TABLE: Default Delta table name
    CONFIG_KEY_ASYNC_JOBS_TABLE: Config key for table name
    DEFAULT_ESTIMATED_WAIT_SECONDS: Default estimated wait time
    DEFAULT_CLEANUP_RETENTION_DAYS: Default cleanup retention period
    DEFAULT_LIST_LIMIT: Default job listing limit
"""

from __future__ import annotations

__all__ = [
    "DEFAULT_ASYNC_JOBS_TABLE",
    "CONFIG_KEY_ASYNC_JOBS_TABLE",
    "DEFAULT_ESTIMATED_WAIT_SECONDS",
    "DEFAULT_CLEANUP_RETENTION_DAYS",
    "DEFAULT_LIST_LIMIT",
]

# Default table for async job records
DEFAULT_ASYNC_JOBS_TABLE: str = "databricks_api_workspace.async_jobs"

# Config key for async jobs table
CONFIG_KEY_ASYNC_JOBS_TABLE: str = "tables.async_jobs"

# Default estimated wait time in seconds
DEFAULT_ESTIMATED_WAIT_SECONDS: int = 30

# Default cleanup retention in days
DEFAULT_CLEANUP_RETENTION_DAYS: int = 30

# Default job listing limit
DEFAULT_LIST_LIMIT: int = 20
