# Databricks notebook source
# MAGIC %md
# MAGIC # models
# MAGIC
# MAGIC **Auto-generated from:** `models.py`
# MAGIC **Build timestamp:** 2025-12-22T22:33:16.616370+00:00
# MAGIC **Content hash:** 24d692206ef7
# MAGIC
# MAGIC > Do not edit directly. Make changes in source and rebuild.

# COMMAND ----------

"""
databricks_api_workspace.services.databricks_async_job.models - Async job models.

AsyncStatus enum, AsyncJobRecord dataclass, AsyncJobResponse.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime, timezone
from enum import Enum
from typing import Any

__all__ = [
    "AsyncStatus",
    "TERMINAL_STATUSES",
    "is_terminal_status",
    "AsyncJobRecord",
    "AsyncJobResponse",
]


class AsyncStatus(str, Enum):
    """Status of an async operation."""

    PENDING = "PENDING"  # Job submitted, not yet started
    RUNNING = "RUNNING"  # Job is executing
    COMPLETED = "COMPLETED"  # Job finished successfully
    FAILED = "FAILED"  # Job finished with error
    CANCELLED = "CANCELLED"  # Job was cancelled
    TIMEOUT = "TIMEOUT"  # Job exceeded time limit


# Terminal states where job is done
TERMINAL_STATUSES = {
    AsyncStatus.COMPLETED,
    AsyncStatus.FAILED,
    AsyncStatus.CANCELLED,
    AsyncStatus.TIMEOUT,
}


def is_terminal_status(status: AsyncStatus | str) -> bool:
    """Check if status is a terminal (final) state.

    Args:
        status: Status to check.

    Returns:
        True if job has finished (success or failure).
    """
    if isinstance(status, str):
        status = AsyncStatus(status)
    return status in TERMINAL_STATUSES


@dataclass
class AsyncJobRecord:
    """Record for tracking async job execution.

    Stored in Delta table databricks_api_workspace.async_jobs.
    """

    job_id: str
    operation: str
    status: AsyncStatus
    created_at: datetime
    user_id: str | None = None
    correlation_id: str | None = None
    params_json: str | None = None
    result_json: str | None = None
    error_code: str | None = None
    error_message: str | None = None
    started_at: datetime | None = None
    completed_at: datetime | None = None
    databricks_run_id: int | None = None
    metadata: dict[str, Any] = field(default_factory=dict)

    @classmethod
    def create(
        cls,
        job_id: str,
        operation: str,
        user_id: str | None = None,
        correlation_id: str | None = None,
        params_json: str | None = None,
    ) -> AsyncJobRecord:
        """Create a new pending job record.

        Args:
            job_id: Unique job identifier.
            operation: Operation name.
            user_id: User who submitted the job.
            correlation_id: Request correlation ID.
            params_json: JSON-encoded request parameters.

        Returns:
            New AsyncJobRecord in PENDING status.
        """
        return cls(
            job_id=job_id,
            operation=operation,
            status=AsyncStatus.PENDING,
            created_at=datetime.now(timezone.utc),
            user_id=user_id,
            correlation_id=correlation_id,
            params_json=params_json,
        )

    def mark_running(self, databricks_run_id: int | None = None) -> None:
        """Mark job as running.

        Args:
            databricks_run_id: Databricks job run ID if applicable.
        """
        self.status = AsyncStatus.RUNNING
        self.started_at = datetime.now(timezone.utc)
        if databricks_run_id is not None:
            self.databricks_run_id = databricks_run_id

    def mark_completed(self, result_json: str) -> None:
        """Mark job as completed successfully.

        Args:
            result_json: JSON-encoded result envelope.
        """
        self.status = AsyncStatus.COMPLETED
        self.completed_at = datetime.now(timezone.utc)
        self.result_json = result_json

    def mark_failed(self, error_code: str, error_message: str) -> None:
        """Mark job as failed.

        Args:
            error_code: Error code.
            error_message: Error description.
        """
        self.status = AsyncStatus.FAILED
        self.completed_at = datetime.now(timezone.utc)
        self.error_code = error_code
        self.error_message = error_message

    def mark_cancelled(self) -> None:
        """Mark job as cancelled."""
        self.status = AsyncStatus.CANCELLED
        self.completed_at = datetime.now(timezone.utc)

    def mark_timeout(self) -> None:
        """Mark job as timed out."""
        self.status = AsyncStatus.TIMEOUT
        self.completed_at = datetime.now(timezone.utc)
        self.error_code = "OPERATION_TIMEOUT"
        self.error_message = "Operation exceeded time limit"

    @property
    def is_terminal(self) -> bool:
        """Check if job is in terminal state."""
        return is_terminal_status(self.status)

    @property
    def duration_ms(self) -> int | None:
        """Get job duration in milliseconds.

        Returns:
            Duration if job is complete, None otherwise.
        """
        if self.started_at is None or self.completed_at is None:
            return None
        delta = self.completed_at - self.started_at
        return int(delta.total_seconds() * 1000)

    def to_dict(self) -> dict[str, Any]:
        """Convert to dictionary for Delta storage.

        Returns:
            Dictionary representation of job record.
        """
        return {
            "job_id": self.job_id,
            "operation": self.operation,
            "status": self.status.value,
            "created_at": self.created_at.isoformat(),
            "user_id": self.user_id,
            "correlation_id": self.correlation_id,
            "params_json": self.params_json,
            "result_json": self.result_json,
            "error_code": self.error_code,
            "error_message": self.error_message,
            "started_at": self.started_at.isoformat() if self.started_at else None,
            "completed_at": self.completed_at.isoformat() if self.completed_at else None,
            "databricks_run_id": self.databricks_run_id,
            "metadata": self.metadata,
        }

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> AsyncJobRecord:
        """Create from dictionary (Delta query result).

        Args:
            data: Dictionary with job data.

        Returns:
            AsyncJobRecord instance.
        """

        def parse_datetime(val: Any) -> datetime | None:
            if val is None:
                return None
            if isinstance(val, datetime):
                return val
            return datetime.fromisoformat(val)

        return cls(
            job_id=data["job_id"],
            operation=data["operation"],
            status=AsyncStatus(data["status"]),
            created_at=parse_datetime(data["created_at"]) or datetime.now(timezone.utc),
            user_id=data.get("user_id"),
            correlation_id=data.get("correlation_id"),
            params_json=data.get("params_json"),
            result_json=data.get("result_json"),
            error_code=data.get("error_code"),
            error_message=data.get("error_message"),
            started_at=parse_datetime(data.get("started_at")),
            completed_at=parse_datetime(data.get("completed_at")),
            databricks_run_id=data.get("databricks_run_id"),
            metadata=data.get("metadata") or {},
        )


@dataclass
class AsyncJobResponse:
    """Response returned when submitting an async job."""

    job_id: str
    status: AsyncStatus
    operation: str
    estimated_wait_seconds: int | None = None
    poll_url: str | None = None

    def to_dict(self) -> dict[str, Any]:
        """Convert to response dictionary."""
        result: dict[str, Any] = {
            "job_id": self.job_id,
            "status": self.status.value,
            "operation": self.operation,
        }
        if self.estimated_wait_seconds is not None:
            result["estimated_wait_seconds"] = self.estimated_wait_seconds
        if self.poll_url is not None:
            result["poll_url"] = self.poll_url
        return result
