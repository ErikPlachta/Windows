# Databricks notebook source
# MAGIC %md
# MAGIC # storage
# MAGIC
# MAGIC **Auto-generated from:** `storage.py`
# MAGIC **Build timestamp:** 2025-12-22T22:33:16.620103+00:00
# MAGIC **Content hash:** 0a132058a62d
# MAGIC
# MAGIC > Do not edit directly. Make changes in source and rebuild.

# COMMAND ----------

# MAGIC %run ../../core/config/_init
# MAGIC %run ../../core/logging/_init
# MAGIC %run ../../core/runtime/_init
# MAGIC %run ../../core/sql_utils/_init
# MAGIC %run ../../services/databricks_async_job/_settings
# MAGIC %run ../../services/databricks_async_job/models

# COMMAND ----------

"""
databricks_api_workspace.services.databricks_async_job.storage - Job storage.

Internal helpers for persisting job records to Delta tables.
"""

from __future__ import annotations

import json
from typing import TYPE_CHECKING


if TYPE_CHECKING:
    pass

__all__ = [
    "save_job_record",
    "load_job_record",
]


def save_job_record(record: AsyncJobRecord) -> None:
    """Save job record to Delta table.

    Args:
        record: Job record to save.
    """
    table = safe_sql_identifier(
        get_config_value(CONFIG_KEY_ASYNC_JOBS_TABLE, DEFAULT_ASYNC_JOBS_TABLE)
    )
    spark = get_spark()

    try:
        data = record.to_dict()
        # Convert metadata dict to JSON string for storage
        data["metadata"] = json.dumps(data.get("metadata", {}))

        from mocks.spark_mock import Row

        df = spark.createDataFrame([Row(**data)])
        df.write.format("delta").mode("append").option("mergeSchema", "true").saveAsTable(table)
    except Exception as e:  # pragma: no cover
        log_error("Failed to save job record", job_id=record.job_id, error=str(e))
        raise


def load_job_record(job_id: str) -> AsyncJobRecord | None:
    """Load job record from Delta table.

    Args:
        job_id: Job identifier.

    Returns:
        Job record or None if not found.
    """
    table = safe_sql_identifier(
        get_config_value(CONFIG_KEY_ASYNC_JOBS_TABLE, DEFAULT_ASYNC_JOBS_TABLE)
    )
    spark = get_spark()
    safe_job_id = escape_sql_string(job_id)

    try:
        row = spark.sql(f"""
            SELECT *
            FROM {table}
            WHERE job_id = '{safe_job_id}'
            ORDER BY created_at DESC
            LIMIT 1
        """).first()

        if row is None:
            return None

        data = row.asDict()
        # Parse metadata JSON
        if isinstance(data.get("metadata"), str):
            data["metadata"] = json.loads(data["metadata"])

        return AsyncJobRecord.from_dict(data)
    except Exception as e:  # pragma: no cover
        log_warning("Failed to load job record", job_id=job_id, error=str(e))
        return None
