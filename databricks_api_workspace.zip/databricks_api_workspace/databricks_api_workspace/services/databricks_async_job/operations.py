# Databricks notebook source
# MAGIC %md
# MAGIC # operations
# MAGIC
# MAGIC **Auto-generated from:** `operations.py`
# MAGIC **Build timestamp:** 2025-12-22T22:33:16.618417+00:00
# MAGIC **Content hash:** f07e3bff73fc
# MAGIC
# MAGIC > Do not edit directly. Make changes in source and rebuild.

# COMMAND ----------

# MAGIC %run ../../core/config/_init
# MAGIC %run ../../core/errors/_init
# MAGIC %run ../../core/logging/_init
# MAGIC %run ../../core/runtime/_init
# MAGIC %run ../../core/sql_utils/_init
# MAGIC %run ../../services/databricks_async_job/_settings
# MAGIC %run ../../services/databricks_async_job/models
# MAGIC %run ../../services/databricks_async_job/storage
# MAGIC %run ../../services/auth/_init

# COMMAND ----------

"""
databricks_api_workspace.services.databricks_async_job.operations - Job operations.

Submit, query, update, and manage async jobs.
"""

from __future__ import annotations

import json
import uuid
from typing import TYPE_CHECKING, Any


if TYPE_CHECKING:

__all__ = [
    "generate_job_id",
    "submit_async_operation",
    "get_async_status",
    "get_async_result",
    "get_job_record",
    "update_job_status",
    "cancel_job",
    "list_user_jobs",
    "cleanup_old_jobs",
]


def generate_job_id() -> str:
    """Generate unique job ID.

    Returns:
        UUID-based job identifier.
    """
    return f"job-{uuid.uuid4().hex[:16]}"


def submit_async_operation(
    operation: str,
    params: dict[str, Any],
    user_context: UserContext | None = None,
    correlation_id: str | None = None,
) -> AsyncJobResponse:
    """Submit an operation for async execution.

    Creates a job record and returns immediately with job ID.
    Actual execution happens via Databricks Jobs API.

    Args:
        operation: Operation name.
        params: Request parameters.
        user_context: User submitting the job.
        correlation_id: Request correlation ID.

    Returns:
        AsyncJobResponse with job ID and status.
    """
    job_id = generate_job_id()

    # Create job record
    record = AsyncJobRecord.create(
        job_id=job_id,
        operation=operation,
        user_id=user_context.user_id if user_context else None,
        correlation_id=correlation_id,
        params_json=json.dumps(params, default=str),
    )

    # Save to Delta table
    save_job_record(record)

    log_info(
        "Async job submitted",
        job_id=job_id,
        operation=operation,
        user_id=record.user_id,
    )

    # Get estimated wait time from config
    try:

        op_config = get_operation_config(operation)
        estimated_wait = op_config.get("estimated_duration_seconds", DEFAULT_ESTIMATED_WAIT_SECONDS)
    except ValueError:
        estimated_wait = DEFAULT_ESTIMATED_WAIT_SECONDS

    return AsyncJobResponse(
        job_id=job_id,
        status=AsyncStatus.PENDING,
        operation=operation,
        estimated_wait_seconds=estimated_wait,
    )


def get_async_status(job_id: str) -> AsyncStatus:
    """Get current status of an async job.

    Args:
        job_id: Job identifier.

    Returns:
        Current job status.

    Raises:
        NotFoundError: If job doesn't exist.
    """
    record = load_job_record(job_id)
    if record is None:
        raise NotFoundError("async_job", job_id)
    return record.status


def get_async_result(job_id: str) -> dict[str, Any]:
    """Get result of completed async job.

    Args:
        job_id: Job identifier.

    Returns:
        Result envelope if job completed, status info otherwise.

    Raises:
        NotFoundError: If job doesn't exist.
    """
    record = load_job_record(job_id)
    if record is None:
        raise NotFoundError("async_job", job_id)

    result: dict[str, Any] = {
        "job_id": job_id,
        "status": record.status.value,
        "operation": record.operation,
    }

    if record.status == AsyncStatus.COMPLETED and record.result_json:
        result["result"] = json.loads(record.result_json)
    elif record.status == AsyncStatus.FAILED:
        result["error"] = {
            "error_code": record.error_code,
            "message": record.error_message,
        }

    if record.duration_ms is not None:
        result["duration_ms"] = record.duration_ms

    return result


def get_job_record(job_id: str) -> AsyncJobRecord | None:
    """Get full job record.

    Args:
        job_id: Job identifier.

    Returns:
        Job record or None if not found.
    """
    return load_job_record(job_id)


def update_job_status(
    job_id: str,
    status: AsyncStatus,
    result_json: str | None = None,
    error_code: str | None = None,
    error_message: str | None = None,
    databricks_run_id: int | None = None,
) -> None:
    """Update job status.

    Called by executor to update job progress.

    Args:
        job_id: Job identifier.
        status: New status.
        result_json: Result JSON if completed.
        error_code: Error code if failed.
        error_message: Error message if failed.
        databricks_run_id: Databricks run ID if available.
    """
    record = load_job_record(job_id)
    if record is None:
        log_error("Job not found for status update", job_id=job_id)
        return

    if status == AsyncStatus.RUNNING:
        record.mark_running(databricks_run_id)
    elif status == AsyncStatus.COMPLETED and result_json:
        record.mark_completed(result_json)
    elif status == AsyncStatus.FAILED:
        record.mark_failed(
            error_code or ErrorCode.INTERNAL_ERROR.value,
            error_message or "Unknown error",
        )
    elif status == AsyncStatus.CANCELLED:
        record.mark_cancelled()
    elif status == AsyncStatus.TIMEOUT:
        record.mark_timeout()
    else:
        record.status = status

    save_job_record(record)

    log_info(
        "Job status updated",
        job_id=job_id,
        status=status.value,
    )


def cancel_job(job_id: str) -> bool:
    """Cancel a pending or running job.

    Args:
        job_id: Job identifier.

    Returns:
        True if job was cancelled, False if already terminal.
    """
    record = load_job_record(job_id)
    if record is None:
        return False

    if record.is_terminal:
        return False

    record.mark_cancelled()
    save_job_record(record)

    log_info("Job cancelled", job_id=job_id)
    return True


def list_user_jobs(
    user_id: str,
    status: AsyncStatus | None = None,
    limit: int = DEFAULT_LIST_LIMIT,
) -> list[dict[str, Any]]:
    """List jobs for a user.

    Args:
        user_id: User ID to filter by.
        status: Optional status filter.
        limit: Maximum results.

    Returns:
        List of job summaries.
    """
    table = safe_sql_identifier(
        get_config_value(CONFIG_KEY_ASYNC_JOBS_TABLE, DEFAULT_ASYNC_JOBS_TABLE)
    )
    spark = get_spark()

    safe_user_id = escape_sql_string(user_id)
    conditions = [f"user_id = '{safe_user_id}'"]
    if status:
        safe_status = escape_sql_string(status.value)
        conditions.append(f"status = '{safe_status}'")

    where_clause = " AND ".join(conditions)
    query = f"""
        SELECT job_id, operation, status, created_at, completed_at
        FROM {table}
        WHERE {where_clause}
        ORDER BY created_at DESC
        LIMIT {limit}
    """

    try:
        rows = spark.sql(query).collect()
        return [row.asDict() for row in rows]
    except Exception:
        return []


def cleanup_old_jobs(days: int = DEFAULT_CLEANUP_RETENTION_DAYS) -> int:
    """Clean up old completed jobs.

    Args:
        days: Delete jobs older than this many days.

    Returns:
        Number of jobs deleted.
    """
    table = safe_sql_identifier(
        get_config_value(CONFIG_KEY_ASYNC_JOBS_TABLE, DEFAULT_ASYNC_JOBS_TABLE)
    )
    spark = get_spark()

    # Only delete terminal jobs
    terminal_statuses = ", ".join(
        f"'{s.value}'" for s in [AsyncStatus.COMPLETED, AsyncStatus.FAILED, AsyncStatus.CANCELLED]
    )

    query = f"""
        DELETE FROM {table}
        WHERE status IN ({terminal_statuses})
        AND created_at < date_sub(current_date(), {days})
    """

    try:
        spark.sql(query)
        log_info("Old jobs cleaned up", days=days)
        return 0  # Delta doesn't return affected row count easily
    except Exception as e:
        log_error("Failed to cleanup old jobs", error=str(e))
        return 0
