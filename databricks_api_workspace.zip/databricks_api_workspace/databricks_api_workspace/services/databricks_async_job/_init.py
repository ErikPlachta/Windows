# Databricks notebook source
# MAGIC %md
# MAGIC # __init__
# MAGIC
# MAGIC **Auto-generated from:** `__init__.py`
# MAGIC **Build timestamp:** 2025-12-22T22:33:16.622958+00:00
# MAGIC **Content hash:** e40ea0d77a72
# MAGIC
# MAGIC > Do not edit directly. Make changes in source and rebuild.

# COMMAND ----------

# MAGIC %run ../../services/databricks_async_job/_settings
# MAGIC %run ../../services/databricks_async_job/models
# MAGIC %run ../../services/databricks_async_job/operations

# COMMAND ----------

"""
databricks_api_workspace.services.databricks_async_job - Async job management service.

Submit and track async operations via Databricks Jobs API.

Classes:
    AsyncStatus: Job status enumeration
    AsyncJobRecord: Job tracking record dataclass
    AsyncJobResponse: Response from job submission

Functions:
    generate_job_id(): Generate unique job identifier
    submit_async_operation(): Submit operation for async execution
    get_async_status(): Get current job status
    get_async_result(): Get completed job result
    get_job_record(): Get full job record
    update_job_status(): Update job status
    cancel_job(): Cancel pending/running job
    list_user_jobs(): List jobs for a user
    cleanup_old_jobs(): Clean up old completed jobs
    is_terminal_status(): Check if status is terminal
    help(): Display module usage information

Example:
    >>> from databricks_api_workspace.services.databricks_async_job import (
    ...     submit_async_operation,
    ...     get_async_result,
    ... )
    >>> response = submit_async_operation("run_report", {"id": 123})
    >>> result = get_async_result(response.job_id)
"""

from __future__ import annotations


# Re-exports

__all__ = [
    # Models
    "AsyncStatus",
    "AsyncJobRecord",
    "AsyncJobResponse",
    "TERMINAL_STATUSES",
    "is_terminal_status",
    # Operations
    "generate_job_id",
    "submit_async_operation",
    "get_async_status",
    "get_async_result",
    "get_job_record",
    "update_job_status",
    "cancel_job",
    "list_user_jobs",
    "cleanup_old_jobs",
    # Settings
    "DEFAULT_ASYNC_JOBS_TABLE",
    "CONFIG_KEY_ASYNC_JOBS_TABLE",
    "DEFAULT_ESTIMATED_WAIT_SECONDS",
    "DEFAULT_CLEANUP_RETENTION_DAYS",
    "DEFAULT_LIST_LIMIT",
    # Help
    "help",
]


def help() -> str:
    """Display async jobs module usage information.

    Returns:
        str: Help text with all available functions and examples.

    Example:
        >>> from databricks_api_workspace.services import databricks_async_job
        >>> print(databricks_async_job.help())
    """
    return """
databricks_api_workspace.services.databricks_async_job
==========================================================

Submit and track async operations via Databricks Jobs API.

Status Enum:
-----------
  AsyncStatus.PENDING, RUNNING, COMPLETED, FAILED, CANCELLED, TIMEOUT
  TERMINAL_STATUSES - set of terminal states
  is_terminal_status(status) -> bool

Models:
------
  AsyncJobRecord - Job tracking record
    .create(job_id, operation, ...) -> AsyncJobRecord
    .mark_running(databricks_run_id=None)
    .mark_completed(result_json)
    .mark_failed(error_code, error_message)
    .mark_cancelled()
    .mark_timeout()
    .is_terminal -> bool
    .duration_ms -> int | None
    .to_dict() -> dict
    .from_dict(data) -> AsyncJobRecord

  AsyncJobResponse - Response from job submission
    .job_id, .status, .operation, .estimated_wait_seconds, .poll_url
    .to_dict() -> dict

Operations:
----------
  generate_job_id() -> str
  submit_async_operation(operation, params, user_context, correlation_id)
  get_async_status(job_id) -> AsyncStatus
  get_async_result(job_id) -> dict
  get_job_record(job_id) -> AsyncJobRecord | None
  update_job_status(job_id, status, result_json, error_code, error_message)
  cancel_job(job_id) -> bool
  list_user_jobs(user_id, status=None, limit=20) -> list[dict]
  cleanup_old_jobs(days=30) -> int

Quick Start:
-----------
  from databricks_api_workspace.services.databricks_async_job import (
      submit_async_operation, get_async_result, AsyncStatus,
  )
  response = submit_async_operation("run_report", {"id": 123})
  # Poll until complete
  while get_async_status(response.job_id) not in TERMINAL_STATUSES:
      time.sleep(5)
  result = get_async_result(response.job_id)

Submodules:
----------
  _settings - Async job configuration constants
  models - AsyncStatus, AsyncJobRecord, AsyncJobResponse
  operations - Job submission and management
  storage - Delta table persistence
"""
