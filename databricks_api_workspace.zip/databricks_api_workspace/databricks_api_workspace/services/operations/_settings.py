# Databricks notebook source
# MAGIC %md
# MAGIC # _settings
# MAGIC
# MAGIC **Auto-generated from:** `_settings.py`
# MAGIC **Build timestamp:** 2025-12-22T22:33:16.641593+00:00
# MAGIC **Content hash:** 36a925653222
# MAGIC
# MAGIC > Do not edit directly. Make changes in source and rebuild.

# COMMAND ----------

"""Operations configuration constants.

Single source of truth for operation execution settings.
"""

from __future__ import annotations

# Default operation type
DEFAULT_OPERATION_TYPE = "legacy"

# Default notebook path pattern
DEFAULT_NOTEBOOK_PATH_PATTERN = "./operations/{operation}"

# Default operation timeout in seconds
DEFAULT_TIMEOUT_SECONDS = 300
