# Databricks notebook source
# MAGIC %md
# MAGIC # context
# MAGIC
# MAGIC **Auto-generated from:** `context.py`
# MAGIC **Build timestamp:** 2025-12-22T22:33:16.636458+00:00
# MAGIC **Content hash:** c507d7ba7273
# MAGIC
# MAGIC > Do not edit directly. Make changes in source and rebuild.

# COMMAND ----------

"""Base class and dataclasses for operation handlers.

Provides the plugin interface for complex operations that need
custom business logic beyond simple query→response mapping.

Usage:
    from databricks_api_workspace.services.operations import (
        OperationHandler,
        OperationContext,
        QueryResult,
    )

    class MyHandler(OperationHandler):
        def execute(self, context, query_results):
            # Custom logic here
            return {"result": "data"}
"""

from __future__ import annotations

from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from typing import Any


@dataclass
class OperationContext:
    """Context passed to operation handlers.

    Attributes:
        operation: Operation name.
        params: Request parameters.
        user_id: User identifier.
        user_email: User email (optional).
        user_roles: List of user roles.
        correlation_id: Request correlation ID (optional).
        config: Operation config dict from config file.
    """

    operation: str
    params: dict[str, Any]
    user_id: str
    user_email: str | None = None
    user_roles: list[str] = field(default_factory=list)
    correlation_id: str | None = None
    config: dict[str, Any] = field(default_factory=dict)


@dataclass
class QueryResult:
    """Result from a query execution.

    Attributes:
        name: Query name that was executed.
        data: List of row dictionaries.
        row_count: Number of rows returned.
    """

    name: str
    data: list[dict[str, Any]]
    row_count: int

    @property
    def first(self) -> dict[str, Any] | None:
        """Get first row or None."""
        return self.data[0] if self.data else None

    @property
    def is_empty(self) -> bool:
        """Check if result has no rows."""
        return self.row_count == 0


class OperationHandler(ABC):
    """Base class for operation handlers.

    Implement this class for operations with complex business logic
    that can't be expressed purely through config.

    Example:
        class RiskReportHandler(OperationHandler):
            def execute(self, context, query_results):
                metrics = query_results.get("customer_metrics")
                score = self._calculate_score(metrics)
                return {"risk_score": score}

            def _calculate_score(self, metrics):
                # Complex logic here
                return 50.0
    """

    @abstractmethod
    def execute(
        self,
        context: OperationContext,
        query_results: dict[str, QueryResult],
    ) -> dict[str, Any]:
        """Execute operation logic.

        Args:
            context: Operation context with params and user info.
            query_results: Pre-executed query results keyed by result_key.

        Returns:
            Operation result data (will be wrapped in response envelope).
        """
        pass

    def validate_params(self, params: dict[str, Any]) -> list[str]:
        """Optional: Additional param validation beyond schema.

        Override to add custom validation logic.

        Args:
            params: Request parameters.

        Returns:
            List of validation error messages (empty if valid).
        """
        return []

    def pre_query_transform(
        self,
        context: OperationContext,
    ) -> dict[str, Any]:
        """Optional: Transform params before query execution.

        Override to modify parameters before queries run.

        Args:
            context: Operation context.

        Returns:
            Modified params dict.
        """
        return context.params
