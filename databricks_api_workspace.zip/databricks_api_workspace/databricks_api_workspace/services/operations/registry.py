# Databricks notebook source
# MAGIC %md
# MAGIC # registry
# MAGIC
# MAGIC **Auto-generated from:** `registry.py`
# MAGIC **Build timestamp:** 2025-12-22T22:33:16.640586+00:00
# MAGIC **Content hash:** c7dd429f6ee3
# MAGIC
# MAGIC > Do not edit directly. Make changes in source and rebuild.

# COMMAND ----------

# MAGIC %run ../../core/config/_init
# MAGIC %run ../../core/logging/_init
# MAGIC %run ../../services/operations/_settings
# MAGIC %run ../../services/operations/context
# MAGIC %run ../../services/operations/handlers/factory

# COMMAND ----------

"""Operation registry for data-driven execution.

Provides functions to detect operation type, load handlers,
and retrieve execution configuration from operation configs.

Usage:
    from databricks_api_workspace.services.operations import (
        get_operation_type,
        load_handler,
        get_query_config,
    )

    op_type = get_operation_type("get_customer_detail")  # "simple", "plugin", or "legacy"
    handler = load_handler("run_risk_report")  # Returns OperationHandler instance
    queries = get_query_config("get_customer_detail")  # List of query configs
"""

from __future__ import annotations

import importlib
from typing import TYPE_CHECKING, Any


if TYPE_CHECKING:

# Handler class cache (module_path:ClassName -> class)
_handler_cache: dict[str, type[OperationHandler]] = {}


def get_operation_type(operation: str) -> str:
    """Get operation type from config.

    Args:
        operation: Operation name.

    Returns:
        Operation type: "simple", "plugin", or "legacy" (default).
    """
    try:
        config = get_operation_config(operation)
        op_type = config.get("type", DEFAULT_OPERATION_TYPE)
        log_debug("Operation type resolved", operation=operation, type=op_type)
        return op_type
    except ValueError:
        # Operation not in config - treat as legacy
        return DEFAULT_OPERATION_TYPE


def load_handler(operation: str) -> OperationHandler | None:
    """Load handler for plugin-type operations.

    Supports two handler specification methods:
    1. handler_type + handler_config: Uses generic handler factory
    2. handler (explicit): Uses module.path:ClassName reference

    Args:
        operation: Operation name.

    Returns:
        Handler instance, or None if not a plugin operation.

    Raises:
        ImportError: If handler module can't be imported.
        AttributeError: If handler class not found in module.
        ValueError: If handler_type is unknown or handler ref is invalid.
    """
    config = get_operation_config(operation)
    execution = config.get("execution", {})

    # Check for generic handler_type first (new pattern)
    handler_type = execution.get("handler_type")
    if handler_type:
        handler_config = execution.get("handler_config", {})
        log_debug(
            "Loading generic handler",
            operation=operation,
            handler_type=handler_type,
        )
        return _load_generic_handler(handler_type, handler_config)

    # Fall back to explicit handler reference (backward compat)
    handler_ref = execution.get("handler")
    if not handler_ref:
        log_debug("No handler defined", operation=operation)
        return None

    return _load_explicit_handler(handler_ref)


def _load_generic_handler(
    handler_type: str,
    handler_config: dict[str, Any],
) -> OperationHandler:
    """Load a generic handler by type using factory.

    Args:
        handler_type: Handler type string (e.g., "score_aggregator").
        handler_config: Handler-specific configuration.

    Returns:
        Instantiated handler.
    """

    return create_handler(handler_type, handler_config)


def _load_explicit_handler(handler_ref: str) -> OperationHandler:
    """Load handler by explicit module:class reference.

    Args:
        handler_ref: Reference in format "module.path:ClassName".

    Returns:
        Instantiated handler.
    """
    # Check cache first
    if handler_ref in _handler_cache:
        log_debug("Handler loaded from cache", handler=handler_ref)
        return _handler_cache[handler_ref]()

    # Parse handler reference: "module.path:ClassName"
    if ":" not in handler_ref:
        raise ValueError(
            f"Invalid handler reference '{handler_ref}'. Expected format: 'module.path:ClassName'"
        )

    module_path, class_name = handler_ref.rsplit(":", 1)

    log_debug("Loading handler", module=module_path, class_name=class_name)

    module = importlib.import_module(module_path)
    handler_class = getattr(module, class_name)

    # Cache the class
    _handler_cache[handler_ref] = handler_class

    return handler_class()


def get_query_config(operation: str) -> list[dict[str, Any]]:
    """Get query configuration for operation.

    Args:
        operation: Operation name.

    Returns:
        List of query config dicts, each with:
            - name: Query name
            - params_map: Param name mapping
            - result_key: Key for result in results dict
            - condition: Optional condition expression
    """
    config = get_operation_config(operation)
    execution = config.get("execution", {})
    queries = execution.get("queries", [])

    log_debug("Query config loaded", operation=operation, query_count=len(queries))
    return queries


def get_response_mapping(operation: str) -> dict[str, str]:
    """Get response mapping config.

    Args:
        operation: Operation name.

    Returns:
        Dict mapping response field names to expressions.
    """
    config = get_operation_config(operation)
    execution = config.get("execution", {})
    mapping = execution.get("response_mapping", {})

    log_debug("Response mapping loaded", operation=operation, field_count=len(mapping))
    return mapping


def clear_handler_cache() -> None:
    """Clear the handler class cache.

    Useful for testing or reloading handlers.
    """
    global _handler_cache
    _handler_cache = {}
    log_debug("Handler cache cleared")
