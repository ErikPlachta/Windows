# Databricks notebook source
# MAGIC %md
# MAGIC # __init__
# MAGIC
# MAGIC **Auto-generated from:** `__init__.py`
# MAGIC **Build timestamp:** 2025-12-22T22:33:16.642767+00:00
# MAGIC **Content hash:** 6dcee31e62f4
# MAGIC
# MAGIC > Do not edit directly. Make changes in source and rebuild.

# COMMAND ----------

# MAGIC %run ../../services/operations/context
# MAGIC %run ../../services/operations/executor
# MAGIC %run ../../services/operations/handlers/_init
# MAGIC %run ../../services/operations/registry

# COMMAND ----------

"""
databricks_api_workspace.services.operations - Operation execution framework.

Data-driven operation execution with config-based routing:
- simple: Config-driven query execution + response mapping
- plugin: Config + custom Python handler

Classes:
    OperationContext: Context passed to handlers
    QueryResult: Result from query execution
    OperationHandler: Base class for custom handlers (ABC)
    GenericHandler: Base class for config-driven handlers

Functions:
    execute_operation(): Execute operation based on type
    get_operation_type(): Get operation type from config
    load_handler(): Load handler for plugin operations
    get_query_config(): Get query configuration
    get_response_mapping(): Get response mapping config
    clear_handler_cache(): Clear handler cache
    create_handler(): Create handler by type
    register_handler_type(): Register custom handler type
    help(): Display module usage information

Example:
    >>> from databricks_api_workspace.services.operations import (
    ...     execute_operation,
    ...     OperationContext,
    ... )
    >>> result = execute_operation("get_customer", {"id": 123})
"""

from __future__ import annotations

# Re-exports

__all__ = [
    # Context
    "OperationContext",
    "OperationHandler",
    "QueryResult",
    # Executor
    "execute_operation",
    # Registry
    "get_operation_type",
    "load_handler",
    "get_query_config",
    "get_response_mapping",
    "clear_handler_cache",
    # Handlers
    "GenericHandler",
    "create_handler",
    "register_handler_type",
    "HANDLER_TYPES",
    # Executor
    "Executor",
    # Help
    "help",
]


# Also export Executor class for HTTP layer compatibility
class Executor:
    """HTTP-friendly executor interface.

    Provides dict-based I/O for the HTTP layer (router, azure_bridge).

    Examples:
        >>> executor = Executor()
        >>> result = executor.execute("get_customer_detail", {"customer_id": "C123"})
    """

    def execute(
        self,
        operation_name: str,
        params: dict,
        debug: bool = False,
    ) -> dict:
        """Execute operation with dict I/O.

        Args:
            operation_name: Name of the operation to execute.
            params: Operation parameters as dict.
            debug: Enable debug mode.

        Returns:
            Result dict (not wrapped in envelope).
        """
        correlation_id = "debug" if debug else None
        user_context = {"user_id": "executor", "roles": []}
        if correlation_id:
            params = dict(params)
            params["_correlation_id"] = correlation_id

        return execute_operation(
            operation=operation_name,
            params=params,
            user_context=user_context,
        )


def help() -> str:
    """Display operations module usage information.

    Returns:
        str: Help text with all available functions and examples.

    Example:
        >>> from databricks_api_workspace.services import operations
        >>> print(operations.help())
    """
    return """
databricks_api_workspace.services.operations
=======================================

Data-driven operation execution framework.

Operation Types:
---------------
  simple - Config-driven query execution + response mapping
  plugin - Config + custom Python handler
  legacy - Module-based execution (default)

Context Classes:
---------------
  OperationContext(operation, params, user_id, user_email, user_roles, ...)
  QueryResult(name, data, row_count)
    .first -> dict | None
    .is_empty -> bool

Handler Base Classes:
--------------------
  OperationHandler (ABC)
    .execute(context, query_results) -> dict
    .validate_params(params) -> list[str]
    .pre_query_transform(context) -> dict

  GenericHandler(handler_config)
    ._get_config_value(key_path, default) -> Any
    ._eval_condition(condition, context) -> Any
    ._eval_template(template, context) -> str

Execution:
---------
  execute_operation(operation, params, user_context) -> dict

Registry:
--------
  get_operation_type(operation) -> str
  load_handler(operation) -> OperationHandler | None
  get_query_config(operation) -> list[dict]
  get_response_mapping(operation) -> dict
  clear_handler_cache() -> None

Handler Factory:
---------------
  create_handler(handler_type, handler_config) -> GenericHandler
  register_handler_type(type_name, handler_class) -> None
  HANDLER_TYPES - dict of registered handlers

Quick Start:
-----------
  from databricks_api_workspace.services.operations import execute_operation

  result = execute_operation(
      "get_customer_detail",
      {"customer_id": "123"},
      {"user_id": "user1", "roles": ["reader"]}
  )

Submodules:
----------
  _settings - Operation configuration constants
  context - OperationContext, QueryResult, OperationHandler
  registry - Operation type detection and handler loading
  executor - Operation execution engine
  handlers - Generic config-driven handlers
"""
