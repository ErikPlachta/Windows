# Databricks notebook source
# MAGIC %md
# MAGIC # executor
# MAGIC
# MAGIC **Auto-generated from:** `executor.py`
# MAGIC **Build timestamp:** 2025-12-22T22:33:16.638798+00:00
# MAGIC **Content hash:** 8a8b13718871
# MAGIC
# MAGIC > Do not edit directly. Make changes in source and rebuild.

# COMMAND ----------

# MAGIC %run ../../core/config/_init
# MAGIC %run ../../core/errors/_init
# MAGIC %run ../../core/logging/_init
# MAGIC %run ../../services/operations/context
# MAGIC %run ../../services/operations/registry
# MAGIC %run ../../services/query/_init
# MAGIC %run ../../core/data_utils/_init

# COMMAND ----------

"""Data-driven operation execution engine.

Routes operations to the appropriate executor based on type:
- simple: Config-driven query execution + response mapping
- plugin: Config + custom Python handler
- legacy: Original module-based execution

Usage:
    from databricks_api_workspace.services.operations import execute_operation

    result = execute_operation(
        operation="get_customer_detail",
        params={"customer_id": "123"},
        user_context={"user_id": "user1", "roles": ["reader"]},
    )
"""

from __future__ import annotations

from typing import Any



def execute_operation(
    operation: str,
    params: dict[str, Any],
    user_context: dict[str, Any] | None = None,
) -> dict[str, Any]:
    """Execute operation based on type.

    Args:
        operation: Operation name.
        params: Request parameters.
        user_context: User context dict with user_id, email, roles.

    Returns:
        Operation result data.

    Raises:
        APIError: If operation execution fails.
        ValueError: If operation type is unknown.
    """
    user_context = user_context or {}
    op_type = get_operation_type(operation)

    log_info(
        "Executing operation",
        operation=operation,
        type=op_type,
        user_id=user_context.get("user_id"),
    )

    if op_type == "simple":
        context = _build_context(operation, params, user_context)
        return _execute_simple(context)
    elif op_type == "plugin":
        context = _build_context(operation, params, user_context)
        return _execute_plugin(context)
    else:
        raise ValueError(f"Unknown operation type: {op_type}")


def _build_context(
    operation: str,
    params: dict[str, Any],
    user_context: dict[str, Any],
) -> OperationContext:
    """Build operation context from params and user context."""
    config = get_operation_config(operation)

    return OperationContext(
        operation=operation,
        params=params,
        user_id=user_context.get("user_id", "unknown"),
        user_email=user_context.get("email"),
        user_roles=user_context.get("roles", []),
        correlation_id=params.get("_correlation_id"),
        config=config,
    )


@handle_errors(error_code=ErrorCode.EXECUTION_ERROR, reraise=True)
def _execute_simple(context: OperationContext) -> dict[str, Any]:
    """Execute simple config-driven operation.

    Runs configured queries, then applies response mapping.

    Args:
        context: Operation context.

    Returns:
        Mapped response dict.
    """
    query_configs = get_query_config(context.operation)
    response_mapping = get_response_mapping(context.operation)

    log_debug(
        "Executing simple operation",
        operation=context.operation,
        query_count=len(query_configs),
    )

    # Execute queries
    results = _execute_queries(query_configs, context.params)

    # Apply response mapping
    return _apply_response_mapping(response_mapping, context.params, results)


@handle_errors(error_code=ErrorCode.EXECUTION_ERROR, reraise=True)
def _execute_plugin(context: OperationContext) -> dict[str, Any]:
    """Execute plugin-based operation.

    Loads handler, runs pre-query transform, executes queries,
    then delegates to handler.execute().

    Args:
        context: Operation context.

    Returns:
        Handler result.

    Raises:
        ValueError: If no handler defined for plugin operation.
    """
    handler = load_handler(context.operation)
    if not handler:
        raise ValueError(f"No handler defined for plugin operation: {context.operation}")

    log_debug(
        "Executing plugin operation",
        operation=context.operation,
        handler=type(handler).__name__,
    )

    # Pre-query transform
    transformed_params = handler.pre_query_transform(context)
    context.params = transformed_params

    # Additional validation
    validation_errors = handler.validate_params(transformed_params)
    if validation_errors:
        log_warning(
            "Handler validation failed",
            operation=context.operation,
            errors=validation_errors,
        )
        return {"success": False, "errors": validation_errors}

    # Execute queries
    query_configs = get_query_config(context.operation)
    query_results = _execute_queries_for_handler(query_configs, transformed_params)

    # Execute handler
    return handler.execute(context, query_results)


def _execute_queries(
    query_configs: list[dict[str, Any]],
    params: dict[str, Any],
) -> dict[str, Any]:
    """Execute configured queries for simple operations.

    Args:
        query_configs: List of query configurations.
        params: Request parameters.

    Returns:
        Dict mapping result_key to list of row dicts.
    """

    results: dict[str, Any] = {}

    for qc in query_configs:
        query_name = qc.get("name")
        if query_name is None:
            log_warning("Query config missing 'name' field, skipping")
            continue
        result_key = qc.get("result_key", query_name)
        assert result_key is not None  # result_key has default, can't be None

        # Check condition if present
        condition = qc.get("condition")
        if condition:
            try:
                if not eval(condition, {"__builtins__": {}, "params": params}):
                    log_debug("Query skipped (condition false)", query=query_name)
                    continue
            except Exception as e:
                log_warning("Condition eval failed", query=query_name, error=str(e))
                continue

        # Map params
        params_map = qc.get("params_map", {})
        query_params = {k: params.get(v) for k, v in params_map.items()}

        log_debug("Executing query", query=query_name, params=query_params)

        try:
            df = execute_query_by_name(query_name, query_params)
            # Convert to list of dicts
            rows = [row.asDict() for row in df.collect()]
            results[result_key] = rows
        except FileNotFoundError:
            # Query file not found - return empty result
            log_warning("Query file not found", query=query_name)
            results[result_key] = []
        except Exception as e:
            log_warning("Query execution failed", query=query_name, error=str(e))
            results[result_key] = []

    return results


def _execute_queries_for_handler(
    query_configs: list[dict[str, Any]],
    params: dict[str, Any],
) -> dict[str, QueryResult]:
    """Execute queries and return QueryResult objects for handlers.

    Args:
        query_configs: List of query configurations.
        params: Request parameters.

    Returns:
        Dict mapping result_key to QueryResult objects.
    """

    results: dict[str, QueryResult] = {}

    for qc in query_configs:
        query_name = qc.get("name")
        if query_name is None:
            log_warning("Query config missing 'name' field, skipping")
            continue
        result_key = qc.get("result_key", query_name)
        assert result_key is not None  # result_key has default, can't be None

        # Map params
        params_map = qc.get("params_map", {})
        query_params = {k: params.get(v) for k, v in params_map.items()}

        log_debug("Executing query for handler", query=query_name)

        try:
            df = execute_query_by_name(query_name, query_params)
            rows = [row.asDict() for row in df.collect()]
            results[result_key] = QueryResult(
                name=query_name,
                data=rows,
                row_count=len(rows),
            )
        except FileNotFoundError:
            log_warning("Query file not found", query=query_name)
            results[result_key] = QueryResult(name=query_name, data=[], row_count=0)
        except Exception as e:
            log_warning("Query execution failed", query=query_name, error=str(e))
            results[result_key] = QueryResult(name=query_name, data=[], row_count=0)

    return results


def _apply_response_mapping(
    mapping: dict[str, str],
    params: dict[str, Any],
    results: dict[str, Any],
) -> dict[str, Any]:
    """Apply response mapping expressions.

    Args:
        mapping: Dict of field_name -> expression.
        params: Request parameters.
        results: Query results.

    Returns:
        Mapped output dict.
    """
    # Import mapper functions

    # Build safe evaluation context
    eval_context = {
        "params": params,
        "results": results,
        # Safe builtins
        "bool": bool,
        "str": str,
        "int": int,
        "float": float,
        "len": len,
        "list": list,
        "dict": dict,
        "None": None,
        "True": True,
        "False": False,
        # Mapper functions
        **MAPPER_FUNCTIONS,
    }

    output: dict[str, Any] = {}

    for key, expr in mapping.items():
        try:
            output[key] = eval(expr, {"__builtins__": {}}, eval_context)
        except Exception as e:
            log_warning("Mapping eval failed", field=key, expr=expr, error=str(e))
            output[key] = None

    return output
