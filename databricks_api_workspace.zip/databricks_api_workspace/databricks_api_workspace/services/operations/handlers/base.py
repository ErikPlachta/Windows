# Databricks notebook source
# MAGIC %md
# MAGIC # base
# MAGIC
# MAGIC **Auto-generated from:** `base.py`
# MAGIC **Build timestamp:** 2025-12-22T22:33:16.650827+00:00
# MAGIC **Content hash:** df9c19ce2c46
# MAGIC
# MAGIC > Do not edit directly. Make changes in source and rebuild.

# COMMAND ----------

# MAGIC %run ../../../services/operations/context

# COMMAND ----------

"""Base class for generic config-driven handlers.

.. deprecated:: 2.0
    This module is deprecated. Use routes/queries architecture instead.
    See: databricks_api_workspace.core.routes, databricks_api_workspace.services.execution

GenericHandler extends OperationHandler with config evaluation utilities,
allowing subclasses to implement behavior driven entirely by config.
"""

from __future__ import annotations

from abc import abstractmethod
from typing import Any


# Safe builtins for config expression evaluation
SAFE_BUILTINS = {
    "True": True,
    "False": False,
    "None": None,
    "bool": bool,
    "int": int,
    "float": float,
    "str": str,
    "len": len,
    "min": min,
    "max": max,
    "sum": sum,
    "abs": abs,
    "round": round,
    "list": list,
    "dict": dict,
    "set": set,
    "tuple": tuple,
    "sorted": sorted,
    "any": any,
    "all": all,
}


class GenericHandler(OperationHandler):
    """Base class for config-driven handlers.

    Subclasses implement specific handler types (score_aggregator, etc.)
    with behavior controlled by handler_config.

    Attributes:
        config: Handler configuration dict from operation config.

    Example:
        class ScoreAggregatorHandler(GenericHandler):
            def execute(self, context, query_results):
                factors = self._get_config_value("scoring.factors_field")
                # Use config-driven logic
    """

    def __init__(self, handler_config: dict[str, Any] | None = None) -> None:
        """Initialize handler with config.

        Args:
            handler_config: Handler-specific configuration dict.
        """
        self.config = handler_config or {}

    def _get_config_value(
        self,
        key_path: str,
        default: Any = None,
    ) -> Any:
        """Get nested config value by dot-separated path.

        Args:
            key_path: Dot-separated path like "scoring.aggregation".
            default: Default value if path not found.

        Returns:
            Config value or default.

        Example:
            self._get_config_value("scoring.factors_field", "factors")
        """
        keys = key_path.split(".")
        value: Any = self.config
        for k in keys:
            if not isinstance(value, dict):
                return default
            value = value.get(k)
            if value is None:
                return default
        return value

    def _eval_condition(
        self,
        condition: str,
        context: dict[str, Any],
    ) -> Any:
        """Safely evaluate a config condition expression.

        Uses restricted eval with safe builtins only.

        Args:
            condition: Expression string to evaluate.
            context: Variables available in expression.

        Returns:
            Evaluation result.

        Raises:
            ValueError: If expression is invalid or unsafe.

        Example:
            result = self._eval_condition(
                "report_type in ['customer', 'portfolio']",
                {"report_type": "customer"}
            )
        """
        if not condition:
            return True

        try:
            # Build safe eval context
            eval_globals = {"__builtins__": SAFE_BUILTINS}
            eval_globals.update(context)
            return eval(condition, eval_globals)
        except Exception as e:
            raise ValueError(f"Invalid condition '{condition}': {e}") from e

    def _eval_template(
        self,
        template: str,
        context: dict[str, Any],
    ) -> str:
        """Evaluate a template string with {var} placeholders.

        Args:
            template: Template string with {var} placeholders.
            context: Variables to substitute.

        Returns:
            Formatted string.

        Example:
            self._eval_template("{factor}_score", {"factor": "credit"})
            # Returns "credit_score"
        """
        try:
            return template.format(**context)
        except KeyError:
            return template

    @abstractmethod
    def execute(
        self,
        context: OperationContext,
        query_results: dict[str, QueryResult],
    ) -> dict[str, Any]:
        """Execute handler logic using config.

        Subclasses must implement this method.

        Args:
            context: Operation context with params and user info.
            query_results: Pre-executed query results.

        Returns:
            Operation result data.
        """
        pass
