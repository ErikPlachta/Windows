# Databricks notebook source
# MAGIC %md
# MAGIC # score_aggregator
# MAGIC
# MAGIC **Auto-generated from:** `score_aggregator.py`
# MAGIC **Build timestamp:** 2025-12-22T22:33:16.654304+00:00
# MAGIC **Content hash:** 2b34307375b7
# MAGIC
# MAGIC > Do not edit directly. Make changes in source and rebuild.

# COMMAND ----------

# MAGIC %run ../../../core/logging/_init
# MAGIC %run ../../../services/operations/context
# MAGIC %run ../../../services/operations/handlers/base
# MAGIC %run ../../../services/operations/handlers/factory

# COMMAND ----------

"""Score aggregator handler for config-driven scoring operations.

Generic handler for operations that:
- Calculate scores from multiple factors
- Classify scores into levels
- Generate indicators based on conditions
- Produce recommendations based on rules

All behavior is driven by handler_config, no hardcoded business logic.

Status: Complete, tested, registered as "score_aggregator" handler type.
"""

from __future__ import annotations

from datetime import datetime, timezone
from typing import Any



class ScoreAggregatorHandler(GenericHandler):
    """Config-driven handler for score aggregation operations.

    Config schema:
        handler_config:
          validation:
            rules:
              - condition: "report_type in ['customer', 'portfolio']"
                required_fields: ["entity_id"]
          scoring:
            factors_field: "risk_factors"
            score_field_pattern: "{factor}_score"
            aggregation: "average"  # or "max", "sum", "min"
            default_score: 50.0
          classification:
            thresholds:
              - {min: 75, level: "high"}
              - {min: 50, level: "medium"}
              - {min: 25, level: "low"}
            default_level: "minimal"
          indicators:
            - condition: "metrics.get('late_payments', 0) > 3"
              type: "late_payments"
              severity: "warning"
              message: "Multiple late payments detected"
          recommendations:
            overall:
              - {min_score: 75, message: "Immediate review recommended"}
              - {min_score: 50, message: "Schedule periodic monitoring"}
            per_factor:
              threshold: 70
              message_pattern: "Address {factor} risk factors"
          report_types:
            customer:
              metrics_key: "customer_metrics"
              id_field: "customer_id"
            portfolio:
              metrics_key: "portfolio_metrics"
              id_field: "portfolio_id"
              extra_fields:
                concentration_risk: {}
            aggregate:
              metrics_key: null
              extra_fields:
                summary: {total_customers_analyzed: 0, high_risk_count: 0}
    """

    def validate_params(self, params: dict[str, Any]) -> list[str]:
        """Validate params using config rules.

        Args:
            params: Request parameters.

        Returns:
            List of validation error messages.
        """
        errors: list[str] = []
        rules: list[dict[str, Any]] = self._get_config_value("validation.rules", [])

        for rule in rules:
            condition = rule.get("condition", "True")
            required_fields = rule.get("required_fields", [])

            # Evaluate condition with params in context
            if self._eval_condition(condition, params):
                # Check required fields
                for field in required_fields:
                    if not params.get(field):
                        errors.append(f"{field} is required when {condition}")

        return errors

    def execute(
        self,
        context: OperationContext,
        query_results: dict[str, QueryResult],
    ) -> dict[str, Any]:
        """Execute score aggregation operation.

        Args:
            context: Operation context with params.
            query_results: Pre-executed query results.

        Returns:
            Score report data.
        """
        params = context.params
        report_type = params.get("report_type", "customer")
        entity_id = params.get("entity_id")

        log_info(
            "Generating score report",
            operation=context.operation,
            report_type=report_type,
            entity_id=entity_id,
            user_id=context.user_id,
        )

        # Get report type config
        report_config = self._get_config_value(
            f"report_types.{report_type}",
            {"metrics_key": f"{report_type}_metrics"},
        )

        # Get metrics from query results
        metrics_key = report_config.get("metrics_key")
        metrics_result = query_results.get(metrics_key) if metrics_key else None
        metrics_row = metrics_result.first if metrics_result else None

        # Calculate scores
        factors = self._get_factors(params)
        scores = self._calculate_scores(factors, metrics_row)
        overall_score = self._aggregate_scores(scores)
        risk_level = self._classify_score(overall_score)

        # Build report data
        report_data = self._build_report_data(
            report_type=report_type,
            report_config=report_config,
            entity_id=entity_id,
            scores=scores,
            overall_score=overall_score,
            risk_level=risk_level,
            metrics_row=metrics_row,
        )

        # Build response
        result: dict[str, Any] = {
            "success": True,
            "report_type": report_type,
            "entity_id": entity_id,
            "generated_at": datetime.now(timezone.utc).isoformat(),
            "period": {
                "start_date": params.get("start_date"),
                "end_date": params.get("end_date"),
            },
            "risk_factors_analyzed": factors,
            "data": report_data,
        }

        log_info(
            "Score report generated",
            operation=context.operation,
            report_type=report_type,
            overall_score=overall_score,
        )

        return result

    def _get_factors(self, params: dict[str, Any]) -> list[str]:
        """Get scoring factors from params.

        Args:
            params: Request parameters.

        Returns:
            List of factor names.
        """
        factors_field: str = self._get_config_value("scoring.factors_field", "risk_factors")
        default_factors: list[str] = self._get_config_value(
            "scoring.default_factors",
            ["credit", "fraud", "compliance"],
        )
        factors = params.get(factors_field, default_factors)
        return list(factors) if factors else default_factors

    def _calculate_scores(
        self,
        factors: list[str],
        metrics_row: dict[str, Any] | None,
    ) -> dict[str, float]:
        """Calculate score for each factor.

        Args:
            factors: List of factor names.
            metrics_row: Metrics data row.

        Returns:
            Dict mapping factor names to scores.
        """
        default_score = self._get_config_value("scoring.default_score", 50.0)
        pattern = self._get_config_value("scoring.score_field_pattern", "{factor}_score")

        scores: dict[str, float] = {}
        for factor in factors:
            if metrics_row is None:
                scores[factor] = default_score
            else:
                field_name = self._eval_template(pattern, {"factor": factor})
                score = metrics_row.get(field_name, default_score)
                scores[factor] = min(100.0, max(0.0, float(score)))

        return scores

    def _aggregate_scores(self, scores: dict[str, float]) -> float:
        """Aggregate factor scores into overall score.

        Args:
            scores: Dict of factor scores.

        Returns:
            Aggregated overall score.
        """
        if not scores:
            return 0.0

        aggregation = self._get_config_value("scoring.aggregation", "average")
        values = list(scores.values())

        if aggregation == "average":
            result = sum(values) / len(values)
        elif aggregation == "max":
            result = max(values)
        elif aggregation == "min":
            result = min(values)
        elif aggregation == "sum":
            result = sum(values)
        else:
            result = sum(values) / len(values)

        return round(result, 2)

    def _classify_score(self, score: float) -> str:
        """Classify score into level using thresholds.

        Args:
            score: Numeric score.

        Returns:
            Classification level string.
        """
        thresholds = self._get_config_value("classification.thresholds", [])
        default_level = self._get_config_value("classification.default_level", "minimal")

        # Sort thresholds by min descending
        sorted_thresholds = sorted(
            thresholds,
            key=lambda t: t.get("min", 0),
            reverse=True,
        )

        for threshold in sorted_thresholds:
            min_val = threshold.get("min", 0)
            if score >= min_val:
                return threshold.get("level", default_level)

        return default_level

    def _get_indicators(
        self,
        metrics_row: dict[str, Any] | None,
    ) -> list[dict[str, Any]]:
        """Generate indicators from config rules.

        Args:
            metrics_row: Metrics data row.

        Returns:
            List of indicator dicts.
        """
        indicators: list[dict[str, Any]] = []
        if metrics_row is None:
            return indicators

        indicator_rules: list[dict[str, Any]] = self._get_config_value("indicators", [])

        for rule in indicator_rules:
            condition = rule.get("condition", "False")
            # Evaluate with metrics in context
            context = {"metrics": metrics_row}
            context.update(metrics_row)

            try:
                if self._eval_condition(condition, context):
                    indicators.append(
                        {
                            "type": rule.get("type", "unknown"),
                            "severity": rule.get("severity", "info"),
                            "message": rule.get("message", ""),
                        }
                    )
            except (ValueError, KeyError):
                # Skip invalid conditions
                pass

        return indicators

    def _get_recommendations(
        self,
        overall_score: float,
        factor_scores: dict[str, float],
    ) -> list[str]:
        """Generate recommendations from config rules.

        Args:
            overall_score: Overall risk score.
            factor_scores: Dict of factor scores.

        Returns:
            List of recommendation strings.
        """
        recommendations: list[str] = []

        # Overall score recommendations
        overall_rules: list[dict[str, Any]] = self._get_config_value("recommendations.overall", [])
        # Sort by min_score descending
        sorted_rules = sorted(
            overall_rules,
            key=lambda r: r.get("min_score", 0),
            reverse=True,
        )

        for rule in sorted_rules:
            min_score = rule.get("min_score", 0)
            if overall_score >= min_score:
                recommendations.append(str(rule.get("message", "")))
                break  # Only first matching rule

        # Per-factor recommendations
        per_factor = self._get_config_value("recommendations.per_factor", {})
        threshold = per_factor.get("threshold", 70)
        message_pattern = per_factor.get(
            "message_pattern",
            "Address {factor} risk factors",
        )

        for factor, score in factor_scores.items():
            if score >= threshold:
                msg = self._eval_template(message_pattern, {"factor": factor})
                recommendations.append(msg)

        return recommendations

    def _build_report_data(
        self,
        report_type: str,
        report_config: dict[str, Any],
        entity_id: str | None,
        scores: dict[str, float],
        overall_score: float,
        risk_level: str,
        metrics_row: dict[str, Any] | None,
    ) -> dict[str, Any]:
        """Build report data based on report type config.

        Args:
            report_type: Type of report.
            report_config: Config for this report type.
            entity_id: Entity identifier.
            scores: Factor scores.
            overall_score: Overall score.
            risk_level: Classification level.
            metrics_row: Metrics data.

        Returns:
            Report data dict.
        """
        # Base data
        id_field = report_config.get("id_field", f"{report_type}_id")
        data: dict[str, Any] = {
            id_field: entity_id,
            "overall_risk_score": overall_score,
            "risk_level": risk_level,
            "factor_scores": scores,
        }

        # Add indicators (for non-aggregate)
        if report_config.get("metrics_key"):
            data["indicators"] = self._get_indicators(metrics_row)
            data["recommendations"] = self._get_recommendations(overall_score, scores)

        # Add extra fields from config
        extra_fields = report_config.get("extra_fields", {})
        for field_name, default_value in extra_fields.items():
            data[field_name] = default_value

        return data


# Register handler type
register_handler_type("score_aggregator", ScoreAggregatorHandler)
