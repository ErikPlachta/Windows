# Databricks notebook source
# MAGIC %md
# MAGIC # factory
# MAGIC
# MAGIC **Auto-generated from:** `factory.py`
# MAGIC **Build timestamp:** 2025-12-22T22:33:16.652529+00:00
# MAGIC **Content hash:** f634650c4d08
# MAGIC
# MAGIC > Do not edit directly. Make changes in source and rebuild.

# COMMAND ----------

# MAGIC %run ../../../services/operations/handlers/base
# MAGIC %run ../../../services/operations/handlers/_init

# COMMAND ----------

"""Handler factory for creating generic handlers by type.

Maps handler type strings to handler classes and instantiates them
with the provided config.
"""

from __future__ import annotations

from typing import TYPE_CHECKING, Any


if TYPE_CHECKING:
    pass


# Registry of handler type strings to handler classes
# Populated by register_handler_type() or imports
HANDLER_TYPES: dict[str, type[GenericHandler]] = {}


def register_handler_type(
    type_name: str,
    handler_class: type[GenericHandler],
) -> None:
    """Register a handler type.

    Args:
        type_name: Type string used in config (e.g., "score_aggregator").
        handler_class: Handler class to instantiate.

    Example:
        register_handler_type("score_aggregator", ScoreAggregatorHandler)
    """
    HANDLER_TYPES[type_name] = handler_class


def create_handler(
    handler_type: str,
    handler_config: dict[str, Any] | None = None,
) -> GenericHandler:
    """Create a handler instance by type.

    Args:
        handler_type: Type string from config (e.g., "score_aggregator").
        handler_config: Handler-specific configuration.

    Returns:
        Instantiated handler with config.

    Raises:
        ValueError: If handler_type is not registered.

    Example:
        handler = create_handler("score_aggregator", {
            "scoring": {"aggregation": "average"}
        })
    """
    # Lazy import handlers to populate registry
    _ensure_handlers_registered()

    handler_class = HANDLER_TYPES.get(handler_type)
    if handler_class is None:
        available = ", ".join(sorted(HANDLER_TYPES.keys())) or "(none)"
        raise ValueError(f"Unknown handler_type '{handler_type}'. Available: {available}")

    return handler_class(handler_config)


def _ensure_handlers_registered() -> None:
    """Ensure all handler types are registered.

    Called lazily to avoid circular imports.
    """
    if HANDLER_TYPES:
        return

    # Import handlers to trigger registration
    try:

        # Handler registers itself on import
        _ = score_aggregator
    except ImportError:
        pass
