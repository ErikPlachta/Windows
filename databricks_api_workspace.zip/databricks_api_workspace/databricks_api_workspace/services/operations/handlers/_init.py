# Databricks notebook source
# MAGIC %md
# MAGIC # __init__
# MAGIC
# MAGIC **Auto-generated from:** `__init__.py`
# MAGIC **Build timestamp:** 2025-12-22T22:33:16.655644+00:00
# MAGIC **Content hash:** c84a0fc04199
# MAGIC
# MAGIC > Do not edit directly. Make changes in source and rebuild.

# COMMAND ----------

# MAGIC %run ../../../services/operations/handlers/base
# MAGIC %run ../../../services/operations/handlers/factory

# COMMAND ----------

"""Generic handlers for config-driven operation execution.

.. deprecated:: 2.0
    This module is deprecated in favor of the routes/queries architecture.
    Use `databricks_api_workspace.core.routes.RouteRegistry` and
    `databricks_api_workspace.services.execution.NotebookRunner` instead.

    Migration guide:
    1. Define route in routes/{resource}/{operation}.json
    2. Create notebook in queries/{resource}/{operation}.ipynb
    3. Use RouteRegistry to load and NotebookRunner to execute

    See: databricks_api_workspace.core.routes, databricks_api_workspace.services.execution

Legacy usage (deprecated):
    # In operation config:
    execution:
      handler_type: "score_aggregator"
      handler_config:
        scoring:
          factors_field: "risk_factors"
          aggregation: "average"
"""

import warnings


__all__ = [
    "GenericHandler",
    "create_handler",
    "register_handler_type",
    "HANDLER_TYPES",
]

# Emit deprecation warning on import
warnings.warn(
    "databricks_api_workspace.services.operations.handlers is deprecated. "
    "Use core.routes.RouteRegistry and services.execution.NotebookRunner instead.",
    DeprecationWarning,
    stacklevel=2,
)
