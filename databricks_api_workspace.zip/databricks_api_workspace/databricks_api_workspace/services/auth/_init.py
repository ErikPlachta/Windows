# Databricks notebook source
# MAGIC %md
# MAGIC # __init__
# MAGIC
# MAGIC **Auto-generated from:** `__init__.py`
# MAGIC **Build timestamp:** 2025-12-22T22:33:16.629494+00:00
# MAGIC **Content hash:** 0cb24f83908f
# MAGIC
# MAGIC > Do not edit directly. Make changes in source and rebuild.

# COMMAND ----------

# MAGIC %run ../../services/auth/access
# MAGIC %run ../../services/auth/context

# COMMAND ----------

"""
databricks_api_workspace.services.auth - Authentication and authorization module.

User context management and RBAC validation for operation access control.

Classes:
    UserContext: User identity, roles, and settings dataclass

Functions:
    load_user_context(): Load user context from Delta tables
    load_user_context_from_azure_oid(): Load by Azure AD object ID
    inject_user_context(): Inject user context into parameters
    clear_user_cache(): Clear user context cache
    invalidate_user_cache(): Invalidate specific user's cache
    create_anonymous_context(): Create anonymous user context
    get_operation_required_roles(): Get roles required for operation
    validate_operation_access(): Check user has operation access
    require_operation_access(): Raise if user lacks operation access
    validate_resource_access(): Check user has resource access
    require_resource_access(): Raise if user lacks resource access
    get_user_data_filters(): Get data filters for user
    mask_sensitive_fields(): Mask sensitive data based on permissions
    help(): Display module usage information

Example:
    >>> from databricks_api_workspace.services.auth import (
    ...     load_user_context,
    ...     require_operation_access,
    ... )
    >>> user = load_user_context("user123")
    >>> require_operation_access(user, "get_customer")
"""

from __future__ import annotations

# Re-exports

__all__ = [
    # Context
    "UserContext",
    "load_user_context",
    "load_user_context_from_azure_oid",
    "inject_user_context",
    "clear_user_cache",
    "invalidate_user_cache",
    "create_anonymous_context",
    # Access control
    "get_operation_required_roles",
    "validate_operation_access",
    "require_operation_access",
    "validate_resource_access",
    "require_resource_access",
    "get_user_data_filters",
    "mask_sensitive_fields",
    # Help
    "help",
]


def help() -> str:
    """Display auth module usage information.

    Returns:
        str: Help text with all available functions and examples.

    Example:
        >>> from databricks_api_workspace.services import auth
        >>> print(auth.help())
    """
    return """
databricks_api_workspace.services.auth
=================================

User context management and RBAC validation.

UserContext Class:
-----------------
  UserContext(user_id, email, display_name, azure_oid, roles, settings, metadata)
    .has_role(role) -> bool
    .has_any_role(roles) -> bool
    .has_all_roles(roles) -> bool
    .get_setting(key, default=None) -> Any
    .to_dict() -> dict

Context Loading:
---------------
  load_user_context(user_id, use_cache=True) -> UserContext | None
  load_user_context_from_azure_oid(azure_oid, use_cache=True) -> UserContext | None
  create_anonymous_context() -> UserContext
  inject_user_context(params, user_context, fields=None) -> dict

Cache Management:
----------------
  clear_user_cache() -> None
  invalidate_user_cache(user_id) -> None

Operation Access (RBAC):
-----------------------
  get_operation_required_roles(operation) -> list[str]
  validate_operation_access(user_context, operation) -> bool
  require_operation_access(user_context, operation) -> None  # raises

Resource Access (Row-Level):
---------------------------
  validate_resource_access(user_context, resource_type, resource_id, action) -> bool
  require_resource_access(user_context, resource_type, resource_id, action) -> None
  get_user_data_filters(user_context, resource_type) -> dict
  mask_sensitive_fields(data, user_context, operation) -> dict

Quick Start:
-----------
  from databricks_api_workspace.services.auth import (
      load_user_context, require_operation_access, UserContext,
  )
  user = load_user_context("user123")
  require_operation_access(user, "get_customer_detail")

Submodules:
----------
  _settings - Auth configuration constants
  context - UserContext and cache management
  access - RBAC validation functions
"""
