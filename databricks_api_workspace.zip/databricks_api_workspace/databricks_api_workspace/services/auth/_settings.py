# Databricks notebook source
# MAGIC %md
# MAGIC # _settings
# MAGIC
# MAGIC **Auto-generated from:** `_settings.py`
# MAGIC **Build timestamp:** 2025-12-22T22:33:16.628567+00:00
# MAGIC **Content hash:** 7fd782e5c039
# MAGIC
# MAGIC > Do not edit directly. Make changes in source and rebuild.

# COMMAND ----------

"""Auth configuration constants.

Single source of truth for authentication/authorization settings.
"""

from __future__ import annotations

# Cache TTL in seconds (5 minutes)
CACHE_TTL_SECONDS = 300

# Default table names
DEFAULT_USERS_TABLE = "databricks_api_workspace.users"
DEFAULT_USER_ROLES_TABLE = "databricks_api_workspace.user_roles"
DEFAULT_USER_SETTINGS_TABLE = "databricks_api_workspace.user_settings"

# Config keys
CONFIG_KEY_USERS_TABLE = "tables.users"
CONFIG_KEY_USER_ROLES_TABLE = "tables.user_roles"
CONFIG_KEY_USER_SETTINGS_TABLE = "tables.user_settings"
CONFIG_KEY_ADMIN_ROLE = "auth.admin_role"
CONFIG_KEY_SENSITIVE_DATA_ROLE = "auth.sensitive_data_role"

# Default roles
DEFAULT_ADMIN_ROLE = "admin"
DEFAULT_SENSITIVE_DATA_ROLE = "sensitive_data"
DEFAULT_ANONYMOUS_ROLE = "anonymous"

# Default injected field names
DEFAULT_INJECT_FIELDS = ["user_id", "email", "roles"]
