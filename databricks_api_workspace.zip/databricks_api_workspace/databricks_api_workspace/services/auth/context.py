# Databricks notebook source
# MAGIC %md
# MAGIC # context
# MAGIC
# MAGIC **Auto-generated from:** `context.py`
# MAGIC **Build timestamp:** 2025-12-22T22:33:16.627636+00:00
# MAGIC **Content hash:** 9656a3ffeca4
# MAGIC
# MAGIC > Do not edit directly. Make changes in source and rebuild.

# COMMAND ----------

# MAGIC %run ../../core/config/_init
# MAGIC %run ../../core/logging/_init
# MAGIC %run ../../core/runtime/_init
# MAGIC %run ../../core/sql_utils/_init
# MAGIC %run ../../services/auth/_settings

# COMMAND ----------

"""User context utilities.

Load and manage user identity, roles, and settings from Delta tables.

Features:
- UserContext dataclass with role/settings management
- Cached user loading from Delta tables
- Azure AD OID lookup
- Context injection into request params
- Cache management (clear, invalidate)

Status: Complete.
"""

from __future__ import annotations

import threading
from dataclasses import dataclass, field
from time import time
from typing import Any


# Thread lock for cache mutations
_cache_lock = threading.Lock()


@dataclass
class UserContext:
    """User context with identity, roles, and settings."""

    user_id: str
    email: str | None = None
    display_name: str | None = None
    azure_oid: str | None = None
    roles: list[str] = field(default_factory=list)
    settings: dict[str, Any] = field(default_factory=dict)
    metadata: dict[str, Any] = field(default_factory=dict)

    def has_role(self, role: str) -> bool:
        """Check if user has a specific role."""
        return role in self.roles

    def has_any_role(self, roles: list[str]) -> bool:
        """Check if user has any of the specified roles."""
        return any(role in self.roles for role in roles)

    def has_all_roles(self, roles: list[str]) -> bool:
        """Check if user has all specified roles."""
        return all(role in self.roles for role in roles)

    def get_setting(self, key: str, default: Any = None) -> Any:
        """Get a user setting value."""
        return self.settings.get(key, default)

    def to_dict(self) -> dict[str, Any]:
        """Convert to dictionary."""
        return {
            "user_id": self.user_id,
            "email": self.email,
            "display_name": self.display_name,
            "azure_oid": self.azure_oid,
            "roles": self.roles,
            "settings": self.settings,
            "metadata": self.metadata,
        }


# Cache for loaded user contexts: {user_id: (context, cached_at_timestamp)}
_user_cache: dict[str, tuple[UserContext, float]] = {}


def load_user_context(
    user_id: str,
    use_cache: bool = True,
) -> UserContext | None:
    """Load user context from Delta tables.

    Queries:
    - databricks_api_workspace.users for user profile
    - databricks_api_workspace.user_roles for role overrides
    - databricks_api_workspace.user_settings for preferences

    Args:
        user_id: User identifier.
        use_cache: Whether to use cached context.

    Returns:
        UserContext if found, None otherwise.
    """
    if use_cache:
        with _cache_lock:
            if user_id in _user_cache:
                context, cached_at = _user_cache[user_id]
                if time() - cached_at < CACHE_TTL_SECONDS:
                    return context
                # Cache expired, remove and reload
                del _user_cache[user_id]

    spark = get_spark()

    # Query user profile from Delta table
    users_table = safe_sql_identifier(get_config_value(CONFIG_KEY_USERS_TABLE, DEFAULT_USERS_TABLE))
    safe_user_id = escape_sql_string(user_id)
    try:
        user_row = spark.sql(f"""
            SELECT user_id, email, display_name, azure_oid, default_roles, metadata
            FROM {users_table}
            WHERE user_id = '{safe_user_id}'
            LIMIT 1
        """).first()
    except Exception:
        user_row = None

    if user_row is None:
        log_warning(f"User not found: {user_id}")
        return None

    # Query role overrides
    roles_table = safe_sql_identifier(
        get_config_value(CONFIG_KEY_USER_ROLES_TABLE, DEFAULT_USER_ROLES_TABLE)
    )
    try:
        roles_rows = spark.sql(f"""
            SELECT role
            FROM {roles_table}
            WHERE user_id = '{safe_user_id}'
            AND (expires_at IS NULL OR expires_at > current_timestamp())
        """).collect()
        override_roles = [row.role for row in roles_rows]
    except Exception:
        override_roles = []

    # Combine default roles with overrides
    default_roles = user_row.default_roles or []
    if isinstance(default_roles, str):
        default_roles = [default_roles]
    all_roles = list(set(default_roles + override_roles))

    # Query user settings
    settings_table = safe_sql_identifier(
        get_config_value(CONFIG_KEY_USER_SETTINGS_TABLE, DEFAULT_USER_SETTINGS_TABLE)
    )
    try:
        settings_rows = spark.sql(f"""
            SELECT setting_key, setting_value
            FROM {settings_table}
            WHERE user_id = '{safe_user_id}'
        """).collect()
        settings = {row.setting_key: row.setting_value for row in settings_rows}
    except Exception:
        settings = {}

    # Build context
    context = UserContext(
        user_id=user_row.user_id,
        email=user_row.email,
        display_name=user_row.display_name,
        azure_oid=user_row.azure_oid,
        roles=all_roles,
        settings=settings,
        metadata=user_row.metadata or {},
    )

    if use_cache:
        with _cache_lock:
            _user_cache[user_id] = (context, time())

    log_info("Loaded user context", user_id=user_id, roles=all_roles)
    return context


def load_user_context_from_azure_oid(
    azure_oid: str,
    use_cache: bool = True,
) -> UserContext | None:
    """Load user context by Azure AD object ID.

    Args:
        azure_oid: Azure AD object ID.
        use_cache: Whether to use cached context.

    Returns:
        UserContext if found, None otherwise.
    """
    spark = get_spark()
    users_table = safe_sql_identifier(get_config_value(CONFIG_KEY_USERS_TABLE, DEFAULT_USERS_TABLE))
    safe_azure_oid = escape_sql_string(azure_oid)

    try:
        row = spark.sql(f"""
            SELECT user_id
            FROM {users_table}
            WHERE azure_oid = '{safe_azure_oid}'
            LIMIT 1
        """).first()
    except Exception:
        row = None

    if row is None:
        return None

    return load_user_context(row.user_id, use_cache=use_cache)


def inject_user_context(
    params: dict[str, Any],
    user_context: UserContext,
    fields: list[str] | None = None,
) -> dict[str, Any]:
    """Inject user context into request parameters.

    Args:
        params: Original parameters.
        user_context: User context to inject.
        fields: Specific fields to inject (default: user_id, email, roles).

    Returns:
        Parameters with user context injected.
    """
    if fields is None:
        fields = DEFAULT_INJECT_FIELDS

    result = dict(params)
    context_dict = user_context.to_dict()

    for field_name in fields:
        if field_name in context_dict:
            result[f"_user_{field_name}"] = context_dict[field_name]

    return result


def clear_user_cache() -> None:
    """Clear the user context cache. Thread-safe."""
    with _cache_lock:
        _user_cache.clear()


def invalidate_user_cache(user_id: str) -> None:
    """Invalidate cache for a specific user. Thread-safe.

    Args:
        user_id: User to invalidate.
    """
    with _cache_lock:
        _user_cache.pop(user_id, None)


def create_anonymous_context() -> UserContext:
    """Create an anonymous user context.

    Used when no user identity is available.

    Returns:
        UserContext with anonymous identity.
    """
    return UserContext(
        user_id="anonymous",
        email=None,
        display_name="Anonymous User",
        roles=[DEFAULT_ANONYMOUS_ROLE],
        settings={},
    )
