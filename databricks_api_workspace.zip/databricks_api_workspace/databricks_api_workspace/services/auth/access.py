# Databricks notebook source
# MAGIC %md
# MAGIC # access
# MAGIC
# MAGIC **Auto-generated from:** `access.py`
# MAGIC **Build timestamp:** 2025-12-22T22:33:16.625203+00:00
# MAGIC **Content hash:** 16f26979fde0
# MAGIC
# MAGIC > Do not edit directly. Make changes in source and rebuild.

# COMMAND ----------

# MAGIC %run ../../core/config/_init
# MAGIC %run ../../core/errors/_init
# MAGIC %run ../../core/logging/_init
# MAGIC %run ../../services/auth/_settings
# MAGIC %run ../../services/auth/context

# COMMAND ----------

"""Authorization utilities.

RBAC validation for operation access control.
"""

from __future__ import annotations

from typing import TYPE_CHECKING, Any


if TYPE_CHECKING:


def get_operation_required_roles(operation: str) -> list[str]:
    """Get roles required for an operation.

    Args:
        operation: Operation name.

    Returns:
        List of required roles (empty = no restriction).
    """
    try:
        op_config = get_operation_config(operation)
        return op_config.get("required_roles", [])
    except (ValueError, FileNotFoundError):
        return []


def validate_operation_access(
    user_context: UserContext,
    operation: str,
) -> bool:
    """Check if user has access to an operation.

    Rules:
    1. If operation has no required_roles, anyone can access
    2. If operation has required_roles, user must have at least one
    3. Admin role bypasses all checks

    Args:
        user_context: User making the request.
        operation: Operation to access.

    Returns:
        True if user has access.
    """
    # Admin bypass
    admin_role = get_config_value(CONFIG_KEY_ADMIN_ROLE, DEFAULT_ADMIN_ROLE)
    if user_context.has_role(admin_role):
        log_info(
            "Admin access granted",
            user_id=user_context.user_id,
            operation=operation,
        )
        return True

    # Check required roles
    required_roles = get_operation_required_roles(operation)

    # No roles required = open access
    if not required_roles:
        return True

    # User must have at least one required role
    has_access = user_context.has_any_role(required_roles)

    if not has_access:
        log_warning(
            "Access denied",
            user_id=user_context.user_id,
            operation=operation,
            required_roles=required_roles,
            user_roles=user_context.roles,
        )

    return has_access


def require_operation_access(
    user_context: UserContext,
    operation: str,
) -> None:
    """Require user has access to operation, raise if not.

    Args:
        user_context: User making the request.
        operation: Operation to access.

    Raises:
        AuthorizationError: If user lacks required permissions.
    """
    if not validate_operation_access(user_context, operation):
        required_roles = get_operation_required_roles(operation)
        raise AuthorizationError(
            f"User {user_context.user_id} lacks permission for operation {operation}",
            required_roles=required_roles,
        )


def validate_resource_access(
    user_context: UserContext,
    resource_type: str,
    resource_id: str,
    action: str = "read",
) -> bool:
    """Check if user has access to a specific resource.

    This is for row-level security beyond operation access.

    Args:
        user_context: User making the request.
        resource_type: Type of resource (e.g., 'customer', 'report').
        resource_id: Specific resource identifier.
        action: Action being performed (read, write, delete).

    Returns:
        True if user has access.
    """
    # Admin bypass
    admin_role = get_config_value(CONFIG_KEY_ADMIN_ROLE, DEFAULT_ADMIN_ROLE)
    if user_context.has_role(admin_role):
        return True

    # Check user settings for resource restrictions
    allowed_resources = user_context.get_setting(f"allowed_{resource_type}s", None)
    if allowed_resources is not None:
        if resource_id not in allowed_resources:
            log_warning(
                "Resource access denied",
                user_id=user_context.user_id,
                resource_type=resource_type,
                resource_id=resource_id,
                action=action,
            )
            return False

    return True


def require_resource_access(
    user_context: UserContext,
    resource_type: str,
    resource_id: str,
    action: str = "read",
) -> None:
    """Require user has access to resource, raise if not.

    Args:
        user_context: User making the request.
        resource_type: Type of resource.
        resource_id: Specific resource identifier.
        action: Action being performed.

    Raises:
        AuthorizationError: If user lacks access to resource.
    """
    if not validate_resource_access(user_context, resource_type, resource_id, action):
        raise AuthorizationError(
            f"Access denied to {resource_type} {resource_id}",
        )


def get_user_data_filters(
    user_context: UserContext,
    resource_type: str,
) -> dict[str, Any]:
    """Get data filters to apply based on user access.

    Used for row-level filtering in queries.

    Args:
        user_context: User making the request.
        resource_type: Type of resource being queried.

    Returns:
        Filter conditions to apply (empty = no restrictions).
    """
    # Admin gets no filters
    admin_role = get_config_value(CONFIG_KEY_ADMIN_ROLE, DEFAULT_ADMIN_ROLE)
    if user_context.has_role(admin_role):
        return {}

    filters: dict[str, Any] = {}

    # Check for explicit resource restrictions
    allowed_resources = user_context.get_setting(f"allowed_{resource_type}s", None)
    if allowed_resources is not None:
        filters[f"{resource_type}_id"] = {"$in": allowed_resources}

    # Check for tenant isolation
    tenant_id = user_context.get_setting("tenant_id", None)
    if tenant_id:
        filters["tenant_id"] = tenant_id

    return filters


def mask_sensitive_fields(
    data: dict[str, Any],
    user_context: UserContext,
    operation: str,
) -> dict[str, Any]:
    """Mask sensitive fields based on user permissions.

    Args:
        data: Response data to mask.
        user_context: User making the request.
        operation: Operation being performed.

    Returns:
        Data with sensitive fields masked based on permissions.
    """
    # Admin sees everything
    admin_role = get_config_value(CONFIG_KEY_ADMIN_ROLE, DEFAULT_ADMIN_ROLE)
    if user_context.has_role(admin_role):
        return data

    # Get sensitive fields for operation
    try:
        op_config = get_operation_config(operation)
        sensitive_fields = op_config.get("sensitive_fields", [])
    except ValueError:
        sensitive_fields = []

    if not sensitive_fields:
        return data

    # Check if user has permission to see sensitive data
    sensitive_data_role = get_config_value(
        CONFIG_KEY_SENSITIVE_DATA_ROLE, DEFAULT_SENSITIVE_DATA_ROLE
    )
    if user_context.has_role(sensitive_data_role):
        return data

    # Mask sensitive fields
    result = dict(data)
    for field in sensitive_fields:
        if field in result:
            result[field] = "***REDACTED***"

    return result
