# Databricks notebook source
# MAGIC %md
# MAGIC # param_mapper
# MAGIC
# MAGIC **Auto-generated from:** `param_mapper.py`
# MAGIC **Build timestamp:** 2025-12-22T22:33:16.646877+00:00
# MAGIC **Content hash:** fbcb3ed5145b
# MAGIC
# MAGIC > Do not edit directly. Make changes in source and rebuild.

# COMMAND ----------

"""
databricks_api_workspace.services.execution.param_mapper - Parameter mapping.

Map request data to notebook parameters based on route param definitions.

Functions:
    map_params(): Map request to notebook params
    extract_value(): Extract value from request data by source
"""

from __future__ import annotations

from typing import Any

__all__ = [
    "map_params",
    "extract_value",
    "ParamMappingError",
]


class ParamMappingError(Exception):
    """Raised when parameter mapping fails."""

    def __init__(self, message: str, param_name: str | None = None):
        self.param_name = param_name
        super().__init__(message)


def _get_nested(data: dict[str, Any], path: str) -> Any:
    """Get nested value from dict using dot notation.

    Args:
        data: Dictionary to search.
        path: Dot-separated path (e.g., "address.city").

    Returns:
        Value at path or None if not found.
    """
    parts = path.split(".")
    current = data

    for part in parts:
        if isinstance(current, dict) and part in current:
            current = current[part]
        else:
            return None

    return current


def extract_value(
    source: str,
    path_params: dict[str, str] | None = None,
    query_params: dict[str, str] | None = None,
    body: dict[str, Any] | None = None,
    headers: dict[str, str] | None = None,
) -> Any:
    """Extract value from request data based on source specification.

    Source formats:
    - "path.{name}" -> path_params[name]
    - "query.{name}" -> query_params[name]
    - "body" -> entire body
    - "body.{field}" -> body[field]
    - "body.{nested}.{field}" -> body[nested][field]
    - "header.{name}" -> headers[name]

    Args:
        source: Source specification (e.g., "path.id", "body.customer_name").
        path_params: URL path parameters.
        query_params: Query string parameters.
        body: Request body.
        headers: Request headers.

    Returns:
        Extracted value or None if not found.
    """
    if not source:
        return None

    # Handle "body" as special case (entire body)
    if source == "body":
        return body

    # Parse source
    parts = source.split(".", 1)
    if len(parts) < 2:
        return None

    source_type, field_path = parts

    if source_type == "path":
        return (path_params or {}).get(field_path)

    elif source_type == "query":
        return (query_params or {}).get(field_path)

    elif source_type == "body":
        if body is None:
            return None
        return _get_nested(body, field_path)

    elif source_type == "header":
        return (headers or {}).get(field_path)

    return None


def map_params(
    param_defs: list[dict[str, Any]],
    path_params: dict[str, str] | None = None,
    query_params: dict[str, str] | None = None,
    body: dict[str, Any] | None = None,
    headers: dict[str, str] | None = None,
    strict: bool = True,
) -> dict[str, Any]:
    """Map request data to notebook parameters.

    Args:
        param_defs: List of parameter definitions from route.
        path_params: URL path parameters.
        query_params: Query string parameters.
        body: Request body.
        headers: Request headers.
        strict: If True, raise on missing required params.

    Returns:
        Dictionary of notebook parameters.

    Raises:
        ParamMappingError: If strict=True and required param is missing.

    Example:
        >>> param_defs = [
        ...     {"name": "customer_id", "source": "path.id", "required": True},
        ...     {"name": "limit", "source": "query.limit", "default": 10},
        ... ]
        >>> params = map_params(param_defs, path_params={"id": "123"})
        >>> params
        {"customer_id": "123", "limit": 10}
    """
    result: dict[str, Any] = {}

    for param_def in param_defs:
        name = param_def.get("name")
        if not name:
            continue

        source = param_def.get("source", "")
        default = param_def.get("default")
        required = param_def.get("required", False)

        # Extract value
        value = extract_value(
            source,
            path_params=path_params,
            query_params=query_params,
            body=body,
            headers=headers,
        )

        # Apply default if needed
        if value is None:
            value = default

        # Check required
        if value is None and required and strict:
            raise ParamMappingError(
                f"Required parameter '{name}' not found in {source}",
                param_name=name,
            )

        # Add to result (even if None, for explicit params)
        result[name] = value

    return result
