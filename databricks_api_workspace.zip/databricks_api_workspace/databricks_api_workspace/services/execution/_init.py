# Databricks notebook source
# MAGIC %md
# MAGIC # __init__
# MAGIC
# MAGIC **Auto-generated from:** `__init__.py`
# MAGIC **Build timestamp:** 2025-12-22T22:33:16.649505+00:00
# MAGIC **Content hash:** 1c8b9e5f2f3d
# MAGIC
# MAGIC > Do not edit directly. Make changes in source and rebuild.

# COMMAND ----------

# MAGIC %run ../../services/execution/notebook_runner
# MAGIC %run ../../services/execution/param_mapper
# MAGIC %run ../../services/response/_init

# COMMAND ----------

"""
databricks_api_workspace.services.execution - Notebook execution engine.

Execute notebooks locally (via papermill) or in Databricks (via Jobs API).
Maps request parameters to notebook parameters and wraps results.

Classes:
    NotebookResult: Result of notebook execution.
    NotebookRunner: Execute notebooks.
    ParamMappingError: Raised when parameter mapping fails.
    NotebookExecutionError: Raised when execution fails.

Functions:
    map_params(): Map request to notebook params
    extract_value(): Extract value from request data by source
    help(): Display module usage information

Example:
    >>> from databricks_api_workspace.services.execution import NotebookRunner
    >>> runner = NotebookRunner()
    >>> result = runner.execute(route, path_params={"id": "123"})
"""

from __future__ import annotations

from typing import Any


__all__ = [
    # Classes
    "NotebookResult",
    "NotebookRunner",
    "NotebookExecutionError",
    "ParamMappingError",
    # Functions
    "map_params",
    "extract_value",
    "wrap_result_envelope",
    # Help
    "help",
]


def wrap_result_envelope(
    result: NotebookResult,
    operation: str,
    correlation_id: str | None = None,
) -> dict[str, Any]:
    """Wrap NotebookResult in a standard response envelope.

    Converts execution result to the standard API response format.
    For success: includes data and metadata.
    For error: includes error code and message.

    Args:
        result: NotebookResult from execution.
        operation: Operation name for metadata.
        correlation_id: Request correlation ID.

    Returns:
        Response envelope dict.

    Example:
        >>> result = runner.execute(route, path_params={"id": "123"})
        >>> envelope = wrap_result_envelope(result, "customers/get")
        >>> envelope["meta"]["status"]
        'success'
    """
    # Lazy import to avoid circular dependency

    if result.success:
        # Async job response
        if result.job_id:
            return build_async_response(
                operation=operation,
                job_id=result.job_id,
                correlation_id=correlation_id,
            )

        # Success response - use execution_time_ms for duration
        # We need to fake start_time since we have duration_ms directly
        import time

        fake_start = time.time() - (result.execution_time_ms / 1000)

        return build_response(
            data=result.data,
            operation=operation,
            start_time=fake_start,
            correlation_id=correlation_id,
        )
    else:
        # Error response
        details = {}
        if result.notebook_path:
            details["notebook_path"] = result.notebook_path
        if result.metadata:
            details.update(result.metadata)

        # Calculate start_time from execution_time_ms
        import time

        fake_start = time.time() - (result.execution_time_ms / 1000)

        return build_error_response(
            operation=operation,
            error_code=result.error_code or "NOTEBOOK_ERROR",
            message=result.error_message or "Execution failed",
            start_time=fake_start,
            correlation_id=correlation_id,
            details=details if details else None,
        )


def help() -> str:
    """Display execution module usage information.

    Returns:
        str: Help text with all available classes, functions, and examples.

    Example:
        >>> from databricks_api_workspace.services import execution
        >>> print(execution.help())
    """
    return """
databricks_api_workspace.services.execution
==========================================

Notebook execution engine for routes.

Classes:
-------
  NotebookResult         - Result of notebook execution
  NotebookRunner         - Execute notebooks locally or in Databricks
  NotebookExecutionError - Raised on execution failure
  ParamMappingError      - Raised on parameter mapping failure

Functions:
---------
  map_params(param_defs, path_params, query_params, body, headers) -> dict
  extract_value(source, path_params, query_params, body, headers) -> Any
  wrap_result_envelope(result, operation, correlation_id) -> dict

Quick Start:
-----------
  from databricks_api_workspace.services.execution import NotebookRunner
  from databricks_api_workspace.core.routes import RouteRegistry

  # Load routes
  registry = RouteRegistry.load()
  route = registry.get_by_path("GET", "/customers/{id}")

  # Execute
  runner = NotebookRunner()
  result = runner.execute(
      route,
      path_params={"id": "123"},
      query_params={"include_orders": "true"},
  )

  if result.success:
      print(result.data)
  else:
      print(f"Error: {result.error_code} - {result.error_message}")

Param Source Mapping:
--------------------
  path.{name}         -> URL path parameter
  query.{name}        -> Query string parameter
  body                -> Entire request body
  body.{field}        -> Body field
  body.{nested}.{f}   -> Nested body field
  header.{name}       -> Request header

Submodules:
----------
  _settings       - Execution configuration constants
  param_mapper    - Parameter mapping utilities
  notebook_runner - Notebook execution logic
"""
