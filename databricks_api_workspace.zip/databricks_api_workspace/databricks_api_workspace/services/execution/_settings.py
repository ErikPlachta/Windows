# Databricks notebook source
# MAGIC %md
# MAGIC # _settings
# MAGIC
# MAGIC **Auto-generated from:** `_settings.py`
# MAGIC **Build timestamp:** 2025-12-22T22:33:16.647867+00:00
# MAGIC **Content hash:** ba3a6bcab5a6
# MAGIC
# MAGIC > Do not edit directly. Make changes in source and rebuild.

# COMMAND ----------

"""
databricks_api_workspace.services.execution settings (private).

Default constants for notebook execution. These are compile-time
defaults that can be overridden at runtime via external config.

Constants:
    QUERIES_DEFAULT_PATH: Default path for queries folder
    EXECUTION_TIMEOUT_DEFAULT: Default execution timeout
    EXECUTION_RETRY_ATTEMPTS: Default retry attempts
    EXECUTION_RETRY_DELAY: Delay between retries
"""

from __future__ import annotations

__all__ = [
    "QUERIES_DEFAULT_PATH",
    "EXECUTION_TIMEOUT_DEFAULT",
    "EXECUTION_RETRY_ATTEMPTS",
    "EXECUTION_RETRY_DELAY",
    "NOTEBOOK_EXTENSION",
]

# -----------------------------------------------------------------------------
# Paths
# -----------------------------------------------------------------------------

# Default path for queries folder (relative to package root)
QUERIES_DEFAULT_PATH: str = "queries"

# Notebook file extension
NOTEBOOK_EXTENSION: str = ".ipynb"

# -----------------------------------------------------------------------------
# Execution Settings
# -----------------------------------------------------------------------------

# Default execution timeout (seconds)
EXECUTION_TIMEOUT_DEFAULT: int = 300

# Default retry attempts for transient failures
EXECUTION_RETRY_ATTEMPTS: int = 3

# Delay between retries (seconds)
EXECUTION_RETRY_DELAY: float = 1.0
