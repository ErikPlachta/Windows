# Databricks notebook source
# MAGIC %md
# MAGIC # notebook_runner
# MAGIC
# MAGIC **Auto-generated from:** `notebook_runner.py`
# MAGIC **Build timestamp:** 2025-12-22T22:33:16.645502+00:00
# MAGIC **Content hash:** 53dbe44d0a08
# MAGIC
# MAGIC > Do not edit directly. Make changes in source and rebuild.

# COMMAND ----------

# MAGIC %run ../../core/routes/_init
# MAGIC %run ../../core/runtime/_init
# MAGIC %run ../../services/execution/_settings
# MAGIC %run ../../services/execution/param_mapper
# MAGIC %run ../../core/routes/schema_validation

# COMMAND ----------

"""
databricks_api_workspace.services.execution.notebook_runner - Notebook execution.

Execute notebooks locally (via papermill) or in Databricks (via Jobs API).

Classes:
    NotebookResult: Result of notebook execution.
    NotebookRunner: Execute notebooks.
"""

from __future__ import annotations

import json
import time
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any


__all__ = [
    "NotebookResult",
    "NotebookRunner",
    "NotebookExecutionError",
]


class NotebookExecutionError(Exception):
    """Raised when notebook execution fails."""

    def __init__(
        self,
        message: str,
        notebook_path: str | None = None,
        error_code: str = "NOTEBOOK_ERROR",
    ):
        self.notebook_path = notebook_path
        self.error_code = error_code
        super().__init__(message)


@dataclass
class NotebookResult:
    """Result of notebook execution."""

    success: bool
    data: Any = None
    error_code: str | None = None
    error_message: str | None = None
    execution_time_ms: int = 0
    notebook_path: str | None = None
    job_id: str | None = None
    metadata: dict[str, Any] = field(default_factory=dict)


class NotebookRunner:
    """Execute notebooks locally or in Databricks.

    In local mode, uses papermill to execute notebooks.
    In Databricks mode, uses the Jobs API via dbutils.notebook.run().
    """

    def __init__(
        self,
        queries_path: Path | str | None = None,
        timeout: int | None = None,
        retry_attempts: int | None = None,
        retry_delay: float | None = None,
    ):
        """Initialize notebook runner.

        Args:
            queries_path: Path to queries folder.
            timeout: Execution timeout in seconds.
            retry_attempts: Number of retry attempts.
            retry_delay: Delay between retries in seconds.
        """
        self.queries_path = Path(queries_path) if queries_path else self._default_path()
        self.timeout = timeout or EXECUTION_TIMEOUT_DEFAULT
        self.retry_attempts = retry_attempts or EXECUTION_RETRY_ATTEMPTS
        self.retry_delay = retry_delay or EXECUTION_RETRY_DELAY

    def _default_path(self) -> Path:
        """Get default queries path."""
        package_root = Path(__file__).parent.parent.parent.parent
        return package_root / QUERIES_DEFAULT_PATH

    def get_notebook_path(self, logic: str) -> Path:
        """Get full path to notebook file.

        Args:
            logic: Logic path from route (e.g., "customers/get_customer_detail").

        Returns:
            Full path to notebook file.
        """
        return self.queries_path / f"{logic}{NOTEBOOK_EXTENSION}"

    def notebook_exists(self, logic: str) -> bool:
        """Check if notebook exists.

        Args:
            logic: Logic path from route.

        Returns:
            True if notebook file exists.
        """
        return self.get_notebook_path(logic).exists()

    def execute(
        self,
        route: Route,
        path_params: dict[str, str] | None = None,
        query_params: dict[str, str] | None = None,
        body: dict[str, Any] | None = None,
        headers: dict[str, str] | None = None,
        validate_schemas: bool = True,
    ) -> NotebookResult:
        """Execute notebook for a route.

        Args:
            route: Route definition.
            path_params: URL path parameters.
            query_params: Query string parameters.
            body: Request body.
            headers: Request headers.
            validate_schemas: Whether to validate request/response against schemas.

        Returns:
            NotebookResult with execution outcome.
        """
        start_time = time.time()
        notebook_path = route.logic

        try:
            # Map parameters
            params = map_params(
                route.params,
                path_params=path_params,
                query_params=query_params,
                body=body,
                headers=headers,
            )

            # Validate request against schema
            if validate_schemas:

                try:
                    validate_route_request(route, params)
                except Exception as e:
                    execution_time = int((time.time() - start_time) * 1000)
                    return NotebookResult(
                        success=False,
                        error_code="VALIDATION_ERROR",
                        error_message=str(e),
                        execution_time_ms=execution_time,
                        notebook_path=notebook_path,
                    )

            # Execute based on environment
            if is_databricks():
                result = self._execute_databricks(notebook_path, params, route.timeout_seconds)
            else:
                result = self._execute_local(notebook_path, params)

            execution_time = int((time.time() - start_time) * 1000)
            result.execution_time_ms = execution_time
            result.notebook_path = notebook_path

            # Validate response against schema
            if validate_schemas and result.success and result.data:

                try:
                    validate_route_response(route, result.data)
                except Exception as e:
                    # Log warning but don't fail - response already generated
                    result.metadata["response_validation_warning"] = str(e)

            return result

        except Exception as e:
            execution_time = int((time.time() - start_time) * 1000)
            return NotebookResult(
                success=False,
                error_code="NOTEBOOK_ERROR",
                error_message=str(e),
                execution_time_ms=execution_time,
                notebook_path=notebook_path,
            )

    def _execute_local(self, notebook_path: str, params: dict[str, Any]) -> NotebookResult:
        """Execute notebook locally using papermill.

        Args:
            notebook_path: Path to notebook (relative to queries folder).
            params: Notebook parameters.

        Returns:
            NotebookResult.
        """
        try:
            import papermill as pm
        except ImportError:
            return NotebookResult(
                success=False,
                error_code="INTERNAL_ERROR",
                error_message="papermill not installed. Run: pip install papermill",
            )

        full_path = self.get_notebook_path(notebook_path)
        if not full_path.exists():
            return NotebookResult(
                success=False,
                error_code="NOT_FOUND",
                error_message=f"Notebook not found: {full_path}",
            )

        # Create temp output path
        output_path = full_path.parent / f".{full_path.stem}_output{NOTEBOOK_EXTENSION}"

        try:
            # Execute with papermill
            pm.execute_notebook(
                str(full_path),
                str(output_path),
                parameters=params,
                kernel_name="python3",
            )

            # Extract result from output notebook
            result_data = self._extract_result(output_path)

            return NotebookResult(
                success=True,
                data=result_data,
            )

        except pm.PapermillExecutionError as e:
            return NotebookResult(
                success=False,
                error_code="NOTEBOOK_ERROR",
                error_message=str(e),
            )
        finally:
            # Clean up output notebook
            if output_path.exists():
                output_path.unlink()

    def _execute_databricks(
        self, notebook_path: str, params: dict[str, Any], timeout: int
    ) -> NotebookResult:
        """Execute notebook in Databricks using dbutils.notebook.run.

        Args:
            notebook_path: Path to notebook in DBFS.
            params: Notebook parameters.
            timeout: Execution timeout in seconds.

        Returns:
            NotebookResult.
        """

        dbutils = get_dbutils()

        try:
            # Convert params to strings (notebook.run requires string params)
            string_params = {
                k: json.dumps(v) if not isinstance(v, str) else v for k, v in params.items()
            }

            # Execute notebook
            result_str = dbutils.notebook.run(
                f"/Workspace/{notebook_path}",
                timeout,
                string_params,
            )

            # Parse result
            try:
                result_data = json.loads(result_str) if result_str else None
            except json.JSONDecodeError:
                result_data = result_str

            return NotebookResult(
                success=True,
                data=result_data,
            )

        except Exception as e:
            error_message = str(e)

            # Check for timeout
            if "timeout" in error_message.lower():
                return NotebookResult(
                    success=False,
                    error_code="TIMEOUT",
                    error_message=f"Notebook execution timed out after {timeout}s",
                )

            return NotebookResult(
                success=False,
                error_code="NOTEBOOK_ERROR",
                error_message=error_message,
            )

    def _extract_result(self, output_path: Path) -> Any:
        """Extract result from executed notebook.

        Looks for a cell tagged with 'result' or the last cell output.

        Args:
            output_path: Path to executed notebook.

        Returns:
            Extracted result data.
        """
        try:
            with output_path.open() as f:
                notebook = json.load(f)

            # Look for result-tagged cell
            for cell in notebook.get("cells", []):
                tags = cell.get("metadata", {}).get("tags", [])
                if "result" in tags:
                    outputs = cell.get("outputs", [])
                    for output in outputs:
                        if "text" in output:
                            text = "".join(output["text"])
                            try:
                                return json.loads(text)
                            except json.JSONDecodeError:
                                return text
                        if "data" in output:
                            data = output["data"]
                            if "application/json" in data:
                                return data["application/json"]
                            if "text/plain" in data:
                                text = "".join(data["text/plain"])
                                try:
                                    return json.loads(text)
                                except json.JSONDecodeError:
                                    return text

            # Fallback: last code cell output
            for cell in reversed(notebook.get("cells", [])):
                if cell.get("cell_type") == "code":
                    outputs = cell.get("outputs", [])
                    for output in outputs:
                        if "data" in output:
                            data = output["data"]
                            if "application/json" in data:
                                return data["application/json"]
                            if "text/plain" in data:
                                text = "".join(data["text/plain"])
                                try:
                                    return json.loads(text)
                                except json.JSONDecodeError:
                                    return text

            return None

        except Exception:
            return None
