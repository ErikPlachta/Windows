# Databricks notebook source
# MAGIC %md
# MAGIC # _settings
# MAGIC
# MAGIC **Auto-generated from:** `_settings.py`
# MAGIC **Build timestamp:** 2025-12-22T22:33:16.604977+00:00
# MAGIC **Content hash:** 466862e57d6f
# MAGIC
# MAGIC > Do not edit directly. Make changes in source and rebuild.

# COMMAND ----------

"""
databricks_api_workspace.services.query.settings - Query service configuration.

Path configuration for query templates.

Constants:
    DEFAULT_WORKSPACE_QUERIES_PATH: Databricks workspace query location
    DEFAULT_LOCAL_QUERIES_PATH: Local development query location
"""

from __future__ import annotations

__all__ = [
    "DEFAULT_WORKSPACE_QUERIES_PATH",
    "DEFAULT_LOCAL_QUERIES_PATH",
]

# Workspace path for queries (in Databricks)
DEFAULT_WORKSPACE_QUERIES_PATH: str = "/Workspace/Shared/databricks-api2/queries"

# Local path for queries (in development)
DEFAULT_LOCAL_QUERIES_PATH: str = "queries"
