# Databricks notebook source
# MAGIC %md
# MAGIC # executor
# MAGIC
# MAGIC **Auto-generated from:** `executor.py`
# MAGIC **Build timestamp:** 2025-12-22T22:33:16.601486+00:00
# MAGIC **Content hash:** 5c3c9390686d
# MAGIC
# MAGIC > Do not edit directly. Make changes in source and rebuild.

# COMMAND ----------

# MAGIC %run ../../core/runtime/_init
# MAGIC %run ../../core/sql_utils/_init
# MAGIC %run ../../services/query/loader

# COMMAND ----------

"""
databricks_api_workspace.services.query.executor - Query execution.

Execute parameterized SQL queries against Spark.

Functions:
    execute_query(): Execute SQL with parameter substitution
    execute_query_by_name(): Load and execute named query
    help(): Display module usage information
"""

from __future__ import annotations

from typing import TYPE_CHECKING, Any


if TYPE_CHECKING:
    from pyspark.sql import DataFrame

__all__ = [
    "execute_query",
    "execute_query_by_name",
    "help",
]


def execute_query(template: str, params: dict[str, Any]) -> DataFrame:
    """Execute parameterized SQL query.

    Substitutes :param_name placeholders and executes via Spark SQL.

    Args:
        template: SQL template with :param_name placeholders.
        params: Parameter name -> value mapping.

    Returns:
        DataFrame: Spark DataFrame with query results.

    Raises:
        AnalysisException: If SQL is invalid.

    Example:
        >>> df = execute_query(
        ...     "SELECT * FROM customers WHERE id = :id",
        ...     {"id": 123}
        ... )
        >>> df.show()
    """
    sql = substitute_params(template, params)
    spark = get_spark()
    return spark.sql(sql)


def execute_query_by_name(
    query_name: str,
    params: dict[str, Any],
    use_cache: bool = True,
) -> DataFrame:
    """Load and execute a named query.

    Combines load_query() and execute_query() for convenience.

    Args:
        query_name: Query name (without .sql extension).
        params: Parameter values.
        use_cache: Whether to use cached query template.

    Returns:
        DataFrame: Spark DataFrame with query results.

    Raises:
        FileNotFoundError: If query file doesn't exist.
        AnalysisException: If SQL is invalid.

    Example:
        >>> df = execute_query_by_name("get_customer_detail", {"id": 123})
        >>> customer = df.first()
    """
    template = load_query(query_name, use_cache=use_cache)
    return execute_query(template, params)


def help() -> str:
    """Display module usage information.

    Returns:
        str: Help text with executor usage.
    """
    return """
databricks_api_workspace.services.query.executor
========================================================

Query execution via Spark SQL.

Functions:
---------
  execute_query(template, params) -> DataFrame
      Execute SQL template with parameter substitution.

  execute_query_by_name(query_name, params, use_cache=True) -> DataFrame
      Load query file and execute with parameters.

Usage:
-----
  from databricks_api_workspace.services.query import (
      execute_query,
      execute_query_by_name,
  )

  # Direct SQL execution
  df = execute_query(
      "SELECT * FROM customers WHERE id = :id",
      {"id": 123}
  )

  # Named query execution (loads from file)
  df = execute_query_by_name("get_customer_detail", {"id": 123})

  # Process results
  df.show()
  results = df.collect()
  first_row = df.first()

Notes:
-----
  - Requires Spark session (get_spark())
  - In Databricks: uses cluster's Spark
  - Locally: uses mock or local Spark session
"""
