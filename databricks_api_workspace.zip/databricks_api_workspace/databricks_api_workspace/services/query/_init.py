# Databricks notebook source
# MAGIC %md
# MAGIC # __init__
# MAGIC
# MAGIC **Auto-generated from:** `__init__.py`
# MAGIC **Build timestamp:** 2025-12-22T22:33:16.606069+00:00
# MAGIC **Content hash:** 25ac5f99c093
# MAGIC
# MAGIC > Do not edit directly. Make changes in source and rebuild.

# COMMAND ----------

# MAGIC %run ../../services/query/_settings
# MAGIC %run ../../services/query/executor
# MAGIC %run ../../services/query/loader

# COMMAND ----------

"""
databricks_api_workspace.services.query - Query execution service.

Load and execute parameterized SQL queries against Spark.

Functions:
    load_query(): Load SQL template from file
    execute_query(): Execute SQL with parameter substitution
    execute_query_by_name(): Load and execute named query
    clear_query_cache(): Clear template cache
    set_queries_path(): Set custom query paths
    get_queries_path(): Get current query paths
    help(): Display module usage information

Note:
    SQL utilities (escape_sql_string, safe_sql_identifier, substitute_params)
    are in databricks_api_workspace.core.sql_utils

Usage:
    >>> from databricks_api_workspace.services.query import (
    ...     load_query,
    ...     execute_query,
    ...     execute_query_by_name,
    ... )
"""

from __future__ import annotations


__all__ = [
    # Loader
    "load_query",
    "clear_query_cache",
    "set_queries_path",
    "get_queries_path",
    # Executor
    "execute_query",
    "execute_query_by_name",
    # Settings
    "DEFAULT_WORKSPACE_QUERIES_PATH",
    "DEFAULT_LOCAL_QUERIES_PATH",
    # Help
    "help",
]


def help() -> str:
    """Display module usage information.

    Returns:
        str: Help text with query service usage.
    """
    return """
databricks_api_workspace.services.query
===========================================

Query execution service for Spark SQL.

Functions:
---------
  load_query(query_name, use_cache=True) -> str
      Load SQL template from file.

  execute_query(template, params) -> DataFrame
      Execute SQL template with parameter substitution.

  execute_query_by_name(query_name, params, use_cache=True) -> DataFrame
      Load and execute named query.

  clear_query_cache() -> None
      Clear the template cache.

  set_queries_path(workspace_path=None, local_path=None) -> None
      Set custom query file paths.

  get_queries_path() -> dict
      Get current paths.

SQL Utilities:
-------------
  For SQL escaping, parameter validation, and safety functions,
  see databricks_api_workspace.core.sql_utils:
  - escape_sql_string()
  - safe_sql_identifier()
  - substitute_params()
  - validate_params()

Usage:
-----
  from databricks_api_workspace.services.query import (
      execute_query_by_name,
  )
  from databricks_api_workspace.core.sql_utils import (
      escape_sql_string,
  )

  # Execute named query
  df = execute_query_by_name("get_customer_detail", {"id": 123})
  customer = df.first()
"""
