# Databricks notebook source
# MAGIC %md
# MAGIC # loader
# MAGIC
# MAGIC **Auto-generated from:** `loader.py`
# MAGIC **Build timestamp:** 2025-12-22T22:33:16.603752+00:00
# MAGIC **Content hash:** 09be1959fc54
# MAGIC
# MAGIC > Do not edit directly. Make changes in source and rebuild.

# COMMAND ----------

# MAGIC %run ../../core/runtime/_init
# MAGIC %run ../../services/query/_settings

# COMMAND ----------

"""
databricks_api_workspace.services.query.loader - Query template loading.

Load SQL templates from files with caching support.

Functions:
    load_query(): Load SQL template from file
    clear_query_cache(): Clear the template cache
    set_queries_path(): Set custom query paths
    get_queries_path(): Get current query paths
    help(): Display module usage information
"""

from __future__ import annotations

import threading


__all__ = [
    "load_query",
    "clear_query_cache",
    "set_queries_path",
    "get_queries_path",
    "help",
]

# Thread lock for state mutations
_query_lock = threading.Lock()

# Query template cache
_query_cache: dict[str, str] = {}

# Configurable paths
_workspace_queries_path: str = DEFAULT_WORKSPACE_QUERIES_PATH
_local_queries_path: str = DEFAULT_LOCAL_QUERIES_PATH


def load_query(query_name: str, use_cache: bool = True) -> str:
    """Load SQL template from queries folder.

    In Databricks, loads from workspace path.
    Locally, loads from local development path.

    Args:
        query_name: Query name without .sql extension.
        use_cache: Whether to use cached query. Default True.

    Returns:
        str: SQL template string.

    Raises:
        FileNotFoundError: If query file doesn't exist.

    Example:
        >>> template = load_query("get_customer_detail")
        >>> print(template[:50])
        SELECT * FROM customers WHERE customer_id = :id
    """
    if use_cache and query_name in _query_cache:
        return _query_cache[query_name]

    if is_databricks():  # pragma: no cover
        path = f"{_workspace_queries_path}/{query_name}.sql"
    else:
        path = f"{_local_queries_path}/{query_name}.sql"

    with open(path) as f:
        query = f.read()

    if use_cache:
        with _query_lock:
            _query_cache[query_name] = query

    return query


def clear_query_cache() -> None:
    """Clear the query template cache.

    Thread-safe. Useful for testing or forcing reload.

    Example:
        >>> clear_query_cache()
        >>> template = load_query("my_query")  # Reloads from disk
    """
    with _query_lock:
        _query_cache.clear()


def set_queries_path(
    workspace_path: str | None = None,
    local_path: str | None = None,
) -> None:
    """Set custom query paths.

    Thread-safe. Clears cache when paths change.

    Args:
        workspace_path: Workspace path for Databricks.
        local_path: Local path for development.

    Example:
        >>> set_queries_path(local_path="tests/fixtures/queries")
    """
    global _workspace_queries_path, _local_queries_path
    with _query_lock:
        if workspace_path is not None:
            _workspace_queries_path = workspace_path
        if local_path is not None:
            _local_queries_path = local_path
        _query_cache.clear()  # Clear cache when paths change


def get_queries_path() -> dict[str, str]:
    """Get current query paths.

    Returns:
        dict: {"workspace": str, "local": str}
    """
    return {
        "workspace": _workspace_queries_path,
        "local": _local_queries_path,
    }


def help() -> str:
    """Display module usage information.

    Returns:
        str: Help text with loader usage.
    """
    return """
databricks_api_workspace.services.query.loader
======================================================

Query template loading with caching.

Functions:
---------
  load_query(query_name, use_cache=True) -> str
      Load SQL template from file.
      - Databricks: loads from workspace path
      - Local: loads from local development path

  clear_query_cache() -> None
      Clear the template cache.

  set_queries_path(workspace_path=None, local_path=None) -> None
      Set custom query file paths.

  get_queries_path() -> dict
      Get current paths {"workspace": str, "local": str}.

Usage:
-----
  from databricks_api_workspace.services.query import load_query

  # Load a query template
  template = load_query("get_customer_detail")

  # Force reload (bypass cache)
  template = load_query("get_customer_detail", use_cache=False)

  # Custom path for testing
  from databricks_api_workspace.services.query import set_queries_path
  set_queries_path(local_path="tests/fixtures/queries")
"""
