# Databricks notebook source
# MAGIC %md
# MAGIC # __init__
# MAGIC
# MAGIC **Auto-generated from:** `__init__.py`
# MAGIC **Build timestamp:** 2025-12-22T22:33:16.661255+00:00
# MAGIC **Content hash:** 19c7fcafe418
# MAGIC
# MAGIC > Do not edit directly. Make changes in source and rebuild.

# COMMAND ----------

# MAGIC %run ./core/runtime/_init
# MAGIC %run ./main

# COMMAND ----------

"""
databricks_api_workspace - Dual-mode Databricks execution layer.

Develops as standard Python (pytest, type hints, IDE support).
Builds to Databricks notebooks via automated conversion.

Modules:
    main - CLI and Notebook entry point
    core - Foundation utilities
    services - Business logic

Functions:
    help(): Display package usage information
    is_databricks(): Check if running in Databricks
    get_dbutils(): Get dbutils instance (real or mock)
    get_spark(): Get SparkSession (real or mock)
    execute(): Execute a named operation
    execute_async_job(): Execute an async job

Example:
    >>> from databricks_api_workspace import is_databricks, execute
    >>> if is_databricks():
    ...     result = execute("get_customer", {"id": 123})
"""

from __future__ import annotations

__version__ = "0.4.3"

# Runtime functions - core package exports

# Main entry point functions

__all__ = [
    # Version
    "__version__",
    # Runtime
    "is_databricks",
    "get_dbutils",
    "get_spark",
    # Execution
    "execute",
    "execute_async_job",
    # Help
    "help",
]


def help() -> str:
    """Display package usage information.

    Returns:
        str: Help text with package overview and available modules.

    Example:
        >>> import databricks_api_workspace
        >>> print(databricks_api_workspace.help())
    """
    return """
databricks_api_workspace
========================

Dual-mode Databricks execution layer for local development and notebook deployment.

Quick Start:
-----------
  from databricks_api_workspace import is_databricks, execute

  # Check environment
  if is_databricks():
      print("Running in Databricks")

  # Execute an operation
  result = execute("get_customer", {"id": 123})

Available Functions:
-------------------
  is_databricks()     - Check if running in Databricks
  get_dbutils()       - Get dbutils instance (real or mock)
  get_spark()         - Get SparkSession (real or mock)
  execute()           - Execute a named operation
  execute_async_job() - Execute an async job

Submodules:
----------
  main                - CLI and Notebook entry point
  core/               - Foundation utilities (runtime, errors, config, etc.)
  services/           - Business logic (query, response, auth, http, operations)

For detailed help on any module:
  from databricks_api_workspace.core import runtime
  print(runtime.help())
"""
