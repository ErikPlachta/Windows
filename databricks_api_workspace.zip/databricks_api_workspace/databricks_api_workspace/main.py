# Databricks notebook source
# MAGIC %md
# MAGIC # main
# MAGIC
# MAGIC **Auto-generated from:** `main.py`
# MAGIC **Build timestamp:** 2025-12-22T22:33:16.482780+00:00
# MAGIC **Content hash:** ce3426636a78
# MAGIC
# MAGIC > Do not edit directly. Make changes in source and rebuild.

# COMMAND ----------

# MAGIC %run ./services/operations/_init
# MAGIC %run ./services/databricks_async_job/_init

# COMMAND ----------

"""
databricks_api_workspace main entry point.

CLI and Notebook entry point for the databricks_api_workspace package.
Provides unified access to all package functionality.

Functions:
    main(): CLI entry point
    help(): Display usage information
    execute(): Execute an operation
    execute_async_job(): Execute an async job

Example:
    # CLI usage
    python -m databricks_api_workspace --help

    # Notebook usage
    from databricks_api_workspace.main import execute
    result = execute(operation="get_customer", params={"id": 123})
"""

from __future__ import annotations

import argparse
from typing import Any

__all__ = [
    "main",
    "help",
    "execute",
    "execute_async_job",
]


def main() -> int:
    """CLI entry point for databricks_api_workspace.

    Parses command line arguments and dispatches to appropriate handlers.

    Returns:
        int: Exit code (0 for success, non-zero for errors).

    Example:
        python -m databricks_api_workspace --help
    """
    parser = argparse.ArgumentParser(
        prog="databricks_api_workspace",
        description="Dual-mode Databricks execution layer",
    )
    parser.add_argument(
        "--version",
        action="store_true",
        help="Show version and exit",
    )
    parser.add_argument(
        "--info",
        action="store_true",
        help="Show package info and exit",
    )

    args = parser.parse_args()

    if args.version:

        print(f"databricks_api_workspace {__version__}")
        return 0

    if args.info:
        print(help())
        return 0

    # Default: show help
    parser.print_help()
    return 0


def execute(
    operation: str,
    params: dict[str, Any] | None = None,
    *,
    user_context: dict[str, Any] | None = None,
) -> dict[str, Any]:
    """Execute a named operation.

    Primary entry point for executing operations in both local and Databricks
    environments.

    Args:
        operation: Name of the operation to execute.
        params: Operation parameters.
        user_context: Optional user context for authorization.

    Returns:
        dict: Operation result with status, data, and metadata.

    Example:
        >>> result = execute("get_customer", {"id": 123})
        >>> print(result["status"])
        "success"
    """
    # Lazy import to avoid circular dependencies

    params = params or {}
    user_ctx = user_context or {}
    return execute_operation(operation, params, user_ctx)


def execute_async_job(
    operation: str,
    params: dict[str, Any] | None = None,
    *,
    user_context: dict[str, Any] | None = None,
    job_id: str | None = None,
) -> dict[str, Any]:
    """Execute an operation as an async job.

    For long-running operations that should be executed asynchronously.

    Args:
        operation: Name of the operation to execute.
        params: Operation parameters.
        user_context: Optional user context for authorization.
        job_id: Optional job ID for tracking.

    Returns:
        dict: Job submission result with job_id and status.

    Example:
        >>> result = execute_async_job("bulk_export", {"format": "csv"})
        >>> print(result["job_id"])
        "job_12345"
    """
    # Lazy import to avoid circular dependencies

    params = params or {}
    response = submit_async_operation(
        operation=operation,
        params=params,
        user_context=None,  # async_jobs handles user context separately
        correlation_id=job_id,
    )
    return response.to_dict()


def help() -> str:
    """Display package usage information.

    Returns:
        str: Help text with module purpose, available functions, and examples.

    Example:
        >>> from databricks_api_workspace import main
        >>> print(main.help())
    """
    return """
databricks_api_workspace.main
=============================

Main entry point for CLI and Notebook usage.

Available Functions:
-------------------
  main()              - CLI entry point
  execute()           - Execute a named operation
  execute_async_job() - Execute an async job
  help()              - Display this help message

CLI Usage:
---------
  python -m databricks_api_workspace --help
  python -m databricks_api_workspace --version
  python -m databricks_api_workspace --info

Notebook Usage:
--------------
  from databricks_api_workspace.main import execute

  # Execute an operation
  result = execute("get_customer", {"id": 123})

  # Execute async job
  job = execute_async_job("bulk_export", {"format": "csv"})

See Also:
--------
  databricks_api_workspace.config - Package configuration
  databricks_api_workspace.services.operations - Operation execution
  databricks_api_workspace.services.databricks_async_job - Async job management
  databricks_api_workspace.core.runtime - Runtime detection
"""


