# Databricks notebook source
# MAGIC %md
# MAGIC # api_gateway
# MAGIC
# MAGIC **Auto-generated from:** `api_gateway.py`
# MAGIC **Build timestamp:** 2025-12-22T22:33:16.487828+00:00
# MAGIC **Content hash:** f16e7b260a0b
# MAGIC
# MAGIC > Do not edit directly. Make changes in source and rebuild.

# COMMAND ----------

# MAGIC %run ./databricks_api_workspace/services/auth/_init
# MAGIC %run ./databricks_api_workspace/main
# MAGIC %run ./databricks_api_workspace/core/routes/_init
# MAGIC %run ./databricks_api_workspace/services/response/_init
# MAGIC %run ./tests/databricks/_init
# MAGIC %run ./databricks_api_workspace/core/config/_init
# MAGIC %run ./databricks_api_workspace/core/runtime/_init

# COMMAND ----------

"""API Gateway - Main entry point for all API requests.

This module serves as the single entry point for the databricks_api_workspace API.
Deploy as a Databricks job/notebook to serve as the API gateway.

Usage:
    # In Databricks notebook/job:
    from api_gateway import handle_request
    result = handle_request(operation="health", params={})

    # Or run directly with widgets:
    # Set widgets: operation, params, user_id, user_roles, correlation_id, debug
    # Then run the notebook

Parameters:
    operation: Operation name (e.g., "health", "list_routes", "get_customer")
    params: Dict of operation parameters
    user_id: Optional user ID for authentication context
    user_roles: Optional list of user roles
    correlation_id: Optional request correlation ID for tracing
    debug: Enable debug output

Built-in Operations:
    - health: Health check with component status
    - list_routes: List all available routes
    - run_tests: Run package test suite (admin only)
    - config: Get current configuration (admin only)

Custom Operations:
    Custom operations are defined in route configuration files.
    See data/routes/ for available routes.
"""

from __future__ import annotations

import json
import time
from typing import Any

__all__ = [
    "handle_request",
    "main",
]


def handle_request(
    operation: str,
    params: dict[str, Any] | None = None,
    user_id: str | None = None,
    user_roles: list[str] | None = None,
    correlation_id: str | None = None,
    debug: bool = False,
) -> dict[str, Any]:
    """Handle an API request.

    Args:
        operation: Operation name to execute.
        params: Operation parameters.
        user_id: User ID for auth context.
        user_roles: List of user roles.
        correlation_id: Request correlation ID.
        debug: Enable debug output.

    Returns:
        Response dict with status, data, and metadata.

    Example:
        >>> result = handle_request("health")
        >>> print(result["status"])
        'success'
    """

    params = params or {}
    user_roles = user_roles or []
    start_time = time.time()

    if debug:
        print("=== API Gateway Request ===")
        print(f"Operation: {operation}")
        print(f"Params: {json.dumps(params, indent=2)}")
        print(f"User: {user_id or 'anonymous'}")
        print(f"Roles: {user_roles}")

    # Build user context
    if user_id:
        user_context = UserContext(user_id=user_id, roles=user_roles)
    else:
        user_context = create_anonymous_context()

    # Try built-in operations first
    result = _handle_builtin(operation, params, user_context, start_time, correlation_id)

    if result is None:
        # Route through standard execute

        if debug:
            print("Routing through execute()")

        result = execute(
            operation=operation,
            params=params,
            user_context={"user_id": user_context.user_id, "roles": list(user_context.roles)}
            if user_id
            else None,
        )

    # Add correlation ID
    if correlation_id:
        if "metadata" in result:
            result["metadata"]["correlation_id"] = correlation_id
        elif "meta" in result:
            result["meta"]["correlation_id"] = correlation_id

    if debug:
        execution_time = time.time() - start_time
        print("\n=== Response ===")
        print(f"Status: {result.get('status', result.get('meta', {}).get('status', 'unknown'))}")
        print(f"Execution time: {execution_time:.3f}s")

    return result


def _handle_builtin(
    operation: str,
    params: dict[str, Any],
    user_context: Any,
    start_time: float,
    correlation_id: str | None,
) -> dict[str, Any] | None:
    """Handle built-in operations.

    Returns None if operation is not a built-in.
    """
    if operation == "list_routes":

        routes = load_routes()
        route_list = [
            {
                "name": r.get("name"),
                "path": r.get("path"),
                "method": r.get("method", "POST"),
                "operation": r.get("operation"),
                "description": r.get("description", ""),
            }
            for r in routes
        ]
        return build_response(
            data={"routes": route_list, "count": len(route_list)},
            operation="list_routes",
            start_time=start_time,
            correlation_id=correlation_id,
        )

    elif operation == "run_tests":
        if not user_context.has_role("admin"):

            return build_error_response(
                operation="run_tests",
                error_code="UNAUTHORIZED",
                message="Admin role required for run_tests operation",
            )



        results = run_all(verbose=False)
        total_passed = sum(s.passed for s in results.values())
        total_failed = sum(s.failed for s in results.values())

        return build_response(
            data={
                "passed": total_passed,
                "failed": total_failed,
                "total": total_passed + total_failed,
                "suites": {
                    name: {"passed": s.passed, "failed": s.failed} for name, s in results.items()
                },
            },
            operation="run_tests",
            start_time=start_time,
            correlation_id=correlation_id,
        )

    elif operation == "config":
        if not user_context.has_role("admin"):

            return build_error_response(
                operation="config",
                error_code="UNAUTHORIZED",
                message="Admin role required for config operation",
            )


        config = load_config()
        return build_response(
            data={"config": config},
            operation="config",
            start_time=start_time,
            correlation_id=correlation_id,
        )

    return None


def main() -> None:
    """Entry point when run as Databricks notebook.

    Reads parameters from dbutils widgets and executes the request.
    """

    # Get dbutils (will be available in Databricks)

    dbutils = get_dbutils()

    # Get widgets
    dbutils.widgets.text("operation", "health")
    dbutils.widgets.text("params", "{}")
    dbutils.widgets.text("user_id", "")
    dbutils.widgets.text("user_roles", "")
    dbutils.widgets.text("correlation_id", "")
    dbutils.widgets.text("debug", "false")

    operation = dbutils.widgets.get("operation")
    params_json = dbutils.widgets.get("params")
    user_id = dbutils.widgets.get("user_id") or None
    user_roles_str = dbutils.widgets.get("user_roles")
    correlation_id = dbutils.widgets.get("correlation_id") or None
    debug = dbutils.widgets.get("debug").lower() == "true"

    # Parse params
    try:
        params = json.loads(params_json) if params_json else {}
    except json.JSONDecodeError:
        params = {}

    # Parse roles
    user_roles = (
        [r.strip() for r in user_roles_str.split(",") if r.strip()] if user_roles_str else []
    )

    # Execute
    result = handle_request(
        operation=operation,
        params=params,
        user_id=user_id,
        user_roles=user_roles,
        correlation_id=correlation_id,
        debug=debug,
    )

    # Return result
    result_json = json.dumps(result, default=str)
    print(result_json)
    dbutils.notebook.exit(result_json)


