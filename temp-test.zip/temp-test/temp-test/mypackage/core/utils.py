# Databricks notebook source
# MAGIC %md
# MAGIC # utils
# MAGIC
# MAGIC Simple utility functions to test %run imports.

# COMMAND ----------

def greet(name: str) -> str:
    """Return a greeting."""
    return f"Hello, {name}!"


def add(a: int, b: int) -> int:
    """Add two numbers."""
    return a + b


# Test that this module loaded
print(f"[utils.py] Loaded. greet and add are defined.")
