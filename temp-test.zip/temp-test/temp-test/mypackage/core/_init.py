# Databricks notebook source
# MAGIC %md
# MAGIC # core/_init
# MAGIC
# MAGIC Package init - re-exports utils via %run.

# COMMAND ----------

# MAGIC %run ./utils

# COMMAND ----------

# Test that re-export worked
print(f"[core/_init.py] Loaded. greet available: {callable(greet)}")
