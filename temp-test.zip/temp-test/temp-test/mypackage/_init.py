# Databricks notebook source
# MAGIC %md
# MAGIC # mypackage/_init
# MAGIC
# MAGIC Root package init - imports core.

# COMMAND ----------

# MAGIC %run ./core/_init

# COMMAND ----------

# Test that nested re-export worked
print(f"[mypackage/_init.py] Loaded. greet available: {callable(greet)}")
