# Databricks notebook source
# MAGIC %md
# MAGIC # main_entry_absolute
# MAGIC
# MAGIC Alternative test using ABSOLUTE paths.
# MAGIC
# MAGIC **IMPORTANT:** Edit the WORKSPACE_ROOT below to match your upload location!
# MAGIC Example: /Workspace/Users/your.email@company.com/temp-test

# COMMAND ----------

# MAGIC %md
# MAGIC ## Instructions
# MAGIC
# MAGIC 1. Upload this folder to Databricks (e.g., `/Workspace/Users/you@example.com/temp-test/`)
# MAGIC 2. Edit the %run paths below to use absolute paths
# MAGIC 3. Run this notebook
# MAGIC
# MAGIC Example absolute path: `%run /Workspace/Users/you@example.com/temp-test/mypackage/_init`

# COMMAND ----------

# Uncomment and edit this line with your actual workspace path:
# %run /Workspace/Users/YOUR_EMAIL/temp-test/mypackage/_init

# For now, try relative:
# MAGIC %run ./mypackage/_init

# COMMAND ----------

# Test
print("Testing greet:", greet("World"))
print("Testing add:", add(10, 20))
