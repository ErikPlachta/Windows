# Databricks notebook source
# MAGIC %md
# MAGIC # main_entry
# MAGIC
# MAGIC Root-level entry point (like run_tests.py).
# MAGIC Tests importing from mypackage/ which is a sibling folder.

# COMMAND ----------

# MAGIC %run ./mypackage/_init

# COMMAND ----------

# Test that everything is available
print("=" * 50)
print("MAIN ENTRY POINT TEST")
print("=" * 50)

# Test greet function (should be available via %run chain)
result = greet("Databricks")
print(f"greet('Databricks') = {result}")

# Test add function
result = add(2, 3)
print(f"add(2, 3) = {result}")

print("=" * 50)
print("SUCCESS: All functions available!")
print("=" * 50)
