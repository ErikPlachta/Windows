# Databricks notebook source
# MAGIC %md
# MAGIC # standalone_test
# MAGIC
# MAGIC Simple standalone test - no dependencies.
# MAGIC Run this first to verify notebook format is correct.

# COMMAND ----------

print("Hello from standalone test!")
print("If you see this, the notebook format is correct.")

# COMMAND ----------

def my_function():
    return "Function works!"

result = my_function()
print(f"Result: {result}")

# COMMAND ----------

# MAGIC %md
# MAGIC ## Test Complete
# MAGIC
# MAGIC If all cells ran, the notebook format is valid.
