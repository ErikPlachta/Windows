# Databricks %run Test Structure

## Structure

```
temp-test/
├── main_entry.py              # Root entry point (like run_tests.py)
├── main_entry_absolute.py     # Alternative with absolute path instructions
├── standalone_test.py         # Simple test, no dependencies
├── mypackage/
│   ├── _init.py               # Package init, %runs core/_init
│   └── core/
│       ├── _init.py           # Core init, %runs utils
│       └── utils.py           # Actual functions (greet, add)
```

## Test Order

1. **standalone_test.py** - Run first to verify notebook format works
2. **mypackage/core/utils.py** - Run to verify base module works
3. **mypackage/core/_init.py** - Run to test single %run
4. **mypackage/_init.py** - Run to test nested %run
5. **main_entry.py** - Run full chain from root

## What We're Testing

- `%run ./relative/path` from different depths
- Re-export pattern (functions available after %run chain)
- Root-level notebook importing from nested package

## Expected Output (main_entry.py)

```
[utils.py] Loaded. greet and add are defined.
[core/_init.py] Loaded. greet available: True
[mypackage/_init.py] Loaded. greet available: True
==================================================
MAIN ENTRY POINT TEST
==================================================
greet('Databricks') = Hello, Databricks!
add(2, 3) = 5
==================================================
SUCCESS: All functions available!
==================================================
```

## If It Fails

Report back:
1. Which notebook failed
2. Exact error message
3. The %run path that failed
