$modulePath = Join-Path $PSScriptRoot "SqlObjectBackup\SqlObjectBackup.psd1"
Import-Module -Name $modulePath -Force -ErrorAction Stop

Write-Host "`nModule imported from local path: $modulePath" -ForegroundColor Cyan

Backup-SqlObjects -ServerName "your-server.database.windows.net" `
                  -DatabaseName "your-database"