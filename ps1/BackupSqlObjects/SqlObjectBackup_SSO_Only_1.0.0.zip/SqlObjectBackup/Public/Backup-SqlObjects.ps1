function Backup-SqlObjects {
    [CmdletBinding()]
    param (
        [Parameter(Mandatory = $true)]
        [string]$ServerName,

        [Parameter(Mandatory = $true)]
        [string]$DatabaseName,

        [string]$OutputFolder = ".\SqlObjectBackups"
    )

    if (!(Test-Path -Path $OutputFolder)) {
        New-Item -ItemType Directory -Path $OutputFolder | Out-Null
    }

    $connectionString = Get-ConnectionString -ServerName $ServerName -DatabaseName $DatabaseName

    $changedObjects = Get-SqlChangedObjects -ConnectionString $connectionString -SinceDate (Get-Date).AddDays(-7)

    foreach ($obj in $changedObjects) {
        Save-SqlObjectToFile -ObjectInfo $obj -OutputFolder $OutputFolder
    }

    Write-Host "Backup completed successfully." -ForegroundColor Green
}