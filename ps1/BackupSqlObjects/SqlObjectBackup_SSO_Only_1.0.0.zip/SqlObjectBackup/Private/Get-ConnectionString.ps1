function Get-ConnectionString {
    param (
        [string]$ServerName,
        [string]$DatabaseName
    )

    return "Server=tcp:$ServerName;Database=$DatabaseName;Integrated Security=True;Encrypt=True;TrustServerCertificate=False;Connection Timeout=30;"
}