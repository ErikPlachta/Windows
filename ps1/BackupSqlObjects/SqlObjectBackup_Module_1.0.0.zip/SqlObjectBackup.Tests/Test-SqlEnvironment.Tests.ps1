Describe "Test-SqlEnvironment" {
    It "Should return a boolean result" {
        $result = Test-SqlEnvironment
        $result | Should -BeOfType 'System.Boolean'
    }
}