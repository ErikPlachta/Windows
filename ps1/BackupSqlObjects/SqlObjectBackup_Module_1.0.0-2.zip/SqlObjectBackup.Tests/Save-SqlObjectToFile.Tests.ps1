Describe "Save-SqlObjectToFile" {
    It "Should create a .sql file safely" {
        $obj = [pscustomobject]@{
            SchemaName = "dbo"
            ObjectName = "test_proc"
            ObjectType = "StoredProcedure"
            SqlDefinition = "CREATE PROCEDURE test_proc AS SELECT 1;"
        }
        $outPath = "$env:TEMP\SqlObjectTest"

        if (-not (Test-Path $outPath)) {
            New-Item -ItemType Directory -Path $outPath | Out-Null
        }

        Save-SqlObjectToFile -ObjectInfo $obj -OutputFolder $outPath

        $file = Join-Path $outPath "dbo.test_proc.StoredProcedure.sql"
        Test-Path $file | Should -BeTrue

        Remove-Item -Path $file -Force
    }
}