Describe "Get-SqlChangedObjects" {
    Mock Add-Type {}
    Mock ([System.Data.SqlClient.SqlConnection]) {
        $mockConnection = [pscustomobject]@{
            Open = { return }
            Close = { return }
            CreateCommand = {
                $cmd = New-Object PSObject
                $cmd | Add-Member -MemberType ScriptMethod -Name ExecuteReader -Value { @() }
                return $cmd
            }
        }
        return $mockConnection
    }

    It "Should return a collection" {
        $result = Get-SqlChangedObjects -ConnectionString "mock" -SinceDate (Get-Date)
        $result | Should -BeOfType System.Object[]
    }
}