Describe "Get-ConnectionString" {
    Mock Read-Host { "mockuser" }
    Mock ([Runtime.InteropServices.Marshal]::PtrToStringAuto) { "mockpassword" }

    It "Should return a connection string for SQL auth" {
        $result = Get-ConnectionString -ServerName "server" -DatabaseName "db" -AuthenticationType "Sql"
        $result | Should -Match "Server=tcp:"
    }
}