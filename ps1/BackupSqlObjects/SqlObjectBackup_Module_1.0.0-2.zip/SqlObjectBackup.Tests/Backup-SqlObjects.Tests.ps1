Describe "Backup-SqlObjects" {
    Mock Get-ConnectionString { return "FakeConnectionString" }
    Mock Get-SqlChangedObjects { return @(@{ SchemaName="dbo"; ObjectName="TestProc"; ObjectType="StoredProcedure"; SqlDefinition="CREATE PROCEDURE..." }) }
    Mock Save-SqlObjectToFile {}

    It "Should execute without error with mocks" {
        { Backup-SqlObjects -ServerName "test" -DatabaseName "test" -AuthenticationType "Sql" } | Should -Not -Throw
    }
}