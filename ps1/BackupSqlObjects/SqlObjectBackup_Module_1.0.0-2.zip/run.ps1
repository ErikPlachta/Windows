$modulePath = Join-Path $PSScriptRoot "SqlObjectBackup\SqlObjectBackup.psd1"
Import-Module -Name $modulePath -Force -ErrorAction Stop

Write-Host "`n[1/4] Module imported from local path: $modulePath" -ForegroundColor Cyan

Write-Host "`n[2/4] Running environment check..." -ForegroundColor Cyan
if (-not (Test-SqlEnvironment)) {
    Write-Error "Environment validation failed. Exiting script."
    exit 1
}

Write-Host "`n[3/4] Running backup (dry run, placeholder)...`n" -ForegroundColor Cyan

# Backup-SqlObjects -ServerName "your-server.database.windows.net" `
#                   -DatabaseName "your-database" `
#                   -AuthenticationType "Sql" `
#                   -SinceDate (Get-Date).AddDays(-3)

Write-Host "Backup command stub completed." -ForegroundColor Yellow

Write-Host "`n[4/4] Running Pester tests..." -ForegroundColor Cyan
Invoke-Pester -Path "$PSScriptRoot\SqlObjectBackup.Tests" -Output Detailed