function Backup-SqlObjects {
    [CmdletBinding()]
    param (
        [Parameter(Mandatory = $true)]
        [string]$ServerName,

        [Parameter(Mandatory = $true)]
        [string]$DatabaseName,

        [string]$OutputFolder = ".\SqlObjectBackups",

        [datetime]$SinceDate = (Get-Date).AddDays(-7),

        [ValidateSet("Sql", "Windows", "AzureADIntegrated")]
        [string]$AuthenticationType = "Sql"
    )

    if (!(Test-Path -Path $OutputFolder)) {
        New-Item -ItemType Directory -Path $OutputFolder | Out-Null
    }

    $connectionString = Get-ConnectionString -ServerName $ServerName -DatabaseName $DatabaseName -AuthenticationType $AuthenticationType

    if (-not $connectionString) {
        throw "Unable to create a valid connection string."
    }

    $changedObjects = Get-SqlChangedObjects -ConnectionString $connectionString -SinceDate $SinceDate

    foreach ($obj in $changedObjects) {
        Save-SqlObjectToFile -ObjectInfo $obj -OutputFolder $OutputFolder
    }

    Write-Host "Backup completed successfully." -ForegroundColor Green
}