function Test-SqlEnvironment {
    [CmdletBinding()]
    param ()

    Write-Host "Checking environment prerequisites..." -ForegroundColor Cyan

    $errors = @()

    if ($PSVersionTable.PSVersion.Major -lt 5) {
        $errors += "PowerShell 5.1 or later is required."
    }

    try {
        Add-Type -AssemblyName "System.Data"
    } catch {
        $errors += "System.Data.SqlClient (System.Data.dll) not available."
    }

    $adalPaths = @{
        '64-bit' = "$env:WINDIR\System32\adalsql.dll"
        '32-bit' = "$env:WINDIR\SysWOW64\adalsql.dll"
    }

    foreach ($arch in $adalPaths.Keys) {
        if (-not (Test-Path $adalPaths[$arch])) {
            $errors += "Missing $arch ADALSQL.DLL at $($adalPaths[$arch])"
        }
    }

    $regKeys = @(
        'HKLM:\SOFTWARE\Microsoft\MSADALSQL',
        'HKLM:\SOFTWARE\WOW6432Node\Microsoft\MSADALSQL'
    )

    foreach ($key in $regKeys) {
        if (-not (Test-Path $key)) {
            $errors += "Missing registry key: $key"
        }
    }

    if ($errors.Count -eq 0) {
        Write-Host "All dependency checks passed." -ForegroundColor Green
        return $true
    } else {
        Write-Warning "Dependency check failed:"
        $errors | ForEach-Object { Write-Warning " - $_" }
        return $false
    }
}