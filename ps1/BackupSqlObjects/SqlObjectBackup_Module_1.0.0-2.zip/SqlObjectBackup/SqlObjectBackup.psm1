Get-ChildItem -Path $PSScriptRoot\Private\*.ps1 -Recurse | ForEach-Object { . $_.FullName }
Get-ChildItem -Path $PSScriptRoot\Public\*.ps1 -Recurse | ForEach-Object { . $_.FullName }