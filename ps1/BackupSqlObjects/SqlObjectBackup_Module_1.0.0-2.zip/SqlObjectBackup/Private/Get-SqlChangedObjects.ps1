function Get-SqlChangedObjects {
    param (
        [string]$ConnectionString,
        [datetime]$SinceDate
    )

    Add-Type -AssemblyName "System.Data"
    $results = @()

    $query = @"
SELECT 
    s.name AS SchemaName,
    o.name AS ObjectName,
    o.type_desc AS ObjectType,
    o.modify_date,
    m.definition AS SqlDefinition
FROM sys.objects o
JOIN sys.sql_modules m ON o.object_id = m.object_id
JOIN sys.schemas s ON o.schema_id = s.schema_id
WHERE o.type IN ('P', 'V', 'FN', 'TF', 'IF')
AND o.modify_date >= '$($SinceDate.ToString("yyyy-MM-dd HH:mm:ss"))'
ORDER BY o.modify_date DESC
"@

    $connection = New-Object System.Data.SqlClient.SqlConnection $ConnectionString
    $command = $connection.CreateCommand()
    $command.CommandText = $query
    $connection.Open()
    $reader = $command.ExecuteReader()

    while ($reader.Read()) {
        $results += [PSCustomObject]@{
            SchemaName    = $reader["SchemaName"]
            ObjectName    = $reader["ObjectName"]
            ObjectType    = $reader["ObjectType"]
            ModifyDate    = $reader["modify_date"]
            SqlDefinition = $reader["SqlDefinition"]
        }
    }

    $reader.Close()
    $connection.Close()

    return $results
}