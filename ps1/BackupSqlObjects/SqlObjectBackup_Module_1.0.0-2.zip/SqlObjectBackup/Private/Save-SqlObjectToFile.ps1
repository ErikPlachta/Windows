function Save-SqlObjectToFile {
    param (
        [pscustomobject]$ObjectInfo,
        [string]$OutputFolder
    )

    $safeFileName = "$($ObjectInfo.SchemaName).$($ObjectInfo.ObjectName).$($ObjectInfo.ObjectType).sql" -replace '[\\/:*?"<>|]', '_'
    $filePath = Join-Path $OutputFolder $safeFileName

    try {
        $ObjectInfo.SqlDefinition | Out-File -FilePath $filePath -Encoding UTF8
        Write-Host "Saved: $filePath"
    } catch {
        Write-Warning "Failed to save: $filePath"
    }
}