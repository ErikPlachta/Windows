function Get-ConnectionString {
    param (
        [string]$ServerName,
        [string]$DatabaseName,
        [string]$AuthenticationType
    )

    switch ($AuthenticationType) {
        "Sql" {
            $UserName = Read-Host -Prompt "Enter SQL Username"
            $SecurePassword = Read-Host -Prompt "Enter SQL Password" -AsSecureString
            $Password = [Runtime.InteropServices.Marshal]::PtrToStringAuto(
                [Runtime.InteropServices.Marshal]::SecureStringToBSTR($SecurePassword)
            )
            return "Server=tcp:$ServerName;Database=$DatabaseName;User ID=$UserName;Password=$Password;Encrypt=True;TrustServerCertificate=False;Connection Timeout=30;"
        }
        "Windows" {
            return "Server=tcp:$ServerName;Database=$DatabaseName;Integrated Security=True;Encrypt=True;TrustServerCertificate=False;Connection Timeout=30;"
        }
        "AzureADIntegrated" {
            if (-not (Test-SqlEnvironment)) {
                Write-Warning "Missing dependencies for Azure AD authentication."
                return $null
            }
            return "Server=tcp:$ServerName;Database=$DatabaseName;Authentication=Active Directory Integrated;Encrypt=True;TrustServerCertificate=False;Connection Timeout=30;"
        }
    }
}