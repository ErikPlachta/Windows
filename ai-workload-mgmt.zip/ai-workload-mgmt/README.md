# AI Workload Management Reference

Reference repo for plan-driven AI workload management across **Claude Code** and **VS Code Copilot**, optimized for **token efficiency**.

## Core principles

1. **Cheap models by default.** Mechanical work (scaffolding, archiving, logging, status, branch ops) routes to GPT-4o / GPT-4.1 / Haiku. Premium models (Opus, Sonnet, GPT-5) are reserved for deep reasoning — planning and `grill-me`.
2. **Plans are the source of truth.** Every non-trivial unit of work is a plan file in `docs/plans/`. Its `## Tasks` checklist IS the todo system. Chat UI todos are a mirror.
3. **Single skill location.** Skills live in `.claude/skills/` — both Claude Code and VS Code Copilot discover them there. One authoring location, both runtimes.
4. **Everything is logged.** Every agent/skill writes to `docs/log/<name>/<session>.md`. Session logs are discoverable, auditable, and feed future context.
5. **Grill-me before committing.** For any non-trivial plan or hard bug, run `grill-me` to pressure-test reasoning before work begins.

## Directory map

```
.
├── README.md                 # this file
├── AGENTS.md                 # cross-tool always-on context
├── CLAUDE.md                 # Claude Code supplements
├── .mcp.json                 # Claude Code MCP config
├── docs/
│   ├── README.md             # docs folder guide
│   ├── plans/                # active plans (inline TODOs = source of truth)
│   ├── changelog/            # archived plans (immutable)
│   └── log/                  # per-agent session logs
├── .claude/
│   ├── settings.json         # permissions, hooks, env
│   ├── agents/               # subagents (grill-me, log-keeper)
│   └── skills/               # ALL SKILLS — shared across tools
│       ├── plan-new/
│       ├── plan-archive/
│       ├── plan-status/
│       ├── plan-sync-todos/
│       ├── grill-me/
│       ├── log-append/
│       ├── onedrive-fetch/
│       └── ado-ticket/
├── .github/
│   ├── copilot-instructions.md
│   ├── instructions/         # scoped rules (plans/**, log/**)
│   ├── prompts/              # Copilot slash commands (cheap-model wrappers)
│   └── agents/               # Copilot personas (planner, executor, archiver)
└── .vscode/
    ├── mcp.json
    ├── settings.json         # discovers .claude/skills/
    └── model-tiers.toolsets.jsonc
```

## Model tier policy

| Tier | Models | Used for |
|---|---|---|
| **Cheap** | GPT-4o, GPT-4.1, GPT-4o-mini, Haiku | Scaffolding, archival, logging, status checks, templating, branch ops, MCP tool calls |
| **Mid** | Sonnet, GPT-5.2 | Task execution, code review, implementation |
| **Premium** | Opus, GPT-5 (high reasoning) | `grill-me`, deep planning, complex architectural decisions |

Every skill, prompt, and agent in this repo declares its tier in its frontmatter. Override locally if your plan differs.

## Primary flow: plan-driven work

```
1. /new-plan <slug>              → scaffolds docs/plans/<slug>.md (cheap)
2. /grill-me <slug>              → pressure-tests the plan (PREMIUM)
3. /sync-todos <slug>            → mirrors ## Tasks into chat UI (cheap)
4. work the plan                 → executor agent, mid-tier
   - reads plan → picks lowest unchecked task
   - does work → updates checkbox + bumps modified:
   - appends to docs/log/executor/<session>.md
   - commits per protocol
5. /status                       → read-only progress report (cheap)
6. /archive-plan <slug>          → git mv to docs/changelog/ (cheap)
```

## Secondary flows

- **OneDrive/SharePoint fetch** — `onedrive-fetch` skill wraps the assumed MCP capability; logs every fetch to `docs/log/onedrive-fetch/`.
- **Azure DevOps tickets** — `ado-ticket` skill handles inquire/get/set/validate via assumed MCP; logs every operation.

## Cross-tool reuse

**Skills are the same file in both tools.** `.claude/skills/<name>/SKILL.md` is read by:
- Claude Code natively (project-scoped skills).
- VS Code Copilot via `chat.skillsLocations` in `.vscode/settings.json` pointing to `.claude/skills/`.

**Agents, prompts, instructions** are tool-specific (different schemas). VS Code's `.agent.md` agents are thin wrappers that invoke the shared skills and pin cheaper models.

## Quick start

```bash
# Create a plan
/new-plan fix-auth-bug

# Pressure-test it (premium model)
/grill-me fix-auth-bug

# Sync todos to chat UI
/sync-todos fix-auth-bug

# Work the plan (executor agent handles task-by-task)
@executor work the next task in fix-auth-bug

# Status check
/status

# When done, archive
/archive-plan fix-auth-bug
```

## References

- `docs/README.md` — plan and log conventions
- `AGENTS.md` — cross-tool project context
- `CLAUDE.md` — Claude-specific rules
- `.github/copilot-instructions.md` — VS Code Copilot workspace rules

## Validation & enforcement

The plan-driven workflow is enforced mechanically at three layers. All three share one validation library at `scripts/plan-validation/lib/` (zod schemas + gray-matter).

| Layer | Fires | What it checks |
|---|---|---|
| Claude Code `PostToolUse` hook | After any Edit/Write in `docs/plans/**` | Auto-bumps `modified:` to today |
| Git `pre-commit` | On `git commit` | Staged plan/log schema, `modified == today`, blocks edits to `docs/changelog/` |
| Git `commit-msg` | On `git commit` | Conventional Commits, scope matches plan slug from branch |
| Git `pre-push` | On `git push` | Full-repo validation + archival-commit presence check |
| CI `plan-validation.yml` | PR + push to main | All of the above |

Setup:

```bash
pnpm install            # installs tsx, zod, gray-matter
pnpm hooks:install      # writes .git/hooks/{pre-commit,commit-msg,pre-push}
```

Manual runs:

```bash
pnpm validate:plans     # schema check every plan + archived plan
pnpm validate:logs      # schema check every log file
pnpm validate:archival  # no slug collisions, changelog status==done, etc.
pnpm validate:branch    # branch/plan frontmatter alignment
pnpm validate:all       # all of the above
```

Emergency bypass: `git commit --no-verify` / `git push --no-verify`. Don't.
