---
session_id: s-xxxxxxxx
agent: <agent-or-skill-name>
started: YYYY-MM-DDTHH:MM:SSZ
ended: YYYY-MM-DDTHH:MM:SSZ
plan_ref:              # docs/plans/<slug>.md or docs/changelog/<slug>.md
task_ref:              # task number from plan, if applicable
model:                 # e.g. gpt-4o, claude-haiku-4-5, claude-opus-4-7
tier: cheap | mid | premium
---

## Summary
<1-2 sentences of what this session did>

## Actions
- <step 1>
- <step 2>

## Decisions
- <non-obvious choices made + rationale>

## Outcome
<result / next step / blocked-on>

## Artifacts
- <files touched, PRs opened, tickets updated, resources fetched>
