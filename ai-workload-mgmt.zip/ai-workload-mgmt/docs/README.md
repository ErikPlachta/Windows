# docs/

All plan-driven workflow artifacts live here. Agents and humans read this folder; it is the operational source of truth.

## Structure

```
docs/
├── README.md            # this file
├── plans/               # ACTIVE plans — one file = one plan
│   ├── _template.md     # copy this to scaffold a new plan
│   └── <slug>.md
├── changelog/           # COMPLETED plans (immutable)
│   └── <slug>.md
└── log/                 # per-agent session logs
    ├── _template.md
    ├── planner/
    ├── executor/
    ├── archiver/
    ├── grill-me/
    ├── onedrive-fetch/
    ├── ado-ticket/
    └── log-keeper/
```

## Plan lifecycle

1. **Create** — copy `plans/_template.md` → `plans/<slug>.md` (use `/new-plan <slug>` or `plan-new` skill).
2. **Active work** — task checklist is the source of truth. Update checkboxes as tasks complete. Bump `modified:` on every edit.
3. **Archive** — when `status: done` and all tasks checked: `git mv` to `changelog/`. Use `/archive-plan` or `plan-archive` skill.

## Plan file schema

YAML frontmatter + markdown body. Dates in ISO (`YYYY-MM-DD`).

```markdown
---
title: <Plan Title>
status: draft          # draft | active | blocked | done
author: <user>
branch: <type>/<slug>
ticket:                # optional — ADO ID, GitHub issue, etc.
created: YYYY-MM-DD
modified: YYYY-MM-DD
completed:             # set on archival only
tier: cheap | mid | premium   # default model tier for tasks
---

# <Plan Title>

## Goal
One sentence.

## Context
Links, background, `docs/log/` references if grilled.

## Tasks
- [ ] 1. <atomic todo>
- [ ] 2. <atomic todo>

## Decisions
- <date>: <decision + rationale>

## Open Questions
- <question>

## Outcome
<!-- Filled on archival. -->
```

**Rules:**
- `title` mirrors the H1.
- `status` transitions: `draft` → `active` → (`blocked` ↔ `active`) → `done`.
- `modified` bumps on every commit touching the plan.
- `completed` blank until archival.
- Research > ~20 lines goes in `docs/log/grill-me/` or a linked file, not inline.

## Todo mirroring

The plan's `## Tasks` checklist IS the todo system. Chat UIs (VS Code Copilot todo panel, Claude Code TodoWrite) mirror it. On divergence, plan file wins. Use `/sync-todos <slug>` or the `plan-sync-todos` skill.

## Log schema

Every agent/skill that does meaningful work appends a session log at `docs/log/<agent>/<session-id>.md`. Use `log-append` skill — do not hand-write.

```markdown
---
session_id: s-a1b2c3d4
agent: <agent-or-skill-name>
started: 2026-04-22T14:30:00Z
ended: 2026-04-22T14:42:00Z
plan_ref: docs/plans/<slug>.md
task_ref: 3                  # task number from plan, if applicable
model: gpt-4o                # which model ran this
tier: cheap
---

## Summary
<1-2 sentences>

## Actions
- <what was done, in order>

## Decisions
- <non-obvious choices + rationale>

## Outcome
<result / next step / blocked-on>

## Artifacts
- <files touched, PRs opened, tickets updated>
```

Session IDs: `s-` + 8 hex chars. Filename: `<session-id>.md` or `<YYYY-MM-DD>_<session-id>.md`.

## Archival = final commit on plan branch

1. Set `status: done`, `completed: <date>`, bump `modified:`.
2. Fill `## Outcome`.
3. `git mv docs/plans/<slug>.md docs/changelog/<slug>.md`.
4. Grep for `docs/plans/<slug>` — update stale links.
5. Commit: `chore(<slug>): archive plan to changelog`.
6. Open merge PR.

Plans in `changelog/` are immutable. Amendments require a new plan referencing the archived one.
