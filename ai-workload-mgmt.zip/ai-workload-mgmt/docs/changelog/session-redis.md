---
title: Migrate session store from memory to Redis
status: done
author: erik
branch: refactor/session-redis
ticket: ADO-4712
created: 2026-03-14
modified: 2026-03-28
completed: 2026-03-28
tier: mid
---

# Migrate session store from memory to Redis

## Goal
Replace in-memory session store with Redis to support horizontal scaling of the auth service.

## Context
- ADO ticket: ADO-4712
- Grill session: `docs/changelog/log/grill-me/s-2d8e1f90.md`
- Blocked multi-instance deploy tracked in plan `scale-auth-horizontal` (archived).

## Tasks
- [x] 1. Add Redis client to auth service
- [x] 2. Implement RedisSessionStore adapter
- [x] 3. Add feature flag `SESSION_STORE=redis|memory`
- [x] 4. Migrate existing sessions on startup
- [x] 5. Add integration tests against redis:7-alpine
- [x] 6. Update deployment manifests
- [x] 7. Runbook entry for Redis failure modes

## Decisions
- 2026-03-15: Adapter pattern over direct replacement — allows staged rollout via feature flag.
- 2026-03-20: 24h TTL on sessions (unchanged from memory impl). Refresh on access.
- 2026-03-24: Chose `ioredis` over `redis` client for cluster-mode support.

## Outcome
Shipped in PR #1247. Feature flag flipped to `redis` in prod on 2026-03-27; memory path deleted in follow-up plan `remove-memory-session-store`. Enabled the `scale-auth-horizontal` work that landed later the same week. No regressions observed in 48h post-flip.

Follow-ups spawned: `remove-memory-session-store`, `add-session-metrics-grafana`.
