---
slug: auth-rate-limit
set_at: 2026-04-22T09:10:00Z
set_by: erik
branch: feat/auth-rate-limit
---

# Current plan: [auth-rate-limit](./auth-rate-limit.md)

Set via `/plan-current set auth-rate-limit`. Clear with `/plan-current clear`.
