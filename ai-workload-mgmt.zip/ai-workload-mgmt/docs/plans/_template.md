---
title: <Plan Title>
status: draft
author: <user>
branch: <type>/<slug>
ticket:
created: YYYY-MM-DD
modified: YYYY-MM-DD
completed:
tier: mid
---

# <Plan Title>

## Goal
<One sentence. What "done" looks like.>

## Context
<Background, related plans, log refs. Keep links to research/grill sessions in docs/log/grill-me/.>

## Tasks
- [ ] 1. <atomic todo>
- [ ] 2. <atomic todo>
- [ ] 3. <atomic todo>

## Decisions
<!-- append entries as: - YYYY-MM-DD: <decision + rationale> -->

## Open Questions
<!-- - <question> -->

## Outcome
<!-- Filled on archival: what shipped, PR links, follow-up plans. -->
