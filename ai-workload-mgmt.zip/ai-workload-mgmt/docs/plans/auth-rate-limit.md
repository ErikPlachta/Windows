---
title: Add rate limiting to auth endpoints
status: active
author: erik
branch: feat/auth-rate-limit
ticket: ADO-4821
created: 2026-04-20
modified: 2026-04-22
completed:
tier: mid
---

# Add rate limiting to auth endpoints

## Goal
Cap auth endpoints (`/login`, `/register`, `/reset-password`) at 5 req/min per IP to mitigate brute-force risk.

## Context
- ADO ticket: ADO-4821
- Grill session: `docs/log/grill-me/s-7f3a9c21.md` — surfaced shared-IP concern, led to decision to use account+IP composite key
- Existing rate limiter lib: `libs/rate-limit/` (sliding window, Redis-backed)

## Tasks
- [x] 1. Add composite-key strategy (IP + account) to rate-limit lib
- [x] 2. Wire limiter into `/login` handler
- [ ] 3. Wire limiter into `/register` handler
- [ ] 4. Wire limiter into `/reset-password` handler
- [ ] 5. Add integration tests covering shared-IP scenario
- [ ] 6. Add limiter metrics to existing Grafana dashboard
- [ ] 7. Update API docs with 429 response schema

## Decisions
- 2026-04-20: Use composite key (IP + account) instead of IP-only to avoid locking out NAT'd users. Rationale in grill session.
- 2026-04-21: Sliding window over fixed — existing lib already supports it, no need to reinvent.

## Open Questions
- Should `/reset-password` have a stricter limit (2/min)? — pending product sign-off

## Outcome
<!-- Filled on archival. -->
