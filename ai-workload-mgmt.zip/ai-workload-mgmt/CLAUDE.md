# CLAUDE.md

Claude Code project memory. Supplements `AGENTS.md` — read both.

## Claude-specific

- Prefer skills over inline prompting. Skills in `.claude/skills/` are the canonical catalog.
- For deep-analysis tasks (grill-me, complex bug), invoke the `grill-me-subagent` via the Task tool — keeps main context clean.
- For mechanical repeat work (logging, archival, status), let the cheap-tier skills handle it. Don't write templates by hand.
- Append to session logs via the `log-append` skill, never by direct Write calls to `docs/log/`.

## Skill catalog

| Skill | Tier | Purpose |
|---|---|---|
| `plan-new` | cheap | Scaffold new plan file |
| `plan-archive` | cheap | Archive completed plan → changelog |
| `plan-status` | cheap | List active plans + progress |
| `plan-sync-todos` | cheap | Mirror plan `## Tasks` into chat UI |
| `grill-me` | premium | Pressure-test plan/bug/design |
| `log-append` | cheap | Write session log entry |
| `onedrive-fetch` | cheap | Fetch SharePoint/OneDrive resource |
| `ado-ticket` | cheap | Azure DevOps ticket ops |

## Subagents

| Subagent | Tier | Purpose |
|---|---|---|
| `grill-me-subagent` | premium | Isolated deep reasoning for grill sessions |
| `log-keeper` | cheap | Background log aggregation + cleanup |

## Session pattern

1. Check `docs/plans/` for the active plan. If none, ask before creating.
2. Mirror its `## Tasks` via `plan-sync-todos`.
3. Pick lowest unchecked task. Do the work.
4. Check the box, bump `modified:`, log the session, commit.
5. Stop. Wait for user confirmation unless told to continue.

## Tool policy

- Read/Grep/Glob: always allowed
- Edit in `src/`, `tests/`, `docs/`: allowed
- Edit in `.github/workflows/`, `.claude/settings.json`: ask first
- Bash destructive ops (`rm -rf`, `git push --force`, `git reset --hard`): denied
- Network / MCP: allowed for declared servers only

## Validation awareness

Edits to `docs/plans/**` trigger the `PostToolUse` bump-modified hook — `modified:` is auto-corrected to today. Don't write the date manually; let the hook handle it.

`git commit` is preceded by a `PreToolUse` hook that runs `pnpm validate:plans && pnpm validate:logs`. If it fails, fix the reported issues rather than bypassing with `--no-verify`.

Branch/slug/scope must align:
- Branch `<type>/<slug>` ↔ plan file `docs/plans/<slug>.md` ↔ frontmatter `branch:` ↔ commit scope `<type>(<slug>):`
- Mismatch anywhere → commit-msg or pre-push hook fails. Fix the source of truth (usually the plan file) rather than the check.
