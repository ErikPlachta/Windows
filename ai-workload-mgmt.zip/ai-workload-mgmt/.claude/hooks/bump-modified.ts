#!/usr/bin/env -S npx tsx
/**
 * Claude Code PostToolUse hook for Edit/Write on docs/plans/**.
 *
 * Runs inside Claude Code's tool loop after an edit. If the edited file is a plan
 * and its `modified:` frontmatter isn't today, rewrite the frontmatter with
 * today's date. Complements the pre-commit git hook — this one catches it
 * immediately so the agent sees the corrected state before committing.
 *
 * Input: file path as $1 (Claude Code passes the tool input via env/args).
 */
import { existsSync } from 'node:fs';
import { readMarkdown, writeMarkdown } from '../../scripts/plan-validation/lib/frontmatter.ts';
import { PlanFrontmatterSchema } from '../../scripts/plan-validation/lib/schema.ts';
import { today } from '../../scripts/plan-validation/lib/today.ts';

const file = process.argv[2] ?? process.env['TOOL_INPUT_FILE'] ?? '';

if (!file) {
  // No file argument — nothing to do. Exit clean so the hook never blocks the loop.
  process.exit(0);
}

if (!file.startsWith('docs/plans/') || !file.endsWith('.md') || file.endsWith('/_template.md')) {
  process.exit(0);
}

if (!existsSync(file)) {
  process.exit(0);
}

try {
  const parsed = readMarkdown(file);
  const result = PlanFrontmatterSchema.safeParse(parsed.data);
  if (!result.success) {
    // Schema invalid — let pre-commit / validate:plans report it. Hook stays silent.
    process.exit(0);
  }

  const now = today();
  if (result.data.modified === now) {
    process.exit(0);
  }

  const updated = { ...result.data, modified: now };
  writeMarkdown(file, updated, parsed.body);
  console.log(`[bump-modified] ${file}: modified -> ${now}`);
  process.exit(0);
} catch (err) {
  console.error(`[bump-modified] ${file}: ${(err as Error).message}`);
  // Never fail the tool call over a hook error — just log.
  process.exit(0);
}
