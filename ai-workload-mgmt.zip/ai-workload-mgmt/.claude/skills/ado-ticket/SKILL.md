---
name: ado-ticket
description: Azure DevOps work-item operations via the ADO MCP — inquire, get, set, validate, link. Use when the user references an ADO ticket ID, asks to "update the ticket", "pull ADO-XXXX", "set state to active", "add comment", or needs work-item context for a plan.
argument-hint: "<operation> <ticket-id> [args]"
allowed-tools: azure-devops/*, Read, Write
model: gpt-4o-mini
metadata:
  tier: cheap
---

# ado-ticket

Thin wrapper around the Azure DevOps MCP. Assumes the MCP handles auth and API semantics — this skill orchestrates common operations consistently.

## Operations

### get
`ado-ticket get <id>` — fetch full ticket: title, description, state, assignedTo, acceptance criteria, related items, comments.

### set
`ado-ticket set <id> <field>=<value> [...]` — update fields. Always confirm with user before writing. Supported fields: `state`, `assignedTo`, `iteration`, `tags`, `title`.

### inquire
`ado-ticket inquire <query>` — WIQL or free-text search. Returns compact table of matching tickets.

### validate
`ado-ticket validate <id>` — check ticket against team conventions: has AC, has iteration, has assignee if state=Active, description non-empty.

### link
`ado-ticket link <id> <url>` — add a URL (PR, plan file, commit) to the ticket's related items.

### comment
`ado-ticket comment <id> <text>` — append comment. Auto-prefix with `[agent:<n>]`.

## Steps

1. Parse operation + args.
2. For write operations (`set`, `link`, `comment`), show the proposed change and confirm with user.
3. Invoke the corresponding MCP tool.
4. On failure, report the error verbatim — don't retry silently.
5. Invoke `log-append` → `docs/log/ado-ticket/<session-id>.md`.

## Auto-linking

When called from within a plan context (caller passes `plan_ref`), auto-append the plan link to the ticket on first `set state=Active`.

## Do not

- Invent field values. If the user's intent is ambiguous, ask.
- Batch-update multiple tickets without explicit confirmation per ticket.
- Store PATs or auth tokens — that's the MCP's concern.
- Change state to `Closed`/`Done` without user confirmation, even if all tasks complete.
