---
name: plan-archive
description: Archive a completed plan from docs/plans/ to docs/changelog/. Use when all tasks are checked and status is ready to flip to done. Sets completed date, moves file, updates links, commits. Also archives the plan's grill/planner/executor logs.
argument-hint: "<slug>"
allowed-tools: Read, Edit, Bash(git *), Bash(grep *), Bash(sed *)
model: haiku
metadata:
  tier: cheap
---

# plan-archive

Mechanical archival of a completed plan.

## Preconditions (fail loudly if not met)

- `docs/plans/<slug>.md` exists
- All checkboxes in `## Tasks` are `[x]`
- `## Outcome` section has content (not just the HTML comment placeholder)
- Working tree is clean except for the plan file

## Steps

1. Read plan. Verify preconditions. If any fail, abort with clear message.
2. Update frontmatter:
   - `status: done`
   - `completed: <today>`
   - `modified: <today>`
3. If `## Outcome` still contains the template comment, abort — user must fill it first.
4. `git mv docs/plans/<slug>.md docs/changelog/<slug>.md`.
5. Grep for stale references: `grep -rl "docs/plans/<slug>"` — for each hit (excluding the changelog file itself), update to `docs/changelog/<slug>`.
6. Commit: `chore(<slug>): archive plan to changelog`.
7. Invoke `log-append` skill for `docs/log/archiver/<session-id>.md`.

## After archival

Prompt the user:

```
Plan archived. Next actions:
  - Open PR: gh pr create --title "<type>(<slug>): <goal>" --body-file <tmpl>
  - Delete branch after merge: git branch -D <type>/<slug>
```

Do not open the PR automatically — that's an explicit user decision.

## Do not

- Archive if `status != done` or any task unchecked.
- Overwrite a file in `docs/changelog/` — slug collision means abort.
- Edit the plan content beyond frontmatter + link fixes.
- Run on a branch that isn't the plan's own branch (check frontmatter `branch:` matches current).
