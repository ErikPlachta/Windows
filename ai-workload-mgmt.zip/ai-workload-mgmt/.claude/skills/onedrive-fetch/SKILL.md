---
name: onedrive-fetch
description: Fetch a resource from OneDrive or SharePoint via the Microsoft Graph MCP. Use when the user provides a SharePoint link, drive-item ID, or asks to "get the spec from OneDrive", "pull the doc", "fetch from SharePoint". Caches locally and logs the fetch.
argument-hint: "<share-link | drive-item-id | search-query>"
allowed-tools: microsoft-graph/*, Write, Read
model: gpt-4o-mini
metadata:
  tier: cheap
---

# onedrive-fetch

Thin wrapper around the Microsoft Graph MCP for SharePoint/OneDrive resource retrieval. Assumes the MCP knows how to auth, list, get, and download — this skill just orchestrates.

## Inputs

- Share link (e.g. `https://contoso.sharepoint.com/:w:/s/...`)
- Drive-item ID
- Free-text search (file name or keyword)

## Steps

1. Resolve input to a drive-item:
   - Share link → `microsoft-graph/resolve_share_link`
   - ID → use directly
   - Search → `microsoft-graph/search_drive_items` → confirm top hit with user if ambiguous
2. Fetch metadata: name, size, mime, lastModified.
3. If > 5 MB or binary non-convertible type, confirm with user before downloading.
4. Download via `microsoft-graph/get_drive_item_content`.
5. If `.docx` / `.pptx` / `.xlsx`, convert to markdown (use the relevant skill: `docx`, `pptx`, `xlsx`).
6. Cache to `docs/cache/<slugified-name>.md` (gitignored).
7. Return path + short summary (first 3 headings or first 200 chars).
8. Invoke `log-append` → `docs/log/onedrive-fetch/<session-id>.md`.

## Do not

- Store credentials. Auth is the MCP's concern.
- Commit fetched content — `docs/cache/` must be gitignored.
- Re-fetch if a recent cached copy exists (< 24h) unless user forces refresh.
- Escalate to premium model — this is orchestration, not reasoning.
