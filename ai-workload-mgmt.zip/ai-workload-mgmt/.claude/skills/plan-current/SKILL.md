---
name: plan-current
description: Manage docs/plans/_current.md — thin pointer to the active plan. Use when switching plans ("switch to <slug>", "what's the current plan", "clear current plan"). Read, set, clear operations. All other skills read this file to know what plan to operate on when no slug is provided.
argument-hint: "[get|set <slug>|clear]"
allowed-tools: Read, Write, Edit, Bash(test *), Bash(cat *)
model: haiku
metadata:
  tier: cheap
---

# plan-current

Pointer file at `docs/plans/_current.md` tracks which plan is active in the current session/branch context. Thin — just frontmatter + a link.

## Schema of _current.md

```markdown
---
slug: auth-rate-limit
set_at: 2026-04-22T14:30:00Z
set_by: erik
branch: feat/auth-rate-limit
---

# Current plan: [auth-rate-limit](./auth-rate-limit.md)

Cleared or changed via `/plan-current set <slug>` or `/plan-current clear`.
```

## Operations

### get (default when no args)

1. Read `docs/plans/_current.md`.
2. If missing or empty: report "no current plan set".
3. If set: print slug, branch, set_at, and the plan's current status + task progress (reuse `plan-status` single-plan view for this).
4. Verify the pointed-to plan still exists in `docs/plans/`. If it's been archived, note that and suggest clearing.

### set <slug>

1. Verify `docs/plans/<slug>.md` exists and is not in `docs/changelog/`.
2. Read that plan's `branch:` frontmatter.
3. Warn if current git branch doesn't match the plan's branch.
4. Write `docs/plans/_current.md` with the schema above.
5. Invoke `log-append` for `docs/log/plan-current/<session-id>.md`.
6. Do NOT commit — pointer changes are session-scoped and typically gitignored (see Rules below).

### clear

1. Truncate `docs/plans/_current.md` to empty frontmatter + "No current plan." line.
2. Log the clear.

## Rules

- `_current.md` is session/developer state, not workflow state. Add to `.gitignore` if you don't want it tracked.
- If it IS tracked (team wants to share "what we're working on right now"), don't bump `modified:` on every set — it would churn diffs. The pre-commit hook should skip this file.
- Skills and agents that accept an optional `<slug>` argument should fall back to reading this file when the arg is empty.

## Do not

- Set to an archived plan.
- Overwrite a set pointer without prompting the user.
- Infer current plan from git branch — always read the file. Branch and plan can diverge briefly (e.g., during archival).
