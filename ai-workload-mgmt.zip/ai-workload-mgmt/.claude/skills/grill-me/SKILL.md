---
name: grill-me
description: Pressure-test a plan, design, bug hypothesis, or decision. Use when the user says "grill me", "stress-test this", "poke holes", "challenge my plan", "find the gaps", "play devil's advocate", or when a plan feels shaky before starting work. Surfaces concerns — does NOT rewrite or fix.
argument-hint: "[slug | topic]"
allowed-tools: Read, Grep, Glob
model: opus
metadata:
  tier: premium
---

# grill-me

Adversarial-collaborative interrogation. Surface risks, unstated assumptions, missing steps, and failure modes.

## Input

- `$ARGUMENTS = <slug>` → grill the plan at `docs/plans/<slug>.md`.
- `$ARGUMENTS = <topic>` or empty → grill whatever the user is currently describing.

## Method

For each claim, step, or assumption, ask in this order:

1. **What breaks if this is wrong?** — identify failure mode
2. **What's the worst-case input/state?** — probe edges
3. **What's unstated?** — surface hidden assumptions
4. **What's missing?** — flag absent error handling, observability, tests, rollback
5. **What's misordered?** — check dependencies

Go one round at a time. Let the user respond. Mark decisions and move on — do not re-litigate resolved points.

## Stop conditions

- All concerns addressed or explicitly deferred.
- User says "proceed" / "enough" / "ship it".
- Three rounds with no new concerns.

## Output per round

```markdown
## Round N

### Blocker
- <concern> — <failure mode if unaddressed>

### Major
- <concern>

### Minor
- <concern>

### Resolved this round
- <what the user clarified>

### Proceed?
YES / NO — <reason if no>
```

## On completion

1. Invoke `log-append` skill → `docs/log/grill-me/<session-id>.md` with the full transcript summary, decisions reached, and final proceed verdict.
2. If the plan file was updated during the session, verify `modified:` was bumped. (Don't bump it yourself — that's the user's commit.)
3. Return a final one-line verdict: `Ready to proceed` / `Blocked on: <...>`.

## Do not

- Rewrite the plan for the user.
- Be sycophantic. "Good question" is filler. Skip it.
- Chase stylistic nits — focus on correctness, risk, and completeness.
- Escalate minor issues to blockers to seem thorough.
