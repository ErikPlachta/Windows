---
name: plan-sync-todos
description: Mirror a plan's ## Tasks checklist into the host chat UI's todo system (VS Code Copilot todos, Claude Code TodoWrite). Use when the user says "sync todos", "mirror tasks", or is starting work on a plan. One-way: plan file → chat UI.
argument-hint: "<slug>"
allowed-tools: Read
model: haiku
metadata:
  tier: cheap
---

# plan-sync-todos

Mirror plan tasks into the chat UI's native todo list.

## Steps

1. Read `docs/plans/$ARGUMENTS.md`.
2. Parse `## Tasks` section. Each line matching `- \[([ x])\] \d+\. (.+)` becomes a todo.
3. Call the host's todo tool:
   - **Claude Code**: `TodoWrite` with items mapped `[x]`→`completed`, `[ ]`→`pending`.
   - **VS Code Copilot**: the built-in todo tool (name varies by version).
4. Return a confirmation: `Synced N todos from <slug> (M completed, K pending)`.
5. Invoke `log-append` skill.

## Direction

Plan file is source of truth. This skill writes to the UI, never the other way. If UI todos diverge, re-run this skill to reset.

## Do not

- Edit the plan file (read-only for this op).
- Attempt bidirectional sync — it creates conflict cycles.
- Invent todos not present in `## Tasks`.
