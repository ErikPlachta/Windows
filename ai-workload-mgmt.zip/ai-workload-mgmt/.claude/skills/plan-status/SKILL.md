---
name: plan-status
description: Read-only status report across active plans. Use when the user asks "what's the status", "what plans are active", "show me todos", "where are we on <slug>". Outputs a compact table. Never modifies anything.
argument-hint: "[slug]"
allowed-tools: Read, Grep, Glob, Bash(git branch *), Bash(git log *)
model: haiku
metadata:
  tier: cheap
---

# plan-status

Read-only progress report. Never edits.

## Inputs

- `$ARGUMENTS` empty → check `docs/plans/_current.md`. If set, show single-plan view for that slug. If not set, show all-plans view.
- `$ARGUMENTS = --all` → force all-plans view even if current is set.
- `$ARGUMENTS = <slug>` → detailed view of that plan.

## All-plans view

1. Glob `docs/plans/*.md` (excluding `_template.md`).
2. For each, parse frontmatter + count `[x]`/`[ ]` in `## Tasks`.
3. Output table:

```
| Slug | Status | Tasks | Branch | Modified | Ticket |
|---|---|---|---|---|---|
| auth-rate-limit | active | 2/7 | feat/auth-rate-limit | 2026-04-22 | ADO-4821 |
| ... |
```

4. Flag anomalies:
   - `status: blocked` → highlight
   - `modified` older than 14 days → "stale?"
   - branch not matching frontmatter → "branch drift"

## Single-plan view

1. Read plan file.
2. Show frontmatter, `## Goal`, task breakdown, `## Open Questions`.
3. List session logs referencing this plan: `grep -rl "plan_ref: docs/plans/<slug>.md" docs/log/`.
4. Show last 3 commits touching the plan: `git log -3 --oneline -- docs/plans/<slug>.md`.

## Do not

- Write files (including logs — this is read-only; no log entry needed).
- Run long git operations. Stick to `git log -n 3` and similar bounded queries.
- Escalate to premium model.
