---
name: planner-setup
description: Verify the repo and host environment are correctly configured for plan-driven workflow. Checks VS Code settings (subagent nesting, agent locations), Claude Code settings, git hooks, MCP availability, and current-plan pointer. Use on first setup, after cloning, or when handoffs/subagents misbehave.
allowed-tools: Read, Bash(git *), Bash(test *), Bash(cat *), Bash(ls *), Bash(code --*), Write
model: haiku
metadata:
  tier: cheap
---

# planner-setup

Environment + configuration verifier. Non-destructive by default — reports issues, offers fixes, never silently mutates settings.

## Checks

### 1. Git hooks installed
- `test -x .git/hooks/pre-commit && test -x .git/hooks/commit-msg && test -x .git/hooks/pre-push`
- Fail → suggest `pnpm install && pnpm hooks:install`

### 2. TypeScript runtime available
- `which tsx || npx --no-install tsx --version`
- Fail → suggest `pnpm install`

### 3. Validation passes
- Run `pnpm validate:all`. Any failures = setup incomplete.

### 4. Claude Code settings
- `.claude/settings.json` exists and has `hooks.PostToolUse` with `bump-modified.ts`
- `.mcp.json` exists with expected servers (github, microsoft-graph, azure-devops)

### 5. VS Code settings
Read `.vscode/settings.json`. Verify:
- `chat.skillsLocations` → `.claude/skills` is `true`
- `chat.agentFilesLocations` → `.github/agents` is `true`
- `chat.agent.enabled` is `true`
- `chat.mcp.discovery.enabled` is `true`
- `chat.agent.useAgentsMd` is `true`

### 6. VS Code subagent nesting (CRITICAL for planner/executor handoffs)

Check `chat.subagents.allowInvocationsFromSubagents`:

```bash
# Workspace-level
grep -E '"chat\.subagents\.allowInvocationsFromSubagents"' .vscode/settings.json || echo "not set (workspace)"
```

User-level check is platform-dependent. Show the user the path and ask them to verify, rather than reading their global settings:

- macOS: `~/Library/Application Support/Code/User/settings.json`
- Linux: `~/.config/Code/User/settings.json`
- Windows: `%APPDATA%\Code\User\settings.json`

If workspace setting is missing OR false, **output this guidance** (do not auto-edit user settings):

```
⚠ Subagent nesting is disabled or unset.

This breaks multi-step handoff chains (e.g., planner → grill-me → executor
when invoked as subagents rather than as user handoff button clicks).

To enable at workspace level (recommended — version-controlled with repo):

  1. Open .vscode/settings.json
  2. Add: "chat.subagents.allowInvocationsFromSubagents": true

Or enable at user level (applies to all workspaces):

  1. Cmd/Ctrl+Shift+P → "Preferences: Open User Settings (JSON)"
  2. Add: "chat.subagents.allowInvocationsFromSubagents": true

Or via UI:

  1. Cmd/Ctrl+, → search "subagents"
  2. Tick "Chat › Subagents: Allow Invocations From Subagents"

After changing: reload the window (Cmd/Ctrl+Shift+P → "Developer: Reload Window").
```

Ask: "Apply to workspace settings automatically? (y/N)" — only edit `.vscode/settings.json` on explicit `y`.

### 7. Current-plan pointer
- `test -f docs/plans/_current.md`
- If missing, offer to create it pointing at latest-modified plan or leave it empty.

### 8. MCP server env vars (smoke check)
For each MCP server in `.mcp.json` with `${env:VAR}` references:
- Verify the env var is set in the current shell: `test -n "$VAR"`
- Report missing vars without revealing their values.

## Output

Structured report:

```
## planner-setup report

### OK
- Git hooks installed
- TypeScript runtime available
- Validation passes
- VS Code chat.skillsLocations configured

### Warn
- Workspace setting chat.subagents.allowInvocationsFromSubagents missing (defaults to false)

### Fail
- docs/plans/_current.md missing
- MS_CLIENT_SECRET env var not set (microsoft-graph MCP)

### Suggested fixes
1. Enable subagent nesting: <see above>
2. Create current-plan pointer: /plan-current <slug>
3. Set MS_CLIENT_SECRET in .env.local
```

## Do not

- Silently edit user-level VS Code settings.
- Print env var values.
- Install hooks without user confirmation.
- Exit non-zero — this is diagnostic, not gating.
