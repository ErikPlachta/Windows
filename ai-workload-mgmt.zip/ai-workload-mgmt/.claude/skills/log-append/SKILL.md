---
name: log-append
description: Write a structured session log entry under docs/log/<agent>/<session-id>.md. Use at the end of any non-trivial agent/skill execution to record what was done. All other skills invoke this — do not hand-write log files.
argument-hint: "<agent-name> <session-id>"
allowed-tools: Write, Read
model: haiku
metadata:
  tier: cheap
---

# log-append

Mechanical log writer. Produces a conforming session log from structured input.

## Expected caller contract

The invoking skill/agent should pass a JSON-ish payload in $ARGUMENTS or via conversation context with:

```
agent: <name>
session_id: <s-xxxxxxxx>
started: <ISO timestamp>
ended: <ISO timestamp>
plan_ref: <path or empty>
task_ref: <number or empty>
model: <model ID used>
tier: cheap | mid | premium
summary: <1-2 sentences>
actions: [<list>]
decisions: [<list>]
outcome: <text>
artifacts: [<list>]
```

## Steps

1. Generate session_id if not provided: `s-` + 8 hex chars (e.g. from Date.now() + random).
2. Ensure directory exists: `docs/log/<agent>/`.
3. Render the template at `docs/log/_template.md` with the provided values.
4. Write to `docs/log/<agent>/<session-id>.md`.
5. Return the path and session_id to the caller.

## Validation

- `session_id` matches `s-[0-9a-f]{8}`.
- `started` and `ended` are valid ISO 8601.
- `tier` is one of `cheap|mid|premium`.
- `plan_ref`, if present, exists in `docs/plans/` or `docs/changelog/`.
- If any validation fails, abort with an error listing what's wrong. Do not write a partial log.

## Do not

- Invent content. If a field is missing from caller input, leave it blank (not fabricate).
- Overwrite existing log files. Session IDs should be unique; collision = abort.
- Write anywhere outside `docs/log/`.
