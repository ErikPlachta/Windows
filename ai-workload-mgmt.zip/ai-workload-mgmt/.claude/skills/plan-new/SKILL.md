---
name: plan-new
description: Scaffold a new plan file in docs/plans/ from the template. Use when the user says "new plan", "create a plan", "start planning <X>", or provides a slug to plan against. Creates branch, scaffolds frontmatter, commits the scaffold.
argument-hint: "<slug> [ticket-id]"
allowed-tools: Read, Write, Edit, Bash(git *), Bash(date *)
model: haiku
metadata:
  tier: cheap
---

# plan-new

Scaffold a new plan. Mechanical operation — no deep reasoning needed.

## Inputs

- `$ARGUMENTS` — slug (kebab-case) and optional ticket ID. Example: `fix-auth-bug ADO-4821`

## Steps

1. Validate slug: kebab-case, no spaces, no existing file at `docs/plans/<slug>.md` or `docs/changelog/<slug>.md`. If collision, abort with message.
2. Determine type prefix: ask user if not clear from slug context (feat/fix/chore/refactor/docs/spike).
3. Create branch: `git checkout -b <type>/<slug>`.
4. Copy `docs/plans/_template.md` → `docs/plans/<slug>.md`.
5. Fill frontmatter:
   - `title`: generate from slug (humanize) or ask user
   - `status: draft`
   - `author`: current git user
   - `branch: <type>/<slug>`
   - `ticket`: from $ARGUMENTS if provided
   - `created`: today
   - `modified`: today
   - `tier: mid` (default; user can adjust)
6. Leave body sections empty for user to fill (Goal, Tasks, etc.).
7. Commit: `chore(<slug>): scaffold plan`.
8. Invoke `log-append` skill to write session log at `docs/log/plan-new/<session-id>.md`.

## Output

```
Plan scaffolded: docs/plans/<slug>.md
Branch: <type>/<slug>
Next: fill Goal and Tasks sections, then run /grill-me <slug>
```

## Do not

- Populate Tasks from imagination — that's a planning decision, not a scaffolding decision.
- Set status to active — user does that when ready to work.
- Escalate to a premium model for this — it's template substitution.
