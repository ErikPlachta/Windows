#!/usr/bin/env -S npx tsx
/**
 * pre-commit hook
 *
 * Fast checks on staged files only:
 *  - Staged plan files: full schema + modified==today
 *  - Staged log files: full schema
 *  - Reject edits inside docs/changelog/ (archived plans are immutable)
 *  - Reject log files outside expected locations
 */
import { stagedFiles, stagedFileStatus } from '../lib/git.ts';
import { Reporter } from '../lib/report.ts';
import { validateLog, validatePlan } from '../lib/validators.ts';

const reporter = new Reporter();
const staged = stagedFiles();

for (const file of staged) {
  // Block edits to archived plans — allow only renames (from archival `git mv`).
  if (file.startsWith('docs/changelog/') && file.endsWith('.md')) {
    const status = stagedFileStatus(file);
    if (status !== 'R') {
      reporter.error(file, `docs/changelog/ is immutable — status "${status}" not allowed (only R for archival rename)`);
    }
    continue;
  }

  // Validate staged plan files (skip _template.md, _current.md, anything _*.md)
  if (
    file.startsWith('docs/plans/') &&
    file.endsWith('.md') &&
    !/\/_[^/]*\.md$/.test(file)
  ) {
    validatePlan(file, reporter, { requireModifiedToday: true });
  }

  // Validate staged log files (skip _template.md)
  if (file.startsWith('docs/log/') && file.endsWith('.md') && !/\/_[^/]*\.md$/.test(file)) {
    // Reject logs outside per-agent subfolders
    const parts = file.split('/');
    if (parts.length !== 4) {
      reporter.error(file, 'log files must live at docs/log/<agent>/<session-id>.md');
    } else {
      validateLog(file, reporter);
    }
  }
}

reporter.print('pre-commit: plan & log validation');
reporter.exit();
