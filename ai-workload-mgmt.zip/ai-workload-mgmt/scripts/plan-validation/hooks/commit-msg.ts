#!/usr/bin/env -S npx tsx
/**
 * commit-msg hook
 *
 * Enforces Conventional Commits scoped to the plan slug.
 * Format: <type>(<slug>): <summary, <=72 chars>
 *
 * Skipped for merge/revert/fixup commits.
 */
import { readFileSync } from 'node:fs';
import { currentBranch } from '../lib/git.ts';

const msgFile = process.argv[2];
if (!msgFile) {
  console.error('commit-msg: no message file argument');
  process.exit(1);
}

const raw = readFileSync(msgFile, 'utf8');
const firstLine = raw.split('\n')[0]?.trim() ?? '';

// Auto-skip merges, reverts, fixups, autosquash
if (/^(Merge|Revert|fixup!|squash!)/i.test(firstLine)) {
  process.exit(0);
}

const CONVENTIONAL = /^(feat|fix|chore|refactor|docs|spike|test|perf|ci|build)(\(([a-z0-9][a-z0-9-]*)\))?!?: (.+)$/;
const match = firstLine.match(CONVENTIONAL);

if (!match) {
  console.error(`\x1b[31m✗ commit-msg\x1b[0m`);
  console.error(`  Message does not match Conventional Commits format:`);
  console.error(`    <type>(<slug>): <summary>`);
  console.error(`  Got: "${firstLine}"`);
  console.error(`  Types: feat, fix, chore, refactor, docs, spike, test, perf, ci, build`);
  process.exit(1);
}

const [, , , scope, summary] = match;

if (summary!.length > 72) {
  console.error(`\x1b[31m✗ commit-msg\x1b[0m subject > 72 chars (${summary!.length})`);
  process.exit(1);
}

// If on a plan branch, scope should match the slug
const branch = currentBranch();
const branchMatch = branch.match(/^(feat|fix|chore|refactor|docs|spike)\/([a-z0-9][a-z0-9-]*)$/);

if (branchMatch) {
  const slug = branchMatch[2]!;
  if (scope && scope !== slug) {
    console.error(`\x1b[31m✗ commit-msg\x1b[0m`);
    console.error(`  Scope "${scope}" does not match plan slug "${slug}" (from branch "${branch}")`);
    process.exit(1);
  }
  if (!scope) {
    console.error(`\x1b[33m⚠ commit-msg\x1b[0m`);
    console.error(`  No scope provided. On a plan branch ("${branch}") the scope should be "${slug}".`);
    // warn only, don't fail
  }
}

process.exit(0);
