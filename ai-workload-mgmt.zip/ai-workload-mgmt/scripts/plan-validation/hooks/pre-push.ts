#!/usr/bin/env -S npx tsx
/**
 * pre-push hook
 *
 * Full-repo validation before pushing to shared remote:
 *  - Every plan file valid
 *  - Every log file valid
 *  - If any plan has status: done, its archival commit is present on the branch
 *  - Active plan's `branch:` matches current branch
 *
 * Slower than pre-commit; runs only on push.
 */
import { trackedFiles, currentBranch, refExists, commitsSince, mergeBase } from '../lib/git.ts';
import { readMarkdown } from '../lib/frontmatter.ts';
import { PlanFrontmatterSchema } from '../lib/schema.ts';
import { Reporter } from '../lib/report.ts';
import { validateLog, validatePlan } from '../lib/validators.ts';

const reporter = new Reporter();

// Validate every plan file
for (const file of trackedFiles('docs/plans/*.md')) {
  if (file.endsWith('/_template.md')) continue;
  validatePlan(file, reporter);
}
for (const file of trackedFiles('docs/changelog/*.md')) {
  if (file.endsWith('/_template.md')) continue;
  validatePlan(file, reporter);
}

// Validate every log file
for (const file of trackedFiles('docs/log/**/*.md')) {
  if (file.endsWith('/_template.md')) continue;
  validateLog(file, reporter);
}

// Archival commit check: if any active plan flipped to status: done on this branch,
// require a corresponding archival commit.
const branch = currentBranch();
const branchMatch = branch.match(/^(feat|fix|chore|refactor|docs|spike)\/([a-z0-9][a-z0-9-]*)$/);

if (branchMatch) {
  const slug = branchMatch[2]!;

  // Is this slug's plan in docs/changelog/ on HEAD?
  const archivedPath = `docs/changelog/${slug}.md`;
  const archivedExists = trackedFiles(archivedPath).length > 0;

  if (archivedExists) {
    const base = mergeBase();
    const commits = commitsSince(base);
    const hasArchivalCommit = commits.some((c) =>
      c.subject.includes(`archive plan to changelog`) && c.subject.includes(slug),
    );
    if (!hasArchivalCommit) {
      reporter.error(
        archivedPath,
        `plan archived to changelog/ but no "chore(${slug}): archive plan to changelog" commit on branch — run the archival protocol`,
      );
    }
  }

  // Active plan on this branch: branch name matches its frontmatter
  const activePath = `docs/plans/${slug}.md`;
  if (trackedFiles(activePath).length > 0) {
    try {
      const plan = readMarkdown(activePath);
      const result = PlanFrontmatterSchema.safeParse(plan.data);
      if (result.success && result.data.branch !== branch) {
        reporter.error(
          activePath,
          `frontmatter branch "${result.data.branch}" does not match current branch "${branch}"`,
        );
      }
    } catch {
      // validatePlan already reported
    }
  }
}

// If origin/main doesn't exist yet, we can't do the "diverged from main" check.
// Not fatal — just skip.
if (!refExists('origin/main') && !refExists('main')) {
  reporter.warn('(repo)', 'no main branch reference found; skipping divergence checks');
}

reporter.print('pre-push: full validation');
reporter.exit();
