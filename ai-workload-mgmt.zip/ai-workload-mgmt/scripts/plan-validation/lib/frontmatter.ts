/**
 * Frontmatter parse/serialize helpers wrapping gray-matter.
 * Keeps gray-matter's API contained so swapping parsers later is a one-file change.
 */
import matter from 'gray-matter';
import { readFileSync, writeFileSync } from 'node:fs';

export interface ParsedFile<T = Record<string, unknown>> {
  path: string;
  data: T;
  body: string;
  raw: string;
}

export function readMarkdown<T = Record<string, unknown>>(path: string): ParsedFile<T> {
  const raw = readFileSync(path, 'utf8');
  const parsed = matter(raw);
  return {
    path,
    data: parsed.data as T,
    body: parsed.content,
    raw,
  };
}

export function writeMarkdown(path: string, data: Record<string, unknown>, body: string): void {
  const serialised = matter.stringify(body, data);
  writeFileSync(path, serialised, 'utf8');
}

export function parseString<T = Record<string, unknown>>(raw: string): Omit<ParsedFile<T>, 'path'> {
  const parsed = matter(raw);
  return { data: parsed.data as T, body: parsed.content, raw };
}
