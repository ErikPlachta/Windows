/**
 * Schemas for plan files and session log files.
 * Single source of truth — hooks, CI, and the log-append skill all validate against these.
 */
import { z } from 'zod';

const ISO_DATE = /^\d{4}-\d{2}-\d{2}$/;
const ISO_DATETIME = /^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}Z$/;
const BRANCH_NAME = /^(feat|fix|chore|refactor|docs|spike)\/[a-z0-9][a-z0-9-]*$/;
const SESSION_ID = /^s-[0-9a-f]{8}$/;

export const PlanStatus = z.enum(['draft', 'active', 'blocked', 'done']);
export const Tier = z.enum(['cheap', 'mid', 'premium']);

export const PlanFrontmatterSchema = z
  .object({
    title: z.string().min(1, 'title is required'),
    status: PlanStatus,
    author: z.string().min(1),
    branch: z.string().regex(BRANCH_NAME, 'branch must match <type>/<slug>'),
    ticket: z.string().optional().nullable(),
    created: z.string().regex(ISO_DATE, 'created must be YYYY-MM-DD'),
    modified: z.string().regex(ISO_DATE, 'modified must be YYYY-MM-DD'),
    completed: z.string().regex(ISO_DATE).optional().nullable(),
    tier: Tier,
  })
  .superRefine((data, ctx) => {
    if (data.status === 'done' && !data.completed) {
      ctx.addIssue({
        code: z.ZodIssueCode.custom,
        path: ['completed'],
        message: 'completed is required when status: done',
      });
    }
    if (data.status !== 'done' && data.completed) {
      ctx.addIssue({
        code: z.ZodIssueCode.custom,
        path: ['completed'],
        message: 'completed must be blank unless status: done',
      });
    }
  });

export type PlanFrontmatter = z.infer<typeof PlanFrontmatterSchema>;

export const LogFrontmatterSchema = z.object({
  session_id: z.string().regex(SESSION_ID, 'session_id must match s-xxxxxxxx (8 hex)'),
  agent: z.string().min(1),
  started: z.string().regex(ISO_DATETIME, 'started must be ISO 8601 with Z suffix'),
  ended: z.string().regex(ISO_DATETIME, 'ended must be ISO 8601 with Z suffix'),
  plan_ref: z.string().optional().nullable(),
  task_ref: z.union([z.number(), z.string()]).optional().nullable(),
  model: z.string().min(1),
  tier: Tier,
});

export type LogFrontmatter = z.infer<typeof LogFrontmatterSchema>;

export const REQUIRED_PLAN_SECTIONS = ['## Goal', '## Context', '## Tasks', '## Decisions', '## Open Questions', '## Outcome'] as const;
export const REQUIRED_LOG_SECTIONS = ['## Summary', '## Actions', '## Outcome'] as const;

export const OUTCOME_PLACEHOLDER = /<!-- Filled on archival/;
export const TASK_LINE = /^- \[([ xX])\] (\d+)\. (.+)$/;
