/**
 * Shared validation logic. Used by both hook scripts and CI binaries.
 */
import { basename, dirname } from 'node:path';
import { readMarkdown } from './frontmatter.ts';
import { Reporter } from './report.ts';
import {
  LogFrontmatterSchema,
  OUTCOME_PLACEHOLDER,
  PlanFrontmatterSchema,
  REQUIRED_LOG_SECTIONS,
  REQUIRED_PLAN_SECTIONS,
  TASK_LINE,
} from './schema.ts';
import { today } from './today.ts';

/** Validate a plan file. Add findings to reporter. */
export function validatePlan(
  file: string,
  reporter: Reporter,
  opts: { requireModifiedToday?: boolean } = {},
): void {
  let parsed;
  try {
    parsed = readMarkdown(file);
  } catch (err) {
    reporter.error(file, `cannot read file: ${(err as Error).message}`);
    return;
  }

  const result = PlanFrontmatterSchema.safeParse(parsed.data);
  if (!result.success) {
    for (const issue of result.error.issues) {
      reporter.error(file, issue.message, issue.path.join('.'));
    }
    return;
  }

  const fm = result.data;

  // modified: today check (pre-commit only)
  if (opts.requireModifiedToday && fm.modified !== today()) {
    reporter.error(
      file,
      `modified (${fm.modified}) must be today (${today()}) when plan file is staged`,
      'modified',
    );
  }

  // H1 matches title
  const h1 = parsed.body.match(/^#\s+(.+)$/m)?.[1]?.trim();
  if (!h1) {
    reporter.error(file, 'missing H1 heading in body');
  } else if (h1 !== fm.title) {
    reporter.error(file, `H1 "${h1}" does not match frontmatter title "${fm.title}"`);
  }

  // Required sections
  for (const section of REQUIRED_PLAN_SECTIONS) {
    if (!parsed.body.includes(section)) {
      reporter.error(file, `missing required section: ${section}`);
    }
  }

  // Tasks must exist and match format
  const tasksSection = extractSection(parsed.body, '## Tasks');
  if (!tasksSection || tasksSection.trim().length === 0) {
    reporter.error(file, '## Tasks section is empty');
  } else {
    const lines = tasksSection.split('\n').filter((l) => l.trim().startsWith('- ['));
    for (const line of lines) {
      if (!TASK_LINE.test(line)) {
        reporter.error(file, `malformed task line: "${line.trim()}"`, 'tasks');
      }
    }
    if (lines.length === 0) {
      reporter.error(file, '## Tasks section contains no tasks');
    }
  }

  // status: done requires Outcome filled
  if (fm.status === 'done') {
    const outcomeSection = extractSection(parsed.body, '## Outcome');
    if (!outcomeSection || outcomeSection.trim().length === 0) {
      reporter.error(file, 'status: done requires non-empty ## Outcome');
    } else if (OUTCOME_PLACEHOLDER.test(outcomeSection)) {
      reporter.error(file, '## Outcome still contains template placeholder — fill it before archival');
    }

    // All tasks checked
    const tasksSectionForDone = extractSection(parsed.body, '## Tasks') ?? '';
    const unchecked = tasksSectionForDone
      .split('\n')
      .filter((l) => l.match(/^- \[ \] /));
    if (unchecked.length > 0) {
      reporter.error(file, `status: done but ${unchecked.length} task(s) unchecked`);
    }
  }

  // Archived plans must live in docs/changelog/
  const dir = dirname(file);
  if (fm.status === 'done' && !dir.includes('docs/changelog')) {
    reporter.warn(file, 'status: done should live in docs/changelog/ — run plan-archive');
  }
  if (fm.status !== 'done' && dir.includes('docs/changelog')) {
    reporter.error(file, `file in docs/changelog/ but status is ${fm.status} — changelog is immutable`);
  }
}

export function validateLog(file: string, reporter: Reporter): void {
  let parsed;
  try {
    parsed = readMarkdown(file);
  } catch (err) {
    reporter.error(file, `cannot read file: ${(err as Error).message}`);
    return;
  }

  const result = LogFrontmatterSchema.safeParse(parsed.data);
  if (!result.success) {
    for (const issue of result.error.issues) {
      reporter.error(file, issue.message, issue.path.join('.'));
    }
    return;
  }

  const fm = result.data;

  // Filename matches session_id
  const name = basename(file, '.md');
  const sessionIdInName = name.replace(/^\d{4}-\d{2}-\d{2}_/, '');
  if (sessionIdInName !== fm.session_id) {
    reporter.error(file, `filename "${name}" does not contain session_id "${fm.session_id}"`);
  }

  // Agent folder matches frontmatter agent
  const agentFolder = basename(dirname(file));
  if (agentFolder !== fm.agent) {
    reporter.error(
      file,
      `folder "${agentFolder}" does not match frontmatter agent "${fm.agent}"`,
      'agent',
    );
  }

  // Required sections
  for (const section of REQUIRED_LOG_SECTIONS) {
    if (!parsed.body.includes(section)) {
      reporter.error(file, `missing required section: ${section}`);
    }
  }

  // ended >= started
  if (new Date(fm.ended) < new Date(fm.started)) {
    reporter.error(file, `ended (${fm.ended}) is before started (${fm.started})`);
  }

  // plan_ref, if present, must resolve to an existing plan or archived plan
  if (fm.plan_ref) {
    // Just check syntax — existence check is expensive and a warn-level concern
    if (!fm.plan_ref.startsWith('docs/plans/') && !fm.plan_ref.startsWith('docs/changelog/')) {
      reporter.error(file, `plan_ref must start with docs/plans/ or docs/changelog/`, 'plan_ref');
    }
  }
}

function extractSection(body: string, heading: string): string | null {
  const lines = body.split('\n');
  const start = lines.findIndex((l) => l.trim() === heading);
  if (start === -1) return null;
  const rest = lines.slice(start + 1);
  const end = rest.findIndex((l) => /^##\s/.test(l));
  const slice = end === -1 ? rest : rest.slice(0, end);
  return slice.join('\n');
}
