/**
 * Minimal git helpers. Shells out to git — no library dependency.
 */
import { execSync } from 'node:child_process';

function git(args: string): string {
  return execSync(`git ${args}`, { encoding: 'utf8' }).trim();
}

/** Files staged for commit (added, modified, renamed — excludes deleted). */
export function stagedFiles(): string[] {
  const out = git('diff --cached --name-only --diff-filter=ACMR');
  return out ? out.split('\n') : [];
}

/** Status letter for a staged file: A added, M modified, R renamed, C copied, D deleted. */
export function stagedFileStatus(file: string): string {
  const out = git(`diff --cached --name-status -- "${file}"`);
  return out.trim().charAt(0);
}

/** Files in the working tree (including untracked, excluding gitignored). */
export function trackedFiles(glob: string): string[] {
  const out = git(`ls-files -- ${glob}`);
  return out ? out.split('\n') : [];
}

export function currentBranch(): string {
  return git('rev-parse --abbrev-ref HEAD');
}

/** Commit messages on HEAD not reachable from the given base. */
export function commitsSince(base: string): { hash: string; subject: string }[] {
  try {
    const out = git(`log ${base}..HEAD --format=%H%x1f%s`);
    if (!out) return [];
    return out.split('\n').map((line) => {
      const [hash = '', subject = ''] = line.split('\x1f');
      return { hash, subject };
    });
  } catch {
    return [];
  }
}

/** Does the branch exist? Useful to probe origin/main availability. */
export function refExists(ref: string): boolean {
  try {
    git(`rev-parse --verify ${ref}`);
    return true;
  } catch {
    return false;
  }
}

/** Get content of a file at a git ref — empty string if not present. */
export function fileAtRef(ref: string, path: string): string {
  try {
    return execSync(`git show ${ref}:${path}`, { encoding: 'utf8' });
  } catch {
    return '';
  }
}

/** Determine the merge base for pre-push comparison. Prefers origin/main, falls back to main. */
export function mergeBase(): string {
  if (refExists('origin/main')) return 'origin/main';
  if (refExists('main')) return 'main';
  return 'HEAD~1';
}
