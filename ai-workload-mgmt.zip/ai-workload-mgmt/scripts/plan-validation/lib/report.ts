/**
 * Terminal-friendly validation reporting. ANSI colours, no deps.
 */
const RED = '\x1b[31m';
const YELLOW = '\x1b[33m';
const GREEN = '\x1b[32m';
const DIM = '\x1b[2m';
const BOLD = '\x1b[1m';
const RESET = '\x1b[0m';

const supportsColor = process.stdout.isTTY && !process.env['NO_COLOR'];

function paint(code: string, text: string): string {
  return supportsColor ? `${code}${text}${RESET}` : text;
}

export interface Finding {
  file: string;
  severity: 'error' | 'warn';
  field?: string;
  message: string;
}

export class Reporter {
  readonly findings: Finding[] = [];

  error(file: string, message: string, field?: string): void {
    this.findings.push({ file, severity: 'error', field, message });
  }

  warn(file: string, message: string, field?: string): void {
    this.findings.push({ file, severity: 'warn', field, message });
  }

  get errorCount(): number {
    return this.findings.filter((f) => f.severity === 'error').length;
  }

  get warnCount(): number {
    return this.findings.filter((f) => f.severity === 'warn').length;
  }

  print(label: string): void {
    if (this.findings.length === 0) {
      console.log(paint(GREEN, `✓ ${label}: no issues`));
      return;
    }

    const byFile = new Map<string, Finding[]>();
    for (const f of this.findings) {
      const list = byFile.get(f.file) ?? [];
      list.push(f);
      byFile.set(f.file, list);
    }

    console.log(paint(BOLD, `\n${label}\n`));
    for (const [file, items] of byFile) {
      console.log(paint(DIM, file));
      for (const item of items) {
        const colour = item.severity === 'error' ? RED : YELLOW;
        const tag = paint(colour, item.severity.toUpperCase());
        const field = item.field ? paint(DIM, ` [${item.field}]`) : '';
        console.log(`  ${tag}${field} ${item.message}`);
      }
    }
    console.log(
      `\n${paint(BOLD, 'Summary:')} ${paint(RED, `${this.errorCount} error(s)`)}, ${paint(
        YELLOW,
        `${this.warnCount} warning(s)`,
      )}\n`,
    );
  }

  /** Exit 1 if any errors, 0 otherwise. Warnings never fail. */
  exit(): never {
    process.exit(this.errorCount > 0 ? 1 : 0);
  }
}
