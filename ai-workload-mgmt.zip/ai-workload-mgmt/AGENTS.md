# AGENTS.md

Cross-tool project context for AI coding agents.

## Project

Plan-driven AI workload management reference. Demonstrates how to coordinate planning, task execution, logging, and external integrations (SharePoint, Azure DevOps) across Claude Code and VS Code Copilot using shared skills and tier-optimized models.

## Workflow: plan-driven, always

All non-trivial work starts with a plan file in `docs/plans/`. No plan → no code changes beyond single-file edits.

- **Plan file** is the single source of truth for todos. Its `## Tasks` checklist is what the chat UI mirrors.
- **One plan = one branch** named `<type>/<plan-slug>` (type ∈ feat, fix, chore, refactor, docs, spike).
- **One task = one commit minimum**, scoped to the plan slug.
- **Archive** to `docs/changelog/` when all tasks checked and `status: done`.

See `docs/README.md` for the full plan schema and archival protocol.

## Logging

Every agent and skill that performs work appends to `docs/log/<agent-or-skill-name>/<session-id>.md`. Use the `log-append` skill — do not hand-write log files.

## Model tier policy

Use the cheapest model that gets the job done correctly. Specifically:

- **Mechanical/repeat work** (scaffolding, templating, archival, branch ops, status checks, logging, MCP tool calls): cheap tier (GPT-4o, GPT-4.1, Haiku).
- **Task execution / code changes**: mid tier (Sonnet, GPT-5.2).
- **Deep reasoning** (grill-me, planning from scratch, complex bug analysis): premium tier (Opus, GPT-5).

If you're unsure whether a task needs more power, start cheap and escalate explicitly.

## External integrations

- **OneDrive/SharePoint**: use the `onedrive-fetch` skill (wraps the Microsoft Graph MCP).
- **Azure DevOps tickets**: use the `ado-ticket` skill (wraps the ADO MCP).
- **GitHub**: use the GitHub MCP directly, or via the `executor` agent for branch/PR work.

Never hand-roll these integrations inline. If the capability is missing, file a plan for adding it.

## Conventions

- Conventional Commits scoped to plan slug: `<type>(<slug>): <summary>`
- Dates in ISO: `YYYY-MM-DD`
- Session IDs: `s-<8-char-hex>` (e.g. `s-a1b2c3d4`)
- Kebab-case for plan slugs, skill names, agent names
- Plans stay under ~100 lines; decompose into sub-plans with a parent index if longer

## Pre-submit checks

Before declaring a task done:

- Plan file checkbox updated
- `modified:` in frontmatter bumped to today
- Session log entry written
- Tests/lint/typecheck pass for the affected area
- Commit follows the format above

## Validation & hooks

Mechanical enforcement — do not rely on agent cooperation:

- **`.claude/hooks/bump-modified.ts`** — Claude Code `PostToolUse` hook. Auto-bumps `modified:` after any Edit/Write to `docs/plans/**`.
- **`.git/hooks/pre-commit`** — runs `scripts/plan-validation/hooks/pre-commit.ts`. Validates staged plan/log files, blocks edits to `docs/changelog/` (except archival renames), enforces `modified == today`.
- **`.git/hooks/commit-msg`** — enforces Conventional Commits with scope matching the plan slug on a plan branch.
- **`.git/hooks/pre-push`** — full-repo validation + archival-commit presence check.
- **CI (`.github/workflows/plan-validation.yml`)** — same validators run on every PR and push to main.

Install hooks: `pnpm hooks:install`. Bypass only in emergencies: `git commit --no-verify` / `git push --no-verify`.

Shared validation library at `scripts/plan-validation/lib/` — schemas (zod), frontmatter parsing, git helpers. Both hooks and CI binaries use the same library, so rules are defined in exactly one place.
