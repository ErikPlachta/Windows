---
name: 'Session Log Standards'
description: 'Schema rules for session log files under docs/log/'
applyTo: 'docs/log/**/*.md'
---

# Session log rules

## Filename

`docs/log/<agent-name>/<session-id>.md` or `docs/log/<agent-name>/<YYYY-MM-DD>_<session-id>.md`

- Session ID: `s-` + 8 hex chars (e.g. `s-a1b2c3d4`).
- Agent folder: matches the `name:` field of the skill/agent that wrote it.

## Frontmatter required

- `session_id` — matches `^s-[0-9a-f]{8}$`
- `agent` — matches folder name
- `started` — ISO 8601 with `Z` suffix
- `ended` — ISO 8601 with `Z` suffix
- `model` — e.g. `gpt-4o`, `claude-haiku-4-5`, `claude-opus-4-7`
- `tier` — `cheap` | `mid` | `premium`

Optional: `plan_ref`, `task_ref`.

## Body required sections

- `## Summary` — 1-2 sentences
- `## Actions` — bulleted, ordered
- `## Outcome` — result / next step / blocked-on

Optional: `## Decisions`, `## Artifacts`.

## Immutability

Log files are append-only in spirit. Do not edit existing log entries. If a correction is needed, write a new log referencing the original session_id.

## Automation

Use the `log-append` skill for all writes. Do not hand-write log content. If the skill's validation fails, fix the input rather than bypassing it.

## Forbidden

- Writing anywhere outside `docs/log/`.
- Fabricating actions, decisions, or artifacts not actually performed.
- Using arbitrary session-id formats.
- Mismatched `agent:` frontmatter vs folder.
