---
name: 'Plan File Standards'
description: 'Schema and hygiene rules for files in docs/plans/ and docs/changelog/'
applyTo: 'docs/{plans,changelog}/**/*.md'
---

# Plan file rules

> `_template.md` and `_current.md` are exempt from the schema — they use different frontmatter shapes. Hooks and CI skip files starting with `_`.

## Frontmatter required fields

- `title` (mirrors the H1)
- `status` — one of: `draft`, `active`, `blocked`, `done`
- `author`
- `branch` — `<type>/<slug>` where type ∈ feat, fix, chore, refactor, docs, spike
- `created` — ISO date, set once, never changes
- `modified` — ISO date, **must bump on every edit**
- `tier` — cheap | mid | premium

Optional: `ticket`, `completed` (required only when `status: done`).

## Body required sections

- `# <Title>` (H1 matches frontmatter `title`)
- `## Goal` — one sentence
- `## Context` — background, links, log references
- `## Tasks` — numbered checklist, each task atomic
- `## Decisions` — dated entries
- `## Open Questions`
- `## Outcome` — filled only on archival

## Task format

```
- [ ] <N>. <atomic todo>
```

- Numbered starting at 1.
- Exactly one task per line.
- Atomic: completable in one sitting, testable independently.

## Hygiene rules (Copilot should enforce on edit)

- If editing a plan file, bump `modified:` to today's date in the same edit.
- If adding a decision, format: `- <YYYY-MM-DD>: <decision + rationale>`.
- Never inline >20 lines of research — link to `docs/log/grill-me/<session-id>.md` or similar.
- Plans should stay under ~100 lines. If longer, propose decomposition.
- Never edit files in `docs/changelog/` — archived plans are immutable.

## Forbidden

- Removing or renumbering completed tasks.
- Changing `created` or `branch` after initial scaffold.
- Marking `status: done` without all tasks checked AND `## Outcome` filled.
