# Copilot Instructions

Workspace-wide instructions auto-applied to all Copilot chat requests. Complements `AGENTS.md` and `CLAUDE.md`.

## Plan-driven workflow — always

No multi-step work without a plan. If the user asks for non-trivial work and no plan exists in `docs/plans/`, run the `new-plan` prompt first, or propose one and wait for confirmation.

- Plan's `## Tasks` checklist IS the todo system. Mirror it via the `sync-todos` prompt/skill.
- One plan = one branch = one concern.
- One task = one commit minimum.

## Model tier policy

Pick the cheapest model that gets the job done:

- **Cheap (GPT-4o, GPT-4.1, GPT-4o-mini)** — scaffolding, archival, logging, status checks, templating, MCP orchestration, branch ops.
- **Mid (Sonnet, GPT-5.2)** — task execution, code edits, reviews.
- **Premium (Opus, GPT-5)** — `grill-me`, deep planning, gnarly debugging only.

Every prompt file and agent in `.github/` declares its tier in frontmatter. Don't escalate without reason.

## Logging

Every meaningful action appends a session log via the `log-append` skill at `docs/log/<agent-or-skill>/<session-id>.md`. Never hand-write logs.

## Skills are shared

All skills live in `.claude/skills/`. This workspace's `.vscode/settings.json` configures Copilot to discover them there. Don't duplicate skill definitions under `.github/skills/`.

## External integrations

- OneDrive/SharePoint → `onedrive-fetch` skill.
- Azure DevOps → `ado-ticket` skill.
- GitHub → `github/*` MCP tools or the `executor` agent.

Never hand-roll these inline.

## Code conventions

- TypeScript strict, no `any`, `interface` for object shapes.
- Python PEP 8 via ruff, type hints required.
- Conventional Commits scoped to plan slug.
- British English in user-facing copy.

## Pre-submit

Before declaring a task done: checkbox ticked, `modified:` bumped, session log written, lint+typecheck+tests green for the affected area.
