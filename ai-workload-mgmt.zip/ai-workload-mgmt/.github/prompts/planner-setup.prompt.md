---
name: planner-setup
description: Verify environment is configured for plan-driven workflow (hooks, settings, subagent nesting, MCP env)
agent: agent
model: 'GPT-4o-mini'
tools: ['runCommands', 'editFiles']
---

# Planner Setup

Invoke the `planner-setup` skill.

Runs a non-destructive diagnostic across:
- Git hooks installation
- TypeScript runtime
- Validation (`pnpm validate:all`)
- `.claude/settings.json` + `.mcp.json`
- `.vscode/settings.json`
- **`chat.subagents.allowInvocationsFromSubagents`** — critical for handoff chains
- `docs/plans/_current.md` pointer
- MCP env vars

Reports OK/Warn/Fail with suggested fixes. Prompts before mutating settings.
