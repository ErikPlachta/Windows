---
name: sync-todos
description: Mirror a plan's ## Tasks into the Copilot chat todo UI
argument-hint: '<slug>'
agent: agent
model: 'GPT-4o-mini'
tools: ['editFiles']
---

# Sync Todos

Invoke the `plan-sync-todos` skill with slug: `${input:slug}`.

Skill reads `docs/plans/<slug>.md`, parses `## Tasks`, and mirrors each item into the chat UI's todo system.

Plan file is source of truth. If UI todos diverge, re-run to reset.

Return: `Synced N todos from <slug> (M completed, K pending)`.
