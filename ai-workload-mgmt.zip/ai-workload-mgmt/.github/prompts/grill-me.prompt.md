---
name: grill-me
description: Pressure-test a plan, bug, or design via the grill-me skill (premium model)
argument-hint: '[slug | topic]'
agent: agent
model: 'Claude Opus 4.7'
tools: ['search/codebase', 'search/usages', 'web/fetch', 'think']
---

# Grill Me

Invoke the `grill-me` skill with: `${input:target}`.

This is the one place premium reasoning is worth the tokens. Do not escalate for routine planning — only when:
- Plan feels shaky or underspecified
- Non-obvious bug needs hypothesis testing
- Architectural decision with irreversibility
- User explicitly asks to be grilled

Skill surfaces concerns by severity (blocker / major / minor). It does NOT rewrite the plan. At the end, logs the full session to `docs/log/grill-me/<session-id>.md`.

Stop conditions: all concerns addressed or deferred, user says proceed, three rounds with no new concerns.
