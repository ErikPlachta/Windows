---
name: status
description: Read-only status report across active plans
argument-hint: '[slug]'
agent: ask
model: 'GPT-4o-mini'
tools: ['runCommands']
---

# Status

Invoke the `plan-status` skill with: `${input:slug}` (empty for all-plans view).

All-plans view: compact table of active plans with task progress, branch, modified date, ticket.

Single-plan view: frontmatter, goal, task breakdown, open questions, linked session logs.

Read-only. No edits, no log entries written.
