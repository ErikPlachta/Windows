---
name: plan-current
description: Get, set, or clear the current plan pointer at docs/plans/_current.md
argument-hint: '[get | set <slug> | clear]'
agent: agent
model: 'GPT-4o-mini'
tools: ['editFiles']
---

# Plan Current

Invoke the `plan-current` skill with: `${input:op}`.

- No args / `get` → print current plan + status
- `set <slug>` → point at `docs/plans/<slug>.md` (must exist, not archived)
- `clear` → empty the pointer

Pointer file is session state. Do not commit unless your team shares it.
