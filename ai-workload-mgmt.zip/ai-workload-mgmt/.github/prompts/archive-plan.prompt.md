---
name: archive-plan
description: Archive a completed plan to docs/changelog/
argument-hint: '<slug>'
agent: agent
model: 'GPT-4o'
tools: ['editFiles', 'runCommands']
---

# Archive Plan

Invoke the `plan-archive` skill with slug: `${input:slug}`.

Preconditions the skill will verify:
- All tasks checked
- `## Outcome` filled
- Working tree clean except for the plan file
- On the plan's own branch

Skill will: update frontmatter (`status: done`, `completed:`, bump `modified:`), `git mv` to `docs/changelog/`, update stale links, commit, log.

Do not open the PR automatically. Prompt the user with the next step after archival.
