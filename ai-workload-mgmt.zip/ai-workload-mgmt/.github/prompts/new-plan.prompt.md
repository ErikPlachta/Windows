---
name: new-plan
description: Scaffold a new plan in docs/plans/ and create its branch
argument-hint: '<slug> [ticket-id]'
agent: agent
model: 'GPT-4o'
tools: ['editFiles', 'runCommands']
---

# New Plan

Invoke the `plan-new` skill with the arguments: `${input:args}`.

The skill will:
1. Create branch `<type>/<slug>`.
2. Scaffold `docs/plans/<slug>.md` from `_template.md`.
3. Populate frontmatter (title from slug, author from git, ticket from args).
4. Commit the scaffold.
5. Log the session to `docs/log/plan-new/`.

If the slug collides with an existing plan (active or archived), abort and report.

After scaffolding, tell the user:
> Plan created. Fill `## Goal` and `## Tasks`, then run `/grill-me <slug>` before starting work.

Do not fill in tasks from imagination. That's planning, not scaffolding.
